"""Persistente eToro-Wiederherstellung nach einem moeglicherweise angenommenen Kauf.

Der Datensatz ist die lokale Beweiskette zwischen Kaufentscheidung, POST,
Order, Fill und Position. Er ist absichtlich unabhaengig vom Scanner: ein
Neustart darf weder einen zweiten POST erlauben noch Identitaeten verlieren.
"""
from __future__ import annotations

import json
import logging
import os
import time
from datetime import datetime, timezone
from pathlib import Path

import config
from broker.base import BrokerFehler, Fill, VerbindungVerloren, OrderErgebnis
from decision_analytics import mark_execution, record_execution_event, record_order_state
from safe_persistence import atomic_write_json

NON_TERMINAL = {
    "SUBMITTING", "RECONCILING", "UNKNOWN_AFTER_SUBMIT",
    "AWAITING_POSITION_CONFIRMATION", "PARTIALLY_FILLED",
}
TERMINAL = {
    "FILLED", "REJECTED", "CANCELLED", "EXPIRED",
    "REJECTED_PARTIALLY_FILLED", "UNPROVABLE",
    "CLOSED_BEFORE_IMPORT",
    "FAILED_BEFORE_SUBMIT", "FAILED",
}
logger = logging.getLogger(__name__)


def _root() -> Path:
    return Path(os.getenv("TRADINGBOT_TEST_STATE_DIR", "").strip() or Path(__file__).resolve().parent)


def path() -> Path:
    return _root() / getattr(config, "ETORO_RECONCILIATION_FILE", "etoro_reconciliation.json")


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _load() -> dict:
    try:
        data = json.loads(path().read_text(encoding="utf-8")) if path().exists() else {}
        return data if isinstance(data, dict) else {}
    except Exception:
        # Fail closed: corrupt evidence must not become an empty, tradeable domain.
        return {"schema": 1, "records": {}, "storage_error": "unreadable"}


def _save(data: dict) -> None:
    data["schema"] = 2
    data["updated_at_utc"] = _now()
    atomic_write_json(path(), data)


def domain_key(*, paper: bool, profile: str) -> str:
    # An unresolved broker order belongs to the account, not to the selected
    # risk profile. Otherwise a profile switch could bypass the buy lock.
    return f"etoro:{'demo' if paper else 'live'}"


def active_for_domain(domain: str, *, exclude_decision_id: int | None = None) -> list[dict]:
    data = _load()
    if data.get("storage_error"):
        return [{"state": "RECONCILING", "reason": "reconciliation storage unreadable"}]
    out = []
    for record in (data.get("records") or {}).values():
        if str(record.get("domain")) != str(domain):
            continue
        if exclude_decision_id is not None and int(record.get("decision_id") or 0) == int(exclude_decision_id):
            continue
        if str(record.get("state") or "").upper() in NON_TERMINAL:
            out.append(dict(record))
    return out


def assert_domain_available(*, paper: bool, profile: str, decision_id: int | None = None) -> None:
    domain = domain_key(paper=paper, profile=profile)
    if active_for_domain(domain, exclude_decision_id=decision_id):
        raise BrokerFehler(f"Neue Kaeufe gesperrt: ungeklärte eToro-Ausführung in {domain}")


def start_intent(*, decision_id: int, symbol: str, paper: bool, profile: str,
                 quantity: float, price: float, stop: float, take_profit: float) -> dict:
    data = _load()
    if data.get("storage_error"):
        raise BrokerFehler("eToro-Reconciliation-Datei ist nicht lesbar; Kauf fail-closed")
    key = str(int(decision_id))
    existing = (data.get("records") or {}).get(key)
    if existing and str(existing.get("state") or "").upper() in NON_TERMINAL | TERMINAL:
        raise BrokerFehler("Diese decision_id besitzt bereits einen Submit-Datensatz; kein Doppel-POST")
    record = {
        "decision_id": int(decision_id), "symbol": str(symbol).upper(), "broker": "etoro",
        "paper": bool(paper), "profile": str(profile or ""),
        "domain": domain_key(paper=paper, profile=profile), "quantity": float(quantity),
        "price": float(price), "stop": float(stop), "take_profit": float(take_profit),
        "state": "SUBMITTING", "created_at_utc": _now(), "updated_at_utc": _now(),
        "order_ids": [], "reference_id": "", "position_ids": [], "fills": [],
        "filled_quantity": 0.0, "remaining_quantity": float(quantity),
    }
    data.setdefault("records", {})[key] = record
    _save(data)
    record_execution_event(decision_id, "SUBMITTING", record,
                           event_id=f"etoro:{decision_id}:submitting")
    return record


def accepted(decision_id: int, *, order_id: str = "", reference_id: str = "") -> dict:
    """Persist immediately after POST acceptance and before every lookup."""
    data = _load(); record = data.setdefault("records", {}).get(str(int(decision_id)))
    if not record:
        raise BrokerFehler("Angenommene eToro-Order ohne persistierte Kaufabsicht")
    if order_id and str(order_id) not in record["order_ids"]:
        record["order_ids"].append(str(order_id))
    if reference_id:
        record["reference_id"] = str(reference_id)
    record["state"] = "RECONCILING"; record["updated_at_utc"] = _now()
    _save(data)
    mark_execution(decision_id, "RECONCILING", record["order_ids"],
                   reference_id=record["reference_id"], broker_paper=record["paper"])
    record_order_state(decision_id, broker="etoro",
                       broker_order_id=str(order_id or reference_id), role="ENTRY",
                       status="RECONCILING", symbol=record["symbol"],
                       client_order_id=reference_id, requested_qty=record["quantity"],
                       remaining_qty=record["quantity"], requested_price=record["price"],
                       raw={"stop": record["stop"], "take_profit": record["take_profit"]})
    record_execution_event(decision_id, "ORDER_ACCEPTED", record,
                           event_id=f"etoro:{decision_id}:accepted:{order_id or reference_id}")
    _notify(record, "uncertain")
    return dict(record)


def register_reference(decision_id: int, reference_id: str) -> dict:
    """Persist the idempotency/lookup anchor before the broker POST."""
    data = _load(); record = data.setdefault("records", {}).get(str(int(decision_id)))
    if not record:
        raise BrokerFehler("eToro-referenceId ohne persistierte Kaufabsicht")
    record["reference_id"] = str(reference_id or "")
    record["updated_at_utc"] = _now()
    _save(data)
    record_execution_event(
        decision_id, "REFERENCE_RESERVED", {"reference_id": record["reference_id"]},
        event_id=f"etoro:{decision_id}:reference:{record['reference_id']}",
    )
    return dict(record)


def mark_submit_failed(decision_id: int, *, state: str, detail: str = "") -> dict:
    """Terminalize a definitively failed submit without discarding evidence.

    This must only be used for failures where the broker adapter did not turn
    the result into OrderStatusUnklar. Ambiguous POST outcomes stay locked.
    """
    target = str(state or "FAILED").upper()
    if target not in {"FAILED", "FAILED_BEFORE_SUBMIT"}:
        raise ValueError(f"ungueltiger terminaler Submit-Status: {target}")
    data = _load(); record = data.setdefault("records", {}).get(str(int(decision_id)))
    if not record:
        return {}
    current = str(record.get("state") or "").upper()
    if current not in {"SUBMITTING"}:
        # Accepted/ambiguous evidence must never be unlocked by a broad catch.
        return dict(record)
    record["state"] = target
    record["last_error"] = str(detail)[:500]
    record["updated_at_utc"] = _now()
    _save(data)
    mark_execution(
        decision_id, target, record.get("order_ids") or [],
        reference_id=record.get("reference_id", ""), broker_paper=record.get("paper"),
    )
    record_execution_event(
        decision_id, target, {"detail": record["last_error"]},
        event_id=f"etoro:{decision_id}:{target.lower()}",
    )
    return dict(record)


def mark_unknown(decision_id: int, *, order_ids=(), reference_id: str = "", detail: str = "") -> None:
    data = _load(); record = data.setdefault("records", {}).get(str(int(decision_id)))
    if not record:
        return
    for oid in order_ids or ():
        if str(oid) and str(oid) not in record["order_ids"]:
            record["order_ids"].append(str(oid))
    if reference_id:
        record["reference_id"] = str(reference_id)
    record["state"] = "UNKNOWN_AFTER_SUBMIT"; record["last_error"] = str(detail)[:500]
    record["updated_at_utc"] = _now(); _save(data)
    mark_execution(decision_id, "UNKNOWN_AFTER_SUBMIT", record["order_ids"],
                   reference_id=record["reference_id"], broker_paper=record["paper"])
    record_execution_event(decision_id, "UNKNOWN_AFTER_SUBMIT", {"detail": str(detail)[:500]},
                           event_id=f"etoro:{decision_id}:unknown")
    _notify(record, "uncertain")


def _status(data: dict) -> tuple[str, int]:
    status = data.get("status") or {}
    return str(status.get("name") or "").upper(), int(status.get("id") or 0)


def apply_broker_evidence(decision_id: int, evidence: dict) -> dict:
    """Resolve only from exact stored order/reference IDs and exact returned position IDs."""
    data = _load(); record = data.setdefault("records", {}).get(str(int(decision_id)))
    if not record:
        raise BrokerFehler("Kein lokaler Reconciliation-Datensatz")
    returned_order = str(evidence.get("orderId") or evidence.get("orderID") or "")
    known_orders = {str(x) for x in record.get("order_ids") or []}
    if returned_order and known_orders and returned_order not in known_orders:
        raise BrokerFehler("Brokerantwort gehoert nicht zur exakt gespeicherten Order-ID")
    returned_ref = str(evidence.get("referenceId") or evidence.get("requestId") or "")
    if returned_ref and record.get("reference_id") and returned_ref != record["reference_id"]:
        raise BrokerFehler("Brokerantwort gehoert nicht zur exakt gespeicherten referenceId")
    if returned_order and returned_order not in known_orders:
        # A referenceId lookup can reveal the broker order ID for the first
        # time. It is exact broker evidence, not a symbol/quantity guess.
        record.setdefault("order_ids", []).append(returned_order)
        known_orders.add(returned_order)
    name, sid = _status(evidence)
    executions = evidence.get("positionExecutions") or []
    fills = []
    for ex in executions:
        opening = ex.get("openingData") or {}
        q = abs(float(opening.get("units") or ex.get("filledUnits") or 0))
        px = float(opening.get("avgPrice") or 0)
        pid = str(ex.get("positionId") or "")
        if q > 0 and px > 0 and pid:
            fills.append({"position_id": pid, "quantity": q, "price": px,
                          "execution_time": opening.get("executionTime")})
    filled = sum(x["quantity"] for x in fills)
    requested = float(record.get("quantity") or 0)
    remaining = max(0.0, requested - filled)
    record["fills"] = fills; record["filled_quantity"] = filled
    record["remaining_quantity"] = remaining
    record["position_ids"] = sorted({x["position_id"] for x in fills})
    terminal_reject = sid in (4, 10) or name in {"REJECTED", "CANCELLED", "EXPIRED", "REJECTEDPARTIALLYFILLED"}
    if filled > 0 and terminal_reject:
        execution_state = "REJECTED_PARTIALLY_FILLED"
    elif filled > 0 and remaining > 1e-10:
        execution_state = "PARTIALLY_FILLED"
    elif filled > 0:
        execution_state = "FILLED"
    elif terminal_reject:
        execution_state = "REJECTED"
    else:
        execution_state = "RECONCILING"

    # Eine Orderauskunft mit positionExecutions ist noch kein Beweis, dass
    # die Position im aktuellen Depot existiert. Genau diese Verwechslung
    # erzeugte den MSFT-Phantomtrade: der Lookup meldete einen Fill, der
    # aktuelle Brokerbestand enthielt die positionId aber nicht. Fills bleiben
    # deshalb gesperrt, bis verify_broker_truth() dieselbe positionId im Depot
    # oder in der vollstaendig gelesenen Historie gefunden hat.
    state = ("AWAITING_POSITION_CONFIRMATION"
             if filled > 0 else execution_state)
    record["broker_execution_state"] = execution_state
    record["position_verified"] = False
    record["state"] = state; record["broker_status"] = name or str(sid)
    record["updated_at_utc"] = _now(); _save(data)
    if known_orders or record.get("reference_id"):
        try:
            from order_ownership import OrderOwnershipRegistry
            registry = OrderOwnershipRegistry(
                _root() / getattr(config, "BOT_ORDER_REGISTRY_FILE", "bot_order_registry.json"))
            registry.register_orders(
                sorted(known_orders | {str(record.get("reference_id") or "")}),
                record["symbol"],
                meta={"decision_id": int(decision_id), "zustand": state,
                      "profile": record.get("profile", ""),
                      "broker": "etoro", "asset_type": "stock",
                      "qty": requested, "signal_price": record.get("price"),
                      "stop": record.get("stop"), "take": record.get("take_profit"),
                      "reference_id": record.get("reference_id", ""),
                      "reason": "eToro-Ausfuehrung exakt wiederhergestellt"},
                owner="BOT", asset_type="stock",
            )
        except Exception:
            logger.exception("Exakte eToro-Order-Ownership konnte nicht persistiert werden")
    avg = (sum(x["quantity"] * x["price"] for x in fills) / filled) if filled else None
    mark_execution(decision_id, state, record["order_ids"], reference_id=record["reference_id"],
                   position_ids=record["position_ids"], fill_price=avg, fill_qty=filled,
                   broker_paper=record["paper"])
    record_order_state(decision_id, broker="etoro",
                       broker_order_id=str(next(iter(known_orders), record.get("reference_id") or decision_id)),
                       # Orderausfuehrung und Positionsbeweis sind getrennte
                       # Zustaende: CANCELED/REJECTED_PARTIALLY_FILLED darf
                       # nicht durch den uebergeordneten Abgleichstatus
                       # AWAITING_POSITION_CONFIRMATION verdeckt werden.
                       role="ENTRY", status=execution_state, symbol=record["symbol"],
                       client_order_id=record["reference_id"], requested_qty=requested,
                       filled_qty=filled, remaining_qty=remaining, requested_price=record["price"],
                       avg_fill_price=avg, raw=evidence)
    record_execution_event(decision_id, state, record,
                           event_id=f"etoro:{decision_id}:{state}:{filled:g}")
    # Ein Order-Lookup beweist die Ausfuehrung, aber noch keine aktuell
    # offene Position. Die Erfolgsnachricht darf erst nach dem exakten
    # positionId-Abgleich mit Depot oder Trade-Historie entstehen.
    if execution_state == "REJECTED":
        _notify(record, "failed")
    return dict(record)


def record_for(decision_id: int) -> dict:
    """Aktueller persistierter Datensatz einer Kaufentscheidung."""
    return dict(((_load().get("records") or {}).get(str(int(decision_id))) or {}))


def reconcile_one(broker, decision_id: int, *, attempts: int = 4,
                  delays=(0.0, 0.8, 1.6, 3.2)) -> dict:
    """Rate-limit friendly GET recovery; orderId/referenceId are never combined."""
    record = (_load().get("records") or {}).get(str(int(decision_id)))
    if not record:
        raise BrokerFehler("Kein Reconciliation-Datensatz")
    last_error = ""
    anchors = [("order_id", x) for x in record.get("order_ids") or []]
    if record.get("reference_id"):
        anchors.append(("reference_id", record["reference_id"]))
    for attempt in range(max(1, int(attempts))):
        if attempt < len(delays) and float(delays[attempt]) > 0:
            time.sleep(float(delays[attempt]))
        for kind, value in anchors:
            try:
                evidence = broker._lookup_order(**{kind: value})
                if evidence:
                    return apply_broker_evidence(decision_id, evidence)
            except (BrokerFehler, VerbindungVerloren) as exc:
                last_error = str(exc)[:500]
    mark_unknown(decision_id, order_ids=record.get("order_ids"),
                 reference_id=record.get("reference_id", ""), detail=last_error or "nicht gefunden")
    return dict(((_load().get("records") or {}).get(str(int(decision_id))) or {}))


def recover_all(broker, *, paper: bool, profile: str) -> list[dict]:
    domain = domain_key(paper=paper, profile=profile)
    recovered = []
    for record in active_for_domain(domain):
        decision_id = int(record.get("decision_id") or 0)
        if decision_id <= 0:
            # Fail closed without crashing reconnect/startup on corrupt storage.
            recovered.append(dict(record))
            continue
        recovered.append(reconcile_one(broker, decision_id))
    # Auch bereits terminal als FILLED gespeicherte Altfaelle pruefen. Genau
    # diese Pruefung fehlte in 9.0.2 und konnte nach einem Neustart einen
    # Phantomtrade erzeugen.
    return recovered + verify_broker_truth(
        broker, paper=paper, profile=profile)


def recovered_buy_fills(*, paper: bool,
                        current_position_ids: set[str] | None = None) -> list[Fill]:
    """Expose exact persisted BUY executions after restart.

    Fill IDs intentionally match the adapter's immediate queue. The global
    fill tracker therefore makes repeated polls and restart recovery exactly
    once without deleting reconciliation evidence prematurely.
    """
    data = _load()
    if data.get("storage_error"):
        return []
    # Fail closed: ohne aktuellen, erfolgreich gelesenen Depot-Snapshot wird
    # kein persistierter BUY erneut in den Geldpfad eingespielt.
    # ``None`` bleibt ausschliesslich fuer direkte Diagnose-/Altaufrufe
    # kompatibel. Der produktive Adapter uebergibt immer einen expliziten
    # Snapshot (auch eine leere Menge), sodass dort ohne Brokerbeweis weiter
    # strikt keine Wiederherstellung erfolgt.
    if current_position_ids is None:
        current = {
            str(pid)
            for record in (data.get("records") or {}).values()
            for pid in (record.get("position_ids") or [])
            if str(pid)
        }
        legacy_verified = True
    else:
        current = {str(x) for x in current_position_ids if str(x)}
        legacy_verified = False
    if not current:
        return []
    out: list[Fill] = []
    for record in (data.get("records") or {}).values():
        if bool(record.get("paper")) != bool(paper):
            continue
        if not legacy_verified and not bool(record.get("position_verified")):
            continue
        if (not legacy_verified and
                str(record.get("broker_position_status") or "") != "OPEN_CONFIRMED"):
            continue
        order_id = str(next(iter(record.get("order_ids") or []), "") or
                       record.get("reference_id") or "")
        if not order_id:
            continue
        for item in record.get("fills") or []:
            quantity = float(item.get("quantity") or 0)
            price = float(item.get("price") or 0)
            position_id = str(item.get("position_id") or "")
            if quantity <= 0 or price <= 0 or not position_id or position_id not in current:
                continue
            timestamp = item.get("execution_time")
            out.append(Fill(
                fill_id=f"etoro-open:{order_id}:{position_id}:{timestamp}",
                order_id=order_id, symbol=str(record.get("symbol") or "").upper(),
                side="BUY", quantity=quantity, price=price, currency="USD",
                asset_type="stock", broker_id=position_id, timestamp=timestamp,
            ))
    return out


def _created_day(record: dict) -> str:
    raw = str(record.get("created_at_utc") or "")
    try:
        return datetime.fromisoformat(raw.replace("Z", "+00:00")).date().isoformat()
    except (TypeError, ValueError):
        return datetime.now(timezone.utc).date().isoformat()


def verify_broker_truth(broker, *, paper: bool, profile: str) -> list[dict]:
    """Persistierte eToro-Fills gegen aktuelle/geschlossene positionIds pruefen.

    Symbol und Menge sind absichtlich keine Zuordnungsmerkmale. Nur eine
    exakte positionId darf AUTO-Verwaltung oder einen offenen Ledgertrade
    herstellen.
    """
    data = _load()
    if data.get("storage_error"):
        return []
    domain = domain_key(paper=paper, profile=profile)
    candidates = [
        dict(r) for r in (data.get("records") or {}).values()
        if str(r.get("domain")) == domain and (r.get("fills") or [])
    ]
    if not candidates:
        return []

    try:
        current_ids = {str(x) for x in broker.current_position_ids(force=True)}
    except Exception as exc:
        logger.warning("eToro-Depotbeweis nicht lesbar; Reconciliation bleibt gesperrt: %s", exc)
        return []

    earliest = min(_created_day(r) for r in candidates)
    try:
        history = broker.trade_history(earliest)
    except Exception as exc:
        # Eine offene positionId ist bereits ein ausreichender positiver
        # Beweis. Nur die negative Einstufung wartet auf lesbare Historie.
        logger.warning("eToro-Historienbeweis nicht lesbar: %s", exc)
        history = None
    closed_by_id = ({str(x.get("positionId") or ""): dict(x) for x in history}
                    if history is not None else {})

    changed: list[dict] = []
    for candidate in candidates:
        did = int(candidate.get("decision_id") or 0)
        if did <= 0:
            continue
        pids = {str(x) for x in candidate.get("position_ids") or [] if str(x)}
        if not pids:
            pids = {str(x.get("position_id") or "") for x in candidate.get("fills") or []
                    if str(x.get("position_id") or "")}
        open_ids = sorted(pids & current_ids)
        closed_ids = sorted(pids & set(closed_by_id))
        latest = (_load().get("records") or {}).get(str(did), candidate)
        was_verified = bool(latest.get("position_verified"))

        if open_ids:
            if (was_verified
                    and str(latest.get("broker_position_status") or "") == "OPEN_CONFIRMED"
                    and sorted(str(x) for x in latest.get("verified_position_ids") or []) == open_ids):
                # Brokerwahrheit wurde erneut geprueft, aber es hat sich
                # nichts geaendert. Keine zweite Meldung/kein zweites Ereignis.
                continue
            data = _load(); record = data.setdefault("records", {}).get(str(did))
            if not record:
                continue
            record["position_verified"] = True
            record["broker_position_status"] = "OPEN_CONFIRMED"
            execution_state = str(
                record.get("broker_execution_state") or record.get("state") or "FILLED"
            ).upper()
            record["state"] = execution_state
            record["verified_position_ids"] = open_ids
            record["position_verified_at_utc"] = _now()
            record["updated_at_utc"] = _now()
            _save(data)
            mark_execution(
                did, execution_state, record.get("order_ids") or [],
                reference_id=record.get("reference_id", ""),
                position_ids=open_ids,
                fill_price=(sum(float(x.get("quantity") or 0) * float(x.get("price") or 0)
                                for x in record.get("fills") or []) /
                            max(float(record.get("filled_quantity") or 0), 1e-12)),
                fill_qty=float(record.get("filled_quantity") or 0),
                broker_paper=record.get("paper"),
            )
            record_execution_event(
                did, "POSITION_OPEN_CONFIRMED",
                {"position_ids": open_ids},
                event_id=f"etoro:{did}:position-open:{','.join(open_ids)}")
            try:
                import trade_ledger
                trade_ledger.mark_decision_reconciliation(
                    did, "CONFIRMED_OPEN",
                    notiz="eToro-positionId im aktuellen Depot bestaetigt")
            except Exception:
                logger.debug("eToro-Positionsbeweis nicht ins Ledger gespiegelt", exc_info=True)
            if not was_verified:
                _notify(record, "confirmed")
            changed.append(dict(record))
            continue

        if history is None:
            # Kein negativer Schluss aus einer unvollstaendigen Datenlage.
            continue

        if closed_ids:
            if (str(latest.get("broker_position_status") or "") == "CLOSED_CONFIRMED"
                    and sorted(str(x) for x in latest.get("closed_position_ids") or []) == closed_ids):
                continue
            data = _load(); record = data.setdefault("records", {}).get(str(did))
            if not record:
                continue
            record["position_verified"] = False
            record["broker_position_status"] = "CLOSED_CONFIRMED"
            record["state"] = "CLOSED_BEFORE_IMPORT"
            record["closed_position_ids"] = closed_ids
            record["position_verified_at_utc"] = _now()
            record["updated_at_utc"] = _now()
            _save(data)
            mark_execution(did, "CLOSED_BEFORE_IMPORT", record.get("order_ids") or [],
                           reference_id=record.get("reference_id", ""),
                           position_ids=closed_ids, broker_paper=record.get("paper"))
            record_execution_event(
                did, "POSITION_CLOSED_CONFIRMED",
                {"position_ids": closed_ids},
                event_id=f"etoro:{did}:position-closed:{','.join(closed_ids)}")
            try:
                import trade_ledger
                trade_ledger.mark_decision_reconciliation(
                    did, "CLOSED", close_without_result=True,
                    notiz="eToro-Historie bestaetigt bereits geschlossene positionId; P&L unbekannt")
            except Exception:
                logger.debug("eToro-Schliessungsbeweis nicht ins Ledger gespiegelt", exc_info=True)
            changed.append(dict(record))
            continue

        # Lookup-Fill vorhanden, aber weder aktuelle noch geschlossene
        # positionId im exakt gleichen Brokerkonto: kein offener Trade.
        reason = ("Gespeicherte eToro-positionId weder im aktuellen Depot noch "
                  "in der vollstaendig gelesenen Trade-Historie gefunden")
        if str(latest.get("state") or "") == "UNPROVABLE":
            continue
        mark_unprovable(did, reason)
        try:
            import trade_ledger
            trade_ledger.mark_decision_reconciliation(did, "UNPROVABLE", notiz=reason)
        except Exception:
            logger.debug("UNPROVABLE nicht ins Ledger gespiegelt", exc_info=True)
        record = ((_load().get("records") or {}).get(str(did)) or {})
        changed.append(dict(record))
    return changed


def mark_unprovable(decision_id: int, reason: str) -> None:
    data = _load(); record = data.setdefault("records", {}).get(str(int(decision_id)))
    if not record:
        return
    record["state"] = "UNPROVABLE"; record["last_error"] = str(reason)[:500]
    record["updated_at_utc"] = _now(); _save(data)
    mark_execution(decision_id, "UNPROVABLE", record.get("order_ids"),
                   reference_id=record.get("reference_id", ""))
    record_execution_event(
        decision_id, "UNPROVABLE", {"reason": str(reason)[:500]},
        event_id=f"etoro:{decision_id}:unprovable")
    _notify(record, "failed")


def _notify(record: dict, phase: str) -> None:
    try:
        from notifier import send_telegram
        did = int(record["decision_id"]); symbol = record.get("symbol", "?")
        if phase == "uncertain":
            text = (f"⚠️ eToro-Kauf {symbol} angenommen, Ausführung noch ungeklärt. "
                    "Kein erneuter Kauf; automatische Wiederherstellung läuft.")
            event = f"etoro-reconcile:{did}:uncertain"
        elif phase == "confirmed":
            text = (f"✅ eToro-Ausführung {symbol} eindeutig wiederhergestellt: "
                    f"{float(record.get('filled_quantity') or 0):g} gefüllt.")
            event = f"etoro-reconcile:{did}:confirmed:{float(record.get('filled_quantity') or 0):g}"
        else:
            text = (f"🚨 eToro-Status {symbol} endgültig nicht sicher beweisbar/abgelehnt. "
                    "Position bleibt OBSERVE; bitte Brokerkonto prüfen.")
            event = f"etoro-reconcile:{did}:failed"
        send_telegram(text, priority="critical", event_id=event)
    except Exception:
        # Broker evidence must survive even if notification is unavailable.
        logger.debug("Reconciliation-Telegram nicht zustellbar", exc_info=True)


def status() -> dict:
    data = _load()
    records = list((data.get("records") or {}).values())
    records.sort(key=lambda x: (str(x.get("created_at_utc") or ""), int(x.get("decision_id") or 0)), reverse=True)
    return {"updated_at_utc": data.get("updated_at_utc"), "storage_error": data.get("storage_error"),
            "active": [x for x in records if str(x.get("state") or "").upper() in NON_TERMINAL],
            "records": records}
