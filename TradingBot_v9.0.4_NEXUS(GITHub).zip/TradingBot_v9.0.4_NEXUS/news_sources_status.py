"""Zeigt Konfiguration UND tatsaechlich zuletzt gemessene Erreichbarkeit."""
from __future__ import annotations

from news_sources import MultiSourceNews
from console_io import configure_utf8_console

configure_utf8_console()


def _fmt_age(seconds):
    if seconds is None:
        return "nie"
    seconds = max(0, int(seconds))
    if seconds < 60:
        return f"{seconds}s"
    if seconds < 3600:
        return f"{seconds//60}m"
    return f"{seconds/3600:.1f}h"


def main():
    client = MultiSourceNews()
    health = client.health_snapshot()
    print("=" * 94)
    print("RESEARCH / NEWS STATUS - 8.0 NEXUS")
    print("=" * 94)
    print(f"{'QUELLE':22} {'KONFIG':9} {'STATUS':11} {'ALTER':8} DETAILS")
    print("-" * 94)
    configured = healthy = 0
    for name, row in health.items():
        if row['configured']:
            configured += 1
        if row['healthy']:
            healthy += 1
        state = row['state'].upper()
        if state == 'BACKOFF':
            state = f"PAUSE {max(1,row['backoff_seconds']//60)}m"
        print(
            f"{name:22} {'JA' if row['configured'] else 'NEIN':9} "
            f"{state:11} {_fmt_age(row['age_seconds']):8} {row['detail'][:42]}"
        )
    print("-" * 94)
    print(f"Tatsaechlich erreichbar: {healthy}/{configured} der eingerichteten Quellen")
    print()
    print("Hinweis: 'KONFIGURIERT' ist nicht dasselbe wie 'ERREICHBAR'.")
    print("HTTP-403/Netzwerkfehler werden mit Backoff pausiert, damit keine Log-/Request-Schleife entsteht.")


if __name__ == '__main__':
    main()
