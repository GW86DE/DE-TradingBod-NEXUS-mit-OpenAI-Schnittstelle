"""Robuste Fill-Deduplizierung für echte Executions und kumulative Order-Fills."""
from __future__ import annotations
from dataclasses import replace
from pathlib import Path
import json
import logging
from safe_persistence import atomic_write_json

logger = logging.getLogger(__name__)


class FillProgressTracker:
    def __init__(self, path="fill_progress.json"):
        self.path = Path(path)
        self.seen_ids = set()
        self.cumulative = {}
        self._load()

    def _load(self):
        if not self.path.exists():
            return
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
            self.seen_ids = set(str(x) for x in data.get("seen_ids", []))
            self.cumulative = {
                str(k): float(v) for k, v in data.get("cumulative", {}).items()
            }
        except Exception as exc:
            logger.warning("Fill-Tracker konnte nicht geladen werden: %s", exc)
            self.seen_ids = set()
            self.cumulative = {}

    def save(self):
        payload = {
            "seen_ids": sorted(self.seen_ids)[-5000:],
            "cumulative": self.cumulative,
        }
        atomic_write_json(self.path, payload)

    def seed(self, fills):
        """Vorhandene Broker-Historie beim Start als bereits verarbeitet markieren."""
        changed = False
        for fill in fills or []:
            if getattr(fill, "quantity_is_cumulative", False):
                key = str(getattr(fill, "order_id", "") or "")
                if not key:
                    continue
                current = max(0.0, float(getattr(fill, "quantity", 0) or 0))
                if current > self.cumulative.get(key, 0.0):
                    self.cumulative[key] = current
                    changed = True
            else:
                fid = str(getattr(fill, "fill_id", "") or "")
                if fid and fid not in self.seen_ids:
                    self.seen_ids.add(fid)
                    changed = True
        if changed:
            self.save()

    def prepare(self, fill):
        """
        Gibt (verarbeitbarer_fill, token) oder (None, None) zurück.
        Aus einer kumulierten Fill-Menge wird eine Delta-Ausfuehrung.
        Commit erfolgt erst NACH erfolgreicher P&L-/Positionsverarbeitung.
        """
        if getattr(fill, "quantity_is_cumulative", False):
            key = str(getattr(fill, "order_id", "") or "")
            if not key:
                return None, None
            current = max(0.0, float(getattr(fill, "quantity", 0) or 0))
            previous = max(0.0, float(self.cumulative.get(key, 0.0)))
            delta = current - previous
            if delta <= 1e-12:
                return None, None
            fid = f"{key}:{current:.12g}"
            prepared = replace(fill, fill_id=fid, quantity=delta)
            return prepared, ("cumulative", key, current)

        fid = str(getattr(fill, "fill_id", "") or "")
        if not fid or fid in self.seen_ids:
            return None, None
        return fill, ("id", fid)

    def commit(self, token):
        if not token:
            return
        if token[0] == "cumulative":
            _, key, current = token
            self.cumulative[str(key)] = float(current)
        else:
            _, fid = token
            self.seen_ids.add(str(fid))
        self.save()
