"""FMP als Referenz- und Kursquelle (neu in v8.1.2).

WARUM DIESES MODUL EXISTIERT
============================
Bis v8.1.1 war FMP im Bot als NACHRICHTENquelle eingebunden. Das konnte mit
einem Gratistarif nie funktionieren. Nachgemessen am 24.08.2026 mit einem
echten Free-Plan-Schluessel:

    /stable/news/stock                 HTTP 402 Payment Required
    /stable/news/general-latest        HTTP 402 Payment Required
    /stable/search-symbol              OK
    /stable/quote                      OK
    /stable/profile                    OK
    /stable/historical-price-eod/full  OK

Die 250 Anfragen pro Tag sind ein MENGENlimit, kein Freischalten der
News-Endpunkte. Ein 402 ist deshalb kein Fehler, sondern eine
Tarifaussage -- und muss auch so angezeigt werden, sonst sucht man den
Fehler ewig im eigenen Code.

WAS FMP STATTDESSEN LIEFERT
===========================
Genau die Daten, die dem Aktien-Universum bisher gefehlt haben:

    Symbolsuche     Ticker aufloesen und Identitaet pruefen
    Quote           Preis, Volumen, Marktkapitalisierung, 50/200-Tage-Schnitt
    Profil          Sektor, Branche und isActivelyTrading -> Delisting-Erkennung
    Tageskerzen     rund 390 Tage OHLCV mit VWAP -> echtes Dollar-Volumen

Damit ersetzt FMP auf der Aktienseite das, wofuer bisher MASSIVE noetig war.

BUDGET
======
250 Anfragen pro Tag werden hart mitgezaehlt. Ist das Budget aufgebraucht,
liefert das Modul den letzten bekannten Wert bzw. einen klaren Zustand --
und feuert nicht weiter gegen ein Limit, das sich erst um Mitternacht
zuruecksetzt.
"""

from __future__ import annotations

import logging
import threading
import time
from datetime import date, datetime, timedelta, timezone
from typing import Any, Optional

import requests

from massive_api import TagesBudget

logger = logging.getLogger(__name__)

FMP_BASE = "https://financialmodelingprep.com/stable"

# Endpunkte, die der Gratistarif nachweislich NICHT enthaelt.
NEWS_ENDPUNKTE = ("/news/stock", "/news/general-latest", "/news/stock-latest",
                  "/news/press-releases-latest")


class FMPTarifFehlt(RuntimeError):
    """Der Endpunkt ist im gebuchten Tarif nicht enthalten (HTTP 402).

    Bewusst ein eigener Fehlertyp: der Bot soll ihn als Zustand anzeigen
    ("nicht im Tarif") statt als Stoerung ("Verbindung fehlgeschlagen").
    """


class FMPReferenz:
    """Referenz-, Kurs- und Fundamentaldaten von FMP mit Tagesbudget."""

    def __init__(self, api_key: str = "", *, base_url: str = FMP_BASE,
                 tageslimit: int = 0, timeout: float = 12.0):
        import live_settings
        self._key = str(api_key or live_settings.fmp_key() or "").strip()
        self.base_url = str(base_url or FMP_BASE).rstrip("/")
        self.timeout = float(timeout)
        self.budget = TagesBudget(limit=int(tageslimit or live_settings.fmp_tageslimit() or 250))
        self.session = requests.Session()
        self.session.headers.update({"Accept": "application/json",
                                     "User-Agent": "TradingBot-v8-NEXUS"})
        self._status: dict[str, Any] = {"ok": None, "detail": "noch nicht abgefragt",
                                        "zeit": "", "count": 0}
        self._faehigkeiten: dict[str, dict] = {}
        self._lock = threading.RLock()

    @property
    def konfiguriert(self) -> bool:
        return bool(self._key)

    # -- Kernaufruf ---------------------------------------------------------
    def _get(self, pfad: str, params: Optional[dict] = None) -> Any:
        if not self.konfiguriert:
            raise RuntimeError("FMP API-Key fehlt")
        frei, grund = self.budget.frei()
        if not frei:
            raise RuntimeError(f"FMP pausiert: {grund}")

        anfrage = dict(params or {})
        anfrage["apikey"] = self._key
        try:
            self.budget.buchen()
            antwort = self.session.get(f"{self.base_url}{pfad}", params=anfrage,
                                       timeout=self.timeout)
        except requests.RequestException as exc:
            # Bewusst nur der Ausnahmetyp: manche Bibliotheken haengen die
            # vollstaendige URL inklusive apikey an die Meldung.
            self._merke(False, f"nicht erreichbar ({type(exc).__name__})")
            raise RuntimeError(f"FMP nicht erreichbar ({type(exc).__name__})") from None

        if antwort.status_code == 402:
            # Tarifaussage, keine Stoerung. Kein 24h-Backoff: der Endpunkt
            # wird ohnehin nur noch aufgerufen, wenn jemand ihn ausdruecklich
            # freischaltet.
            self._merke_faehigkeit(pfad, False, "nicht im Tarif enthalten (HTTP 402)")
            raise FMPTarifFehlt(f"FMP {pfad}: im gebuchten Tarif nicht enthalten (HTTP 402)")
        if antwort.status_code in (401, 403):
            self.budget.sperren(3600, f"Zugang abgelehnt (HTTP {antwort.status_code})")
            self._merke(False, f"Zugang abgelehnt (HTTP {antwort.status_code})")
            raise RuntimeError(f"FMP HTTP {antwort.status_code}: Schluessel ungueltig")
        if antwort.status_code == 429:
            self.budget.sperren(3600, "Ratenbegrenzung erreicht (HTTP 429)")
            self._merke(False, "Ratenbegrenzung erreicht (HTTP 429)")
            raise RuntimeError("FMP HTTP 429: zu viele Anfragen")
        if antwort.status_code >= 400:
            self._merke(False, f"HTTP {antwort.status_code}")
            raise RuntimeError(f"FMP HTTP {antwort.status_code}")

        try:
            daten = antwort.json()
        except ValueError:
            self._merke(False, "Antwort nicht lesbar")
            raise RuntimeError("FMP-Antwort nicht lesbar")
        if isinstance(daten, dict) and (daten.get("Error Message") or daten.get("error")):
            meldung = str(daten.get("Error Message") or daten.get("error"))[:200]
            self._merke(False, meldung)
            raise RuntimeError(f"FMP: {meldung}")
        self._merke_faehigkeit(pfad, True, "erreichbar")
        return daten

    def _merke(self, ok: bool, detail: str, count: int = 0) -> None:
        with self._lock:
            self._status = {"ok": bool(ok), "detail": str(detail)[:240],
                            "zeit": datetime.now(timezone.utc).isoformat(), "count": int(count)}

    def _merke_faehigkeit(self, pfad: str, ok: bool, detail: str) -> None:
        with self._lock:
            self._faehigkeiten[pfad] = {
                "ok": bool(ok), "detail": detail,
                "zeit": datetime.now(timezone.utc).isoformat(),
            }

    # -- Fachliche Abfragen -------------------------------------------------
    def search_symbol(self, symbol: str, limit: int = 10) -> list[dict]:
        rows = self._get("/search-symbol", {"query": str(symbol).upper(),
                                            "limit": max(1, min(50, int(limit)))})
        return list(rows or []) if isinstance(rows, list) else []

    def quote(self, symbol: str) -> dict:
        rows = self._get("/quote", {"symbol": str(symbol).upper()})
        if isinstance(rows, list) and rows:
            return dict(rows[0])
        return dict(rows) if isinstance(rows, dict) else {}

    def profil(self, symbol: str) -> dict:
        rows = self._get("/profile", {"symbol": str(symbol).upper()})
        if isinstance(rows, list) and rows:
            return dict(rows[0])
        return dict(rows) if isinstance(rows, dict) else {}

    def tageskerzen(self, symbol: str, tage: int = 30) -> list[dict]:
        """Tageskerzen, neueste zuerst."""
        daten = self._get("/historical-price-eod/full", {"symbol": str(symbol).upper()})
        zeilen = daten if isinstance(daten, list) else (daten or {}).get("historical", [])
        return list(zeilen or [])[: max(1, int(tage))]

    # -- Abgeleitete Kennzahlen --------------------------------------------
    def dollar_volumen(self, symbol: str, tage: int = 20) -> float:
        """Mittlerer Tagesumsatz in USD -- das Liquiditaetsmass fuer Aktien."""
        try:
            zeilen = self.tageskerzen(symbol, tage=tage)
        except (RuntimeError, FMPTarifFehlt):
            return 0.0
        werte = []
        for zeile in zeilen:
            volumen = float(zeile.get("volume") or 0.0)
            preis = float(zeile.get("vwap") or zeile.get("close") or 0.0)
            if volumen > 0 and preis > 0:
                werte.append(volumen * preis)
        return sum(werte) / len(werte) if werte else 0.0

    def ist_aktiv(self, symbol: str) -> Optional[bool]:
        """Wird der Wert noch gehandelt? None = nicht feststellbar.

        Beantwortet die Delisting-Frage aus dem Profil-Endpunkt, der im
        Gratistarif enthalten ist.
        """
        try:
            profil = self.profil(symbol)
        except (RuntimeError, FMPTarifFehlt):
            return None
        if not profil:
            return None
        if "isActivelyTrading" in profil:
            return bool(profil.get("isActivelyTrading"))
        return None

    def sektor(self, symbol: str) -> str:
        try:
            return str(self.profil(symbol).get("sector") or "")
        except (RuntimeError, FMPTarifFehlt):
            return ""

    # -- Diagnose -----------------------------------------------------------
    def verbindungstest(self) -> dict:
        """Prueft genau die Faehigkeit, die der Bot wirklich benutzt."""
        if not self.konfiguriert:
            return {"ok": False, "detail": "Kein API-Key hinterlegt"}
        try:
            treffer = self.search_symbol("AAPL", limit=1)
        except FMPTarifFehlt as exc:
            return {"ok": False, "detail": str(exc), "tarif": True}
        except RuntimeError as exc:
            return {"ok": False, "detail": str(exc)}
        self._merke(True, "Symbolsuche erreichbar", len(treffer))
        return {"ok": True, "count": len(treffer),
                "detail": f"Symbolsuche erreichbar ({len(treffer)} Treffer), "
                          f"Budget {self.budget.verbraucht}/{self.budget.limit} heute"}

    def faehigkeitstest(self) -> dict:
        """Prueft der Reihe nach, was der gebuchte Tarif wirklich kann.

        Kostet vier Anfragen und wird nur auf ausdruecklichen Knopfdruck
        ausgefuehrt. Das Ergebnis erklaert dem Nutzer schwarz auf weiss,
        warum News nicht gehen und Referenzdaten schon.
        """
        pruefungen = [
            ("Symbolsuche", lambda: self.search_symbol("AAPL", 1)),
            ("Kurs", lambda: self.quote("AAPL")),
            ("Profil (Sektor, Delisting)", lambda: self.profil("AAPL")),
            ("Tageskerzen", lambda: self.tageskerzen("AAPL", 5)),
        ]
        ergebnis: dict[str, dict] = {}
        for name, aufruf in pruefungen:
            try:
                daten = aufruf()
                ergebnis[name] = {"ok": True, "detail": f"{len(daten) if hasattr(daten, '__len__') else 1} Datensatz"}
            except FMPTarifFehlt as exc:
                ergebnis[name] = {"ok": False, "tarif": True, "detail": str(exc)}
            except RuntimeError as exc:
                ergebnis[name] = {"ok": False, "detail": str(exc)}
        ergebnis["Nachrichten"] = {
            "ok": False, "tarif": True,
            "detail": "Im Gratistarif nicht enthalten (HTTP 402). Wird deshalb "
                      "nicht abgefragt und zaehlt nicht gegen das Tagesbudget.",
        }
        return ergebnis

    # -- Zwischenspeicher ---------------------------------------------------
    # 250 Anfragen pro Tag reichen NICHT, um bei jedem Universumslauf alle
    # 100 Aktien neu abzufragen: 32 Laeufe am Tag mal 100 Werte waeren 3200
    # Anfragen. Referenzdaten aendern sich aber langsam (Sektor praktisch
    # nie, Delisting selten, Dollar-Volumen ueber 20 Tage gemittelt).
    # Deshalb wird je Symbol einmal am Tag abgefragt und persistent
    # gespeichert; pro Lauf werden nur die aeltesten Eintraege nachgezogen.
    def _cache_datei(self):
        import os
        from pathlib import Path
        wurzel = Path(os.getenv("TRADINGBOT_TEST_STATE_DIR", "").strip()
                      or Path(__file__).resolve().parent)
        return wurzel / "fmp_reference_cache.json"

    def _cache_laden(self) -> dict:
        import json
        datei = self._cache_datei()
        try:
            daten = json.loads(datei.read_text(encoding="utf-8"))
            return daten if isinstance(daten, dict) else {}
        except Exception:
            return {}

    def _cache_speichern(self, daten: dict) -> None:
        from safe_persistence import best_effort_json
        best_effort_json(self._cache_datei(), daten, label="FMP-Referenzcache")

    def referenzdaten(self, symbol: str, *, max_alter_stunden: float = 20.0,
                      erlaube_abruf: bool = True) -> dict:
        """Sektor, Delisting-Status und Dollar-Volumen -- hoechstens 1x taeglich.

        Liefert immer einen auswertbaren Datensatz. 'frisch' sagt, ob die
        Werte aus einem aktuellen Abruf stammen oder aus dem Speicher.
        """
        symbol = str(symbol).upper().strip()
        speicher = self._cache_laden()
        eintrag = speicher.get(symbol) or {}
        alter = float("inf")
        if eintrag.get("zeit"):
            try:
                gelesen = datetime.fromisoformat(str(eintrag["zeit"]))
                if gelesen.tzinfo is None:
                    gelesen = gelesen.replace(tzinfo=timezone.utc)
                alter = (datetime.now(timezone.utc) - gelesen).total_seconds() / 3600.0
            except ValueError:
                alter = float("inf")
        if alter <= max_alter_stunden:
            return {**eintrag, "frisch": False, "alter_stunden": round(alter, 1)}
        if not erlaube_abruf or not self.konfiguriert:
            return {**eintrag, "frisch": False, "alter_stunden": None}

        neu = dict(eintrag)
        try:
            profil = self.profil(symbol)
            if profil:
                neu["bezeichnung"] = str(profil.get("companyName") or "")
                neu["ist_etf"] = bool(profil.get("isEtf", False))
                neu["ist_fonds"] = bool(profil.get("isFund", False))
                neu["sektor"] = str(profil.get("sector") or "")
                neu["branche"] = str(profil.get("industry") or "")
                neu["aktiv"] = bool(profil.get("isActivelyTrading", True))
                neu["preis"] = float(profil.get("price") or 0.0)
                neu["marktkapitalisierung"] = float(profil.get("marketCap") or 0.0)
        except FMPTarifFehlt as exc:
            neu["hinweis"] = str(exc)
        except RuntimeError as exc:
            return {**eintrag, "frisch": False, "fehler": str(exc)}

        umsatz = self.dollar_volumen(symbol, tage=20)
        if umsatz > 0:
            neu["dollar_volumen"] = umsatz
        neu["zeit"] = datetime.now(timezone.utc).isoformat()

        speicher[symbol] = neu
        self._cache_speichern(speicher)
        return {**neu, "frisch": True, "alter_stunden": 0.0}

    def aktualisiere_stapel(self, symbole, *, max_anfragen: int = 20) -> dict:
        """Zieht die aeltesten Eintraege nach, ohne das Tagesbudget zu sprengen.

        Jedes Symbol kostet zwei Anfragen (Profil + Kerzen). Es werden
        deshalb hoechstens max_anfragen/2 Symbole je Lauf aktualisiert.
        """
        speicher = self._cache_laden()

        def alter_von(sym: str) -> float:
            eintrag = speicher.get(str(sym).upper()) or {}
            if not eintrag.get("zeit"):
                return float("inf")
            try:
                gelesen = datetime.fromisoformat(str(eintrag["zeit"]))
                if gelesen.tzinfo is None:
                    gelesen = gelesen.replace(tzinfo=timezone.utc)
                return (datetime.now(timezone.utc) - gelesen).total_seconds()
            except ValueError:
                return float("inf")

        sortiert = sorted({str(s).upper() for s in symbole or []},
                          key=alter_von, reverse=True)
        grenze = max(0, int(max_anfragen) // 2)
        aktualisiert = []
        for symbol in sortiert[:grenze]:
            frei, _ = self.budget.frei()
            if not frei:
                break
            ergebnis = self.referenzdaten(symbol, erlaube_abruf=True)
            if ergebnis.get("frisch"):
                aktualisiert.append(symbol)
        return {"aktualisiert": aktualisiert, "geprueft": len(sortiert),
                "budget": self.budget.als_dict()}

    def status(self) -> dict:
        with self._lock:
            eintrag = dict(self._status)
            faehigkeiten = dict(self._faehigkeiten)
        eintrag["budget"] = self.budget.als_dict()
        eintrag["konfiguriert"] = self.konfiguriert
        eintrag["faehigkeiten"] = faehigkeiten
        eintrag["news_im_tarif"] = False
        return eintrag


_CLIENT: Optional[FMPReferenz] = None
_CLIENT_LOCK = threading.RLock()


def client() -> FMPReferenz:
    """Gemeinsame Instanz, damit das Tagesbudget prozessweit stimmt."""
    global _CLIENT
    with _CLIENT_LOCK:
        if _CLIENT is None:
            _CLIENT = FMPReferenz()
        return _CLIENT


def neu_laden() -> None:
    """Nach einer Schluesseländerung die Instanz verwerfen."""
    global _CLIENT
    with _CLIENT_LOCK:
        _CLIENT = None


__all__ = ["FMPReferenz", "FMPTarifFehlt", "client", "neu_laden", "FMP_BASE", "NEWS_ENDPUNKTE"]
