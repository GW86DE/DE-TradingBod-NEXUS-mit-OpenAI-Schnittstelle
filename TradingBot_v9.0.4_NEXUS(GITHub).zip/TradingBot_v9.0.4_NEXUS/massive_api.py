"""MASSIVE-Marktdaten-API (Referenzdaten, Kurse, News) -- NEXUS v8.1.1.

WOFUER
======
MASSIVE liefert drei Dinge, die dem Bot bisher gefehlt haben:

    1. Einen vollstaendigen, taeglich gepflegten Tickerkatalog inklusive
       'active'-Kennzeichen. Damit erkennt der Bot ein Delisting, statt
       weiter gegen ein totes Symbol zu handeln.
    2. Aggregierte Tagesumsaetze fuer die Liquiditaetsbewertung des
       dynamischen Aktienuniversums.
    3. Nachrichten mit sauberem Zeitstempel und Tickerbezug.

TARIFGRENZEN
============
Jeder Tarif hat ein eigenes Anfragebudget. Ein ueberschrittenes Budget
liefert HTTP 429, ein nicht enthaltener Endpunkt HTTP 402/403. Beide Faelle
werden hier ALS ZUSTAND behandelt, nicht als Ausnahme: der Bot merkt sich
die Sperre, meldet sie im Status und fragt bis zum naechsten Tag nicht mehr
nach. Genau daran ist die FMP-Anbindung in v6 gescheitert -- sie hat den
402er stuendlich neu provoziert.
"""

from __future__ import annotations

import logging
import threading
import time
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta, timezone
from typing import Any, Iterable, Optional

import requests

logger = logging.getLogger(__name__)

MASSIVE_BASE = "https://api.massive.com"


@dataclass
class TagesBudget:
    """Zaehlt Anfragen pro Kalendertag und sperrt bei Ueberschreitung."""
    limit: int = 250
    tag: str = field(default_factory=lambda: date.today().isoformat())
    verbraucht: int = 0
    gesperrt_bis: float = 0.0
    sperrgrund: str = ""

    def _tag_pruefen(self) -> None:
        heute = date.today().isoformat()
        if heute != self.tag:
            self.tag = heute
            self.verbraucht = 0
            self.gesperrt_bis = 0.0
            self.sperrgrund = ""

    def frei(self) -> tuple[bool, str]:
        self._tag_pruefen()
        if self.gesperrt_bis and time.time() < self.gesperrt_bis:
            rest = int((self.gesperrt_bis - time.time()) / 60)
            return False, f"{self.sperrgrund} (noch ca. {max(1, rest)} min)"
        if self.limit > 0 and self.verbraucht >= self.limit:
            return False, f"Tagesbudget von {self.limit} Anfragen aufgebraucht"
        return True, ""

    def buchen(self) -> None:
        self._tag_pruefen()
        self.verbraucht += 1

    def sperren(self, sekunden: float, grund: str) -> None:
        self.gesperrt_bis = time.time() + max(60.0, float(sekunden))
        self.sperrgrund = str(grund)[:200]

    def als_dict(self) -> dict:
        self._tag_pruefen()
        return {"limit": self.limit, "verbraucht": self.verbraucht,
                "rest": max(0, self.limit - self.verbraucht) if self.limit > 0 else None,
                "gesperrt": bool(self.gesperrt_bis and time.time() < self.gesperrt_bis),
                "sperrgrund": self.sperrgrund, "tag": self.tag}


class MassiveClient:
    """REST-Zugriff auf MASSIVE mit Budgetwaechter und Statusmeldung."""

    def __init__(self, api_key: str = "", *, base_url: str = MASSIVE_BASE,
                 tageslimit: int = 0, timeout: float = 15.0):
        import config
        self._key = str(api_key or __import__("live_settings").massive_key() or "").strip()
        self.base_url = str(base_url or MASSIVE_BASE).rstrip("/")
        self.timeout = float(timeout)
        limit = int(tageslimit or getattr(config, "MASSIVE_DAILY_REQUEST_LIMIT", 0) or 0)
        self.budget = TagesBudget(limit=limit)
        self.session = requests.Session()
        self.session.headers.update({"Accept": "application/json",
                                     "User-Agent": "TradingBot-v8-NEXUS"})
        self._status = {"ok": None, "detail": "noch nicht abgefragt", "zeit": "", "count": 0}
        self._lock = threading.RLock()

    @property
    def konfiguriert(self) -> bool:
        return bool(self._key)

    # -- Kernaufruf ---------------------------------------------------------
    def _get(self, pfad: str, params: Optional[dict] = None) -> dict:
        if not self.konfiguriert:
            raise RuntimeError("MASSIVE API-Key fehlt")
        frei, grund = self.budget.frei()
        if not frei:
            raise RuntimeError(f"MASSIVE pausiert: {grund}")

        anfrage = dict(params or {})
        anfrage["apiKey"] = self._key
        url = f"{self.base_url}{pfad}"
        try:
            self.budget.buchen()
            antwort = self.session.get(url, params=anfrage, timeout=self.timeout)
        except requests.RequestException as exc:
            self._merke(False, f"nicht erreichbar ({type(exc).__name__})")
            raise RuntimeError(f"MASSIVE nicht erreichbar ({type(exc).__name__})") from None

        if antwort.status_code in (401, 403):
            self.budget.sperren(86400, f"Zugang abgelehnt (HTTP {antwort.status_code})")
            self._merke(False, f"Zugang abgelehnt (HTTP {antwort.status_code})")
            raise RuntimeError(f"MASSIVE HTTP {antwort.status_code}: Schluessel oder Tarif deckt das nicht ab")
        if antwort.status_code == 402:
            self.budget.sperren(86400, "Tarif deckt diesen Endpunkt nicht ab (HTTP 402)")
            self._merke(False, "Tarif deckt diesen Endpunkt nicht ab (HTTP 402)")
            raise RuntimeError("MASSIVE HTTP 402: Tarif deckt diesen Endpunkt nicht ab")
        if antwort.status_code == 429:
            self.budget.sperren(3600, "Ratenbegrenzung erreicht (HTTP 429)")
            self._merke(False, "Ratenbegrenzung erreicht (HTTP 429)")
            raise RuntimeError("MASSIVE HTTP 429: Ratenbegrenzung erreicht")
        if antwort.status_code >= 400:
            self._merke(False, f"HTTP {antwort.status_code}")
            raise RuntimeError(f"MASSIVE HTTP {antwort.status_code}")

        try:
            daten = antwort.json()
        except ValueError:
            self._merke(False, "Antwort nicht lesbar")
            raise RuntimeError("MASSIVE-Antwort nicht lesbar")
        status = str(daten.get("status", "")).upper()
        if status and status not in ("OK", "DELAYED", "SUCCESS"):
            self._merke(False, f"Status {status}")
            raise RuntimeError(f"MASSIVE-Status {status}")
        return daten

    def _merke(self, ok: bool, detail: str, count: int = 0) -> None:
        with self._lock:
            self._status = {"ok": bool(ok), "detail": str(detail)[:240],
                            "zeit": datetime.now(timezone.utc).isoformat(), "count": int(count)}

    def status(self) -> dict:
        with self._lock:
            eintrag = dict(self._status)
        eintrag["budget"] = self.budget.als_dict()
        eintrag["konfiguriert"] = self.konfiguriert
        return eintrag

    # -- Verbindungstest ----------------------------------------------------
    def verbindungstest(self) -> dict:
        """Prueft BEIDE Faehigkeiten getrennt: Referenzdaten und Nachrichten.

        Bis v8.1.1 hat dieser Test nur /v3/reference/tickers abgefragt und
        anschliessend "OK" gemeldet -- auch dann, wenn der tatsaechlich
        genutzte Nachrichtenendpunkt /v2/reference/news im gebuchten Tarif
        gar nicht enthalten war. Der Test hat also die falsche Sache
        geprueft und ein funktionierendes MASSIVE vorgetaeuscht, waehrend
        im Betrieb keine einzige Meldung ankam.
        """
        if not self.konfiguriert:
            return {"ok": False, "detail": "Kein API-Key hinterlegt"}

        faehigkeiten: dict[str, dict] = {}

        try:
            daten = self._get("/v3/reference/tickers", {"limit": 1, "active": "true"})
            anzahl = len(daten.get("results") or [])
            faehigkeiten["Referenzdaten"] = {
                "ok": True, "detail": f"erreichbar ({anzahl} Datensatz)", "count": anzahl}
        except RuntimeError as exc:
            faehigkeiten["Referenzdaten"] = {"ok": False, "detail": str(exc)}

        try:
            meldungen = self.news(limit=1)
            faehigkeiten["Nachrichten"] = {
                "ok": True, "detail": f"erreichbar ({len(meldungen)} Meldung)",
                "count": len(meldungen)}
        except RuntimeError as exc:
            text = str(exc)
            tarif = "402" in text or "403" in text
            faehigkeiten["Nachrichten"] = {
                "ok": False, "tarif": tarif,
                "detail": (f"nicht im Tarif enthalten ({text})" if tarif else text)}

        news_ok = bool(faehigkeiten["Nachrichten"].get("ok"))
        referenz_ok = bool(faehigkeiten["Referenzdaten"].get("ok"))
        # Als Nachrichtenquelle zaehlt MASSIVE nur, wenn die NACHRICHTEN gehen.
        gesamt_ok = news_ok
        if news_ok:
            detail = "Nachrichten und Referenzdaten erreichbar"
        elif referenz_ok:
            detail = ("Referenzdaten erreichbar, Nachrichten aber nicht: "
                      + str(faehigkeiten["Nachrichten"].get("detail", "")))
        else:
            detail = str(faehigkeiten["Referenzdaten"].get("detail", "nicht erreichbar"))

        self._merke(gesamt_ok, detail, int(faehigkeiten["Nachrichten"].get("count", 0) or 0))
        return {"ok": gesamt_ok, "detail": detail, "faehigkeiten": faehigkeiten,
                "count": int(faehigkeiten["Nachrichten"].get("count", 0) or 0)}

    # -- Referenzdaten ------------------------------------------------------
    def tickers(self, *, market: str = "stocks", limit: int = 1000,
                aktiv: bool = True, max_seiten: int = 5) -> list[dict]:
        """Tickerkatalog, seitenweise. Jede Seite kostet eine Anfrage."""
        gesammelt: list[dict] = []
        params = {"market": market, "limit": min(1000, max(1, int(limit))),
                  "active": "true" if aktiv else "false", "sort": "ticker", "order": "asc"}
        cursor = ""
        for _ in range(max(1, int(max_seiten))):
            if cursor:
                params["cursor"] = cursor
            daten = self._get("/v3/reference/tickers", params)
            treffer = daten.get("results") or []
            gesammelt.extend(treffer)
            weiter = str(daten.get("next_url") or "")
            if not weiter or not treffer:
                break
            cursor = weiter.split("cursor=")[-1] if "cursor=" in weiter else ""
            if not cursor:
                break
        self._merke(True, f"{len(gesammelt)} Ticker geladen", len(gesammelt))
        return gesammelt

    def ticker_details(self, ticker: str) -> dict:
        daten = self._get("/v3/reference/tickers", {"ticker": str(ticker).upper(), "limit": 1})
        treffer = daten.get("results") or []
        return treffer[0] if treffer else {}

    def ist_aktiv(self, ticker: str) -> Optional[bool]:
        """True/False, oder None wenn nicht feststellbar (z.B. Budget leer)."""
        try:
            eintrag = self.ticker_details(ticker)
        except RuntimeError:
            return None
        if not eintrag:
            return None
        return bool(eintrag.get("active", True))

    # -- Aggregierte Kurse --------------------------------------------------
    def tagesaggregate(self, ticker: str, tage: int = 30) -> list[dict]:
        """Tageskerzen fuer die Liquiditaetsbewertung."""
        ende = date.today()
        start = ende - timedelta(days=int(max(2, tage)) + 10)
        pfad = (f"/v2/aggs/ticker/{str(ticker).upper()}/range/1/day/"
                f"{start.isoformat()}/{ende.isoformat()}")
        daten = self._get(pfad, {"adjusted": "true", "sort": "desc", "limit": int(tage)})
        return list(daten.get("results") or [])

    def dollar_volumen(self, ticker: str, tage: int = 20) -> float:
        """Mittlerer Tagesumsatz in USD -- das Liquiditaetsmass fuer Aktien."""
        try:
            zeilen = self.tagesaggregate(ticker, tage=tage)
        except RuntimeError:
            return 0.0
        werte = []
        for zeile in zeilen[:tage]:
            volumen = float(zeile.get("v") or 0.0)
            preis = float(zeile.get("vw") or zeile.get("c") or 0.0)
            if volumen > 0 and preis > 0:
                werte.append(volumen * preis)
        return sum(werte) / len(werte) if werte else 0.0

    # -- Nachrichten --------------------------------------------------------
    def news(self, ticker: str = "", limit: int = 20) -> list[dict]:
        params: dict[str, Any] = {"limit": min(50, max(1, int(limit))), "order": "desc",
                                  "sort": "published_utc"}
        if ticker:
            params["ticker"] = str(ticker).upper()
        daten = self._get("/v2/reference/news", params)
        treffer = daten.get("results") or []
        self._merke(True, f"{len(treffer)} Meldungen", len(treffer))
        return treffer


__all__ = ["MassiveClient", "TagesBudget", "MASSIVE_BASE"]
