"""Mehrquellen-Nachrichtenadapter fuer TradingBot 8.2 NEXUS.

Ziel: Nachrichten- und Risikologik nutzt mehrere voneinander unabhaengige Quellen.

Quellen umfassen GDELT, SEC EDGAR, Nasdaq Halts, Yahoo/Google News sowie optional
Alpha Vantage, Finnhub, Financial Modeling Prep und MASSIVE.

Wichtig: Quellen ohne Zugangsdaten werden sauber uebersprungen. Positive
Event-Trades koennen in event_intelligence.py eine Mindest-Quellenvielfalt
verlangen; kritische negative/offizielle Meldungen duerfen weiterhin auch aus
einer einzelnen glaubwuerdigen Quelle einen Sicherheitsblock ausloesen.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from pathlib import Path
from urllib.parse import quote
import hashlib
import html
from email.utils import parsedate_to_datetime
import json
from safe_persistence import best_effort_json
import logging
import os
import re
import time
import threading
import xml.etree.ElementTree as ET

import requests
import config

logger = logging.getLogger(__name__)
ROOT = Path(__file__).resolve().parent

# Der Quellenstatus ist eine LAUFZEITdatei und gehoert damit in das
# Zustandsverzeichnis -- nicht in den Releasebaum. Vorher schrieb jeder
# Testlauf 'news_source_status.json' direkt neben den Quellcode, wodurch
# die Release-Hygienepruefung anschliessend zu Recht Alarm schlug.
_STATE_ROOT = Path(os.getenv("TRADINGBOT_TEST_STATE_DIR", "").strip() or ROOT)
STATUS_FILE = _STATE_ROOT / getattr(config, "NEWS_SOURCE_STATUS_FILE", "news_source_status.json")

# Gemeinsamer Prozess-Cache: NewsRadar und NachrichtenFilter teilen dieselben
# Provider-Antworten. Dadurch wird dieselbe Quelle im selben Zyklus nicht
# mehrfach abgefragt.
_GLOBAL_CACHE = {}
_GLOBAL_CACHE_LOCK = threading.RLock()



def _now_utc():
    return datetime.now(timezone.utc)


def _safe_dt(value):
    if value is None:
        return None
    if isinstance(value, datetime):
        return value if value.tzinfo else value.replace(tzinfo=timezone.utc)
    if isinstance(value, (int, float)):
        try:
            return datetime.fromtimestamp(float(value), tz=timezone.utc)
        except Exception:
            return None
    s = str(value).strip()
    if not s:
        return None
    try:
        if "," in s and ("GMT" in s.upper() or "+" in s or "-" in s[8:]):
            dt = parsedate_to_datetime(s)
            return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)
    except Exception:
        __import__("logging").getLogger(__name__).debug("Best-effort-Ausnahme unterdrueckt", exc_info=True)
    # Alpha Vantage: 20260817T145900
    for fmt in ("%Y%m%dT%H%M%S", "%Y-%m-%dT%H:%M:%S%z", "%Y-%m-%dT%H:%M:%SZ",
                "%Y-%m-%d %H:%M:%S", "%Y-%m-%d"):
        try:
            dt = datetime.strptime(s, fmt)
            return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)
        except Exception:
            __import__("logging").getLogger(__name__).debug("Best-effort-Ausnahme unterdrueckt", exc_info=True)
    try:
        dt = datetime.fromisoformat(s.replace("Z", "+00:00"))
        return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)
    except Exception:
        return None


def _clean_text(text):
    s = html.unescape(str(text or ""))
    s = re.sub(r"<[^>]+>", " ", s)
    s = re.sub(r"\s+", " ", s).strip()
    return s


def _headline_key(headline, url=""):
    # URL ist bei Syndizierung oft verschieden; Titel normalisieren.
    text = _clean_text(headline).lower()
    text = re.sub(r"[^a-z0-9äöüß]+", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    if len(text) >= 24:
        return text[:180]
    return (str(url or "").split("?")[0] or text)[:220]


def _within_hours(dt, hours):
    if not dt:
        return True
    try:
        return dt >= _now_utc() - timedelta(hours=max(1, int(hours)))
    except Exception:
        return True


@dataclass
class NewsItem:
    source: str
    headline: str
    summary: str = ""
    url: str = ""
    published_at: datetime | None = None
    symbols: list[str] = field(default_factory=list)
    provider_weight: float = 1.0
    providers: list[str] = field(default_factory=list)
    official: bool = False
    metadata: dict = field(default_factory=dict)

    def __post_init__(self):
        self.headline = _clean_text(self.headline)
        self.summary = _clean_text(self.summary)
        self.symbols = sorted({str(x).upper().replace("/", "") for x in (self.symbols or []) if str(x).strip()})
        if not self.providers:
            self.providers = [self.source]

    def text(self):
        return f"{self.headline} {self.summary}".strip()

    def as_dict(self):
        return {
            "source": self.source,
            "providers": list(self.providers),
            "headline": self.headline,
            "summary": self.summary,
            "url": self.url,
            "published_at": self.published_at.isoformat() if self.published_at else "",
            "symbols": list(self.symbols),
            "official": bool(self.official),
        }


@dataclass
class NewsBundle:
    items: list[NewsItem] = field(default_factory=list)
    sources_ok: list[str] = field(default_factory=list)
    sources_failed: dict = field(default_factory=dict)
    sources_skipped: list[str] = field(default_factory=list)
    sources_backoff: dict = field(default_factory=dict)

    @property
    def source_count(self):
        return len(set(self.sources_ok))

    @property
    def provider_names(self):
        names = set()
        for item in self.items:
            names.update(item.providers or [item.source])
        return sorted(names)

    def as_dicts(self):
        return [x.as_dict() for x in self.items]


class MultiSourceNews:
    ALPHA_URL = "https://www.alphavantage.co/query"
    FINNHUB_BASE = "https://finnhub.io/api/v1"
    FMP_BASE = "https://financialmodelingprep.com/stable"
    SEC_TICKERS = "https://www.sec.gov/files/company_tickers.json"
    SEC_SUBMISSIONS = "https://data.sec.gov/submissions/CIK{cik:010d}.json"
    GDELT_DOC = "https://api.gdeltproject.org/api/v2/doc/doc"
    YAHOO_RSS = "https://feeds.finance.yahoo.com/rss/2.0/headline"
    GOOGLE_NEWS_RSS = "https://news.google.com/rss/search"
    NASDAQ_HALTS_RSS = "https://www.nasdaqtrader.com/rss.aspx?feed=tradehalts"

    def __init__(self):
        self.session = requests.Session()
        # Klarer, normaler HTTP-Client fuer die aktiv gepflegten Quellen.
        self.session.headers.update({
            "User-Agent": "TradingBot/8.1.1-NEXUS (+local private trading assistant)",
            "Accept": "application/json, text/plain, */*",
        })
        self.timeout = float(getattr(config, "NEWS_SOURCE_TIMEOUT_SECONDS", 10))
        self.max_each = int(getattr(config, "NEWS_SOURCE_MAX_PER_PROVIDER", 10))
        self._cache = _GLOBAL_CACHE
        self._status = self._load_status()
        self._sec_tickers_cache = None
        self._sec_tickers_loaded_at = 0.0
        self._massive_client = None

    # ------------------------------- Status -------------------------------
    def _load_status(self):
        try:
            return json.loads(STATUS_FILE.read_text(encoding="utf-8")) if STATUS_FILE.exists() else {}
        except Exception:
            return {}

    def _save_status(self):
        best_effort_json(STATUS_FILE, self._status, label="News-Quellenstatus")

    def _mark(self, source, ok, detail="", count=0, backoff_seconds=0):
        now = _now_utc()
        old = self._status.get(source, {}) if isinstance(self._status.get(source, {}), dict) else {}
        failures = 0 if ok else int(old.get("consecutive_failures", 0) or 0) + 1
        retry_at = ""
        if (not ok) and backoff_seconds:
            retry_at = (now + timedelta(seconds=max(1, int(backoff_seconds)))).isoformat()
        self._status[source] = {
            "ok": bool(ok),
            "detail": str(detail)[:500],
            "count": int(count),
            "time": now.isoformat(),
            "consecutive_failures": failures,
            "next_retry_at": retry_at,
        }
        self._save_status()
        return failures

    def _backoff_remaining(self, source):
        row = self._status.get(source, {}) if isinstance(self._status.get(source, {}), dict) else {}
        value = row.get("next_retry_at")
        if not value:
            return 0
        dt = _safe_dt(value)
        if not dt:
            return 0
        return max(0, int((dt - _now_utc()).total_seconds()))

    # Fehler, die sich durch Warten NICHT beheben: Der Tarif deckt den
    # Endpunkt nicht ab oder der Schluessel ist ungueltig. Ein stuendlicher
    # Wiederholungsversuch erzeugt hier nur Protokollrauschen und Last.
    _DAUERHAFTE_FEHLER = (
        "402", "payment required",
        "401", "unauthorized", "invalid api key", "invalid token",
        "403 forbidden" ,
        "you don't have access", "not available under your", "upgrade your plan",
        "exclusive endpoint", "premium",
    )

    def _ist_dauerhaft(self, text: str) -> bool:
        return any(x in text for x in self._DAUERHAFTE_FEHLER)

    def _failure_backoff(self, source, exc):
        text = str(exc).lower()

        # Tarif-/Schluesselprobleme: sehr lange pausieren statt staendig
        # neu zu versuchen. Der Nutzer sieht den Grund im Status und kann
        # die Quelle bewusst abschalten oder einen Tarif waehlen.
        if self._ist_dauerhaft(text):
            return int(getattr(config, "NEWS_SOURCE_PLAN_BACKOFF_SECONDS", 86400))

        if any(x in text for x in ("25 requests per day", "daily api rate", "daily limit")):
            return int(getattr(config, "NEWS_SOURCE_DAILY_LIMIT_BACKOFF_SECONDS", 21600))
        if any(x in text for x in ("429", "492", "too many requests", "rate limit")):
            # GDELT ist in der kostenlosen Nutzung besonders streng und
            # antwortet schnell mit 429. Eine kurze Pause fuehrt direkt in
            # die naechste Sperre -- deshalb hier deutlich laenger.
            if source.upper() == "GDELT":
                return int(getattr(config, "NEWS_SOURCE_GDELT_RATE_BACKOFF_SECONDS", 7200))
            return int(getattr(config, "NEWS_SOURCE_RATE_LIMIT_BACKOFF_SECONDS", 3600))
        base = int(getattr(config, "NEWS_SOURCE_FAILURE_BACKOFF_SECONDS", 600))
        prev = self._status.get(source, {}) if isinstance(self._status.get(source, {}), dict) else {}
        n = max(0, int(prev.get("consecutive_failures", 0) or 0))
        return min(int(getattr(config, "NEWS_SOURCE_MAX_BACKOFF_SECONDS", 3600)), base * (2 ** min(n, 3)))

    def health_snapshot(self):
        """Lokaler Quellenstatus ohne Netzwerkzugriff.

        ``configured`` bedeutet: aktiviert und erforderliche Zugangsdaten sind
        vorhanden. ``healthy`` bedeutet: der letzte echte Abruf war erfolgreich
        und ist fuer die jeweilige Cache-Dauer noch hinreichend aktuell.
        """
        conf = self.provider_configuration()
        out = {}
        for name, configured in conf.items():
            row = self._status.get(name, {}) if isinstance(self._status.get(name, {}), dict) else {}
            dt = _safe_dt(row.get("time"))
            age = ((_now_utc() - dt).total_seconds() if dt else None)
            max_age = max(1800, self._ttl(name) * int(getattr(config, "NEWS_SOURCE_HEALTH_TTL_MULTIPLIER", 3)))
            backoff = self._backoff_remaining(name)
            if not configured:
                state = "disabled"
            elif not row:
                state = "unknown"
            elif backoff > 0 and not row.get("ok"):
                state = "backoff"
            elif bool(row.get("ok")) and (age is None or age <= max_age):
                state = "ok"
            elif bool(row.get("ok")):
                state = "stale"
            else:
                state = "error"
            out[name] = {
                "configured": bool(configured),
                "state": state,
                "healthy": state == "ok",
                "detail": str(row.get("detail", "")),
                "count": int(row.get("count", 0) or 0),
                "time": str(row.get("time", "")),
                "age_seconds": age,
                "backoff_seconds": backoff,
                "consecutive_failures": int(row.get("consecutive_failures", 0) or 0),
            }
        return out

    def provider_configuration(self):
        """Welche Quellen sind JETZT aktiv?

        Ab v8.1.2 kommen Schalter und Schluessel aus live_settings und damit
        direkt aus der Zugangsdatei. Vorher stammten sie aus config.py, das
        nur beim Prozessstart gelesen wird -- ein in der WebUI umgelegter
        Schalter blieb dadurch wirkungslos, bis Core und WebUI neu starteten.
        Das war die eigentliche Ursache der "News gehen nicht"-Meldungen.
        """
        import live_settings as ls
        return {
            "SEC EDGAR": bool(ls.quelle_aktiv("sec_edgar") and ls.sec_kontakt()),
            "Nasdaq Halts": bool(ls.quelle_aktiv("nasdaq_halts")),
            "Yahoo Finance": bool(ls.quelle_aktiv("yahoo_finance")),
            "Google News": bool(ls.quelle_aktiv("google_news")),
            "GDELT": bool(ls.quelle_aktiv("gdelt")),
            "Alpha Vantage": bool(ls.quelle_aktiv("alpha_vantage") and ls.alpha_vantage_key()),
            "Finnhub": bool(ls.quelle_aktiv("finnhub") and ls.finnhub_key()),
            # FMP hat ZWEI getrennte Faehigkeiten. Im Gratistarif liefert die
            # Symbolsuche Daten, waehrend die News-Endpunkte mit HTTP 402
            # antworten. Ein 402 der News darf die funktionierende
            # Symbolsuche deshalb nicht mitreissen.
            "FMP": bool(ls.quelle_aktiv("fmp") and ls.fmp_key()
                        and bool(getattr(config, "FMP_NEWS_ENABLED", False))),
            "FMP Symbol Search": bool(ls.quelle_aktiv("fmp") and ls.fmp_key()),
            "MASSIVE": bool(ls.quelle_aktiv("massive") and ls.massive_key()),
        }

    # ------------------------------- Cache --------------------------------
    def _cache_get(self, key, ttl):
        with _GLOBAL_CACHE_LOCK:
            row = self._cache.get(key)
            if row and (time.time() - row[0]) < ttl:
                return row[1]
        return None

    def _cache_put(self, key, value):
        with _GLOBAL_CACHE_LOCK:
            self._cache[key] = (time.time(), value)
        return value

    def _ttl(self, source):
        defaults = {
            "Alpha Vantage": 7200,  # API-Budget schonen; Marktfeed reicht meist
            "Finnhub": 1800,
            "FMP": 1800,
            "FMP Symbol Search": 1800,
            "MASSIVE": 1800,
            "SEC EDGAR": 1800,
            "Nasdaq Halts": 60,
            "Yahoo Finance": 900,
            "Google News": 900,
            "GDELT": 600,
        }
        attr = "NEWS_SOURCE_" + source.upper().replace(".", "_").replace(" ", "_") + "_CACHE_SECONDS"
        return int(getattr(config, attr, defaults[source]))

    # ----------------------------- Provider --------------------------------

    def _gdelt(self, symbol=None, hours=48, market=False):
        """GDELT is used only for broad market/crisis context in v5.6.

        Short ticker symbols are too ambiguous for a global media corpus.
        Company-specific research uses SEC/Yahoo/Google instead.
        """
        if symbol:
            return []
        if not self.provider_configuration().get("GDELT"):
            return None
        key=("gdelt","MARKET",int(hours))
        cached=self._cache_get(key,self._ttl("GDELT"))
        if cached is not None:return cached
        query='(stocks OR shares OR earnings OR markets OR recession OR inflation OR crisis) sourcecountry:US'
        params={"query":query,"mode":"ArtList","format":"json","maxrecords":min(50,self.max_each*3),
                "timespan":f"{max(1,int(hours))}h","sort":"HybridRel"}
        r=self.session.get(self.GDELT_DOC,params=params,timeout=self.timeout);r.raise_for_status();raw=r.json()
        out=[]
        for a in (raw.get("articles",[]) if isinstance(raw,dict) else []):
            title=a.get("title") or "";url=a.get("url") or ""
            if not title:continue
            dt=_safe_dt(a.get("seendate"))
            if not _within_hours(dt,hours):continue
            domain=str(a.get("domain") or "")
            out.append(NewsItem("GDELT Market",title,domain,url,dt,[],0.65,metadata={"domain":domain,"language":a.get("language"),"scope":"market"}))
            if len(out)>=self.max_each:break
        self._mark("GDELT",True,"Markt-/Krisenfeed erreichbar",len(out))
        return self._cache_put(key,out)

    def _company_name(self, symbol: str) -> str:
        try:
            row=self._sec_ticker_map().get(str(symbol).upper()) or {}
            return _clean_text(row.get("title") or symbol)
        except Exception:
            return str(symbol)

    def _yahoo(self, symbol=None, hours=48, market=False):
        """Ticker-specific Yahoo news via the already-installed yfinance client.

        The old feeds.finance.yahoo.com RSS URL started returning HTTP 404 in
        our live verification and is therefore no longer queried. This source
        is best-effort/medium weight; SEC/Nasdaq remain the hard signals.
        """
        if not symbol or not self.provider_configuration().get("Yahoo Finance"):
            return None
        key=("yahoo-yfinance",str(symbol).upper(),int(hours))
        cached=self._cache_get(key,self._ttl("Yahoo Finance"))
        if cached is not None:return cached
        try:
            import yfinance as yf
            rows=(yf.Ticker(str(symbol).upper()).news or [])[:self.max_each*3]
            out=[]
            for row in rows:
                if not isinstance(row,dict):continue
                c=row.get("content") if isinstance(row.get("content"),dict) else row
                title=_clean_text(c.get("title") or row.get("title"))
                summary=_clean_text(c.get("summary") or row.get("summary") or "")
                can=c.get("canonicalUrl") if isinstance(c,dict) else None
                link=(can or {}).get("url") if isinstance(can,dict) else (c.get("link") or row.get("link") or "")
                pub=_safe_dt(c.get("pubDate") or row.get("providerPublishTime") or c.get("displayTime"))
                if title and _within_hours(pub,hours):
                    out.append(NewsItem("Yahoo Finance",title,summary,link,pub,[symbol],0.80,metadata={"feed":"yfinance"}))
                if len(out)>=self.max_each:break
            self._mark("Yahoo Finance",True,"Ticker-News via yfinance erreichbar",len(out))
            return self._cache_put(key,out)
        except Exception as exc:
            raise RuntimeError(f"Yahoo/yfinance News nicht erreichbar: {exc}") from exc

    def _google_news(self, symbol=None, hours=48, market=False):
        if not symbol or not self.provider_configuration().get("Google News"):
            return None
        key=("google-news",str(symbol).upper(),int(hours));cached=self._cache_get(key,self._ttl("Google News"))
        if cached is not None:return cached
        name=self._company_name(symbol)
        params={"q":f'"{name}" when:{max(1,int(hours/24) or 1)}d',"hl":"en-US","gl":"US","ceid":"US:en"}
        r=self.session.get(self.GOOGLE_NEWS_RSS,params=params,headers={"User-Agent":"Mozilla/5.0 TradingBot/5.6"},timeout=self.timeout);r.raise_for_status();root=ET.fromstring(r.content)
        out=[]
        for node in root.findall(".//item")[:self.max_each*2]:
            title=_clean_text(node.findtext("title"));link=_clean_text(node.findtext("link"));pub=_safe_dt(node.findtext("pubDate"));src=node.find("source");publisher=_clean_text(src.text if src is not None else "")
            if title and _within_hours(pub,hours):out.append(NewsItem("Google News",title,publisher,link,pub,[symbol],0.70,metadata={"publisher":publisher,"company_name":name}))
            if len(out)>=self.max_each:break
        self._mark("Google News",True,"Firmennamen-RSS erreichbar",len(out));return self._cache_put(key,out)

    def _nasdaq_halts(self, symbol=None, hours=48, market=False):
        if not self.provider_configuration().get("Nasdaq Halts"):return None
        key=("nasdaq-halts",int(hours));cached=self._cache_get(key,self._ttl("Nasdaq Halts"))
        if cached is None:
            r=self.session.get(self.NASDAQ_HALTS_RSS,headers={"User-Agent":"Mozilla/5.0 TradingBot/5.6"},timeout=self.timeout);r.raise_for_status();root=ET.fromstring(r.content);rows=[]
            for node in root.findall(".//item")[:100]:
                title=_clean_text(node.findtext("title"));desc=_clean_text(node.findtext("description"));link=_clean_text(node.findtext("link"));pub=_safe_dt(node.findtext("pubDate"))
                text=f"{title} {desc}"
                m=re.search(r'\b([A-Z]{1,6})\b',title or '')
                syms=[m.group(1)] if m else []
                if title:rows.append(NewsItem("Nasdaq Halts",title,desc,link,pub,syms,1.00,official=True,metadata={"hard_signal":True}))
            cached=self._cache_put(key,rows);self._mark("Nasdaq Halts",True,"Offizieller Trading-Halt-RSS erreichbar",len(rows))
        if not symbol:return cached
        sym=str(symbol).upper();return [x for x in cached if sym in x.symbols or re.search(r'(?<![A-Z0-9])'+re.escape(sym)+r'(?![A-Z0-9])',x.text(),re.I)]

    def _alpha(self, symbol=None, hours=48, market=False):
        if not self.provider_configuration()["Alpha Vantage"]:
            return None
        key = ("alpha", symbol or "MARKET", int(hours))
        cached = self._cache_get(key, self._ttl("Alpha Vantage"))
        if cached is not None:
            return cached
        params = {"function": "NEWS_SENTIMENT", "limit": self.max_each,
                  "apikey": __import__("live_settings").alpha_vantage_key()}
        if symbol:
            params["tickers"] = symbol
        params["time_from"] = (_now_utc() - timedelta(hours=hours)).strftime("%Y%m%dT%H%M")
        r = self.session.get(self.ALPHA_URL, params=params, timeout=self.timeout)
        r.raise_for_status(); raw = r.json()
        if isinstance(raw, dict) and (raw.get("Information") or raw.get("Note")):
            raise RuntimeError(raw.get("Information") or raw.get("Note"))
        out = []
        for a in (raw.get("feed", []) if isinstance(raw, dict) else []):
            syms = []
            for ts in a.get("ticker_sentiment", []) or []:
                if ts.get("ticker"):
                    syms.append(ts["ticker"])
            out.append(NewsItem("Alpha Vantage", a.get("title", ""), a.get("summary", ""), a.get("url", ""),
                                _safe_dt(a.get("time_published")), syms, 0.86))
        self._mark("Alpha Vantage", True, "NEWS_SENTIMENT erreichbar", len(out))
        return self._cache_put(key, out)

    def _finnhub(self, symbol=None, hours=48, market=False):
        if not self.provider_configuration()["Finnhub"]:
            return None
        key = ("finnhub", symbol or "MARKET", int(hours))
        cached = self._cache_get(key, self._ttl("Finnhub"))
        if cached is not None:
            return cached
        api_key = __import__("live_settings").finnhub_key()
        if symbol:
            start = (_now_utc() - timedelta(hours=hours)).date().isoformat()
            end = _now_utc().date().isoformat()
            url = self.FINNHUB_BASE + "/company-news"
            params = {"symbol": symbol, "from": start, "to": end, "token": api_key}
        else:
            url = self.FINNHUB_BASE + "/news"
            params = {"category": "general", "token": api_key}
        r = self.session.get(url, params=params, timeout=self.timeout)
        r.raise_for_status(); rows = r.json()
        out = []
        for a in (rows or [])[: self.max_each]:
            dt = _safe_dt(a.get("datetime"))
            if not _within_hours(dt, hours):
                continue
            syms = [symbol] if symbol else []
            if a.get("related"):
                syms += [x.strip() for x in str(a.get("related")).split(",") if x.strip()]
            out.append(NewsItem("Finnhub", a.get("headline", ""), a.get("summary", ""), a.get("url", ""), dt, syms, 0.90))
        self._mark("Finnhub", True, "Company/General News erreichbar", len(out))
        return self._cache_put(key, out)

    def _fmp_get(self, path: str, params: dict | None = None):
        """FMP Stable API ohne API-Key-Leak in Exceptions/Logs."""
        api_key = __import__("live_settings").fmp_key()
        if not api_key:
            raise RuntimeError("FMP API-Key fehlt")
        query = dict(params or {})
        query["apikey"] = api_key
        r = self.session.get(self.FMP_BASE + str(path), params=query, timeout=self.timeout)
        try:
            data = r.json() if getattr(r, "content", b"") else []
        except ValueError:
            data = None
        if not r.ok:
            detail = ""
            if isinstance(data, dict):
                detail = str(data.get("Error Message") or data.get("error") or data.get("message") or "")
            if not detail:
                detail = str(getattr(r, "reason", "") or "Request fehlgeschlagen")
            raise RuntimeError(f"FMP HTTP {r.status_code}: {detail[:240]}")
        if isinstance(data, dict):
            detail = data.get("Error Message") or data.get("error")
            if detail:
                raise RuntimeError(f"FMP API: {str(detail)[:240]}")
        return data

    def fmp_search_symbol(self, symbol: str, limit: int = 10) -> list[dict]:
        """Aktuelle FMP Stable Symbolsuche (read-only, Diagnose/Validierung)."""
        if not self.provider_configuration().get("FMP Symbol Search"):
            return []
        rows = self._fmp_get("/search-symbol", {"query": str(symbol).upper(), "limit": max(1,min(50,int(limit)))})
        out = list(rows or []) if isinstance(rows, list) else []
        self._mark("FMP Symbol Search", True, "Stable Symbolsuche erreichbar", len(out))
        return out

    def fmp_diagnostic(self, symbol: str = "AAPL") -> dict:
        """Expliziter FMP-Key/Stable-Endpoint-Test ohne Handelswirkung.

        Respektiert denselben Provider-Backoff wie der Live-News-Pfad, damit
        ein manueller Test nach HTTP 429/Quota-Fehler nicht sofort erneut
        gegen denselben Dienst feuert.
        """
        symbol=str(symbol or "AAPL").upper().strip()
        if not self.provider_configuration().get("FMP Symbol Search"):
            return {"configured": False, "symbol": symbol, "resolved": False, "news": 0}
        remaining = self._backoff_remaining("FMP")
        if remaining > 0:
            return {
                "configured": True, "symbol": symbol, "resolved": False, "news": 0,
                "backoff_seconds": remaining,
                "detail": f"FMP nach vorherigem Fehler noch ca. {max(1, remaining // 60)} min pausiert",
            }
        rows=self.fmp_search_symbol(symbol, limit=10)
        exact=next((r for r in rows if str(r.get("symbol","")).upper()==symbol), None)
        news=self._fmp(symbol, hours=168) or []
        return {
            "configured": True, "symbol": symbol, "resolved": bool(exact),
            "company": str((exact or {}).get("name") or (exact or {}).get("companyName") or ""),
            "exchange": str((exact or {}).get("exchange") or (exact or {}).get("exchangeShortName") or ""),
            "news": len(news),
        }

    def _fmp(self, symbol=None, hours=48, market=False):
        if not self.provider_configuration()["FMP"]:
            return None
        key = ("fmp", symbol or "MARKET", int(hours))
        cached = self._cache_get(key, self._ttl("FMP"))
        if cached is not None:
            return cached
        if symbol:
            rows = self._fmp_get("/news/stock", {
                "symbols": str(symbol).upper(),
                "from": (_now_utc()-timedelta(hours=hours)).date().isoformat(),
                "to": _now_utc().date().isoformat(),
                "limit": self.max_each,
            })
        else:
            # Fuer ein Aktienuniversum ist stock-latest zielgerichteter als
            # allgemeine Nachrichten ohne Tickerbezug. Ein Abruf wird gecacht.
            rows = self._fmp_get("/news/stock-latest", {"page": 0, "limit": self.max_each})
        out = []
        for a in (rows or [])[: self.max_each]:
            dt = _safe_dt(a.get("publishedDate") or a.get("publishedAt") or a.get("date"))
            if not _within_hours(dt, hours):
                continue
            syms = []
            raw_sym = a.get("symbol") or a.get("symbols")
            if isinstance(raw_sym, list): syms = raw_sym
            elif raw_sym: syms = [x.strip() for x in str(raw_sym).split(",") if x.strip()]
            if symbol and not syms: syms = [symbol]
            out.append(NewsItem("FMP", a.get("title", ""), a.get("text") or a.get("snippet") or "",
                                a.get("url") or a.get("link") or "", dt, syms, 0.86))
        self._mark("FMP", True, "Stable Stock-News erreichbar", len(out))
        return self._cache_put(key, out)

    def _massive(self, symbol=None, hours=48, market=False):
        if not self.provider_configuration().get("MASSIVE"):
            return None
        key = ("massive-news", symbol or "MARKET", int(hours))
        cached = self._cache_get(key, self._ttl("MASSIVE"))
        if cached is not None:
            return cached
        if self._massive_client is None:
            from massive_api import MassiveClient
            self._massive_client = MassiveClient()
        rows = self._massive_client.news(str(symbol or ""), limit=self.max_each)
        out = []
        for row in rows:
            dt = _safe_dt(row.get("published_utc"))
            if not _within_hours(dt, hours):
                continue
            out.append(NewsItem(
                "MASSIVE", row.get("title", ""), row.get("description", ""),
                row.get("article_url", ""), dt, row.get("tickers") or ([symbol] if symbol else []),
                0.90, metadata={"publisher": (row.get("publisher") or {}).get("name", "")},
            ))
        self._mark("MASSIVE", True, "Reference News erreichbar", len(out))
        return self._cache_put(key, out)

    def _sec_headers(self):
        email = __import__("live_settings").sec_kontakt()
        return {"User-Agent": f"TradingBot/8.1.1-NEXUS {email}", "Accept-Encoding": "gzip, deflate"}

    def _sec_ticker_map(self):
        if self._sec_tickers_cache is not None and time.time()-self._sec_tickers_loaded_at < 86400:
            return self._sec_tickers_cache
        r = self.session.get(self.SEC_TICKERS, headers=self._sec_headers(), timeout=self.timeout)
        r.raise_for_status(); raw = r.json()
        mapping = {}
        rows = raw.values() if isinstance(raw, dict) else raw
        for row in rows or []:
            t = str(row.get("ticker", "")).upper()
            if t:
                mapping[t] = {"cik": int(row.get("cik_str")), "title": row.get("title", "")}
        self._sec_tickers_cache = mapping; self._sec_tickers_loaded_at = time.time()
        return mapping

    def _sec(self, symbol=None, hours=48, market=False):
        if not symbol or not self.provider_configuration()["SEC EDGAR"]:
            return None
        key = ("sec", symbol, int(hours))
        cached = self._cache_get(key, self._ttl("SEC EDGAR"))
        if cached is not None:
            return cached
        row = self._sec_ticker_map().get(symbol.upper())
        if not row:
            return self._cache_put(key, [])
        cik = row["cik"]
        r = self.session.get(self.SEC_SUBMISSIONS.format(cik=cik), headers=self._sec_headers(), timeout=self.timeout)
        r.raise_for_status(); raw = r.json(); rec = ((raw.get("filings") or {}).get("recent") or {})
        forms = rec.get("form", []) or []
        dates = rec.get("filingDate", []) or []
        accessions = rec.get("accessionNumber", []) or []
        docs = rec.get("primaryDocument", []) or []
        items_col = rec.get("items", []) or []
        accepted = {"8-K", "8-K/A", "10-Q", "10-Q/A", "10-K", "10-K/A", "6-K", "20-F", "424B", "S-3", "S-1"}
        cutoff = (_now_utc() - timedelta(hours=hours)).date()
        out = []
        for i, form in enumerate(forms[:80]):
            if form not in accepted:
                continue
            try:
                d = datetime.strptime(dates[i], "%Y-%m-%d").date()
                if d < cutoff: continue
            except Exception:
                d = _now_utc().date()
            acc = str(accessions[i]).replace("-", "") if i < len(accessions) else ""
            doc = docs[i] if i < len(docs) else ""
            filing_items = items_col[i] if i < len(items_col) else ""
            url = f"https://www.sec.gov/Archives/edgar/data/{cik}/{acc}/{quote(str(doc))}" if acc and doc else ""
            # Richtung wird absichtlich NICHT geraten. SEC ist ein offizieller
            # Event-/Risikobeleg, nicht automatisch bullish/bearish.
            headline = f"SEC filing {form} – {row.get('title') or symbol}"
            summary = f"Offizielle EDGAR-Meldung. Items: {filing_items or 'n/a'}"
            out.append(NewsItem("SEC EDGAR", headline, summary, url,
                                datetime.combine(d, datetime.min.time(), tzinfo=timezone.utc), [symbol], 1.00,
                                official=True, metadata={"form": form, "items": filing_items}))
            if len(out) >= self.max_each:
                break
        self._mark("SEC EDGAR", True, "Company Submissions erreichbar", len(out))
        return self._cache_put(key, out)

    # -------------------------- Aggregation -------------------------------
    def _provider_call(self, name, fn, bundle):
        configured = self.provider_configuration().get(name, False)
        if not configured:
            bundle.sources_skipped.append(name)
            return []

        remaining = self._backoff_remaining(name)
        if remaining > 0:
            detail = f"temporär pausiert nach Fehler; neuer Versuch in ca. {max(1, remaining // 60)} min"
            bundle.sources_backoff[name] = detail
            bundle.sources_failed[name] = detail
            return []

        try:
            rows = fn()
            if rows is None:
                bundle.sources_skipped.append(name)
                return []
            bundle.sources_ok.append(name)
            return rows
        except Exception as exc:
            bundle.sources_failed[name] = str(exc)
            backoff = self._failure_backoff(name, exc)
            failures = self._mark(name, False, exc, 0, backoff_seconds=backoff)
            # Nur der erste Fehler einer Serie kommt als WARNING ins Log.
            # Danach verhindert Backoff Log-Spam und unnoetige Requests.
            log = logger.warning if failures <= 1 else logger.debug
            log("Newsquelle %s fehlgeschlagen (Pause %ss): %s", name, backoff, exc)
            return []

    @staticmethod
    def _dedupe(items):
        """Merge exact and near-duplicate syndicated headlines.

        Two publishers repeating the same original press release must not count
        as independent evidence. We therefore merge both canonical URL/exact
        headline duplicates and highly similar normalized headline token sets.
        """
        merged=[]
        def tokens(text):
            return {x for x in re.findall(r"[a-z0-9]{3,}",str(text).lower())
                    if x not in {"the","and","for","with","from","after","says","new","inc","corp"}}
        for item in items:
            if not item.headline:continue
            exact=_headline_key(item.headline,item.url)
            itok=tokens(item.headline)
            found=None
            for old,old_exact,otok in merged:
                similar=False
                if exact==old_exact:
                    similar=True
                elif itok and otok:
                    j=len(itok & otok)/max(1,len(itok | otok))
                    similar=(j>=0.78 and len(itok & otok)>=4)
                if similar:
                    found=old;break
            if found is not None:
                found.providers=sorted(set(found.providers+item.providers))
                found.symbols=sorted(set(found.symbols+item.symbols))
                found.official=found.official or item.official
                if len(item.summary)>len(found.summary):found.summary=item.summary
                if not found.url and item.url:found.url=item.url
                found.provider_weight=max(found.provider_weight,item.provider_weight)
            else:
                merged.append((item,exact,itok))
        rows=[x[0] for x in merged]
        rows.sort(key=lambda x:x.published_at or datetime.min.replace(tzinfo=timezone.utc),reverse=True)
        return rows

    def _attach_symbols(self, items, universe):
        symbols = [str(x).upper() for x in (universe or [])]
        if not symbols:
            return items
        # Erst exakte Ticker-Tokens. Fuer Ueberschriften, die meist den
        # Firmennamen statt AAPL/MSFT nennen, darf
        # optional der offizielle SEC-Ticker->Firmenname-Datensatz helfen.
        patterns = {
            s: re.compile(r"(?<![A-Z0-9])" + re.escape(s) + r"(?![A-Z0-9])", re.I)
            for s in symbols if len(s) >= 2
        }
        name_patterns = {}
        if bool(getattr(config, "NEWS_COMPANY_NAME_MATCH_ENABLED", True)):
            try:
                mapping = self._sec_ticker_map() if self.provider_configuration().get("SEC EDGAR") else {}
                suffix = re.compile(
                    r"\s+(incorporated|inc\.?|corp\.?|corporation|company|co\.?|plc|ltd\.?|limited|holdings?)$",
                    re.I,
                )
                for sym in symbols:
                    title = _clean_text((mapping.get(sym) or {}).get("title", ""))
                    title = suffix.sub("", title).strip(" .,-")
                    if len(title) >= 4:
                        name_patterns[sym] = re.compile(r"\b" + re.escape(title) + r"\b", re.I)
            except Exception as exc:
                logger.debug("Firmenname-Zuordnung aus SEC nicht verfuegbar: %s", exc)
        for item in items:
            if item.symbols:
                continue
            text = item.text()
            source=str(getattr(item,"source","") or "").upper()
            # GDELT bleibt bewusst eine breite Markt-/Krisenquelle. Kurze
            # Ticker wie KO, ALL oder ALGO sind dort zu mehrdeutig und duerfen
            # keine Einzelaktie priorisieren. Falls ueberhaupt eine Firma aus
            # GDELT zugeordnet wird, dann nur ueber den offiziellen SEC-Namen.
            if source == "GDELT":
                found = [sym for sym, pat in name_patterns.items() if pat.search(text)] if name_patterns else []
            else:
                found = [sym for sym, pat in patterns.items() if pat.search(text)]
                if not found and name_patterns:
                    found = [sym for sym, pat in name_patterns.items() if pat.search(text)]
            if found:
                item.symbols = found[:8]
        return items

    def _market_items_for_symbol(self, symbol, hours=48):
        """Bereits gepoolte Markt-News fuer ein Symbol nutzen.

        Das ist der wichtigste API-Schutz der v5.2: breite Feeds werden einmal
        pro Cache-Fenster geladen und fuer das gesamte Aktienuniversum wiederverwendet.
        Erst danach werden – falls erlaubt – gezielte Company-News nachgeladen.
        """
        market = self.fetch_market(hours=hours, universe=[symbol])
        symbol = str(symbol).upper().replace("/", "")
        pat = re.compile(r"(?<![A-Z0-9])" + re.escape(symbol) + r"(?![A-Z0-9])", re.I)
        rows = []
        for item in market.items:
            if symbol in item.symbols or pat.search(item.text()):
                rows.append(item)
        return rows, market

    def fetch_symbol(self, symbol, hours=48, focused=True):
        """Nachrichten fuer ein Instrument.

        Stufe 1: kostenlose Kernfeeds (GDELT/SEC) plus optionale Zusatzquellen
        aus dem Prozess-Cache filtern.
        Stufe 2: gezielte Company-Abfragen nur fuer Quellen, bei denen sie
        aktiviert sind. Alpha Vantage focused ist standardmaessig AUS, damit
        ein begrenztes API-Budget nicht beim Durchlauf durch das Aktienuniversum
        verbraucht wird.
        """
        symbol = str(symbol).upper().replace("/", "")
        bundle = NewsBundle(); items = []

        pooled, market_bundle = self._market_items_for_symbol(symbol, hours)
        items.extend(pooled)
        bundle.sources_ok.extend(market_bundle.sources_ok)
        bundle.sources_skipped.extend(market_bundle.sources_skipped)
        bundle.sources_failed.update(market_bundle.sources_failed)

        if focused:
            providers = [
                ("SEC EDGAR", lambda: self._sec(symbol, hours), bool(getattr(config, "NEWS_FOCUSED_SEC_ENABLED", True))),
                ("Nasdaq Halts", lambda: self._nasdaq_halts(symbol, hours), bool(getattr(config, "NEWS_FOCUSED_NASDAQ_HALTS_ENABLED", True))),
                ("Yahoo Finance", lambda: self._yahoo(symbol, hours), bool(getattr(config, "NEWS_FOCUSED_YAHOO_ENABLED", True))),
                ("Google News", lambda: self._google_news(symbol, hours), bool(getattr(config, "NEWS_FOCUSED_GOOGLE_NEWS_ENABLED", True))),
                ("Alpha Vantage", lambda: self._alpha(symbol, hours),
                 bool(getattr(config, "NEWS_FOCUSED_ALPHA_VANTAGE_ENABLED", False))),
                ("Finnhub", lambda: self._finnhub(symbol, hours),
                 bool(getattr(config, "NEWS_FOCUSED_FINNHUB_ENABLED", True))),
                ("FMP", lambda: self._fmp(symbol, hours),
                 bool(getattr(config, "NEWS_FOCUSED_FMP_ENABLED", False))),
                ("MASSIVE", lambda: self._massive(symbol, hours), True),
            ]
            for name, fn, allowed in providers:
                if not allowed:
                    continue
                rows = self._provider_call(name, fn, bundle)
                items.extend(rows)

        bundle.sources_ok = sorted(set(bundle.sources_ok))
        bundle.sources_skipped = sorted(set(bundle.sources_skipped))
        bundle.items = self._dedupe(items)[: int(getattr(config, "NEWS_MAX_ARTICLES", 20))]
        return bundle

    def fetch_market(self, hours=24, universe=None):
        bundle = NewsBundle(); items = []
        providers = [
            ("GDELT", lambda: self._gdelt(None, hours, market=True)),
            ("Nasdaq Halts", lambda: self._nasdaq_halts(None, hours, market=True)),
            # Alpha Vantage NEWS_SENTIMENT wird gezielt fuer bereits relevante
            # Ticker genutzt; kein pauschaler Marktabruf, um das API-Budget zu schonen.
            ("Finnhub", lambda: self._finnhub(None, hours, market=True)),
            ("FMP", lambda: self._fmp(None, hours, market=True)),
            ("MASSIVE", lambda: self._massive(None, hours, market=True)),
        ]
        for name, fn in providers:
            items.extend(self._provider_call(name, fn, bundle))
        items = self._attach_symbols(items, universe)
        bundle.sources_ok = sorted(set(bundle.sources_ok))
        bundle.sources_skipped = sorted(set(bundle.sources_skipped))
        bundle.items = self._dedupe(items)[: int(getattr(config, "NEWS_MARKET_MAX_ARTICLES", 80))]
        return bundle

    def active_health_test(self, source: str, symbol: str = "AAPL") -> dict:
        """Bewusster echter Netzwerktest fuer genau eine Quelle.

        Der normale Dashboard-Status ist passiv und verbraucht kein Budget.
        Diese Methode wird nur ueber den ausdruecklichen Test-Knopf aufgerufen.
        """
        name = str(source or "").strip()
        if name.lower() in {"finanzen.net", "finanzen_net"}:
            return {"ok": False, "source": "finanzen.net", "retired": True,
                    "detail": ("finanzen.net ist in NEXUS 8.2 entfernt, weil der "
                               "automatisierte RSS-Abruf wiederholt blockiert wurde."),
                    "tested_at": _now_utc().isoformat()}
        conf = self.provider_configuration()
        if name not in conf:
            return {"ok": False, "source": name, "detail": "unbekannte Quelle"}
        if not conf[name]:
            return {"ok": False, "source": name, "detail": "nicht aktiviert oder Zugang fehlt"}
        try:
            if name == "FMP Symbol Search":
                # Ueber den budgetgefuehrten Referenzclient testen, damit der
                # Test dieselben 250 Anfragen pro Tag mitzaehlt wie der Betrieb.
                import fmp_reference
                ergebnis = fmp_reference.client().verbindungstest()
                self._mark(name, bool(ergebnis.get("ok")), ergebnis.get("detail", ""),
                           int(ergebnis.get("count", 0) or 0))
                return {"source": name, **ergebnis, "tested_at": _now_utc().isoformat()}
            elif name == "FMP":
                # Nachrichten sind im FMP-Gratistarif nachweislich nicht
                # enthalten (HTTP 402). Das ist eine Tarifaussage und keine
                # Stoerung -- der Test sagt das deshalb im Klartext, statt
                # eine Fehlermeldung zu erzeugen, die nach Defekt aussieht.
                if not bool(getattr(config, "FMP_NEWS_ENABLED", False)):
                    detail = ("FMP-Nachrichten sind im Gratistarif nicht enthalten "
                              "(HTTP 402). Symbolsuche, Kurse, Sektor und Delisting-"
                              "Status funktionieren und werden weiter genutzt.")
                    self._mark(name, False, detail, 0)
                    return {"ok": False, "source": name, "tarif": True, "detail": detail,
                            "tested_at": _now_utc().isoformat()}
                self._cache.pop(("fmp", symbol, 48), None)
                rows = self._fmp(symbol, 48) or []
            elif name == "MASSIVE":
                from massive_api import MassiveClient
                result = MassiveClient().verbindungstest()
                self._mark(name, bool(result.get("ok")), result.get("detail", ""), result.get("count", 0))
                return {"source": name, **result, "tested_at": _now_utc().isoformat()}
            elif name == "GDELT":
                self._cache.pop(("gdelt", "MARKET", 24), None)
                rows = self._gdelt(None, 24, market=True) or []
            elif name == "Finnhub":
                self._cache.pop(("finnhub", symbol, 48), None)
                rows = self._finnhub(symbol, 48) or []
            elif name == "Alpha Vantage":
                self._cache.pop(("alpha", symbol, 48), None)
                rows = self._alpha(symbol, 48) or []
            elif name == "SEC EDGAR":
                self._sec_tickers_cache = None
                rows = [self._sec_ticker_map().get(symbol)]
                self._mark(name, True, "Tickerkatalog erreichbar", int(bool(rows[0])))
            elif name == "Nasdaq Halts":
                self._cache.pop(("nasdaq-halts", 48), None)
                rows = self._nasdaq_halts(None, 48) or []
            elif name == "Google News":
                self._cache.pop(("google-news", symbol, 48), None)
                rows = self._google_news(symbol, 48) or []
            elif name == "Yahoo Finance":
                self._cache.pop(("yahoo-yfinance", symbol, 48), None)
                rows = self._yahoo(symbol, 48) or []
            else:
                rows = []
            return {"ok": True, "source": name, "count": len(rows),
                    "detail": "Verbindung erfolgreich", "tested_at": _now_utc().isoformat()}
        except Exception as exc:
            backoff = self._failure_backoff(name, exc)
            self._mark(name, False, str(exc), 0, backoff_seconds=backoff)
            return {"ok": False, "source": name, "detail": str(exc)[:300],
                    "tested_at": _now_utc().isoformat()}


def configured_sources():
    return MultiSourceNews().provider_configuration()


def source_health():
    """Lokaler letzter Quellenstatus fuer GUI/Diagnose, ohne API-Aufruf."""
    return MultiSourceNews().health_snapshot()
