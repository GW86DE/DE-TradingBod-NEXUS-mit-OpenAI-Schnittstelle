"""Klassifizierung von Brokerguthaben (P0-07, neu in v8.1.2).

DAS PROBLEM AUS DEM LAUFZEITPROTOKOLL
=====================================
    crypto_engine: OKX-Guthaben ohne Positionsbuch-Eintrag: BTC, XRP, USD, ETH

Diese Zeile stand alle paar Minuten im Log und hat drei voellig
verschiedene Sachverhalte in einen Topf geworfen:

    USD      ist gar kein Bestand, sondern Guthaben (Cash)
    BTC/ETH  koennen manuell gekaufte Altbestaende sein
    XRP      koennte auch der Rest einer nicht zugeordneten Bot-Order sein

Nur der letzte Fall ist gefaehrlich. Ohne Unterscheidung sieht man ihn im
Rauschen der anderen nicht -- und ein Bot, der ungeklaerte Exposure nur
protokolliert statt sie zu behandeln, hat ein Sicherheitsproblem.

DIE FUENF KLASSEN
=================
    CASH             Quote-/Cashwaehrung. Kein Positionsalarm.
    BOT_MANAGED      Steht im Positionsbuch. Normaler Stop-/Ziel-Ablauf.
    EXTERNAL_HOLDING Manuell vorhanden, kein Bot-Bezug. Nur anzeigen,
                     niemals automatisch verkaufen.
    RESIDUAL         Passt zu einer nicht abgeschlossenen Bot-Order.
                     Neue Einstiege sperren, Reconciliation anstossen.
    UNKNOWN          Nicht erklaerbar. Fail-closed fuer diese Domaene,
                     bis der Ursprung geklaert ist.

GRUNDREGEL
==========
Der Bot verkauft NIEMALS automatisch einen Bestand, den er nicht selbst
eroeffnet hat. Fremdbestand wird sichtbar gemacht, nicht angefasst.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Iterable, Optional

logger = logging.getLogger(__name__)

CASH = "CASH"
BOT_MANAGED = "BOT_MANAGED"
EXTERNAL_HOLDING = "EXTERNAL_HOLDING"
RESIDUAL = "RESIDUAL_EXPOSURE"
UNKNOWN = "UNKNOWN_EXPOSURE"

# Klassen, die neue Einstiege in dieser Brokerdomaene sperren.
SPERRENDE_KLASSEN = frozenset({RESIDUAL, UNKNOWN})

# Waehrungen, die immer als Cash gelten -- auch wenn sie nicht die aktuell
# eingestellte Quotewaehrung sind. USD tauchte im Log als vermeintlicher
# Kryptobestand auf, weil es in OKX_ALLOWED_QUOTE_CCY fehlte.
STANDARD_CASH = ("EUR", "USDC", "USD", "USDG", "USDT")

# Unterhalb dieses Gegenwerts ist ein Restbestand Staub und kein Risiko.
STAUB_GRENZE_QUOTE = 1.0


@dataclass
class Bestand:
    """Ein klassifizierter Guthabenposten."""
    waehrung: str
    menge: float
    klasse: str
    gegenwert_quote: float = 0.0
    begruendung: str = ""
    sperrt_einstiege: bool = False
    zusatz: dict = field(default_factory=dict)

    def als_dict(self) -> dict:
        return {
            "waehrung": self.waehrung,
            "menge": self.menge,
            "klasse": self.klasse,
            "gegenwert_quote": round(self.gegenwert_quote, 2),
            "begruendung": self.begruendung,
            "sperrt_einstiege": self.sperrt_einstiege,
            **({"zusatz": self.zusatz} if self.zusatz else {}),
        }


def cash_waehrungen(cfg=None) -> set[str]:
    """Alle Waehrungen, die als Guthaben und nicht als Position gelten."""
    try:
        import config as _config
        cfg = cfg or _config
    except Exception:
        return set(STANDARD_CASH)
    erlaubt = set(STANDARD_CASH)
    erlaubt.add(str(getattr(cfg, "OKX_QUOTE_CCY", "EUR")).upper())
    for wert in getattr(cfg, "OKX_ALLOWED_QUOTE_CCY", ()) or ():
        erlaubt.add(str(wert).upper())
    return {w for w in erlaubt if w}


def klassifiziere(guthaben: dict, *, positionsbuch: Iterable = (),
                  offene_orders: Iterable = (), ledger_trades: Iterable = (),
                  preise: Optional[dict] = None,
                  cfg=None) -> dict:
    """Ordnet jeden Guthabenposten genau einer Klasse zu.

    guthaben        {'BTC': {'gesamt': 0.5, 'cash': 0.5}, 'EUR': {...}}
    positionsbuch   Objekte oder dicts mit 'symbol' und 'menge'
    offene_orders   nicht abgeschlossene Bot-Orders mit 'symbol'
    ledger_trades   offene Ledger-Trades; ohne Positionsbuch sind sie Residuen
    preise          {'BTC': 60000.0} zur Bewertung in Quotewaehrung
    """
    cash = cash_waehrungen(cfg)
    preise = {str(k).upper(): float(v or 0.0) for k, v in (preise or {}).items()}

    gebucht: dict[str, float] = {}
    for eintrag in positionsbuch or ():
        symbol = str(getattr(eintrag, "symbol", None) or
                     (eintrag.get("symbol") if isinstance(eintrag, dict) else "")).upper()
        menge = float(getattr(eintrag, "menge", None) or
                      (eintrag.get("menge") if isinstance(eintrag, dict) else 0.0) or 0.0)
        if symbol:
            gebucht[symbol] = gebucht.get(symbol, 0.0) + menge

    offen = set()
    for eintrag in offene_orders or ():
        symbol = str(getattr(eintrag, "symbol", None) or
                     (eintrag.get("symbol") if isinstance(eintrag, dict) else "")).upper()
        if symbol:
            offen.add(symbol)

    ledger: dict[str, float] = {}
    for eintrag in ledger_trades or ():
        symbol = str(getattr(eintrag, "symbol", None) or
                     (eintrag.get("symbol") if isinstance(eintrag, dict) else "")).upper()
        menge = float(getattr(eintrag, "menge", None) or
                      (eintrag.get("menge") if isinstance(eintrag, dict) else 0.0) or 0.0)
        if symbol and menge > 0:
            ledger[symbol] = ledger.get(symbol, 0.0) + menge

    bestaende: list[Bestand] = []
    for waehrung, werte in (guthaben or {}).items():
        waehrung = str(waehrung).upper()
        if isinstance(werte, dict):
            menge = float(werte.get("gesamt", werte.get("cash", 0.0)) or 0.0)
        else:
            menge = float(werte or 0.0)
        if menge <= 0:
            continue

        if waehrung in cash:
            bestaende.append(Bestand(waehrung, menge, CASH,
                                     gegenwert_quote=menge,
                                     begruendung="Guthaben in Cash-/Quotewaehrung"))
            continue

        gegenwert = menge * preise.get(waehrung, 0.0)
        gebuchte_menge = gebucht.get(waehrung, 0.0)

        if gebuchte_menge > 0:
            rest = menge - gebuchte_menge
            if abs(rest) <= max(gebuchte_menge * 0.02, 1e-12):
                bestaende.append(Bestand(waehrung, menge, BOT_MANAGED, gegenwert,
                                         "Im Positionsbuch gefuehrt"))
                continue
            if rest > 0:
                # Mehr im Konto als im Buch: der Ueberhang ist erklaerungsbeduerftig.
                bestaende.append(Bestand(waehrung, gebuchte_menge, BOT_MANAGED,
                                         gebuchte_menge * preise.get(waehrung, 0.0),
                                         "Im Positionsbuch gefuehrt"))
                kurs = float(preise.get(waehrung, 0.0) or 0.0)
                ueberhang_wert = rest * kurs
                if kurs <= 0:
                    # OHNE KURS KEIN STAUB. Faellt der Ticker aus, waere der
                    # Gegenwert 0 und ein Ueberhang von 0,94 BTC wuerde als
                    # Staubrest durchgehen -- die Sperre fiele offen aus.
                    bestaende.append(Bestand(
                        waehrung, rest, UNKNOWN, 0.0,
                        f"{rest:g} {waehrung} mehr im Konto als im Positionsbuch; "
                        f"Kurs nicht abrufbar, Gegenwert unbekannt",
                        sperrt_einstiege=True))
                    continue
                if ueberhang_wert <= STAUB_GRENZE_QUOTE:
                    bestaende.append(Bestand(waehrung, rest, EXTERNAL_HOLDING,
                                             ueberhang_wert, "Staubrest ohne Bot-Bezug"))
                else:
                    bestaende.append(Bestand(
                        waehrung, rest, UNKNOWN, ueberhang_wert,
                        f"{rest:g} {waehrung} mehr im Konto als im Positionsbuch",
                        sperrt_einstiege=True))
                continue
            # Weniger im Konto als im Buch -- der Rest wurde extern verkauft.
            bestaende.append(Bestand(waehrung, menge, RESIDUAL, gegenwert,
                                     "Weniger Bestand als im Positionsbuch gefuehrt",
                                     sperrt_einstiege=True))
            continue

        if waehrung in offen:
            bestaende.append(Bestand(waehrung, menge, RESIDUAL, gegenwert,
                                     "Passt zu einer noch offenen Bot-Order",
                                     sperrt_einstiege=True))
            continue

        if ledger.get(waehrung, 0.0) > 0:
            bestaende.append(Bestand(
                waehrung, menge, RESIDUAL, gegenwert,
                "Offener Trade im Ledger, aber kein Eintrag im Positionsbuch",
                sperrt_einstiege=True,
                zusatz={"ledger_menge": round(ledger[waehrung], 12)}))
            continue

        if gegenwert and gegenwert <= STAUB_GRENZE_QUOTE:
            bestaende.append(Bestand(waehrung, menge, EXTERNAL_HOLDING, gegenwert,
                                     "Staubrest, kein Handlungsbedarf"))
            continue

        # Kein Bot-Bezug: manuell gekaufter Bestand. Sichtbar machen, aber
        # niemals automatisch verkaufen.
        bestaende.append(Bestand(waehrung, menge, EXTERNAL_HOLDING, gegenwert,
                                 "Manuell vorhanden, nicht vom Bot eroeffnet"))

    nach_klasse: dict[str, list] = {}
    for b in bestaende:
        nach_klasse.setdefault(b.klasse, []).append(b.als_dict())

    sperren = [b for b in bestaende if b.sperrt_einstiege]
    return {
        "zeit": datetime.now(timezone.utc).isoformat(),
        "bestaende": [b.als_dict() for b in bestaende],
        "nach_klasse": nach_klasse,
        "cash_waehrungen": sorted(cash),
        "einstiege_gesperrt": bool(sperren),
        "sperrgruende": [f"{b.waehrung}: {b.begruendung}" for b in sperren],
    }


def kurzfassung(ergebnis: dict) -> str:
    """Eine Zeile fuer das Protokoll -- statt einer nichtssagenden Liste."""
    zaehler: dict[str, int] = {}
    for b in ergebnis.get("bestaende", []):
        zaehler[b["klasse"]] = zaehler.get(b["klasse"], 0) + 1
    if not zaehler:
        return "Kein Guthaben vorhanden"
    teile = [f"{anzahl}x {klasse}" for klasse, anzahl in sorted(zaehler.items())]
    text = ", ".join(teile)
    if ergebnis.get("einstiege_gesperrt"):
        text += " | NEUE EINSTIEGE GESPERRT: " + "; ".join(ergebnis.get("sperrgruende", []))
    return text


__all__ = [
    "klassifiziere", "kurzfassung", "cash_waehrungen", "Bestand",
    "CASH", "BOT_MANAGED", "EXTERNAL_HOLDING", "RESIDUAL", "UNKNOWN",
    "SPERRENDE_KLASSEN", "STANDARD_CASH", "STAUB_GRENZE_QUOTE",
]
