"""Kostenlose SEC-EDGAR-Unternehmensdaten ohne API-Key.

Es wird ausschliesslich data.sec.gov genutzt. Fuer faire Nutzung verlangt die
SEC einen identifizierenden User-Agent mit Kontakt-E-Mail; kein API-Key noetig.
"""
from __future__ import annotations
from pathlib import Path
from datetime import datetime, timezone
import json, time, requests
from safe_persistence import best_effort_json
import config

ROOT=Path(__file__).resolve().parent
CACHE=ROOT/"sec_fundamentals_cache.json"
TICKERS="https://www.sec.gov/files/company_tickers.json"
FACTS="https://data.sec.gov/api/xbrl/companyfacts/CIK{cik:010d}.json"

class SecFundamentals:
    def __init__(self):
        self.email=str(getattr(config,"SEC_USER_AGENT_EMAIL","") or "").strip()
        self.timeout=float(getattr(config,"NEWS_SOURCE_TIMEOUT_SECONDS",10))
        self.ttl=int(getattr(config,"SEC_FUNDAMENTALS_CACHE_SECONDS",21600))
        self.s=requests.Session()
        self.s.headers.update({"User-Agent":f"TradingBot/5.6 private research {self.email}","Accept-Encoding":"gzip, deflate"})
        self._tickers=None
        try:self.cache=json.loads(CACHE.read_text(encoding="utf-8")) if CACHE.exists() else {}
        except Exception:self.cache={}
    def enabled(self): return bool(self.email and "@" in self.email)
    def _save(self):
        best_effort_json(CACHE, self.cache, label='SEC-Fundamentals-Cache')
    def _map(self):
        if self._tickers is not None:return self._tickers
        if not self.enabled(): return {}
        r=self.s.get(TICKERS,timeout=self.timeout); r.raise_for_status(); raw=r.json()
        self._tickers={str(v.get('ticker','')).upper():v for v in raw.values()}
        return self._tickers
    @staticmethod
    def _latest(facts, names):
        for name in names:
            item=facts.get(name) or {}
            units=item.get("units") or {}
            rows=[]
            for vals in units.values():
                for r in vals or []:
                    if str(r.get("form")) in ("10-Q","10-K","20-F","40-F") and r.get("val") is not None:
                        rows.append(r)
            if rows:
                rows.sort(key=lambda x:(str(x.get("filed","")),str(x.get("end",""))), reverse=True)
                r=rows[0]
                return {"value":r.get("val"),"unit":next(iter(units.keys()),""),"end":r.get("end"),"filed":r.get("filed"),"form":r.get("form"),"concept":name}
        return None
    def snapshot(self,symbol):
        symbol=str(symbol).upper()
        old=self.cache.get(symbol,{})
        if old and time.time()-float(old.get("_ts",0))<self.ttl:return old
        if not self.enabled(): return {"available":False,"reason":"SEC Kontakt-E-Mail nicht eingerichtet"}
        row=self._map().get(symbol)
        if not row:return {"available":False,"reason":"Ticker bei SEC nicht gefunden"}
        cik=int(row.get("cik_str") or 0)
        r=self.s.get(FACTS.format(cik=cik),timeout=self.timeout); r.raise_for_status(); raw=r.json()
        f=((raw.get("facts") or {}).get("us-gaap") or {})
        out={"available":True,"symbol":symbol,"company":raw.get("entityName"),"cik":cik,
             "revenue":self._latest(f,["RevenueFromContractWithCustomerExcludingAssessedTax","Revenues","SalesRevenueNet"]),
             "net_income":self._latest(f,["NetIncomeLoss"]),
             "eps_diluted":self._latest(f,["EarningsPerShareDiluted"]),
             "operating_cashflow":self._latest(f,["NetCashProvidedByUsedInOperatingActivities"]),
             "assets":self._latest(f,["Assets"]),"liabilities":self._latest(f,["Liabilities"]),
             "source":"SEC EDGAR / Company Facts","fetched_at":datetime.now(timezone.utc).isoformat(),"_ts":time.time()}
        self.cache[symbol]=out; self._save(); return out
