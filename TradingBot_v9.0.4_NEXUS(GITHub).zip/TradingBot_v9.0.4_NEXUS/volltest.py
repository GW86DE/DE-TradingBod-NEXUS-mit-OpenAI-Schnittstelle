"""Versionsaktueller Offline-Volltest fuer TradingBot NEXUS.

Der Test fuehrt verhaltensbasierte Regressionen des Geldpfads mit Testdoubles,
den lokalen Selbsttest, Syntaxpruefung, Pi-Preflight und Shell-Syntaxpruefung aus.
Es werden keine echten Orders, Telegram-Nachrichten oder KI-Anfragen gesendet.
"""
from __future__ import annotations

import ast
import importlib.util
import os
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def _allow_local_state() -> bool:
    """Installed trees may legitimately contain private runtime state.

    The default remains strict so that a packaged release can never silently
    contain credentials or state databases.  The Pi installer opts in only for
    its repeatable local verification run, where those files can already exist
    after a partial installation or an update.
    """
    return os.getenv("TRADINGBOT_ALLOW_LOCAL_STATE", "").strip() == "1"

# Verzeichnisse, die nicht zum ausgelieferten TradingBot-Quellcode gehoeren.
# Besonders wichtig auf dem Raspberry Pi: Pi_Installieren.sh erzeugt .venv
# vor dem Volltest. Fremdpakete unter site-packages duerfen deshalb niemals
# als TradingBot-Releasecode bewertet werden.
HYGIENE_EXCLUDED_DIRS = {
    ".venv", "venv", "env", "site-packages",
    "__pycache__", ".pytest_cache", ".mypy_cache", ".ruff_cache",
    ".git", "build", "dist",
}

REQUIRED_RELEASE_FILES = (
    "VERSION.txt", "live_trader.py", "gui_app.py", "news_check.py", "research_snapshot.py",
    "crypto_diagnose.py", "tests_intelligence.py", "tests_integration_v560.py",
    "Pi_Installieren.sh", "Pi_GUI_Starten.sh", "tradingbot-pi5.service.template",
    "TradingBot_GUI.desktop.template", "TradingBot_Starten.desktop.template",
    "TradingBot_Stoppen.desktop.template", "TradingBot_Status.desktop.template",
    "requirements-lock.txt", "requirements-test.txt",
    # --- NEXUS 8.1.1 ---------------------------------------------------------
    "nexus_start.py", "nexus_setup.py", "venv_guard.py",
    "crypto_engine.py", "ai_router.py", "risk_pots.py", "scheduler_v7.py",
    "decision_source.py", "massive_api.py",
    "decision_snapshot.py",
    "etoro_reconciliation.py", "core_volume_20.py", "crypto_dynamic_30.py",
    "trade_chart_data.py",
    # NEXUS 9.0: isolierter, positionsgebundener SampleStrategy-Modus.
    "crypto_strategy_mode.py", "freqtrade_sample_strategy.py",
    "freqtrade_sample_backtest.py", "tests/test_v900_freqtrade_sample.py",
    # v8.1.3: Universums-Kennzahlen, Trade-Ledger und Strategieversion.
    "universe_overview.py", "trade_ledger.py", "strategy_version.py",
    "stock_universe_runner.py",
    # v8.1.4: Handelsbereitschaft, Meldeschicht, OKX-Status, Second Opinion,
    # Universumsdiagnose.
    "trading_ready.py", "meldungen.py", "okx_status.py",
    "second_opinion.py", "universe_diagnose.py",
    # v8.1.5: Tagesbuch, gemeinsamer Risikopfad, Positionsuebergabe.
    "tagesbuch.py", "risk_state_pfad.py", "positions_auftraege.py",
    "webui/templates/positions.html", "webui/static/positions.js",
    "broker/okx.py", "broker/okx_stream.py", "broker/multi.py",
    "Nexus_Starten.sh", "Nexus_Einrichten.sh",
    "CHANGELOG_v8.1.2_NEXUS.txt", "README_V8_1_2_NEXUS_DE.md",
    "INSTALLATIONSANLEITUNG_NEXUS_8.1.5_DE.md", "INSTALLATIONSANLEITUNG_NEXUS_8.2_DE.md",
    "INSTALLATIONSANLEITUNG_NEXUS_8.2.1_DE.md",
    "INSTALLATIONSANLEITUNG_NEXUS_8.2.2_DE.md",
    "INSTALLATIONSANLEITUNG_NEXUS_8.3.0_DE.md",
    "INSTALLATIONSANLEITUNG_NEXUS_8.3.1_DE.md",
    "CHANGELOG_v8.2_NEXUS.txt", "MASTER_NOTIZ_NEXUS_8.2.txt",
    "CHANGELOG_v8.2.1_NEXUS.txt", "MASTER_NOTIZ_NEXUS_8.2.1.txt",
    "CHANGELOG_v8.2.2_NEXUS.txt", "MASTER_NOTIZ_NEXUS_8.2.2.txt",
    "CHANGELOG_v8.3.0_NEXUS.txt", "TEST_REPORT_v8.3.0_NEXUS.txt",
    "CHANGELOG_v8.3.1_NEXUS.txt", "TEST_REPORT_v8.3.1_NEXUS.txt",
    "CHANGELOG_v9.0_NEXUS.txt", "TEST_REPORT_v9.0_NEXUS.txt",
    "INSTALLATIONSANLEITUNG_NEXUS_9.0_DE.md",
    "FREQTRADE_MODUS_NEXUS_9.0_DE.md", "RISIKOPRUEFUNG_NEXUS_9.0_DE.md",
    "CHANGELOG_v9.0.1_NEXUS.txt", "TEST_REPORT_v9.0.1_NEXUS.txt",
    "INSTALLATIONSANLEITUNG_NEXUS_9.0.1_DE.md",
    "KRYPTO_UNIVERSUM_UND_TRADEANALYSE_NEXUS_9.0.1_DE.md",
    "CHANGELOG_v9.0.2_NEXUS.txt", "TEST_REPORT_v9.0.2_NEXUS.txt",
    "INSTALLATIONSANLEITUNG_NEXUS_9.0.2_DE.md",
    "KORREKTUREN_NEXUS_9.0.2_DE.md", "tests/test_v902_stability_fixes.py",
    "CHANGELOG_v9.0.3_NEXUS.txt", "TEST_REPORT_v9.0.3_NEXUS.txt",
    "INSTALLATIONSANLEITUNG_NEXUS_9.0.3_DE.md",
    "KORREKTUREN_NEXUS_9.0.3_DE.md", "tests/test_v903_broker_truth_and_mobile.py",
    "CHANGELOG_v9.0.4_NEXUS.txt", "TEST_REPORT_v9.0.4_NEXUS.txt",
    "INSTALLATIONSANLEITUNG_NEXUS_9.0.4_DE.md",
    "KORREKTUREN_NEXUS_9.0.4_DE.md", "tests/test_v904_critical_regressions.py",
    "ARCHITEKTUR_V8_NEXUS_DE.md",
    "TEST_REPORT_v8.1.1_NEXUS.txt", "broker_diagnostics.py",
    "broker_live_arming.py", "webui_start.py", "webui_setup.py",
    "webui/app.py", "webui/auth.py", "webui/settings_store.py", "webui/state.py",
    "webui/templates/dashboard.html", "webui/templates/settings.html",
    "webui/templates/trades.html", "webui/static/trades.js",
    "webui/static/common.js", "webui/static/dashboard.js", "webui/static/settings.js", "webui/static/app.css",
    "webui_network_setup.py", "webui_open.py", "Pi_WebUI_Aktivieren.sh", "Pi_Service_Unit_Pruefen.sh",
    "tests/test_v821_service_guard.py", "tests/test_v821_favorites_routing.py",
    "tradingbot-webui.service.template", "TradingBot_WebUI.desktop.template",
    "WIREGUARD_VPN_EINRICHTUNG_DE.md", "WireGuard_Status_Pruefen.sh",
)


def _versionstext() -> str:
    """Versionsangabe fuer die Zusammenfassung -- ohne feste Nummer im Code."""
    try:
        return (ROOT / "VERSION.txt").read_text(encoding="utf-8").strip() or "unbekannt"
    except OSError:
        return "unbekannt"


def _is_hygiene_excluded(path: Path) -> bool:
    try:
        rel = path.relative_to(ROOT)
    except ValueError:
        return True
    return any(part in HYGIENE_EXCLUDED_DIRS for part in rel.parts)


def _run(label: str, cmd: list[str], *, env: dict[str, str]) -> tuple[str, int, float]:
    print("\n" + "=" * 78)
    print(label)
    print("=" * 78)
    t0 = time.time()
    proc = subprocess.run(cmd, cwd=ROOT, env=env)
    return label, proc.returncode, time.time() - t0


def _static_hygiene() -> tuple[int, list[str]]:
    issues: list[str] = []
    # In echten Release-Baeumen Vollstaendigkeit pruefen. Unit-Tests duerfen
    # ROOT absichtlich auf einen Minimalbaum umbiegen, um einzelne Hygiene-
    # Regeln isoliert zu testen; ohne VERSION.txt ist es kein Release-Baum.
    if (ROOT / "VERSION.txt").exists():
        for name in REQUIRED_RELEASE_FILES:
            if not (ROOT / name).is_file():
                issues.append(f"Pflichtdatei fehlt im Release: {name}")
        try:
            version = (ROOT / "VERSION.txt").read_text(encoding="utf-8").strip()
            # Die Pruefung haengt nicht mehr an einer festen Nummer, sondern
            # vergleicht VERSION.txt mit config.VERSION_NEXUS. Eine fest
            # verdrahtete "6.0" liess den Volltest bei jedem Versionssprung
            # zwangslaeufig fehlschlagen -- ohne dass etwas kaputt war.
            if not version:
                issues.append("VERSION.txt ist leer")
            else:
                erwartet = ""
                try:
                    import config as _cfg
                    erwartet = str(getattr(_cfg, "VERSION_NEXUS", "") or "").strip()
                except Exception as exc:
                    issues.append(f"config.py nicht ladbar: {exc}")
                if erwartet and version != erwartet:
                    issues.append(
                        f"VERSION.txt ({version!r}) und config.VERSION_NEXUS ({erwartet!r}) "
                        "stimmen nicht ueberein")
        except Exception as exc:
            issues.append(f"VERSION.txt nicht lesbar: {exc}")
    for path in ROOT.rglob("*.py"):
        if _is_hygiene_excluded(path):
            continue
        try:
            tree = ast.parse(path.read_text(encoding="utf-8"))
        except Exception as exc:
            issues.append(f"{path.relative_to(ROOT)}: AST nicht lesbar: {exc}")
            continue
        for node in ast.walk(tree):
            if (
                isinstance(node, ast.ExceptHandler)
                and isinstance(node.type, ast.Name)
                and node.type.id == "Exception"
                and len(node.body) == 1
                and isinstance(node.body[0], ast.Pass)
            ):
                issues.append(f"{path.relative_to(ROOT)}:{node.lineno}: stummer Exception-Pfad")
    # Release soll keine lokalen Laufzeit-/Credential-Dateien ausliefern.
    forbidden_runtime = [
        "decision_history.sqlite",
        "telegram_queue.json",
        "telegram_control_status.json",
        "telegram_control_state.json",
        "telegram_command_audit.jsonl",
        "etoro_cost_status.json",
        "news_source_status.json",
        "ai_attention_usage.json",
        "ai_control_state.json",
        "live_trading_arm.json",
        "risk_state.json",
        "approved_universe.json",
        "universe_proposals.json",
        "weekly_intelligence_state.json",
        # --- NEXUS-Laufzeitzustaende der Kryptoseite -----------------------
        "universe_state.json",
        "universe_audit.jsonl",
        "decision_sources.jsonl",
        "ai_router_usage.json",
        "ai_router_cache.json",
        "ai_usage_audit.jsonl",
        "crypto_positions.json",
        "stock_positions.json",
        "market_regime.json",
        "ai_pending_orders.json",
        "second_opinion_settings.json",
        "handel_settings.json",
        "risk_state_etoro.json",
        "risk_state_okx.json",
        "runtime_status_okx.json",
        "okx_live_arm.json",
        "etoro_live_arm.json",
        "web_ui_credentials.json",
        "web_ui_settings.json",
        "migration_report.json",
        "crypto_strategy_mode.json",
        "crypto_dynamic_30.json",
        "crypto_dynamic_30_history.json",
    ]
    if not _allow_local_state():
        for name in forbidden_runtime:
            if (ROOT / name).exists():
                issues.append(f"Laufzeitdatei im Release-Baum: {name}")
        for path in ROOT.glob("*_credentials.json"):
            issues.append(f"Credential-Datei im Release-Baum: {path.name}")
        if (ROOT / "openai_ai_settings.json").exists():
            issues.append("Lokale KI-Zugangsdaten im Release-Baum")
        if (ROOT / "strategy_reports").exists():
            issues.append("Lokale Strategy-Berichte im Release-Baum")

    # NEXUS nutzt ausschliesslich eToro fuer Aktien und OKX fuer Krypto. Alte Brokerbezeichnungen duerfen weder in
    # Produktcode noch GUI, Tests oder Dokumentation des Release-Baums stehen.
    forbidden_broker_terms = ("al" + "paca", "ib" + "kr", "interactive" + " brokers")
    text_ext = {".py", ".md", ".txt", ".json", ".sh", ".bat", ".template"}
    for path in ROOT.rglob("*"):
        if not path.is_file() or path.suffix.lower() not in text_ext or _is_hygiene_excluded(path):
            continue
        try:
            text = path.read_text(encoding="utf-8", errors="ignore").lower()
        except Exception as exc:
            issues.append(f"{path.relative_to(ROOT)}: Textscan fehlgeschlagen: {exc}")
            continue
        for term in forbidden_broker_terms:
            if term in text:
                issues.append(f"{path.relative_to(ROOT)}: verbotene Alt-Brokerreferenz '{term}'")
                break
    return (0 if not issues else 1), issues


def main() -> int:
    started = time.time()
    results: list[tuple[str, int, float]] = []
    with tempfile.TemporaryDirectory(prefix="tradingbot_v80_nexus_test_") as td:
        env = os.environ.copy()
        env["TRADINGBOT_TEST_STATE_DIR"] = td
        env["PYTHONUNBUFFERED"] = "1"
        env["TRADING_MODE"] = "paper"

        # Release-Hygiene MUSS vor verhaltensbasierten Tests laufen: einige
        # Tests erzeugen bewusst lokale Statusdateien. Diese duerfen einen
        # sauberen, frisch entpackten Release nicht nachtraeglich als unsauber
        # erscheinen lassen.
        print("\n" + "=" * 78)
        print("STATIC RELEASE HYGIENE (vor Testlauf)")
        print("=" * 78)
        t0 = time.time()
        code, issues = _static_hygiene()
        for issue in issues:
            print("FEHLER:", issue)
        if not issues:
            print("OK")
        results.append(("STATIC RELEASE HYGIENE", code, time.time() - t0))

        if importlib.util.find_spec("pytest") is None:
            print("\nFEHLER: pytest fehlt in dieser Python-Umgebung.")
            print("Auf dem Pi bitte ./Pi_Installieren.sh verwenden; das Setup installiert requirements-test.txt vor diesem Volltest.")
            results.append(("PYTEST GELDPFAD / REGRESSIONEN", 78, 0.0))
        else:
            results.append(_run("PYTEST GELDPFAD / REGRESSIONEN", [sys.executable, "-m", "pytest", "-q", "tests"], env=env))
        results.append(_run("SELF TEST", [sys.executable, "self_test.py"], env=env))
        results.append(_run(
            "COMPILEALL",
            [sys.executable, "-m", "compileall", "-q", "-x", r"(^|/)(\.venv|venv|env|site-packages|__pycache__|\.pytest_cache|build|dist)(/|$)", str(ROOT)],
            env=env,
        ))
        results.append(_run("PI PREFLIGHT (host-neutral)", [sys.executable, "pi_preflight.py", "--no-imports"], env=env))

        if shutil.which("bash"):
            shell_files = sorted(ROOT.glob("*.sh"))
            if shell_files:
                results.append(_run("SHELL SYNTAX", ["bash", "-n", *map(str, shell_files)], env=env))

    print("\n" + "=" * 78)
    print(f"VOLLTEST {_versionstext()} - ZUSAMMENFASSUNG")
    print("=" * 78)
    failed = []
    for name, code, seconds in results:
        state = "OK" if code == 0 else f"FEHLER({code})"
        print(f"{name:34s} {state:12s} {seconds:7.2f}s")
        if code != 0:
            failed.append(name)
    print(f"Gesamtlaufzeit: {time.time() - started:.1f}s")
    if failed:
        print("FEHLGESCHLAGEN:", ", ".join(failed))
        return 1
    print("VOLLTEST OK")
    print("Grenze: echte eToro-/Telegram-/KI-Netzwerkaufrufe und ARM64-Hardware werden offline nicht simuliert.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
