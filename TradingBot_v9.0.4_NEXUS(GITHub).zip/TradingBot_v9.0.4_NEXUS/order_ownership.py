"""Persistente, asset-sichere Zuordnung von eToro-Order-IDs zu Bot-Orders."""
from __future__ import annotations
from pathlib import Path
import json
import logging
import time

from instrument_identity import canonical_key
from safe_persistence import atomic_write_json

logger = logging.getLogger(__name__)


def _pending_key(symbol, asset_type="stock") -> str:
    return canonical_key(symbol, asset_type)


# Orderzustaende. Nur TERMINALE Zustaende beenden Ownership und Reservierung.
TERMINALE_ZUSTAENDE = frozenset({"FILLED", "REJECTED", "CANCELLED", "EXPIRED"})

# Alles andere ist NICHT terminal und darf niemals per Zeitablauf verschwinden:
# eine Order, die der Broker angenommen hat, bleibt unser Problem -- auch nach
# 24 Stunden Ausfall. Bis 8.1.1 loeschte die TTL solche Eintraege nach sechs
# Stunden; ein spaeter Fill war danach nicht mehr zuzuordnen.
NICHT_TERMINALE_ZUSTAENDE = frozenset({
    "PLANNED", "SUBMITTING", "SUBMITTED", "PARTIALLY_FILLED",
    "UNKNOWN_AFTER_SUBMIT", "LATE_FILL_WATCH",
})

# Nur dieser Zustand ist rein vorbereitend und wurde nie gesendet.
NUR_VORBEREITET = "PLANNED"


def ist_terminal(zustand) -> bool:
    return str(zustand or "").upper() in TERMINALE_ZUSTAENDE


def darf_per_ttl_verfallen(meta) -> bool:
    """Darf dieser Pending-Eintrag durch blossen Zeitablauf weg?

    Nur wenn er nie gesendet wurde. Sobald ein Submit begonnen hat, bleibt
    der Eintrag bis zu einer eindeutigen Brokerantwort erhalten.
    """
    zustand = str((meta or {}).get("zustand") or "").upper()
    if not zustand:
        # Altbestand ohne Zustandsfeld: konservativ als vorbereitend werten,
        # ABER nur wenn keine Brokerreferenz vorhanden ist.
        referenzen = [(meta or {}).get(k) for k in ("ord_id", "order_id", "cl_ord_id",
                                                    "clOrdId", "reference_id")]
        return not any(str(x or "").strip() for x in referenzen)
    return zustand == NUR_VORBEREITET


class OrderOwnershipRegistry:
    def __init__(self, path="bot_order_registry.json", pending_ttl=900):
        self.path = Path(path)
        self.pending_ttl = float(pending_ttl or 900)
        self.orders = {}
        self.pending = {}
        self._load()
        self.cleanup()

    def _load(self):
        try:
            raw = json.loads(self.path.read_text(encoding="utf-8")) if self.path.exists() else {}
            self.orders = {str(k): dict(v) for k, v in (raw.get("orders") or {}).items() if isinstance(v, dict)}
            self.pending = {str(k): dict(v) for k, v in (raw.get("pending") or {}).items() if isinstance(v, dict)}
        except Exception as exc:
            logger.warning("Order-Ownership-Registry unlesbar; konservativer Neustart: %s", exc)
            self.orders = {}
            self.pending = {}

    def save(self):
        atomic_write_json(self.path, {"orders": self.orders, "pending": self.pending, "updated_at": time.time()})

    def cleanup(self):
        now = time.time(); changed = False
        for key, meta in list(self.pending.items()):
            if not darf_per_ttl_verfallen(meta):
                continue        # nicht-terminal: bleibt bis zur Brokerantwort
            if now - float(meta.get("created_at_ts", 0) or 0) > max(60.0, self.pending_ttl):
                self.pending.pop(key, None); changed = True
        for oid, meta in list(self.orders.items()):
            if now - float(meta.get("registered_at", 0) or 0) > 45 * 86400:
                self.orders.pop(oid, None); changed = True
        if changed:
            self.save()

    def register_pending(self, symbol, meta, asset_type="stock"):
        d = dict(meta or {})
        d.setdefault("created_at_ts", time.time())
        d.setdefault("zustand", NUR_VORBEREITET)
        d["owner"] = "BOT"
        d["asset_type"] = str(asset_type or d.get("asset_type") or "stock").lower()
        d["canonical_key"] = _pending_key(symbol, d["asset_type"])
        self.pending[d["canonical_key"]] = d
        self.save()

    def setze_zustand(self, symbol, zustand, asset_type="stock", **felder):
        """Schreibt den Orderzustand fort und schuetzt ihn damit vor der TTL."""
        key = _pending_key(symbol, asset_type)
        meta = self.pending.get(key)
        if meta is None:
            return False
        meta["zustand"] = str(zustand or "").upper()
        meta["zustand_seit"] = time.time()
        for name, wert in felder.items():
            if wert not in (None, ""):
                meta[name] = wert
        self.pending[key] = meta
        self.save()
        return True

    def nicht_terminale(self) -> dict:
        """Alle Eintraege, die noch auf eine eindeutige Brokerantwort warten."""
        return {k: dict(v) for k, v in self.pending.items()
                if not darf_per_ttl_verfallen(v)}

    def clear_pending(self, symbol, asset_type="stock"):
        if self.pending.pop(_pending_key(symbol, asset_type), None) is not None:
            self.save()

    def register_orders(self, order_ids, symbol, meta=None, owner="BOT", asset_type="stock"):
        at = str(asset_type or (meta or {}).get("asset_type") or "stock").lower()
        base = dict(meta or {})
        base.update({
            "owner": str(owner or "BOT").upper(),
            "symbol": str(symbol).upper(),
            "asset_type": at,
            "canonical_key": _pending_key(symbol, at),
            "registered_at": time.time(),
        })
        for oid in order_ids or []:
            if str(oid):
                self.orders[str(oid)] = dict(base)
        self.save()

    def register_ambiguous_order(self, order_id, symbol, meta=None, asset_type="stock"):
        self.register_orders([order_id], symbol, meta, owner="AMBIGUOUS", asset_type=asset_type)

    def metadata(self, order_id):
        return dict(self.orders.get(str(order_id), {}))

    def is_bot_order(self, order_id):
        return str((self.orders.get(str(order_id)) or {}).get("owner", "")).upper() == "BOT"

    def owner(self, order_id):
        return str((self.orders.get(str(order_id)) or {}).get("owner", "") or "").upper()

    def pending_metadata(self, symbol, asset_type="stock"):
        meta = self.pending.get(_pending_key(symbol, asset_type))
        if not meta:
            return {}
        if not darf_per_ttl_verfallen(meta):
            return dict(meta)   # nicht-terminal bleibt immer sichtbar
        age = time.time() - float(meta.get("created_at_ts", 0) or 0)
        return dict(meta) if 0 <= age <= max(60.0, self.pending_ttl) else {}


def classify_fill_owner(meta, registry, order_id) -> str:
    """BOT nur bei expliziter Ownership; Ambiguitaet bleibt OBSERVE."""
    meta = dict(meta or {})
    reg_owner = registry.owner(order_id) if registry is not None else ""
    if bool(meta.get("_ownership_ambiguous")) or reg_owner == "AMBIGUOUS":
        return "AMBIGUOUS"
    if bool(meta) or reg_owner == "BOT":
        return "BOT"
    return "MANUAL"
