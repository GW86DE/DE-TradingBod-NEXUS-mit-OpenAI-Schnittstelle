"""Sichere Uebernahme unterstuetzter Einstellungen aus einer aelteren TradingBot-Version.

Es werden eToro-, OKX-, Telegram-, Research-, GUI-/Profil-, Web-UI- und
persistente TradingBot-Zustaende uebernommen. Nicht mehr unterstuetzte
Brokerkonfigurationen werden bewusst ignoriert.

NEU IN v8.0 NEXUS
=================
1. Neue Dateien der v7-Bausteine (OKX, MASSIVE, dynamisches Universum,
   AI-Router, Web-UI) werden mit uebernommen.
2. Der EINE Risikozustand aus v6 (risk_state.json) wird auf den eToro-Topf
   abgebildet. In v6 gab es nur eToro -- ohne diese Abbildung waere die
   Tagesbremse nach dem Umstieg auf null zurueckgesetzt und der Bot duerfte
   an einem bereits schlechten Tag wieder von vorn verlieren.
3. Der Bericht sagt jetzt ausdruecklich, WAS fehlt und noch eingegeben
   werden muss -- statt nur zu zaehlen, was kopiert wurde.
"""
from __future__ import annotations

import argparse
import json
import logging
import shutil
import sqlite3
from pathlib import Path

from credential_store import load_credentials, save_credentials, secure_path

ROOT = Path(__file__).resolve().parent

CREDENTIAL_FILES = {
    "etoro_credentials.json", "telegram_credentials.json", "alpha_vantage_credentials.json",
    "news_sources_credentials.json", "openai_ai_settings.json",
    # --- NEXUS ---
    "okx_credentials.json", "massive_credentials.json", "web_ui_credentials.json",
}

PERSISTENT_FILES = [
    "etoro_credentials.json", "telegram_credentials.json", "alpha_vantage_credentials.json",
    "news_sources_credentials.json",
    "news_research_settings.json", "intelligence_settings.json", "openai_ai_settings.json",
    "favorites.json",
    "handelsmodus.txt", "aktives_profil.txt", "bot_zustand.json", "bot_zustand.txt",
    "position_state.json", "risk_state.json",
    "fill_progress.json", "bot_order_registry.json", "underdog_freigabe.json",
    "ml_model.joblib", "decision_journal.jsonl",
    "decision_history.sqlite", "telegram_control_state.json", "ai_control_state.json",
    "walkforward_status.json", "ml_training_status.json",
    # --- 6.0 ---------------------------------------------------------------
    "market_session_state.json",
    "approved_universe.json",
    "universe_proposals.json",
    "news_source_status.json",
    "ai_attention_usage.json",
    "ai_usage.json",
    "telegram_queue.json",
    "strategy_report.json",
    "runtime_status.json",
    # --- NEXUS -------------------------------------------------------------
    # Ohne diese Eintraege wuerde NEXUS zwar starten, aber jede neue Faehigkeit
    # begaenne bei null: OKX-Zugang neu eintragen, Universum neu aufbauen,
    # KI-Budget des Tages doppelt verbrauchen.
    "okx_credentials.json",            # OKX Demo- und Live-Zugang
    "massive_credentials.json",        # MASSIVE API-Key
    "web_ui_credentials.json",         # Web-Login (Hash, niemals Klartext)
    "web_ui_settings.json",            # Anzeigeoptionen der Weboberflaeche
    "universe_settings.json",          # Grenzen des dynamischen Universums
    "universe_state.json",             # Mitgliedschaften, Aufenthaltsdauer
    "universe_audit.jsonl",            # Aenderungsprotokoll
    "ai_router_settings.json",         # Luna/Terra-Konfiguration
    "ai_router_usage.json",            # verbrauchtes Tagesbudget
    "ai_router_cache.json",            # bereits bezahlte KI-Antworten
    "decision_sources.jsonl",          # Quellenprotokoll der Entscheidungen
    "telegram_command_audit.jsonl",    # Telegram-Befehle ohne Geheimnisse
    "telegram_control_status.json",    # Zustand des Long-Polling-Kanals
    "risk_state_etoro.json",           # Risikotopf Aktien
    "risk_state_okx.json",             # Risikotopf Krypto
    # Ohne das Positionsbuch weiss die Kryptoseite nach einem Wechsel nicht
    # mehr, wo ihre Stops liegen -- OKX Spot kennt keinen Einstandspreis.
    "crypto_positions.json",           # offene Kryptopositionen samt Schutzwerten
    "second_opinion_settings.json",    # Schalter der GPT-Zweitmeinung
    "handel_settings.json",            # Datenfrische-Schwellen (v8.1.5)
    "trading_ready_notifications.json",  # keine doppelte Bereitmeldung nach Update
    # v8.3.1: Ein ungeklärter eToro-Submit und die belegte 30-Tage-
    # Volumenhistorie dürfen bei einem Update niemals vergessen werden.
    "etoro_reconciliation.json",
    "core_volume_20.json",
    "core_volume_20_history.json",
    "crypto_dynamic_30.json",       # 30 monatlich rotierende OKX-Basiswerte
    "crypto_dynamic_30_history.json",  # taegliche Messungen fuer den Monatslauf
    "crypto_strategy_mode.json",     # Laufzeitmodus und revisionssicherer Wechselverlauf
]

# Alte Datei -> neue Datei, wenn die neue noch nicht existiert.
UMBENENNUNGEN = {
    "risk_state.json": "risk_state_etoro.json",
}

# Was NEXUS zusaetzlich braucht und NICHT aus v6 kommen kann.
NEU_EINZUGEBEN = {
    "okx_credentials.json": "OKX API-Key, Secret und Passphrase (Demo und Live getrennt)",
    "massive_credentials.json": "MASSIVE API-Key fuer Referenzdaten und News",
    "web_ui_credentials.json": "Benutzername und Passwort fuer die Weboberflaeche",
}


def _candidates(root: Path):
    seen = set()
    items = []
    for base in (root.parent, root.parent.parent):
        if not base.exists():
            continue
        for p in base.iterdir():
            if not p.is_dir() or p.resolve() == root.resolve():
                continue
            if "TradingBot" not in p.name and "Trading_Bot" not in p.name:
                continue
            try:
                rp = p.resolve()
                if rp in seen:
                    continue
                seen.add(rp)
                score = sum((p / f).exists() or (f in CREDENTIAL_FILES and secure_path(p / f).exists())
                            for f in PERSISTENT_FILES)
                if score:
                    items.append((p.stat().st_mtime, score, p))
            except Exception:
                continue
    # Vollstaendigkeit ist wichtiger als Aenderungszeit. So gewinnt eine
    # komplette v6-Installation gegen einen spaeteren, aber nur teilweise
    # eingerichteten v7-Versuch.
    items.sort(reverse=True, key=lambda x: (x[1], x[0]))
    return [x[2] for x in items]


def _kopiere(name: str, src: Path, dst: Path) -> None:
    if name in CREDENTIAL_FILES:
        data = load_credentials(src, None)
        if not isinstance(data, dict):
            raise ValueError("kein lesbares Zugangsdatenformat")
        # Alte KI-Handelsfelder werden beim Speichern bewusst verworfen.
        if name == "openai_ai_settings.json":
            keep = {"api_key", "enabled", "model", "reasoning_effort", "web_search",
                    "max_calls_per_day", "refresh_minutes", "max_priority",
                    # v7: Luna/Terra-Felder duerfen mitwandern, falls vorhanden
                    "luna_model", "terra_model", "router_enabled"}
            data = {k: v for k, v in data.items() if k in keep}
        if name == "news_sources_credentials.json" and isinstance(data.get("enabled"), dict):
            data["enabled"] = {k: v for k, v in data["enabled"].items()
                               if k in {"alpha_vantage", "finnhub", "fmp",
                                        "sec_edgar", "massive", "gdelt",
                                        "yahoo_finance", "google_news", "nasdaq_halts"}}
        save_credentials(dst, data)
    elif name == "decision_history.sqlite":
        src_con = sqlite3.connect(f"file:{src.as_posix()}?mode=ro", uri=True, timeout=5)
        try:
            dst_con = sqlite3.connect(dst, timeout=5)
            try:
                src_con.backup(dst_con)
            finally:
                dst_con.close()
        finally:
            src_con.close()
    else:
        shutil.copy2(src, dst)


def migrate_from(source: Path, target: Path = ROOT, overwrite: bool = False):
    source = Path(source).resolve()
    target = Path(target).resolve()
    copied, skipped = [], []

    for name in PERSISTENT_FILES:
        src = source / name
        dst = target / name
        src_exists = src.exists() or (name in CREDENTIAL_FILES and secure_path(src).exists())
        dst_exists = dst.exists() or (name in CREDENTIAL_FILES and secure_path(dst).exists())
        if not src_exists:
            continue
        # Das Dashboard initialisiert die Decision-DB schon vor der Migration.
        # Eine leere Zieldatei darf deshalb eine gefuellte Historie nicht
        # versehentlich blockieren.
        empty_decision_db = False
        if name == "decision_history.sqlite" and dst_exists and not overwrite:
            try:
                con = sqlite3.connect(f"file:{dst.as_posix()}?mode=ro", uri=True, timeout=3)
                try:
                    empty_decision_db = int(con.execute("SELECT COUNT(*) FROM decisions").fetchone()[0]) == 0
                finally:
                    con.close()
            except Exception:
                empty_decision_db = True
        if dst_exists and not overwrite and not empty_decision_db:
            skipped.append(name)
            continue
        try:
            _kopiere(name, src, dst)
            copied.append(name)
        except Exception:
            skipped.append(name)

    # Umbenennungen: nur ausfuehren, wenn das Ziel noch fehlt.
    for alt, neu in UMBENENNUNGEN.items():
        src = source / alt
        dst = target / neu
        if not src.exists() or dst.exists():
            continue
        try:
            shutil.copy2(src, dst)
            copied.append(f"{alt} -> {neu}")
        except Exception:
            skipped.append(f"{alt} -> {neu}")

    _migrate_v831_crypto_strategy_evidence(source, target, copied, skipped)
    _force_paper(target)
    _migration_report(target, source, copied, skipped)
    return copied, skipped


def _source_version(source: Path) -> str:
    try:
        return (Path(source) / "VERSION.txt").read_text(encoding="utf-8").strip()
    except OSError:
        return ""


def _migrate_v831_crypto_strategy_evidence(source: Path, target: Path,
                                           copied: list[str], skipped: list[str]) -> None:
    """Bindet belegte 8.3.1-Botpositionen an die damalige Standardstrategie.

    Vor 9.0 gab es keinen Freqtrade-Modus. Eine ausdruecklich als BOT/AUTO
    gefuehrte Position mit positiver decision_id aus einer nachgewiesenen
    8.3.1-Installation kann deshalb eindeutig NEXUS_STANDARD zugeordnet
    werden. Bei jedem fehlenden Beleg wird bewusst nichts geraten; der
    9.0-Loader stellt diese Position spaeter auf BEOBACHTEN.
    """
    if _source_version(source) != "8.3.1-NEXUS":
        return
    path = Path(target) / "crypto_positions.json"
    if not path.exists():
        return
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(data, dict) or not isinstance(data.get("positionen"), list):
            raise ValueError("ungueltiges Kryptopositionsbuch")
        changed = 0
        for row in data["positionen"]:
            if not isinstance(row, dict) or row.get("entry_strategy_mode"):
                continue
            decision_id = row.get("decision_id")
            try:
                decision_proven = int(decision_id) > 0
            except (TypeError, ValueError):
                decision_proven = False
            if not (str(row.get("herkunft") or "").upper() == "BOT"
                    and str(row.get("verwaltung") or "").upper() == "AUTO"
                    and decision_proven):
                continue
            row.update({
                "entry_strategy_mode": "NEXUS_STANDARD",
                "strategy_name": "NEXUS Standard Krypto",
                "strategy_version": "NEXUS-8.3.1-STANDARD-MIGRATED",
                "strategy_parameter_hash": "",
                "strategy_parameters": {
                    "source_version": "8.3.1-NEXUS",
                    "migration": "evidence_based_bot_auto_decision",
                },
            })
            changed += 1
        if not changed:
            return
        data["version"] = max(2, int(data.get("version") or 1))
        from safe_persistence import atomic_write_json
        atomic_write_json(path, data)
        copied.append(f"crypto_positions.json: {changed} Strategiezuordnung(en)")
    except Exception as exc:
        logging.getLogger(__name__).warning(
            "8.3.1-Kryptostrategien konnten nicht sicher migriert werden: %s", exc)
        skipped.append("crypto_positions.json: Strategiezuordnung")


def _migration_report(target: Path, source: Path, copied: list[str], skipped: list[str]) -> None:
    """Nachvollziehbarer Bericht ohne Zugangsdaten oder geheime Werte."""
    from datetime import datetime, timezone
    from safe_persistence import atomic_write_json

    atomic_write_json(Path(target) / "migration_report.json", {
        "version": __import__("config").VERSION_NEXUS,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "source": str(source),
        "copied": list(copied),
        "kept_or_skipped": list(skipped),
        "safety_reset": {
            "etoro_mode": "paper",
            "okx_mode": "demo",
            "live_arming_removed": True,
        },
    })


def _force_paper(target: Path) -> None:
    """Migrationen duerfen niemals einen alten LIVE-Zustand erben."""
    target = Path(target)
    (target / "handelsmodus.txt").write_text("paper\n", encoding="utf-8")
    okx_path = target / "okx_credentials.json"
    try:
        data = load_credentials(okx_path, {})
        if not isinstance(data, dict):
            data = {}
        data["live_trading"] = False
        save_credentials(okx_path, data)
    except Exception:
        logging.getLogger(__name__).warning(
            "OKX-Modus konnte nicht auf Paper zurueckgesetzt werden", exc_info=True)
    for name in ("live_trading_arm.json", "okx_live_arm.json", "etoro_live_arm.json"):
        try:
            (target / name).unlink(missing_ok=True)
        except OSError:
            pass


def fehlende_eingaben(target: Path = ROOT) -> list[str]:
    """Was muss der Nutzer nach der Uebernahme noch selbst eintragen?"""
    target = Path(target).resolve()
    offen = []
    for name, beschreibung in NEU_EINZUGEBEN.items():
        pfad = target / name
        vorhanden = pfad.exists() or secure_path(pfad).exists()
        if vorhanden:
            try:
                daten = load_credentials(pfad, {})
                if isinstance(daten, dict) and any(str(v).strip() for v in daten.values()):
                    continue
            except Exception:
                # Unlesbare Datei zaehlt bewusst als "noch offen": lieber
                # einmal zu viel nachfragen als eine kaputte Datei uebersehen.
                logging.getLogger(__name__).warning(
                    "Zugangsdatei %s ist nicht lesbar; sie gilt als noch nicht eingerichtet.",
                    name, exc_info=True)
        offen.append(f"{name}: {beschreibung}")
    return offen


def auto_migrate(target: Path = ROOT):
    for source in _candidates(target):
        copied, skipped = migrate_from(source, target, False)
        if copied:
            return source, copied, skipped
    return None, [], []


def bericht(target: Path = ROOT) -> dict:
    """Maschinenlesbarer Zustand fuer die Weboberflaeche."""
    quellen = _candidates(Path(target))
    return {
        "gefundene_vorgaengerversionen": [str(p) for p in quellen[:5]],
        "fehlende_eingaben": fehlende_eingaben(target),
        "uebernehmbare_dateien": len(PERSISTENT_FILES),
    }


def main():
    ap = argparse.ArgumentParser(description="Einstellungen aus einer aelteren Version uebernehmen")
    ap.add_argument("source", nargs="?")
    ap.add_argument("--auto", action="store_true")
    ap.add_argument("--json", action="store_true", help="Bericht als JSON ausgeben")
    args = ap.parse_args()

    if args.json:
        print(json.dumps(bericht(), ensure_ascii=False, indent=2))
        return

    if args.auto or not args.source:
        src, copied, skipped = auto_migrate()
        print("Einstellungen uebernommen aus:" if src else "Keine unterstuetzten alten Einstellungen gefunden.",
              src or "")
        if copied:
            print("Kopiert:", ", ".join(copied))
    else:
        copied, skipped = migrate_from(Path(args.source))
        print("Kopiert:", ", ".join(copied) if copied else "nichts")
        if skipped:
            print("Beibehalten/ignoriert:", ", ".join(skipped))

    offen = fehlende_eingaben()
    if offen:
        print()
        print("Noch selbst einzugeben (neu in v8.0):")
        for zeile in offen:
            print("  -", zeile)


if __name__ == "__main__":
    main()
