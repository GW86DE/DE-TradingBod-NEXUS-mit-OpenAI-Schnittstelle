const csrf = () => document.querySelector('meta[name="csrf"]')?.content || '';

async function api(url, opts = {}) {
  opts.headers = {...(opts.headers || {}), Accept: 'application/json'};
  if ((opts.method || 'GET') !== 'GET') opts.headers['X-CSRF-Token'] = csrf();
  const response = await fetch(url, opts);
  let data;
  try { data = await response.json(); }
  catch { data = {detail: await response.text()}; }
  if (response.status === 401) {
    location = '/login';
    throw new Error('Anmeldung abgelaufen');
  }
  if (!response.ok) throw new Error(data.detail || `HTTP ${response.status}`);
  return data;
}

function esc(value) {
  return String(value ?? '').replace(/[&<>"']/g, c => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;'
  })[c]);
}

async function logout() {
  await api('/api/logout', {method: 'POST'});
  location = '/login';
}

function badge(text, kind = '') {
  return `<span class="status ${kind}">${esc(text)}</span>`;
}

function initResponsiveNavigation() {
  const header = document.querySelector('.topbar');
  const nav = header?.querySelector('nav');
  if (!header || !nav || header.querySelector('.mobile-navigation')) return;
  nav.classList.add('desktop-navigation');

  const label = document.createElement('label');
  label.className = 'mobile-navigation';
  label.setAttribute('aria-label', 'Hauptmenü');
  const caption = document.createElement('span');
  caption.textContent = 'Menü';
  const select = document.createElement('select');
  select.setAttribute('aria-label', 'Seite auswählen');

  [...nav.querySelectorAll('a[href]')].forEach(link => {
    const option = document.createElement('option');
    option.value = link.getAttribute('href');
    option.textContent = link.textContent.trim();
    option.selected = link.classList.contains('active');
    select.append(option);
  });
  if (![...select.options].some(option => option.selected)) {
    const current = location.pathname.replace(/\/$/, '') || '/';
    const option = [...select.options].find(item =>
      (item.value.replace(/\/$/, '') || '/') === current);
    if (option) option.selected = true;
  }
  select.addEventListener('change', () => {
    if (select.value && select.value !== location.pathname) location.href = select.value;
  });
  label.append(caption, select);
  nav.insertAdjacentElement('afterend', label);

  const user = header.querySelector(':scope > .small');
  if (user) user.classList.add('topbar-user');
  const logoutButton = header.querySelector(':scope > button');
  if (logoutButton) logoutButton.classList.add('topbar-logout');
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initResponsiveNavigation);
} else {
  initResponsiveNavigation();
}
