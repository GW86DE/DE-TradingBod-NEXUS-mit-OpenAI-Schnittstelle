let tradeDaten = {};
let chartDaten = null;
let ausgewaehlt = null;

const zahl = (v, stellen = 2) => v === null || v === undefined || v === ''
  ? 'unbekannt'
  : Number(v).toLocaleString('de-DE', {minimumFractionDigits: stellen, maximumFractionDigits: stellen});
const zeit = v => {
  if (!v) return '–';
  const d = new Date(v);
  return Number.isNaN(d.getTime()) ? String(v) : d.toLocaleString('de-DE', {dateStyle: 'short', timeStyle: 'short'});
};
const modus = r => r.entry_strategy_mode || r.strategie_version || 'UNBEKANNT';

function metricKarte(titel, wert, zusatz = '', klasse = '') {
  return `<article class="card"><h3>${esc(titel)}</h3><div class="metric ${klasse}">${esc(wert)}</div><div class="small">${esc(zusatz)}</div></article>`;
}

function zeichneKennzahlen() {
  const k = tradeDaten.kennzahlen || {};
  const ergebnis = k.summe_netto === null || k.summe_netto === undefined
    ? 'unbekannt' : `${zahl(k.summe_netto)} ${waehrungHinweis()}`;
  const ergebnisKlasse = Number(k.summe_netto || 0) > 0 ? 'pos' : Number(k.summe_netto || 0) < 0 ? 'neg' : '';
  document.querySelector('#trade-kennzahlen').innerHTML = [
    metricKarte('Offene Trades', k.offen ?? 0, 'werden nicht als 0,00 bewertet'),
    metricKarte('Klärung nötig', k.klaerung ?? 0, 'nicht als offen bestätigt', (k.klaerung ?? 0) ? 'neg' : ''),
    metricKarte('Geschlossene Trades', k.geschlossen ?? 0, `${k.bewertbar ?? 0} mit bekanntem Ergebnis`),
    metricKarte('Trefferquote', k.trefferquote_pct == null ? 'unbekannt' : `${zahl(k.trefferquote_pct, 1)} %`, `${k.gewinne ?? 0} Gewinne · ${k.verluste ?? 0} Verluste`),
    metricKarte('Nettoergebnis', ergebnis, 'realisierte Ledger-Ergebnisse', ergebnisKlasse),
    metricKarte('Gebühren', k.gebuehren == null ? 'unbekannt' : `${zahl(k.gebuehren)} ${waehrungHinweis()}`, 'soweit vom Broker bekannt'),
  ].join('');
}

function waehrungHinweis() {
  const b = document.querySelector('#trade-broker')?.value || '';
  return b === 'etoro' ? 'Kontowährung' : b === 'okx' ? 'Quote' : 'je Trade';
}

function pnlText(v, w = '') {
  if (v === null || v === undefined) return '<span class="small">unbekannt</span>';
  const klasse = Number(v) > 0 ? 'trade-pos' : Number(v) < 0 ? 'trade-neg' : '';
  return `<span class="${klasse}">${esc(zahl(v))} ${esc(w || '')}</span>`;
}

function statusDeutsch(v) {
  return ({PENDING_CONFIRMATION:'Abgleich läuft',RESIDUAL_EXPOSURE:'Restbestand ohne Positionsbuch',
    UNPROVABLE:'Brokerbeweis fehlt',ACCOUNT_MISMATCH:'Anderes OKX-Konto',
    EXTERNAL_OBSERVE:'Externer Bestand · nur beobachten',CONFIRMED_OPEN:'Offen bestätigt'})[String(v||'').toUpperCase()] || (v || 'unbekannt');
}

function tradeTabelle(rows, offen, klaerung = false) {
  if (!rows.length) return `<p class="small">Keine ${offen ? 'offenen' : 'geschlossenen'} Trades im gewählten Zeitraum.</p>`;
  const body = rows.map(r => {
    const id = Number(r.trade_id);
    const selected = id === ausgewaehlt ? ' selected' : '';
    return `<tr class="trade-row${selected}" tabindex="0" data-trade-id="${id}">
      <td><strong>${esc(r.symbol || '?')}</strong><br><span class="small">${esc(String(r.broker || '').toUpperCase())}</span></td>
      <td>${esc(zahl(r.menge, 8))}</td><td>${esc(zahl(r.einstieg_preis, 8))}<br><span class="small">${esc(zeit(r.eingestiegen_am))}</span></td>
      ${offen ? `<td><span class="small">Kurs in Grafik</span></td>` : `<td>${esc(zahl(r.ausstieg_preis, 8))}<br><span class="small">${esc(zeit(r.ausgestiegen_am))}</span></td>`}
      <td>${pnlText(r.netto_pnl, r.waehrung)}</td><td>${esc(klaerung ? statusDeutsch(r.reconciliation_status) : (r.exit_grund || (offen ? 'offen bestätigt' : 'unbekannt')))}${klaerung && r.notiz ? `<br><span class="small">${esc(r.notiz)}</span>` : ''}</td>
      <td>${badge(modus(r), String(modus(r)).includes('FREQTRADE') ? 'warn' : '')}<br><span class="small">${esc(r.enter_tag || 'kein Einstiegstag')}</span></td>
      <td>${r.paper ? badge('DEMO', 'ok') : badge('LIVE', 'bad')}</td>
    </tr>`;
  }).join('');
  return `<table class="trade-table"><thead><tr><th>Wert</th><th>Menge</th><th>Kauf</th><th>${offen ? 'Aktuell' : 'Verkauf'}</th><th>Netto</th><th>Grund</th><th>Modus / Signal</th><th>Konto</th></tr></thead><tbody>${body}</tbody></table>`;
}

function verbindeZeilen() {
  document.querySelectorAll('.trade-row').forEach(row => {
    const waehlen = () => ladeChart(Number(row.dataset.tradeId));
    row.addEventListener('click', waehlen);
    row.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); waehlen(); } });
  });
}

function zeichneTabellen() {
  document.querySelector('#open-trades').innerHTML = tradeTabelle(tradeDaten.offene_trades || [], true);
  document.querySelector('#reconcile-trades').innerHTML = tradeTabelle(tradeDaten.klaerungs_trades || [], true, true);
  document.querySelector('#closed-trades').innerHTML = tradeTabelle(tradeDaten.geschlossene_trades || [], false);
  verbindeZeilen();
}

function svgText(x, y, text, anchor = 'start', klasse = '') {
  return `<text x="${x}" y="${y}" text-anchor="${anchor}" class="${klasse}">${esc(text)}</text>`;
}

function zeichneProfit() {
  const ziel = document.querySelector('#profit-chart');
  const rows = tradeDaten.kumulierte_ergebnisse || [];
  if (!rows.length) { ziel.innerHTML = '<div class="trade-empty">Noch keine bewertbaren geschlossenen Trades.</div>'; return; }
  const width = Math.max(420, ziel.clientWidth || 700), height = Math.max(220, Math.min(330, width * .42));
  const pad = {l: 58, r: 18, t: 18, b: 38};
  const values = [0, ...rows.map(x => Number(x.wert))];
  let min = Math.min(...values), max = Math.max(...values);
  if (min === max) { min -= 1; max += 1; }
  const x = i => pad.l + i * (width - pad.l - pad.r) / Math.max(1, rows.length - 1);
  const y = v => pad.t + (max - v) * (height - pad.t - pad.b) / (max - min);
  const points = rows.map((r, i) => `${x(i)},${y(Number(r.wert))}`).join(' ');
  let grid = '';
  for (let i = 0; i <= 4; i++) {
    const v = min + (max - min) * i / 4, yy = y(v);
    grid += `<line x1="${pad.l}" y1="${yy}" x2="${width-pad.r}" y2="${yy}" class="chart-grid"/>${svgText(pad.l-8, yy+4, zahl(v), 'end', 'chart-label')}`;
  }
  const start = zeit(rows[0].zeit), ende = zeit(rows[rows.length-1].zeit);
  ziel.innerHTML = `<svg viewBox="0 0 ${width} ${height}" class="chart-svg" aria-label="Kumuliertes Nettoergebnis">${grid}<line x1="${pad.l}" y1="${y(0)}" x2="${width-pad.r}" y2="${y(0)}" class="zero-line"/><polyline points="${points}" class="profit-line"/>${rows.map((r,i)=>`<circle cx="${x(i)}" cy="${y(Number(r.wert))}" r="4" class="profit-point"><title>${esc(r.symbol)} · ${esc(zahl(r.pnl))} · ${esc(zeit(r.zeit))}</title></circle>`).join('')}${svgText(pad.l, height-11, start, 'start', 'chart-label')}${svgText(width-pad.r, height-11, ende, 'end', 'chart-label')}</svg>`;
}

function candleZeitX(iso, candles, x) {
  const t = new Date(iso).getTime();
  let best = 0, dist = Infinity;
  candles.forEach((c, i) => { const d = Math.abs(new Date(c.zeit).getTime() - t); if (d < dist) { dist = d; best = i; } });
  return x(best);
}

function zeichneKerzen() {
  const ziel = document.querySelector('#trade-chart');
  if (!chartDaten?.ok || !(chartDaten.candles || []).length) {
    ziel.innerHTML = `<div class="trade-empty">${esc(chartDaten?.fehler || 'Keine Kerzendaten verfügbar.')}</div>`;
    document.querySelector('#trade-chart-legend').innerHTML = '';
    return;
  }
  const candles = chartDaten.candles;
  const width = Math.max(520, ziel.clientWidth || 850), height = Math.max(310, Math.min(510, width * .54));
  const pad = {l: 76, r: 22, t: 28, b: 52};
  const extra = [chartDaten.kauf?.preis, chartDaten.verkauf?.preis, chartDaten.stop, chartDaten.take_profit].filter(v => v != null).map(Number);
  let min = Math.min(...candles.map(c => Number(c.low)), ...extra), max = Math.max(...candles.map(c => Number(c.high)), ...extra);
  const margin = Math.max((max-min) * .08, max * .001); min -= margin; max += margin;
  const plotW = width-pad.l-pad.r, plotH = height-pad.t-pad.b;
  const step = plotW / candles.length, bodyW = Math.max(2, Math.min(10, step*.62));
  const x = i => pad.l + step * (i + .5), y = v => pad.t + (max-Number(v))*plotH/(max-min);
  let grid = '';
  for (let i=0;i<=5;i++) { const v=min+(max-min)*i/5, yy=y(v); grid += `<line x1="${pad.l}" y1="${yy}" x2="${width-pad.r}" y2="${yy}" class="chart-grid"/>${svgText(pad.l-9,yy+4,zahl(v, Math.abs(v)<1?6:2),'end','chart-label')}`; }
  const bodies = candles.map((c,i) => {
    const up=Number(c.close)>=Number(c.open), top=y(Math.max(Number(c.open),Number(c.close))), bottom=y(Math.min(Number(c.open),Number(c.close)));
    return `<g class="candle ${up?'up':'down'}"><line x1="${x(i)}" y1="${y(c.high)}" x2="${x(i)}" y2="${y(c.low)}"/><rect x="${x(i)-bodyW/2}" y="${top}" width="${bodyW}" height="${Math.max(1,bottom-top)}"><title>${esc(zeit(c.zeit))}\nO ${esc(zahl(c.open,8))} · H ${esc(zahl(c.high,8))} · T ${esc(zahl(c.low,8))} · S ${esc(zahl(c.close,8))}</title></rect></g>`;
  }).join('');
  const lines = [[chartDaten.stop,'Stop-Loss','stop-line'],[chartDaten.take_profit,'Take-Profit','target-line']].filter(x=>x[0]!=null).map(([v,label,k])=>`<line x1="${pad.l}" y1="${y(v)}" x2="${width-pad.r}" y2="${y(v)}" class="${k}"/>${svgText(width-pad.r-5,y(v)-6,`${label} ${zahl(v,8)}`,'end','line-label')}`).join('');
  const marker = (obj, label, klasse, richtung) => {
    if (!obj || obj.preis == null) return '';
    const xx=candleZeitX(obj.zeit,candles,x), yy=y(obj.preis), p=richtung==='up'?`${xx},${yy-4} ${xx-8},${yy+12} ${xx+8},${yy+12}`:`${xx},${yy+4} ${xx-8},${yy-12} ${xx+8},${yy-12}`;
    const ly=richtung==='up'?yy+29:yy-19;
    return `<polygon points="${p}" class="${klasse}"><title>${esc(label)} · ${esc(zeit(obj.zeit))} · ${esc(zahl(obj.preis,8))}</title></polygon>${svgText(xx,ly,`${label} ${zahl(obj.preis,8)}`,'middle',`${klasse}-text`)}`;
  };
  const kauf=marker(chartDaten.kauf,'KAUF','buy-marker','up'), verkauf=marker(chartDaten.verkauf,'VERKAUF','sell-marker','down');
  const ticks=[0,Math.floor((candles.length-1)/2),candles.length-1].map(i=>svgText(x(i),height-16,zeit(candles[i].zeit),'middle','chart-label')).join('');
  ziel.innerHTML=`<svg viewBox="0 0 ${width} ${height}" class="chart-svg" aria-label="Kerzen für ${esc(chartDaten.instrument)}">${grid}${bodies}${lines}${kauf}${verkauf}${ticks}</svg>`;
  document.querySelector('#trade-chart-title').textContent=`${chartDaten.instrument} · Kauf/Verkauf`;
  document.querySelector('#trade-chart-info').textContent=`${chartDaten.bar}-Kerzen · nur abgeschlossen · letzter Schluss ${zahl(chartDaten.letzter_schluss,8)} ${chartDaten.waehrung || ''}`;
  document.querySelector('#trade-chart-mode').textContent=chartDaten.entry_strategy_mode || 'UNBEKANNT';
  document.querySelector('#trade-chart-mode').className='status '+(String(chartDaten.entry_strategy_mode||'').includes('FREQTRADE')?'warn':'ok');
  document.querySelector('#trade-chart-legend').innerHTML='<span><i class="legend-buy"></i>Kauf</span><span><i class="legend-sell"></i>Verkauf</span><span><i class="legend-up"></i>Steigende Kerze</span><span><i class="legend-down"></i>Fallende Kerze</span>'+(chartDaten.stop!=null?'<span><i class="legend-stop"></i>Stop-Loss</span>':'')+(chartDaten.take_profit!=null?'<span><i class="legend-target"></i>Take-Profit</span>':'');
}

async function ladeChart(id) {
  ausgewaehlt=id; zeichneTabellen();
  const ziel=document.querySelector('#trade-chart'); ziel.innerHTML='<div class="trade-empty">Kerzen werden geladen …</div>';
  try { chartDaten=await api(`/api/trades/${id}/candles`); zeichneKerzen(); }
  catch(e) { chartDaten={ok:false,fehler:e.message}; zeichneKerzen(); }
}

async function ladeTrades() {
  const broker=document.querySelector('#trade-broker').value, tage=document.querySelector('#trade-tage').value;
  try {
    tradeDaten=await api(`/api/trades?broker=${encodeURIComponent(broker)}&tage=${encodeURIComponent(tage)}`);
    zeichneKennzahlen(); zeichneTabellen(); zeichneProfit();
    document.querySelector('#trade-note').textContent=tradeDaten.hinweis || '';
  } catch(e) { document.querySelector('#trade-note').className='alert danger section'; document.querySelector('#trade-note').textContent=e.message; }
}

document.querySelector('#trade-refresh').addEventListener('click',ladeTrades);
document.querySelector('#trade-broker').addEventListener('change',ladeTrades);
document.querySelector('#trade-tage').addEventListener('change',ladeTrades);
let resizeTimer;
window.addEventListener('resize',()=>{clearTimeout(resizeTimer);resizeTimer=setTimeout(()=>{zeichneProfit();zeichneKerzen();},150)});
ladeTrades();
