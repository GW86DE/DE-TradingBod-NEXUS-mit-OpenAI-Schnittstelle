let daten = {};

function stundenText(h) {
  if (h === null || h === undefined) return '–';
  if (h < 24) return `${h.toFixed(0)} h`;
  return `${(h / 24).toFixed(1)} Tage`;
}

function zustandsFarbe(z) {
  if (z === 'AKTIV') return 'ok';
  if (z === 'ABGANG') return 'warn';
  return '';
}

function merkmale(w) {
  const teile = [];
  if (w.kern) teile.push('<span class="status ok">KERN</span>');
  if (w.gepinnt) teile.push('<span class="status warn">POSITION</span>');
  if (w.favorit) teile.push('<span class="status">FAVORIT</span>');
  if (w.focus) teile.push(`<span class="status">FOCUS ${w.focus_platz || ''}</span>`);
  return teile.join(' ') || '–';
}

function filtern(werte) {
  const suche = (document.querySelector('#f-suche').value || '').trim().toUpperCase();
  const zustand = document.querySelector('#f-zustand').value;
  const art = document.querySelector('#f-art').value;
  let out = werte.filter(w => {
    if (suche && !String(w.symbol || '').toUpperCase().includes(suche)) return false;
    if (zustand && w.zustand !== zustand) return false;
    if (art === 'kern' && !w.kern) return false;
    if (art === 'focus' && !w.focus) return false;
    if (art === 'gepinnt' && !w.gepinnt) return false;
    if (art === 'ki' && !w.ki) return false;
    return true;
  });
  const sortierung = document.querySelector('#f-sortierung').value;
  const nachRang = (a, b) => (a.rang || 9999) - (b.rang || 9999);
  if (sortierung === 'score') out.sort((a, b) => (b.score || 0) - (a.score || 0));
  else if (sortierung === 'symbol') out.sort((a, b) => String(a.symbol).localeCompare(String(b.symbol)));
  else if (sortierung === 'neu') out.sort((a, b) => (a.alter_stunden ?? 1e9) - (b.alter_stunden ?? 1e9));
  else if (sortierung === 'alt') out.sort((a, b) => (b.alter_stunden ?? -1) - (a.alter_stunden ?? -1));
  else out.sort(nachRang);
  return out;
}

function tabelle(werte) {
  if (!werte.length) return '<p class="small">Keine Werte, die zum Filter passen.</p>';
  const zeilen = werte.map(w => `<tr>
    <td><strong>${esc(w.symbol)}</strong></td>
    <td>${badge(w.zustand || '?', zustandsFarbe(w.zustand))}</td>
    <td>${merkmale(w)}</td>
    <td>${w.rang || '–'}${w.bester_rang ? ` <span class="small">(best ${w.bester_rang})</span>` : ''}</td>
    <td>${(w.score ?? 0).toFixed(3)}</td>
    <td>${stundenText(w.alter_stunden)}</td>
    <td>${stundenText(w.stunden_im_zustand)}</td>
    <td>${esc(w.ki || '–')}${w.ki_modell ? `<br><span class="small">${esc(w.ki_modell)}</span>` : ''}</td>
    <td class="small">${esc(w.aufnahmegrund || w.abganggrund || '–')}</td>
  </tr>`).join('');
  return `<table><thead><tr>
    <th>Symbol</th><th>Zustand</th><th>Merkmale</th><th>Rang</th><th>Score</th>
    <th>Aufgenommen vor</th><th>Im Zustand seit</th><th>KI-Urteil</th><th>Grund</th>
  </tr></thead><tbody>${zeilen}</tbody></table>`;
}

function zeichne() {
  const broker = daten.broker || {};
  for (const [key, prefix] of [['okx', 'okx'], ['etoro', 'etoro']]) {
    const d = broker[key] || {};
    const alle = d.werte || [];
    const gefiltert = filtern(alle);
    document.querySelector(`#${prefix}-tabelle`).innerHTML = d.fehler
      ? `<div class="alert danger">${esc(d.fehler)}</div>`
      : tabelle(gefiltert);
    const u = d.uebersicht || {};
    const regel = d.autonome_aufnahme
      ? 'Der Bot nimmt eigenständig auf und entfernt selbst.'
      : 'Aufnahmen brauchen deine Bestätigung per Telegram. Sicherheitsabgänge passieren sofort.';
    document.querySelector(`#${prefix}-info`).innerHTML =
      `${gefiltert.length} von ${alle.length} angezeigt · Limit ${u.aktiv_limit || '?'} · `
      + `Focus ${u.focus_limit || '?'} · handelbar ${u.handelbar || 0} · `
      + `Beobachtung ${u.beobachtung || 0} · gepinnt ${u.gepinnt || 0}<br>${esc(regel)}`;
  }

  const okx = broker.okx?.uebersicht || {}, etoro = broker.etoro?.uebersicht || {};
  // Ab v9.0.1: 20 feste Kryptowerte und 30 monatlich dynamische Werte.
  // Die 75 Aktienticker wuerden die Kachel sprengen -- deshalb nur Zahlen.
  const kernKrypto = daten.kernwerte_krypto || daten.kernwerte || [];
  const kernAktien = daten.kernwerte_aktien || [];
  const kernGesamt = kernKrypto.length + kernAktien.length;
  const kern = kernAktien.length
    ? `${kernAktien.length} Aktien · ${kernKrypto.length} Krypto`
    : `${kernKrypto.length} feste Kryptowerte`;
  const dynamic = daten.dynamic_30 || {};
  const dynamicItems = dynamic.items || [];
  document.querySelector('#kennzahlen').innerHTML = `
    <article class="card"><h3>OKX Krypto</h3><div class="metric">${okx.handelbar || 0}</div>
      <p>handelbar von max. ${okx.aktiv_limit || '?'}</p>
      <div class="small">In Beobachtung: ${okx.beobachtung || 0}</div></article>
    <article class="card"><h3>Fester Kern</h3><div class="metric">${kernGesamt}</div>
      <p>${esc(kern || 'nicht gesetzt')}</p>
      <div class="small">Nie durch Rang oder Hysterese entfernbar</div></article>
    <article class="card"><h3>Dynamische Kryptos</h3><div class="metric">${dynamicItems.length}</div>
      <p>von 30 monatlich bewerteten Werten</p>
      <div class="small">${esc(dynamic.status || 'EMPTY')} · nächste Bewertung ${esc(dynamic.next_due_utc || '–')}</div></article>
    <article class="card"><h3>eToro Aktien</h3><div class="metric">${etoro.handelbar || 0}</div>
      <p>handelbar von max. ${etoro.aktiv_limit || '?'}</p>
      <div class="small">Aufnahme nur mit Telegram-Freigabe</div></article>
    <article class="card"><h3>Offene Positionen</h3><div class="metric">${(okx.gepinnt || 0) + (etoro.gepinnt || 0)}</div>
      <p>bleiben immer im Monitoring</p>
      <div class="small">Auch wenn sie aus dem Entry-Universe fallen</div></article>`;

  const coverage = dynamic.coverage || {}, changes = dynamic.changes || {};
  const items = dynamicItems;
  const statusClass = dynamic.status === 'CURRENT' ? 'ok' : 'warn';
  const rows = items.map(x => `<tr><td>${x.rank || '–'}</td><td><strong>${esc(x.base || '?')}</strong></td>`
    + `<td>${esc(x.pair || '–')}</td><td>${esc(x.quote || '–')}</td>`
    + `<td>${x.volume_30d_median_eur !== undefined ? Number(x.volume_30d_median_eur).toLocaleString('de-DE', {maximumFractionDigits:0}) : Number(x.volume_24h_normalized_eur || 0).toLocaleString('de-DE', {maximumFractionDigits:0})}</td>`
    + `<td class="small">${esc(x.measured_at_utc || '–')}</td></tr>`).join('');
  const kernListe = kernKrypto.join(', ') || 'noch nicht geladen';
  document.querySelector('#crypto-universum').innerHTML = `<h2>Krypto-Universum 20 + 30 ${badge(dynamic.status || 'EMPTY', statusClass)}</h2>`
    + `<p class="small"><strong>Fester Kern (${kernKrypto.length}/20):</strong> ${esc(kernListe)}. Die Mitgliedschaft bleibt; aktuelle Sicherheitsfilter können einzelne Werte sperren.</p>`
    + `<p class="small"><strong>Dynamisch (${items.length}/30):</strong> Quelle: ${esc(dynamic.source || 'OKX official public SPOT tickers')} · `
    + `Auswahl: ${esc(dynamic.selection_method || 'aktuelles normalisiertes 24h-Quote-Notional, danach 30-Tage-Median')} · `
    + `Abdeckung: ${coverage.days || 0}/${coverage.required_days || 20} Tage · Letzter Erfolg: ${esc(dynamic.last_success_utc || '–')} · `
    + `Nächste Fälligkeit: ${esc(dynamic.next_due_utc || '–')}</p>`
    + `<p class="small">Hinzu: ${esc((changes.added || []).join(', ') || 'keine')} · Entfernt: ${esc((changes.removed || []).join(', ') || 'keine')} · `
    + `Unverändert: ${(changes.unchanged || []).length}${dynamic.error ? ` · Hinweis: ${esc(dynamic.error)}` : ''}</p>`
    + (rows ? `<div class="table-wrap"><table><thead><tr><th>Rang</th><th>Basis</th><th>Paar</th><th>Quote</th><th>Volumen EUR</th><th>Messzeit</th></tr></thead><tbody>${rows}</tbody></table></div>`
            : '<p class="small">Noch keine verifizierte dynamische Startliste. Die 20 Kernwerte bleiben sichtbar; jeder Kauf braucht trotzdem vollständige und aktuelle Marktdaten.</p>');
}

async function ladeUniversum() {
  try {
    daten = await api('/api/universe');
    if (daten.fehler) {
      document.querySelector('#kennzahlen').innerHTML = `<div class="alert danger">${esc(daten.fehler)}</div>`;
      return;
    }
    zeichne();
  } catch (e) {
    document.querySelector('#kennzahlen').innerHTML = `<div class="alert danger">${esc(e.message)}</div>`;
  }
}

ladeUniversum();
