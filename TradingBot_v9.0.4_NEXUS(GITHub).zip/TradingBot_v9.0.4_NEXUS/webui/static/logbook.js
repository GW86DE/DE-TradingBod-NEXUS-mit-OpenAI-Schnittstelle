let current = 1, pages = 1;

function qs() {
  return new URLSearchParams({
    page: current, per_page: 50, broker: broker.value,
    asset_type: asset.value, status: status.value, source: source.value,
    symbol: symbol.value, day: day.value,
  });
}

function sources(x) {
  const rows = Array.isArray(x) ? x : [];
  return rows.slice(0, 5)
    .map(v => typeof v === 'string' ? v : (v.quelle || v.source || v.datenquelle || ''))
    .filter(Boolean).join(', ');
}

function strategy(x) {
  const mode = x.strategy_mode || '–', version = x.strategy_version || '';
  return `<strong>${esc(mode)}</strong>${version ? `<br><span class="small">${esc(version)}${x.strategy_parameter_hash ? ` · ${esc(String(x.strategy_parameter_hash).slice(0, 12))}` : ''}</span>` : ''}`;
}

function execution(x) {
  const events = (x.execution_events || []).slice(0, 3).map(e => e.event_type).join(' → ');
  const orders = (x.orders || []).map(o => `${o.role}:${o.status} ${o.filled_qty ?? '–'}/${o.requested_qty ?? '–'}`).join(' · ');
  return `${x.execution_status || ''}${events ? `<br><span class="small">${esc(events)}</span>` : ''}${orders ? `<br><span class="small">${esc(orders)}</span>` : ''}<br><span class="small">${x.paper ? 'Paper' : 'LIVE'} · Update ${esc((x.updated_at_utc || '–').replace('T', ' ').slice(0, 19))}</span>`;
}

async function loadDecisions(page = 1) {
  current = page;
  try {
    const d = await api('/api/logs/decisions?' + qs());
    pages = d.pages || 1;
    count.textContent = `${d.total} Eintraege`;
    decisionRows.innerHTML = d.rows.map(x => `<tr>
      <td>${esc((x.created_at_utc || '').replace('T', ' ').slice(0, 19))}</td>
      <td>${esc(x.broker)}</td>
      <td><strong>${esc(x.symbol)}</strong><br><span class="small">${esc(x.asset_type)}</span></td>
      <td>${strategy(x)}</td>
      <td>${badge(x.status, x.status === 'APPROVED' ? 'ok' : x.status.includes('BLOCK') ? 'bad' : 'warn')}</td>
      <td>${esc(x.reason || x.blocked_by || '')}</td>
      <td>${esc(x.hauptquelle || '')}</td>
      <td class="source-list">${esc(sources(x.sources))}</td>
      <td>${execution(x)}</td></tr>`).join('') || '<tr><td colspan="9">Keine Treffer</td></tr>';
    document.querySelector('#page').textContent = `Seite ${current} von ${pages}`;
    prev.disabled = current <= 1;
    next.disabled = current >= pages;
  } catch (e) {
    decisionRows.innerHTML = `<tr><td colspan="9">${esc(e.message)}</td></tr>`;
  }
}

async function loadSystem() {
  try {
    const p = new URLSearchParams({search: sysSearch.value, level: sysLevel.value, limit: 300});
    const d = await api('/api/logs/system?' + p);
    systemRows.textContent = d.rows.join('\n');
  } catch (e) {
    systemRows.textContent = e.message;
  }
}

prev.onclick = () => loadDecisions(Math.max(1, current - 1));
next.onclick = () => loadDecisions(Math.min(pages, current + 1));
loadDecisions();
loadSystem();

