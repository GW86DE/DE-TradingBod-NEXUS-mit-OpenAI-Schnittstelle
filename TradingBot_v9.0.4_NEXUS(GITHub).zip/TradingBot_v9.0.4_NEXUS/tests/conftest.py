"""Gemeinsame Testvorbereitung (neu in v8.1.5).

WARUM ES DIESE DATEI GIBT
=========================
Die Testsuite hatte keine gemeinsame Vorbereitung. Jede Datei setzte
``TRADINGBOT_TEST_STATE_DIR`` selbst -- manche erst in einer Funktion, manche
gar nicht. Module, die ihren Zustandspfad beim IMPORT festlegen, hatten zu
diesem Zeitpunkt noch keinen Testordner gesehen und schrieben deshalb in den
Release-Baum. Betroffen waren sechs Testdateien.

Das war nicht nur unsauber. Es hat zwei echte Fehlerbilder erzeugt:

1. ``volltest.py`` meldete nach jedem Testlauf zu Recht "Laufzeitdatei im
   Release-Baum". Vor jedem Packen musste jemand von Hand aufraeumen -- und
   wer es vergass, packte eine fremde Entscheidungsdatenbank mit ins Release.

2. Das KI-Tagesbudget in ``ai_router_usage.json`` sammelte sich ueber
   Testlaeufe hinweg im Release-Baum auf. Irgendwann war das Terra-Budget
   aufgebraucht, und ``test_universe_research`` schlug fehl -- mit einem
   Fehlerbild, das mit dem gepruefen Verhalten nichts zu tun hatte. Genau so
   entstehen Tests, denen man nicht mehr glaubt.

pytest laedt ``conftest.py`` VOR den Testmodulen. Nur hier laesst sich die
Variable so frueh setzen, dass auch Module sie sehen, die ihren Pfad beim
Import bestimmen.

Einzelne Tests duerfen weiterhin ``monkeypatch.setenv`` benutzen, um sich ein
eigenes Verzeichnis zu geben -- das hier ist nur der sichere Grundzustand.
"""
from __future__ import annotations

import os
import tempfile
from pathlib import Path

# Muss VOR jedem Import eines Botmoduls stehen.
_STANDARD = Path(tempfile.gettempdir()) / "tradingbot_tests"
_STANDARD.mkdir(parents=True, exist_ok=True)
os.environ.setdefault("TRADINGBOT_TEST_STATE_DIR", str(_STANDARD))

import sys

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
