"""AIRouter -- entscheidet zentral, WELCHES Modell eine Aufgabe bekommt (AIU-001).

DAS PROBLEM
===========
Bis v6.0 ging jede KI-Anfrage an dasselbe Modell (Terra). Das ist bei
haeufigen, einfachen Aufgaben unnoetig teuer: eine Klassifizierung
"HIGH/NORMAL/LOW" braucht kein Modell fuer 2 USD je Million Token, wenn es
eines fuer 0,20 USD genauso gut kann.

DIE LOESUNG
===========
Drei Stufen statt einer:

    KEINE AI   deterministisch loesbar -> gar keine Anfrage
    LUNA       einfach und haeufig     -> guenstiges Modell
    TERRA      komplex und selten      -> starkes Modell

Die Routing-Entscheidung faellt VOR der Anfrage anhand der Aufgabenart und
des Kontexts, nicht danach.

HARTE GRENZEN (AIU-005, AIU-006)
================================
    - Die KI darf Aufmerksamkeit steuern, klassifizieren und erklaeren.
    - Sie darf NIEMALS ein Instrument handelbar machen, einen harten Filter
      ueberschreiben, das Candidate Gate umgehen oder eine Position
      vergroessern.
    - Faellt die KI aus oder ist das Budget leer, laeuft die deterministische
      Pipeline unveraendert weiter. Der Zustand heisst AI_DEGRADED und ist
      ein Hinweis, kein Fehler.
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import threading
import time
from dataclasses import dataclass, field
from datetime import date, datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Optional

import requests

import config
from safe_persistence import best_effort_json

logger = logging.getLogger(__name__)
ROOT = Path(__file__).resolve().parent
STATE_ROOT = Path(os.getenv("TRADINGBOT_TEST_STATE_DIR", "").strip() or ROOT)


def _zustandswurzel() -> Path:
    """Wo Budget, Zwischenspeicher und Pruefspur liegen -- beim Zugriff bestimmt.

    v8.1.5: ``STATE_ROOT`` wurde beim IMPORT festgelegt. Ein Test, der
    ``ai_router`` importiert bevor er ``TRADINGBOT_TEST_STATE_DIR`` setzt,
    schrieb sein Tagesbudget deshalb in den Release-Baum. Dort summierte es
    sich ueber Testlaeufe hinweg auf, bis ein voellig anderer Test scheiterte,
    weil "das Terra-Tagesbudget aufgebraucht" war -- ein Fehlerbild, das mit
    dem gepruefen Verhalten nichts zu tun hatte.
    """
    test_dir = os.getenv("TRADINGBOT_TEST_STATE_DIR", "").strip()
    return Path(test_dir) if test_dir else STATE_ROOT

LUNA = "luna"
TERRA = "terra"
KEINE = "keine"

OPENAI_URL = "https://api.openai.com/v1/responses"


# ---------------------------------------------------------------------------
# Aufgabenkatalog
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class Aufgabe:
    """Beschreibt eine KI-Aufgabe und ihre Standardstufe."""
    name: str
    stufe: str                     # LUNA oder TERRA
    beschreibung: str
    cache_stunden: float = 6.0
    max_output_tokens: int = 900
    reasoning: str = "low"
    web_suche: bool = False


AUFGABEN: dict[str, Aufgabe] = {
    "universe_kandidat": Aufgabe(
        "universe_kandidat", LUNA,
        "Einen beobachteten Wert einstufen: HIGH / NORMAL / LOW",
        cache_stunden=6.0, max_output_tokens=700),
    "universe_batch": Aufgabe(
        "universe_batch", LUNA,
        "Mehrere Focus-Kandidaten in EINER Anfrage priorisieren",
        cache_stunden=6.0, max_output_tokens=1400),
    "news_relevanz": Aufgabe(
        "news_relevanz", LUNA,
        "Ist diese Meldung fuer dieses Instrument relevant?",
        cache_stunden=3.0, max_output_tokens=600),
    "duplikate": Aufgabe(
        "duplikate", LUNA,
        "Doppelte Meldungen zusammenfassen",
        cache_stunden=3.0, max_output_tokens=600),
    "focus_ranking": Aufgabe(
        "focus_ranking", LUNA,
        "Reihenfolge des Focus Sets vorschlagen",
        cache_stunden=2.0, max_output_tokens=900),
    "anomalie_research": Aufgabe(
        "anomalie_research", TERRA,
        "Ursache einer starken, unerklaerten Bewegung untersuchen",
        cache_stunden=12.0, max_output_tokens=2600, reasoning="medium", web_suche=True),
    "widerspruch": Aufgabe(
        "widerspruch", TERRA,
        "Widerspruechliche Meldungen einordnen",
        cache_stunden=12.0, max_output_tokens=2200, reasoning="medium", web_suche=True),
    "krypto_event": Aufgabe(
        "krypto_event", TERRA,
        "Listing, Unlock, Exploit oder Regulierung bewerten",
        cache_stunden=12.0, max_output_tokens=2400, reasoning="medium", web_suche=True),
    "wochen_research": Aufgabe(
        "wochen_research", TERRA,
        "Woechentliches Research fuer Universumsvorschlaege",
        cache_stunden=24.0, max_output_tokens=5000, reasoning="medium", web_suche=True),
    "strategie_auswertung": Aufgabe(
        "strategie_auswertung", TERRA,
        "Aggregierte lokale Strategie-Statistik vorsichtig interpretieren",
        cache_stunden=24.0, max_output_tokens=3500, reasoning="medium", web_suche=False),
    # v8.1.4: Zweite Meinung vor einer Kauforder. Reine Warn- und
    # Dokumentationsschicht -- die KI loest keine Order aus und hebt keine
    # Ablehnung auf. Kein Zwischenspeicher: eine Einschaetzung von vor
    # Stunden waere fuer genau diesen Einstieg wertlos. Keine Websuche,
    # damit der Kaufpfad nicht auf externe Dienste wartet.
    "second_opinion": Aufgabe(
        "second_opinion", TERRA,
        "Zweite Meinung zu einem bereits freigegebenen Kaufkandidaten",
        cache_stunden=0.0, max_output_tokens=900, reasoning="low", web_suche=False),
    "core_volume_identity": Aufgabe(
        "core_volume_identity", LUNA,
        "Monatlichen CORE_VOLUME_20-Diff nur auf Identitaet/Rebranding/Risiko pruefen",
        cache_stunden=720.0, max_output_tokens=700, reasoning="low", web_suche=False),
}


# Ausloeser, die eine einfache Aufgabe zur komplexen hochstufen (AIU-003).
ESKALATIONS_GRUENDE = (
    "marktanomalie", "widerspruch", "exploit", "hack", "unlock",
    "delisting", "regulierung", "uebernahme", "insolvenz",
)


# ---------------------------------------------------------------------------
# Antwortschemata
# ---------------------------------------------------------------------------
SCHEMA_EINSTUFUNG = {
    "type": "object",
    "properties": {
        "attention": {"type": "string", "enum": ["HIGH", "NORMAL", "LOW"]},
        "research_needed": {"type": "boolean"},
        "risiken": {"type": "array", "items": {"type": "string"}, "maxItems": 5},
        "begruendung": {"type": "string"},
    },
    "required": ["attention", "research_needed", "risiken", "begruendung"],
    "additionalProperties": False,
}

SCHEMA_BATCH = {
    "type": "object",
    "properties": {
        "bewertungen": {
            "type": "array",
            "maxItems": 40,
            "items": {
                "type": "object",
                "properties": {
                    "symbol": {"type": "string"},
                    "attention": {"type": "string", "enum": ["HIGH", "NORMAL", "LOW"]},
                    "research_needed": {"type": "boolean"},
                    "begruendung": {"type": "string"},
                },
                "required": ["symbol", "attention", "research_needed", "begruendung"],
                "additionalProperties": False,
            },
        },
        "hinweis": {"type": "string"},
    },
    "required": ["bewertungen", "hinweis"],
    "additionalProperties": False,
}

SCHEMA_CORE_VOLUME_IDENTITY = {
    "type": "object",
    "properties": {"warnings": {"type": "array", "items": {"type": "string"}, "maxItems": 20}},
    "required": ["warnings"], "additionalProperties": False,
}

SCHEMA_RESEARCH = {
    "type": "object",
    "properties": {
        "ursache": {"type": "string"},
        "einordnung": {"type": "string", "enum": ["POSITIV", "NEGATIV", "NEUTRAL", "UNKLAR"]},
        "vertrauen": {"type": "string", "enum": ["HOCH", "MITTEL", "NIEDRIG"]},
        "quellen": {"type": "array", "items": {"type": "string"}, "maxItems": 6},
        "risiken": {"type": "array", "items": {"type": "string"}, "maxItems": 6},
        "zusammenfassung": {"type": "string"},
    },
    "required": ["ursache", "einordnung", "vertrauen", "quellen", "risiken", "zusammenfassung"],
    "additionalProperties": False,
}


# ---------------------------------------------------------------------------
# Budget
# ---------------------------------------------------------------------------
class AIBudget:
    """Getrennte Tagesbudgets fuer Luna und Terra (AIU-007, AIU-008)."""

    def __init__(self, datei: Optional[Path] = None, cfg=None):
        self.cfg = cfg or config
        self.datei = Path(datei or _zustandswurzel() / str(
            getattr(self.cfg, "AI_ROUTER_USAGE_FILE", "ai_router_usage.json")))
        self._lock = threading.RLock()

    def _leer(self) -> dict:
        return {"datum": date.today().isoformat(),
                "luna": {"anfragen": 0, "input_tokens": 0, "output_tokens": 0, "kosten": 0.0},
                "terra": {"anfragen": 0, "input_tokens": 0, "output_tokens": 0, "kosten": 0.0},
                "cache_treffer": 0, "abgelehnt": 0, "fehler": 0}

    def lies(self) -> dict:
        heute = date.today().isoformat()
        try:
            daten = json.loads(self.datei.read_text(encoding="utf-8"))
            if str(daten.get("datum")) == heute:
                for stufe in (LUNA, TERRA):
                    daten.setdefault(stufe, {"anfragen": 0, "input_tokens": 0,
                                             "output_tokens": 0, "kosten": 0.0})
                return daten
        except Exception:
            logger.debug("AI-Budgetdatei nicht lesbar", exc_info=True)
        return self._leer()

    def schreibe(self, daten: dict) -> None:
        best_effort_json(self.datei, daten, label="AI-Router-Budget")

    def grenze(self, stufe: str) -> int:
        if stufe == LUNA:
            return int(getattr(self.cfg, "AI_LUNA_MAX_CALLS_PER_DAY", 40))
        return int(getattr(self.cfg, "AI_TERRA_MAX_CALLS_PER_DAY", 8))

    def kostengrenze(self) -> float:
        return float(getattr(self.cfg, "AI_MAX_COST_PER_DAY_USD", 0.50))

    def frei(self, stufe: str) -> tuple[bool, str]:
        with self._lock:
            daten = self.lies()
        genutzt = int(daten.get(stufe, {}).get("anfragen", 0) or 0)
        grenze = self.grenze(stufe)
        if grenze > 0 and genutzt >= grenze:
            return False, f"{stufe.upper()}-Tagesbudget ({grenze} Anfragen) aufgebraucht"
        kosten = sum(float(daten.get(s, {}).get("kosten", 0.0) or 0.0) for s in (LUNA, TERRA))
        grenze_usd = self.kostengrenze()
        if grenze_usd > 0 and kosten >= grenze_usd:
            return False, f"Tageskostenbudget von {grenze_usd:.2f} USD erreicht"
        return True, ""

    def buche(self, stufe: str, *, input_tokens: int = 0, output_tokens: int = 0,
              kosten: float = 0.0) -> None:
        with self._lock:
            daten = self.lies()
            eintrag = daten.setdefault(stufe, {"anfragen": 0, "input_tokens": 0,
                                               "output_tokens": 0, "kosten": 0.0})
            eintrag["anfragen"] = int(eintrag.get("anfragen", 0)) + 1
            eintrag["input_tokens"] = int(eintrag.get("input_tokens", 0)) + int(input_tokens)
            eintrag["output_tokens"] = int(eintrag.get("output_tokens", 0)) + int(output_tokens)
            eintrag["kosten"] = round(float(eintrag.get("kosten", 0.0)) + float(kosten), 6)
            self.schreibe(daten)

    def zaehle(self, feld: str) -> None:
        with self._lock:
            daten = self.lies()
            daten[feld] = int(daten.get(feld, 0) or 0) + 1
            self.schreibe(daten)

    def status(self) -> dict:
        daten = self.lies()
        return {
            "datum": daten.get("datum"),
            "luna": {**daten.get(LUNA, {}), "grenze": self.grenze(LUNA)},
            "terra": {**daten.get(TERRA, {}), "grenze": self.grenze(TERRA)},
            "kosten_gesamt": round(sum(float(daten.get(s, {}).get("kosten", 0.0) or 0.0)
                                       for s in (LUNA, TERRA)), 4),
            "kostengrenze": self.kostengrenze(),
            "cache_treffer": int(daten.get("cache_treffer", 0) or 0),
            "abgelehnt": int(daten.get("abgelehnt", 0) or 0),
            "fehler": int(daten.get("fehler", 0) or 0),
        }


# ---------------------------------------------------------------------------
# Cache
# ---------------------------------------------------------------------------
class AICache:
    """Antwortcache mit TTL je Aufgabenart (AIU-009).

    Der Cache ist bewusst dateibasiert: er muss einen Neustart ueberleben,
    sonst kostet jeder Neustart wieder ein volles Tagesbudget.
    """

    def __init__(self, datei: Optional[Path] = None, max_eintraege: int = 400):
        self.datei = Path(datei or _zustandswurzel() / "ai_router_cache.json")
        self.max_eintraege = int(max_eintraege)
        self._daten: dict[str, dict] = {}
        self._lock = threading.RLock()
        self._laden()

    def _laden(self) -> None:
        try:
            roh = json.loads(self.datei.read_text(encoding="utf-8"))
            if isinstance(roh, dict):
                self._daten = roh.get("eintraege", {}) or {}
        except Exception:
            self._daten = {}

    def _speichern(self) -> None:
        best_effort_json(self.datei, {"version": 1, "eintraege": self._daten},
                         label="AI-Router-Cache")

    @staticmethod
    def schluessel(aufgabe: str, nutzlast: Any) -> str:
        roh = json.dumps({"a": aufgabe, "p": nutzlast}, sort_keys=True, ensure_ascii=False,
                         default=str)
        return hashlib.sha256(roh.encode("utf-8")).hexdigest()[:32]

    def hole(self, schluessel: str, ttl_stunden: float) -> Optional[dict]:
        with self._lock:
            eintrag = self._daten.get(schluessel)
        if not eintrag:
            return None
        alter = time.time() - float(eintrag.get("zeit", 0.0))
        if alter > max(0.0, ttl_stunden) * 3600.0:
            return None
        return eintrag.get("antwort")

    def setze(self, schluessel: str, antwort: dict, *, aufgabe: str = "") -> None:
        with self._lock:
            self._daten[schluessel] = {"zeit": time.time(), "antwort": antwort,
                                       "aufgabe": aufgabe}
            if len(self._daten) > self.max_eintraege:
                aeltere = sorted(self._daten.items(), key=lambda x: x[1].get("zeit", 0.0))
                for k, _ in aeltere[:len(self._daten) - self.max_eintraege]:
                    self._daten.pop(k, None)
            self._speichern()

    def verwerfe(self, *, aufgabe: str = "", symbol: str = "") -> int:
        """Invalidierung bei neuem Ereignis (AIU-009)."""
        entfernt = 0
        with self._lock:
            for k in list(self._daten):
                eintrag = self._daten[k]
                if aufgabe and str(eintrag.get("aufgabe", "")) != aufgabe:
                    continue
                if symbol:
                    text = json.dumps(eintrag.get("antwort", {}), ensure_ascii=False)
                    if symbol.upper() not in text.upper():
                        continue
                self._daten.pop(k, None)
                entfernt += 1
            if entfernt:
                self._speichern()
        return entfernt


# ---------------------------------------------------------------------------
# Nutzungsprotokoll
# ---------------------------------------------------------------------------
def _audit_pfad() -> Path:
    return _zustandswurzel() / "ai_usage_audit.jsonl"


def schreibe_ai_audit(eintrag: dict) -> None:
    """Ein Eintrag je KI-Nutzung (AIU-011)."""
    eintrag = {"zeit": datetime.now(timezone.utc).isoformat(), **eintrag}
    try:
        datei = _audit_pfad()
        if datei.exists() and datei.stat().st_size > 3 * 1024 * 1024:
            datei.replace(datei.with_suffix(".1.jsonl"))
        with datei.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(eintrag, ensure_ascii=False) + "\n")
    except Exception:
        logger.debug("AI-Audit konnte nicht geschrieben werden", exc_info=True)


# ---------------------------------------------------------------------------
# Router
# ---------------------------------------------------------------------------
@dataclass
class AIAntwort:
    """Ergebnis einer Routeranfrage -- immer auswertbar, auch bei Ausfall."""
    ok: bool = False
    daten: dict = field(default_factory=dict)
    modell: str = ""
    stufe: str = KEINE
    cache_treffer: bool = False
    kosten: float = 0.0
    grund: str = ""

    def als_dict(self) -> dict:
        return {"ok": self.ok, "daten": self.daten, "modell": self.modell,
                "stufe": self.stufe, "cache": self.cache_treffer,
                "kosten": round(self.kosten, 6), "grund": self.grund}


class AIRouter:
    """Zentrale Anlaufstelle fuer alle KI-Anfragen des Bots."""

    def __init__(self, cfg=None, *, budget: Optional[AIBudget] = None,
                 cache: Optional[AICache] = None):
        self.cfg = cfg or config
        self.budget = budget or AIBudget(cfg=self.cfg)
        self.cache = cache or AICache()
        self.letzter_fehler = ""
        self._degraded = False
        self._degraded_grund = ""

    # -- Grundzustand -------------------------------------------------------
    @property
    def api_key(self) -> str:
        return str(getattr(self.cfg, "OPENAI_API_KEY", "") or "").strip()

    @property
    def aktiv(self) -> bool:
        return bool(getattr(self.cfg, "AI_ROUTER_ENABLED", False)) and bool(self.api_key)

    def modellname(self, stufe: str) -> str:
        if stufe == LUNA:
            return str(getattr(self.cfg, "AI_LUNA_MODEL", "gpt-5.6-luna"))
        return str(getattr(self.cfg, "AI_TERRA_MODEL", "gpt-5.6-terra"))

    def preise(self, stufe: str) -> tuple[float, float]:
        """(USD je 1M Input-Token, USD je 1M Output-Token)."""
        if stufe == LUNA:
            return (float(getattr(self.cfg, "AI_LUNA_PRICE_INPUT_PER_M", 0.20)),
                    float(getattr(self.cfg, "AI_LUNA_PRICE_OUTPUT_PER_M", 1.20)))
        return (float(getattr(self.cfg, "AI_TERRA_PRICE_INPUT_PER_M", 2.00)),
                float(getattr(self.cfg, "AI_TERRA_PRICE_OUTPUT_PER_M", 12.00)))

    @property
    def degraded(self) -> bool:
        return self._degraded

    def _setze_degraded(self, grund: str) -> None:
        if not self._degraded:
            logger.warning("AI_DEGRADED: %s -- die deterministische Pipeline laeuft weiter.", grund)
        self._degraded = True
        self._degraded_grund = str(grund)[:300]

    def _degraded_aufheben(self) -> None:
        if self._degraded:
            logger.info("KI wieder verfuegbar.")
        self._degraded = False
        self._degraded_grund = ""

    # -- Routing ------------------------------------------------------------
    def waehle_stufe(self, aufgabe_name: str, kontext: Optional[dict] = None) -> tuple[str, str]:
        """Welche Stufe bearbeitet diese Aufgabe? (AIU-001)"""
        aufgabe = AUFGABEN.get(aufgabe_name)
        if aufgabe is None:
            return KEINE, f"Unbekannte Aufgabe {aufgabe_name!r}"
        if not self.aktiv:
            return KEINE, "KI ist deaktiviert oder kein Schluessel hinterlegt"

        stufe = aufgabe.stufe
        kontext = kontext or {}

        # Eskalation: eine einfache Aufgabe kann durch ihren Inhalt komplex werden.
        if stufe == LUNA:
            text = " ".join(str(v) for v in kontext.values()).lower()
            treffer = [g for g in ESKALATIONS_GRUENDE if g in text]
            if treffer or bool(kontext.get("eskalieren")):
                stufe = TERRA
                grund_text = ", ".join(treffer) or "ausdrueckliche Eskalation"
                frei, grund = self.budget.frei(TERRA)
                if not frei:
                    # Kein Terra-Budget -> lieber Luna als gar nichts.
                    return LUNA, f"Eskalation ({grund_text}) nicht moeglich: {grund}"
                return TERRA, f"Eskalation wegen {grund_text}"

        frei, grund = self.budget.frei(stufe)
        if not frei:
            if stufe == TERRA:
                frei_luna, _ = self.budget.frei(LUNA)
                if frei_luna and bool(getattr(self.cfg, "AI_TERRA_FALLBACK_TO_LUNA", True)):
                    return LUNA, f"Terra nicht verfuegbar ({grund}), Luna uebernimmt"
            return KEINE, grund
        return stufe, "Standardrouting"

    # -- Anfrage ------------------------------------------------------------
    def frage(self, aufgabe_name: str, nutzlast: dict, schema: dict, *,
              anweisung: str = "", kontext: Optional[dict] = None,
              cache_erlaubt: bool = True) -> AIAntwort:
        """Fuehrt genau eine KI-Anfrage aus -- oder liefert sauber 'nicht ok'."""
        aufgabe = AUFGABEN.get(aufgabe_name)
        if aufgabe is None:
            return AIAntwort(grund=f"Unbekannte Aufgabe {aufgabe_name!r}")

        schluessel = AICache.schluessel(aufgabe_name, nutzlast)
        if cache_erlaubt:
            treffer = self.cache.hole(schluessel, aufgabe.cache_stunden)
            if treffer is not None:
                self.budget.zaehle("cache_treffer")
                schreibe_ai_audit({"aufgabe": aufgabe_name, "cache_hit": True,
                                   "modell": "", "kosten": 0.0,
                                   "ergebnis": str(treffer)[:200]})
                return AIAntwort(ok=True, daten=treffer, cache_treffer=True,
                                 stufe=KEINE, grund="aus dem Zwischenspeicher")

        stufe, grund = self.waehle_stufe(aufgabe_name, kontext)
        if stufe == KEINE:
            self.budget.zaehle("abgelehnt")
            self._setze_degraded(grund)
            schreibe_ai_audit({"aufgabe": aufgabe_name, "cache_hit": False,
                               "modell": "", "abgelehnt": True, "grund": grund})
            return AIAntwort(grund=grund)

        modell = self.modellname(stufe)
        payload = {
            "model": modell,
            "reasoning": {"effort": aufgabe.reasoning},
            "input": [
                {"role": "developer", "content": anweisung or self._standard_anweisung()},
                {"role": "user", "content": json.dumps(nutzlast, ensure_ascii=False, default=str)},
            ],
            "text": {"format": {"type": "json_schema", "name": aufgabe_name,
                                "strict": True, "schema": schema}},
            "max_output_tokens": int(aufgabe.max_output_tokens),
            "store": False,
        }
        web_erlaubt = bool(getattr(self.cfg, "AI_WEB_SEARCH_ENABLED", True))
        if aufgabe_name == "wochen_research" and bool(
                getattr(self.cfg, "AI_RESEARCH_ENABLED", False)):
            # Das Ergebnis verlangt pruefbare Quellen; ohne Websuche darf der
            # Job keine Vorschlaege erzeugen.
            web_erlaubt = True
        if aufgabe.web_suche and web_erlaubt:
            payload["tools"] = [{"type": "web_search",
                                 "search_context_size": str(getattr(
                                     self.cfg, "AI_SEARCH_CONTEXT_SIZE", "low"))}]
            payload["tool_choice"] = "auto"

        start = time.time()
        try:
            antwort = requests.post(
                OPENAI_URL,
                headers={"Authorization": f"Bearer {self.api_key}",
                         "Content-Type": "application/json"},
                json=payload,
                timeout=float(getattr(self.cfg, "AI_ROUTER_TIMEOUT_SECONDS", 90)),
            )
            daten = antwort.json() if antwort.content else {}
            if not antwort.ok:
                meldung = str((daten.get("error") or {}).get("message") or "")[:300]
                raise RuntimeError(f"OpenAI HTTP {antwort.status_code}: {meldung}")
            text = self._ausgabetext(daten)
            geparst = json.loads(text) if text else {}
        except Exception as exc:
            self.letzter_fehler = str(exc)[:400]
            self.budget.zaehle("fehler")
            self._setze_degraded(f"{aufgabe_name}: {self.letzter_fehler}")
            schreibe_ai_audit({"aufgabe": aufgabe_name, "cache_hit": False, "modell": modell,
                               "stufe": stufe, "fehler": self.letzter_fehler})
            return AIAntwort(modell=modell, stufe=stufe, grund=self.letzter_fehler)

        nutzung = daten.get("usage") or {}
        eingabe = int(nutzung.get("input_tokens", 0) or 0)
        ausgabe = int(nutzung.get("output_tokens", 0) or 0)
        preis_in, preis_out = self.preise(stufe)
        kosten = (eingabe / 1_000_000.0) * preis_in + (ausgabe / 1_000_000.0) * preis_out

        self.budget.buche(stufe, input_tokens=eingabe, output_tokens=ausgabe, kosten=kosten)
        self.cache.setze(schluessel, geparst, aufgabe=aufgabe_name)
        self._degraded_aufheben()

        schreibe_ai_audit({
            "aufgabe": aufgabe_name, "cache_hit": False, "modell": modell, "stufe": stufe,
            "input_tokens": eingabe, "output_tokens": ausgabe, "kosten": round(kosten, 6),
            "dauer_sekunden": round(time.time() - start, 2),
            "routing_grund": grund,
            "instrumente": nutzlast.get("symbol") or nutzlast.get("symbole") or "",
        })
        return AIAntwort(ok=True, daten=geparst, modell=modell, stufe=stufe, kosten=kosten,
                         grund=grund)

    @staticmethod
    def _standard_anweisung() -> str:
        return (
            "Du unterstuetzt einen regelbasierten TradingBot. Du gibst KEINE Kauf- oder "
            "Verkaufsempfehlung, keine Freigabe und keine Positionsgroesse. Du darfst "
            "ausschliesslich einordnen, priorisieren und Risiken benennen. Erfinde keine "
            "Instrumente und keine Zahlen. Antworte ausschliesslich im vorgegebenen "
            "JSON-Schema und auf Deutsch."
        )

    @staticmethod
    def _ausgabetext(daten: dict) -> str:
        if isinstance(daten.get("output_text"), str):
            return daten["output_text"]
        teile = []
        for eintrag in daten.get("output", []) or []:
            if eintrag.get("type") != "message":
                continue
            for inhalt in eintrag.get("content", []) or []:
                if inhalt.get("type") in ("output_text", "text") and inhalt.get("text"):
                    teile.append(str(inhalt["text"]))
        return "\n".join(teile).strip()

    # -- Fertige Aufgaben ---------------------------------------------------
    def bewerte_universe_kandidat(self, daten: dict) -> dict:
        """Einstufung eines beobachteten Werts. Rueckgabe immer auswertbar."""
        antwort = self.frage(
            "universe_kandidat", daten, SCHEMA_EINSTUFUNG,
            kontext={"symbol": daten.get("symbol", "")},
            anweisung=(self._standard_anweisung() + " Bewerte, ob dieser Wert die "
                       "Aufmerksamkeit des Bots verdient. LOW bedeutet nur: im Focus Set "
                       "spaeter priorisieren. Du kannst weder Beobachtung noch Handel "
                       "freigeben oder blockieren."),
        )
        if not antwort.ok:
            return {"attention": "", "modell": "", "grund": antwort.grund}
        ergebnis = dict(antwort.daten)
        ergebnis["modell"] = antwort.modell
        return ergebnis

    def bewerte_universe_batch(self, eintraege: list[dict]) -> dict:
        """Mehrere Kandidaten in EINER Anfrage (AIU-010).

        Batching ist der zweitgroesste Kostenhebel nach dem Cache: 20
        Einzelanfragen kosten das Zwanzigfache derselben Sammelanfrage.
        """
        if not eintraege:
            return {}
        begrenzt = eintraege[:40]
        antwort = self.frage(
            "universe_batch", {"kandidaten": begrenzt,
                               "symbole": [e.get("symbol") for e in begrenzt]},
            SCHEMA_BATCH,
            anweisung=(self._standard_anweisung() + " Bewerte JEDEN uebergebenen Wert "
                       "einzeln. Verwende ausschliesslich die uebergebenen Symbole."),
        )
        if not antwort.ok:
            return {}
        out: dict[str, dict] = {}
        erlaubt = {str(e.get("symbol", "")).upper() for e in begrenzt}
        for zeile in antwort.daten.get("bewertungen", []) or []:
            symbol = str(zeile.get("symbol", "")).upper()
            if symbol in erlaubt:
                out[symbol] = {**zeile, "modell": antwort.modell}
        return out

    def pruefe_core_volume_diff(self, diff: dict) -> dict:
        antwort = self.frage(
            "core_volume_identity", diff, SCHEMA_CORE_VOLUME_IDENTITY,
            anweisung=(self._standard_anweisung() + " Prüfe ausschließlich die genannten "
                       "hinzugefügten/entfernten Kürzel auf mögliche Namensverwechslung, "
                       "Rebranding oder besondere dokumentierbare Risiken. Verändere die "
                       "Rangfolge nicht und füge kein Symbol hinzu."),
        )
        if not antwort.ok:
            raise RuntimeError(antwort.grund or "GPT-Prüfung fehlgeschlagen")
        return dict(antwort.daten)

    def research_anomalie(self, symbol: str, kontext: dict) -> dict:
        """Terra-Research fuer eine unerklaerte Bewegung (AIU-003)."""
        nutzlast = {"symbol": str(symbol).upper(), **(kontext or {})}
        antwort = self.frage(
            "anomalie_research", nutzlast, SCHEMA_RESEARCH,
            kontext={"anlass": "marktanomalie", "symbol": symbol},
            anweisung=(self._standard_anweisung() + " Untersuche die wahrscheinliche "
                       "Ursache der beschriebenen Bewegung. Nenne Quellen, wenn du "
                       "welche gefunden hast, und markiere Unsicherheit ehrlich als UNKLAR."),
        )
        if not antwort.ok:
            return {"ursache": "", "einordnung": "UNKLAR", "modell": "", "grund": antwort.grund}
        return {**antwort.daten, "modell": antwort.modell, "kosten": round(antwort.kosten, 6)}

    # -- Status -------------------------------------------------------------
    def status(self) -> dict:
        return {
            "aktiv": self.aktiv,
            "degraded": self._degraded,
            "degraded_grund": self._degraded_grund,
            "letzter_fehler": self.letzter_fehler,
            "luna_modell": self.modellname(LUNA),
            "terra_modell": self.modellname(TERRA),
            "budget": self.budget.status(),
        }


__all__ = [
    "AIRouter", "AIBudget", "AICache", "AIAntwort", "Aufgabe", "AUFGABEN",
    "LUNA", "TERRA", "KEINE", "SCHEMA_EINSTUFUNG", "SCHEMA_BATCH", "SCHEMA_RESEARCH", "SCHEMA_CORE_VOLUME_IDENTITY",
    "schreibe_ai_audit",
]
