"""Rein lesende OKX-Kerzendaten fuer die WebUI-Tradeanalyse."""
from __future__ import annotations

import json
import logging
import re
import threading
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path

import config
from broker.okx import OKXClient
from trade_ledger import trade_detail

ROOT = Path(__file__).resolve().parent
PAIR = re.compile(r"^[A-Z0-9]{2,20}-(?:EUR|USDC)$")
_CACHE: dict[int, tuple[float, dict]] = {}
_LOCK = threading.RLock()
logger = logging.getLogger(__name__)
_CLIENT_FACTORY = lambda: OKXClient(
    demo=True, base_url=str(getattr(config, "OKX_BASE_URL", "https://eea.okx.com")),
    timeout=min(10.0, float(getattr(config, "OKX_TIMEOUT_SECONDS", 15.0))),
)


def _utc(value) -> datetime:
    dt = datetime.fromisoformat(str(value or "").replace("Z", "+00:00"))
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


def _timeframe(seconds: float) -> tuple[str, int]:
    """Kleinste Kerze, mit der der Trade in hoechstens 100 Punkten sichtbar ist."""
    for bar, size in (("5m", 300), ("15m", 900), ("1H", 3600),
                      ("4H", 14_400), ("1Dutc", 86_400)):
        if seconds <= size * 92:
            return bar, size
    return "1Dutc", 86_400


def _position_lines(symbol: str) -> dict:
    try:
        path = ROOT / "crypto_positions.json"
        data = json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}
        for row in data.get("positionen") or []:
            if str(row.get("symbol") or "").upper() == symbol:
                return {"stop": row.get("stop"), "take_profit": row.get("take_profit")}
    except Exception:
        logger.debug("Schutzlinien fuer die Trade-Grafik nicht lesbar", exc_info=True)
    return {"stop": None, "take_profit": None}


def _instrument(trade: dict) -> str:
    symbol = str(trade.get("symbol") or "").upper()
    quote = str(trade.get("waehrung") or getattr(config, "OKX_QUOTE_CCY", "EUR")).upper()
    pair = f"{symbol}-{quote}"
    if not PAIR.fullmatch(pair):
        raise ValueError("Ungültige oder nicht unterstützte OKX-Instrumentkennung")
    return pair


def chart_for_trade(trade_id: int, *, force: bool = False) -> dict:
    """Kerzen, Kauf-/Verkaufsmarker und bekannte Schutzlinien."""
    key = int(trade_id)
    now_mono = time.monotonic()
    with _LOCK:
        cached = _CACHE.get(key)
        if cached and not force and now_mono - cached[0] < 60:
            return dict(cached[1])

    trade = trade_detail(key)
    if not trade:
        return {"ok": False, "fehler": "Trade nicht gefunden"}
    if str(trade.get("broker") or "").lower() != "okx":
        return {"ok": False, "fehler": (
            "Kerzen sind auf dieser Seite derzeit für OKX-Kryptotrades verfügbar. "
            "Der eToro-Trade bleibt vollständig in der Tabelle sichtbar.")}
    try:
        entry_time = _utc(trade.get("eingestiegen_am"))
        exit_time = (_utc(trade.get("ausgestiegen_am"))
                     if trade.get("ausgestiegen_am") else datetime.now(timezone.utc))
        if exit_time < entry_time:
            raise ValueError("Ausstiegszeit liegt vor der Einstiegszeit")
        bar, bar_seconds = _timeframe((exit_time - entry_time).total_seconds())
        window_start = entry_time - timedelta(seconds=bar_seconds * 3)
        window_end = exit_time + timedelta(seconds=bar_seconds * 3)
        client = _CLIENT_FACTORY()
        frame = client.historical_candles(
            _instrument(trade), bar=bar, limit=100,
            end_ms=int(window_end.timestamp() * 1000), nur_abgeschlossen=True)
        if frame.empty:
            return {"ok": False, "fehler": "OKX liefert für diesen Zeitraum keine abgeschlossenen Kerzen"}
        frame = frame[(frame.index >= window_start) & (frame.index <= window_end)]
        if frame.empty:
            return {"ok": False, "fehler": "Der historische OKX-Ausschnitt enthält den Tradezeitraum nicht"}
        candles = [{
            "zeit": index.to_pydatetime().astimezone(timezone.utc).isoformat(),
            "open": float(row["open"]), "high": float(row["high"]),
            "low": float(row["low"]), "close": float(row["close"]),
            "volume": float(row["volume"]),
        } for index, row in frame.iterrows()]
        letzter = float(candles[-1]["close"])
        einstieg = float(trade.get("einstieg_preis") or 0)
        menge = float(trade.get("menge") or 0)
        offen = not bool(trade.get("ausgestiegen_am"))
        lines = _position_lines(str(trade.get("symbol") or "").upper()) if offen else {
            "stop": None, "take_profit": None}
        result = {
            "ok": True, "trade_id": key, "symbol": trade.get("symbol"),
            "instrument": _instrument(trade), "bar": bar,
            "nur_abgeschlossene_kerzen": True, "candles": candles,
            "kauf": {"zeit": entry_time.isoformat(), "preis": trade.get("einstieg_preis")},
            "verkauf": ({"zeit": _utc(trade["ausgestiegen_am"]).isoformat(),
                          "preis": trade.get("ausstieg_preis")}
                         if trade.get("ausgestiegen_am") else None),
            "stop": lines.get("stop"), "take_profit": lines.get("take_profit"),
            "letzter_schluss": letzter,
            "offenes_ergebnis": (round((letzter - einstieg) * menge
                                        - float(trade.get("einstieg_gebuehr") or 0), 8)
                                  if offen and einstieg > 0 and menge > 0 else None),
            "waehrung": trade.get("waehrung") or _instrument(trade).rsplit("-", 1)[-1],
            "entry_strategy_mode": trade.get("entry_strategy_mode") or "UNBEKANNT",
            "strategie_version": trade.get("strategie_version") or "UNBEKANNT",
            "hinweis": "Kauf und Verkauf markieren die tatsächlichen Ledger-Zeitpunkte/Fills.",
        }
    except Exception as exc:
        result = {"ok": False, "fehler": f"Kerzendaten nicht verfügbar: {type(exc).__name__}: {str(exc)[:180]}"}
    with _LOCK:
        if len(_CACHE) >= 64:
            oldest = min(_CACHE, key=lambda item: _CACHE[item][0])
            _CACHE.pop(oldest, None)
        _CACHE[key] = (now_mono, result)
    return dict(result)


__all__ = ["chart_for_trade"]
