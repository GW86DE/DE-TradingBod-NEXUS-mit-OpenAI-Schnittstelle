# TradingBot NEXUS 9.0.5

NEXUS handelt zwei strikt getrennte Bereiche:

- eToro für Aktien im Aktien-Marktfenster;
- OKX Deutschland/EEA für Krypto-Spot rund um die Uhr im Demo- oder bewusst
  freigegebenen Live-Modus.

NEXUS 9.0 behebt zuerst die Reconciliation-, Entscheidungsdaten-, Telegram-,
Sortierungs- und `CORE_VOLUME_20`-Fehler aus 8.3.1. Zusätzlich gibt es für
neue OKX-Einstiege einen zur Laufzeit umschaltbaren, isolierten Modus nach den
Regeln der offiziellen Freqtrade `SampleStrategy`.

Der globale Krypto-Modus gilt nur für neue Käufe. Jede offene OKX-Position
behält dauerhaft die Strategie, Version und Parameter, mit der sie eröffnet
wurde. Ein Wechsel verändert niemals rückwirkend die Verwaltung einer offenen
Position.

NEXUS 9.0.1 erweitert gezielt die Kryptoseite: 20 recherchierte Kernwerte
bleiben dauerhaft im OKX-Beobachtungsuniversum, 30 weitere Werte werden
monatlich aus echten OKX-Spotvolumina neu bewertet. Die Aufnahmefilter für
die Beobachtung sind kryptogerechter; vor einer Order gelten weiterhin die
strengeren Geldpfad-Sicherheiten. Die neue Seite **Trades** zeigt auf Deutsch
offene und geschlossene Trades, kumulierte Ergebnisse und für OKX eine
responsive Kerzengrafik mit markiertem Kauf und Verkauf.

NEXUS 9.0.2 ist ein gezieltes Stabilitätsupdate. OKX unterstützt nun die
tatsächlich verfügbaren Spot-Quotes EUR, USD und USDC, verwaiste offene
Ledger-Trades werden sicher mit dem Brokerbestand abgeglichen, identische
Telegram-Nachrichten können nicht mehr parallel doppelt gesendet werden und
brokerseitige eToro-Stop-/Zielausführungen erhalten einen eindeutigen
Ausstiegsgrund. Universum, WebUI und Handelsstrategien bleiben fachlich
unverändert.

NEXUS 9.0.3 zieht die Broker-Wahrheit konsequent vor den lokalen Ledgerstatus:
eToro-Positionen gelten erst mit aktueller, exakt passender `positionId` als
offen; bereits geschlossene Käufe werden nach einem Neustart nicht erneut
eingespielt. OKX lädt die Fill-Historie paginiert nach und rekonstruiert
fehlende Verkäufe und Teilverkäufe. Unklare Ledgerzeilen stehen getrennt unter
**Klärung nötig**. Aktienkäufe besitzen jetzt dieselbe 15-minütige
Handelsbereitschaft wie Krypto. Die WebUI erhält auf Handy und Tablet ein
zugängliches Dropdown-Menü; die Desktopnavigation bleibt unverändert.

NEXUS 9.0.4 schließt die dabei sichtbar gewordenen Restlücken. Eine gemeldete
eToro-Orderausführung erzeugt erst dann einen Trade, wenn dieselbe
`positionId` aktuell beim Broker vorhanden ist; dadurch entsteht kein
Phantom-Trade wie bei MSFT. OKX-Instrumente verwenden die vom Broker
gelieferte `tradeQuoteCcyList`, sodass Unified-USD-Handelspaare korrekt über
EUR, USD, USDC oder USDG ausgewählt werden. SOL und andere Coins bleiben stets
Bestand, niemals Handels-Cash. Ein alter, nicht belegbarer SOL-Ledger-Eintrag
wird erst nach zwei vollständigen Brokerabgleichen geschlossen, ohne das echte
SOL-Guthaben zu verkaufen. Telegram-Nachrichten werden 30 Sekunden gesammelt
und dedupliziert; Telegram lässt sich in der WebUI ohne Neustart aktivieren
oder deaktivieren.

NEXUS 9.0.5 stabilisiert die OKX-Verbindung anhand der offiziellen OKX-V5-
Vorgaben. Eine abweichende Systemzeit wird nicht mehr als dauerhaft falscher
API-Key behandelt. Der Krypto-Worker bleibt bei einem Startfehler aktiv und
verbindet sich mit Backoff erneut. Signierte REST- und WebSocket-Anfragen
verwenden die gemessene OKX-Serverzeit; der Privatstream überwacht Text-
Ping/Pong, Wartungshinweise und Verbindungslimits. Die WebUI trennt jetzt
Worker-Heartbeat, Broker-Authentifizierung und einmaligen API-Test. Alte
Kontodaten können dadurch niemals „ONLINE“ oder „KÄUFE FREI“ vortäuschen.

## Dokumentation

- [Ausführliche Projektbeschreibung für GitHub](README_GITHUB_NEXUS_9.0.4_DE.md)

- [Installation und Update](INSTALLATIONSANLEITUNG_NEXUS_9.0_DE.md)
- [Update auf 9.0.2](INSTALLATIONSANLEITUNG_NEXUS_9.0.2_DE.md)
- [Update auf 9.0.3](INSTALLATIONSANLEITUNG_NEXUS_9.0.3_DE.md)
- [Korrekturen 9.0.3](KORREKTUREN_NEXUS_9.0.3_DE.md)
- [Update auf 9.0.4](INSTALLATIONSANLEITUNG_NEXUS_9.0.4_DE.md)
- [Korrekturen 9.0.4](KORREKTUREN_NEXUS_9.0.4_DE.md)
- [Update auf 9.0.5](INSTALLATIONSANLEITUNG_NEXUS_9.0.5_DE.md)
- [Korrekturen und OKX-PDF-Abgleich 9.0.5](KORREKTUREN_NEXUS_9.0.5_DE.md)
- [Korrekturen 9.0.2](KORREKTUREN_NEXUS_9.0.2_DE.md)
- [Update auf 9.0.1](INSTALLATIONSANLEITUNG_NEXUS_9.0.1_DE.md)
- [Krypto-Universum und Trade-Analyse](KRYPTO_UNIVERSUM_UND_TRADEANALYSE_NEXUS_9.0.1_DE.md)
- [Freqtrade-SampleStrategy-Modus](FREQTRADE_MODUS_NEXUS_9.0_DE.md)
- [Risikoprüfung](RISIKOPRUEFUNG_NEXUS_9.0_DE.md)
- [Änderungen](CHANGELOG_v9.0_NEXUS.txt)
- [Testprotokoll](TEST_REPORT_v9.0_NEXUS.txt)
- [Testprotokoll 9.0.1](TEST_REPORT_v9.0.1_NEXUS.txt)
- [Testprotokoll 9.0.2](TEST_REPORT_v9.0.2_NEXUS.txt)
- [Testprotokoll 9.0.3](TEST_REPORT_v9.0.3_NEXUS.txt)
- [Testprotokoll 9.0.4](TEST_REPORT_v9.0.4_NEXUS.txt)
- [Testprotokoll 9.0.5](TEST_REPORT_v9.0.5_NEXUS.txt)
- [WireGuard/VPN](WIREGUARD_VPN_EINRICHTUNG_DE.md)

## Raspberry-Pi-Schnellstart

```bash
chmod +x Pi_*.sh Nexus_*.sh WebUI_Starten.sh WireGuard_Status_Pruefen.sh
./Pi_Installieren.sh
./.venv/bin/python settings_migration.py --auto
./.venv/bin/python webui_setup.py
./Pi_WebUI_Aktivieren.sh
./Nexus_Einrichten.sh --test
./Pi_Service_Aktivieren.sh
```

Installation und Migration setzen eToro auf Paper und OKX auf Demo. LIVE wird
niemals automatisch übernommen oder aktiviert.
