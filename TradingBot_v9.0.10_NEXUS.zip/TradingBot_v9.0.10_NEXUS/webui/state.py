"""Read-only Dashboard- und Logbuchdaten fuer die WebUI."""
from __future__ import annotations

import json
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from zoneinfo import ZoneInfo

import config

ROOT = Path(__file__).resolve().parents[1]


def _json(name: str, default):
    path = ROOT / name
    try:
        return json.loads(path.read_text(encoding="utf-8")) if path.exists() else default
    except Exception:
        return default


def _runtime(name: str) -> dict:
    data = _json(name, {})
    # Der Aktienkern nennt das Feld broker_connected, der Kryptokern online.
    broker_online = bool(data.get("broker_connected",
                                  data.get("online", False)))
    try:
        ts = datetime.fromisoformat(str(data.get("last_heartbeat") or "").replace("Z", "+00:00"))
        if ts.tzinfo is None:
            ts = ts.replace(tzinfo=timezone.utc)
        age = max(0.0, (datetime.now(timezone.utc) - ts).total_seconds())
    except Exception:
        age = None
    data["heartbeat_age_seconds"] = age
    worker_alive = bool(data.get("running") and age is not None and age <= 180)
    data["worker_alive"] = worker_alive
    data["broker_online"] = broker_online
    data["online"] = bool(worker_alive and broker_online)
    data["status_aktuell"] = worker_alive
    return data


def core_online() -> bool:
    return bool(_runtime("runtime_status.json").get("online")
                or _runtime("runtime_status_okx.json").get("online"))


def _fmt_market_time(value) -> str:
    if not value:
        return ""
    try:
        zone = ZoneInfo(str(getattr(config, "LOCAL_TIMEZONE", "Europe/Berlin")))
        return value.astimezone(zone).strftime("%d.%m.%Y %H:%M %Z")
    except Exception:
        return str(value)


def _decision_storage() -> dict:
    filename = str(getattr(config, "DECISION_DB_FILE", "decision_history.sqlite"))
    path = ROOT / filename
    rows = 0
    if path.exists():
        try:
            con = sqlite3.connect(f"file:{path.as_posix()}?mode=ro", uri=True, timeout=3)
            try:
                rows = int(con.execute("SELECT COUNT(*) FROM decisions").fetchone()[0])
            finally:
                con.close()
        except Exception:
            rows = 0
    return {
        "file": filename, "path": str(path), "exists": path.exists(), "rows": rows,
        "size_bytes": path.stat().st_size if path.exists() else 0,
        "mirror": "decision_journal.jsonl",
        "scope": ("Gespeichert werden ernsthafte Kaufkandidaten ab technischem Signal "
                  "einschliesslich Freigaben, Ablehnungen und Begruendungen. Ein normaler "
                  "Scan ohne Signal erzeugt bewusst keinen Entscheidungsdatensatz."),
    }


def dashboard() -> dict:
    from bot_zustand import BotZustand
    from decision_analytics import summary
    from decision_analytics import latest
    from market_calendar import sitzungsstatus
    from news_sources import source_health
    from settings_migration import bericht as migration_report
    market = sitzungsstatus()
    try:
        from pi_system import metrics, health_flags
        pi = metrics(ROOT)
        pi["warnings"] = health_flags(ROOT)
    except Exception:
        pi = {"warnings": ["Pi-/Linux-Telemetrie nicht lesbar"]}
    try:
        from notifier import telegram_status
        telegram = telegram_status(active=False)
        telegram["control"] = _json("telegram_control_status.json", {})
    except Exception:
        telegram = {"configured": False, "control": {}}
    return {
        "version": getattr(config, "VERSION_NEXUS", ""),
        "time": datetime.now(timezone.utc).isoformat(),
        "bot": BotZustand(str(ROOT / "bot_zustand.json")).momentaufnahme(),
        "etoro": _runtime("runtime_status.json"),
        "okx": _runtime("runtime_status_okx.json"),
        "stock_market": {
            "open": bool(market.get("offen")), "phase": market.get("phase"),
            "reason": market.get("grund"),
            "open_time": _fmt_market_time(market.get("oeffnung")),
            "close_time": _fmt_market_time(market.get("schluss")),
            "next_open": _fmt_market_time(market.get("naechste_oeffnung")),
            "regular_hours_ny": "09:30–16:00 America/New_York",
            "early_close": bool(market.get("verkuerzt")),
        },
        "decisions": summary(),
        "decision_storage": _decision_storage(),
        "recent_decisions": latest(15),
        # v8.1.4: Die Kryptoseite hatte auf dem Dashboard keine eigene Karte.
        "okx_detail": _okx_detail(),
        "news": source_health(),
        "universe": _json("universe_state.json", {}),
        "core_volume_20": _core_volume_status(),
        "dynamic_30": _dynamic_30_status(),
        "crypto_strategy": _crypto_strategy_status(),
        "etoro_reconciliation": _etoro_reconciliation_status(),
        "crypto_positions": _json("crypto_positions.json", {"positionen": []}),
        # v8.1.5: Bis 8.1.4 stand die Zahl der OKX-Positionen ZWEIMAL auf der
        # Hauptseite und die der eToro-Positionen kein einziges Mal.
        "stock_positions": _json("stock_positions.json",
                                 {"positionen": [], "kurse_verfuegbar": False}),
        "migration": migration_report(ROOT),
        "pi": pi,
        "telegram": telegram,
    }


def _core_volume_status() -> dict:
    try:
        import core_volume_20
        return core_volume_20.load()
    except Exception as exc:
        return {"status": "STALE", "error": type(exc).__name__, "items": []}


def _crypto_strategy_status() -> dict:
    try:
        import crypto_strategy_mode
        return crypto_strategy_mode.status()
    except Exception as exc:
        return {"active_mode": "CRYPTO_PAUSED", "error": type(exc).__name__}


def _etoro_reconciliation_status() -> dict:
    try:
        import etoro_reconciliation
        return etoro_reconciliation.status()
    except Exception as exc:
        return {"active": [], "error": type(exc).__name__}


def _dynamic_30_status() -> dict:
    try:
        import crypto_dynamic_30
        return crypto_dynamic_30.load()
    except Exception as exc:
        return {"status": "STALE", "error": type(exc).__name__, "items": []}


def trade_analysis(*, broker: str = "", tage: int = 90) -> dict:
    """Rein sachliche Ledger-Auswertung fuer die deutsche Trade-Seite."""
    from trade_ledger import trade_liste

    broker_name = str(broker or "").strip().lower()
    if broker_name not in ("", "okx", "etoro"):
        broker_name = ""
    lookback = max(1, min(3650, int(tage)))
    rows = trade_liste(broker=broker_name, tage=lookback, limit=500)

    # Interne Parameter-Snapshots sind fuer die Uebersicht unnoetig. Modus,
    # Version und Hash bleiben sichtbar; Geheimnisse werden nie gespeichert.
    erlaubt = {
        "trade_id", "decision_id", "link_status", "enter_tag", "broker",
        "asset_type", "symbol", "waehrung", "strategie_version",
        "entry_strategy_mode", "strategy_parameter_hash", "marktphase", "paper",
        "eingestiegen_am", "einstieg_preis", "einstieg_referenz", "menge",
        "einstieg_gebuehr", "ausgestiegen_am", "ausstieg_preis", "exit_grund",
        "brutto_pnl", "gebuehren", "slippage_geschaetzt", "netto_pnl",
        "haltedauer_minuten", "mfe_pct", "mae_pct", "notiz",
        "broker_position_id", "entry_order_id", "entry_fill_id",
        "broker_account_fingerprint", "reconciliation_status",
        "reconciliation_updated_at",
    }
    clean = [{k: v for k, v in row.items() if k in erlaubt} for row in rows]
    offen = [row for row in clean if not row.get("ausgestiegen_am") and
             str(row.get("reconciliation_status") or "").upper() == "CONFIRMED_OPEN"]
    klaerung = [row for row in clean if not row.get("ausgestiegen_am") and
                str(row.get("reconciliation_status") or "").upper() != "CONFIRMED_OPEN"]
    geschlossen = [row for row in clean if row.get("ausgestiegen_am")]
    bewertbar = [row for row in geschlossen if row.get("netto_pnl") is not None]
    gewinne = [row for row in bewertbar if float(row["netto_pnl"]) > 0]
    verluste = [row for row in bewertbar if float(row["netto_pnl"]) < 0]

    kumuliert = 0.0
    kurve = []
    for row in sorted(bewertbar, key=lambda x: (
            str(x.get("ausgestiegen_am") or ""), int(x.get("trade_id") or 0))):
        pnl = float(row["netto_pnl"])
        kumuliert += pnl
        kurve.append({"zeit": row.get("ausgestiegen_am"), "wert": round(kumuliert, 8),
                      "pnl": round(pnl, 8), "trade_id": row.get("trade_id"),
                      "symbol": row.get("symbol")})

    return {
        "generiert_am": datetime.now(timezone.utc).isoformat(),
        "broker": broker_name or "alle", "zeitraum_tage": lookback,
        "kennzahlen": {
            "offen": len(offen), "klaerung": len(klaerung),
            "geschlossen": len(geschlossen),
            "bewertbar": len(bewertbar), "gewinne": len(gewinne),
            "verluste": len(verluste),
            "summe_netto": (round(sum(float(x["netto_pnl"]) for x in bewertbar), 8)
                             if bewertbar else None),
            "trefferquote_pct": (round(100 * len(gewinne) / len(bewertbar), 2)
                                  if bewertbar else None),
            "gebuehren": (round(sum(float(x.get("gebuehren") or 0) for x in bewertbar), 8)
                           if bewertbar else None),
            "offenes_ergebnis": None,
        },
        "offene_trades": offen,
        "klaerungs_trades": klaerung,
        "geschlossene_trades": geschlossen,
        "kumulierte_ergebnisse": kurve,
        "hinweis": ("Nur vom aktuellen Broker-/Positionsbuchabgleich bestätigte Trades zählen "
                    "als offen. Unklare Altbestände stehen getrennt unter ‚Klärung nötig‘ und "
                    "werden weder automatisch verkauft noch als 0,00 bewertet. Die "
                    "Kerzenansicht verwendet nur abgeschlossene OKX-Kerzen."),
    }


def decision_log(*, page: int = 1, per_page: int = 50, broker: str = "",
                 asset_type: str = "", status: str = "", source: str = "",
                 symbol: str = "", day: str = "") -> dict:
    db = ROOT / getattr(config, "DECISION_DB_FILE", "decision_history.sqlite")
    page = max(1, int(page)); per_page = max(10, min(100, int(per_page)))
    if not db.exists():
        return {"rows": [], "total": 0, "page": page, "pages": 0}
    clauses, args = [], []
    for column, value in (("broker", broker), ("asset_type", asset_type), ("status", status),
                          ("local_day", day)):
        if value:
            clauses.append(f"{column}=?"); args.append(str(value))
    if symbol:
        clauses.append("symbol LIKE ?"); args.append(f"%{str(symbol).upper()}%")
    if source:
        clauses.append("payload_json LIKE ?"); args.append(f"%{str(source)}%")
    where = (" WHERE " + " AND ".join(clauses)) if clauses else ""
    con = sqlite3.connect(f"file:{db.as_posix()}?mode=ro", uri=True, timeout=5)
    con.row_factory = sqlite3.Row
    try:
        total = int(con.execute("SELECT COUNT(*) FROM decisions" + where, args).fetchone()[0])
        rows = con.execute(
            "SELECT * FROM decisions" + where + " ORDER BY created_at_utc DESC, id DESC LIMIT ? OFFSET ?",
            [*args, per_page, (page - 1) * per_page],
        ).fetchall()
        row_ids = [int(x["id"]) for x in rows]
        events_by_id, orders_by_id = {}, {}
        if row_ids:
            marks = ",".join("?" for _ in row_ids)
            try:
                for event in con.execute(
                    f"SELECT * FROM decision_events WHERE decision_id IN ({marks}) ORDER BY created_at_utc DESC, id DESC", row_ids
                ).fetchall():
                    events_by_id.setdefault(int(event["decision_id"]), []).append(dict(event))
                for order in con.execute(
                    f"SELECT * FROM decision_orders WHERE decision_id IN ({marks}) ORDER BY created_at_utc DESC, id DESC", row_ids
                ).fetchall():
                    orders_by_id.setdefault(int(order["decision_id"]), []).append(dict(order))
            except sqlite3.OperationalError:
                pass  # read-only compatibility with a not-yet-migrated old DB
    finally:
        con.close()
    out = []
    for row in rows:
        item = dict(row)
        raw = item.pop("payload_json", "{}")
        try:
            payload = json.loads(raw)
        except Exception:
            payload = {}
        item["sources"] = payload.get("sources") or payload.get("quellen") or []
        item["hauptquelle"] = payload.get("hauptquelle") or item.get("blocked_by") or ""
        item["signal_reason"] = payload.get("signal_reason") or payload.get("reason") or ""
        item["signal_checks"] = payload.get("signal_checks") or {}
        item["metrics"] = {
            key: payload.get(key) for key in (
                "rsi_5m", "tema_5m", "bb_middle_5m", "volume_5m", "atr",
                "spread_pct", "spread_limit_pct", "required_edge_pct",
                "expected_move_pct", "trade_quote_ccy")
            if payload.get(key) is not None
        }
        item["execution_events"] = events_by_id.get(int(item["id"]), [])
        item["orders"] = orders_by_id.get(int(item["id"]), [])
        out.append(item)
    return {"rows": out, "total": total, "page": page,
            "pages": (total + per_page - 1) // per_page, "per_page": per_page}


def system_log(*, search: str = "", level: str = "", limit: int = 300) -> list[str]:
    path = ROOT / getattr(config, "LOG_FILE", "trading_bot.log")
    if not path.exists():
        return []
    with path.open("rb") as handle:
        handle.seek(0, 2); size = handle.tell(); handle.seek(max(0, size - 1_500_000))
        text = handle.read().decode("utf-8", errors="replace")
    rows = text.splitlines()
    if search:
        rows = [x for x in rows if str(search).lower() in x.lower()]
    if level:
        rows = [x for x in rows if str(level).upper() in x.upper()]
    return rows[-max(20, min(1000, int(limit))):]


def _universums_diagnose() -> dict:
    """Die Filterzaehlung des letzten Laufs je Broker."""
    aus = {}
    try:
        import okx_status
        lauf = (okx_status.lies().get("letzter_universumslauf") or {})
        if lauf.get("diagnose"):
            aus["okx"] = lauf["diagnose"]
    except Exception:
        __import__("logging").getLogger(__name__).debug(
            "Universumsdiagnose nicht lesbar", exc_info=True)
    return aus


def _okx_detail() -> dict:
    """Guthaben, Positionen und Handelsbereitschaft der Kryptoseite."""
    try:
        import okx_status
        daten = okx_status.lies()
    except Exception:
        return {}
    if not daten:
        return {"vorhanden": False}
    bereit = daten.get("handelsbereitschaft") or {}
    runtime = _runtime("runtime_status_okx.json")
    alter = okx_status.alter_sekunden(daten)
    max_alter = float(getattr(okx_status, "MAX_ALTER_SEKUNDEN", 180.0))
    heartbeat_aktuell = bool(alter is not None and alter <= max_alter)
    status_aktuell = bool(heartbeat_aktuell and runtime.get("worker_alive"))
    verbunden = bool(status_aktuell and runtime.get("broker_online") and
                     (daten.get("online") or daten.get("verbunden")))
    kaeufe_erlaubt = bool(verbunden and bereit.get("kaeufe_erlaubt"))
    grund = str(bereit.get("grund", "") or "")
    offene = list(bereit.get("offen") or [])
    if not verbunden:
        grund = ("OKX-Worker offline oder Broker nicht authentifiziert; "
                 "angezeigte Kontowerte sind nur der letzte bekannte Stand")
        offene = [grund]
    return {
        "vorhanden": True,
        "modus": daten.get("modus", "?"),
        "online": verbunden,
        "status_aktuell": status_aktuell,
        "werte_veraltet": not verbunden,
        "alter_sekunden": alter,
        "handelbares_kapital": daten.get("handelbares_kapital"),
        "gebuehrensatz_pct": daten.get("gebuehrensatz_pct"),
        "guthaben": daten.get("guthaben") or {},
        "exposure": daten.get("exposure") or {},
        "positionen": daten.get("positionen") or [],
        "universum": daten.get("universum") or {},
        "trading_ready": bool(verbunden and bereit.get("trading_ready")),
        "kaeufe_erlaubt": kaeufe_erlaubt,
        "bereitschaft_grund": grund,
        "offene_bedingungen": offene,
    }


def universe() -> dict:
    """Das dynamische Universum beider Broker fuer die Universums-Seite.

    Bewusst getrennt nach Anbieter: eToro-Aktien und OKX-Krypto folgen
    unterschiedlichen Regeln (Telegram-Freigabe gegen autonome Aufnahme),
    und genau dieser Unterschied soll auf einen Blick sichtbar sein.
    """
    from datetime import datetime, timezone

    def _alter_stunden(iso_text: str) -> float | None:
        if not iso_text:
            return None
        try:
            ts = datetime.fromisoformat(str(iso_text))
        except (TypeError, ValueError):
            return None
        if ts.tzinfo is None:
            ts = ts.replace(tzinfo=timezone.utc)
        return round((datetime.now(timezone.utc) - ts).total_seconds() / 3600.0, 1)

    try:
        import config
        from universe.manager import UniverseManager
        from universe.modelle import UniverseZustand
        manager = UniverseManager(
            UniverseZustand(getattr(config, "UNIVERSE_STATE_FILE", "universe_state.json")))
    except Exception as exc:
        return {"fehler": f"Universum nicht ladbar: {exc}", "broker": {}}

    # Der feste Kern kommt ab v8.1.3 vom Manager, nicht mehr direkt aus der
    # config: Aktien haben jetzt ebenfalls einen Kern (bis zu 75 Werte), und
    # nur der Manager kennt die geltende Obergrenze je Broker.
    kern_krypto = sorted(manager.kernwerte("okx"))
    kern_aktien = sorted(manager.kernwerte("etoro"))
    ausgabe: dict[str, dict] = {}

    for broker, anzeige, assetklasse in (("okx", "OKX Krypto", "crypto"),
                                         ("etoro", "eToro Aktien", "stock")):
        try:
            zeilen = manager.mitglieder_tabelle(broker)
            uebersicht = manager.uebersicht(broker)
            focus = list(uebersicht.get("focus_set") or [])
        except Exception as exc:
            ausgabe[broker] = {"anzeige": anzeige, "fehler": str(exc), "werte": []}
            continue

        for zeile in zeilen:
            symbol = str(zeile.get("symbol", "")).upper()
            mitglied = manager.zustand.hole(broker, symbol)
            zeile["anbieter"] = anzeige
            zeile["asset_type"] = assetklasse
            zeile["kern"] = manager.ist_kern(broker, symbol)
            zeile["focus"] = symbol in focus
            zeile["focus_platz"] = focus.index(symbol) + 1 if symbol in focus else None
            zeile["aufgenommen_am"] = getattr(mitglied, "aufgenommen_am", "") if mitglied else ""
            zeile["alter_stunden"] = _alter_stunden(zeile["aufgenommen_am"])
            zeile["letzte_pruefung"] = getattr(mitglied, "letzte_pruefung", "") if mitglied else ""

        ausgabe[broker] = {
            "anzeige": anzeige,
            "asset_type": assetklasse,
            "uebersicht": uebersicht,
            "autonome_aufnahme": bool(uebersicht.get("autonome_aufnahme")),
            "beobachtung_stunden": float(uebersicht.get("beobachtung_stunden", 0.0) or 0.0),
            "max_aenderungen_pro_lauf": int(uebersicht.get("max_aenderungen_pro_lauf", 0) or 0),
            "werte": zeilen,
        }

    return {
        "zeit": datetime.now(timezone.utc).isoformat(),
        # "kernwerte" bleibt aus Kompatibilitaetsgruenden der Kryptokern --
        # die Aktienliste kommt getrennt dazu, damit die Oberflaeche 75
        # Ticker nicht in eine Kachel zwingen muss.
        # v8.1.4: Warum ist der Pool so klein? Zaehlung je Filter.
        "diagnose": _universums_diagnose(),
        "kernwerte": kern_krypto,
        "kernwerte_krypto": kern_krypto,
        "kernwerte_aktien": kern_aktien,
        "core_volume_20": _core_volume_status(),
        "dynamic_30": _dynamic_30_status(),
        "etoro_reconciliation": _etoro_reconciliation_status(),
        "broker": ausgabe,
    }
