"""Trade-Ledger: die Ausstiegsseite der Handelshistorie (v8.1.3, Etappe A).

WARUM DIESES MODUL EXISTIERT
============================
``decision_history.sqlite`` speicherte bis v8.1.2 nur die EINSTIEGSSEITE:
Fillpreis, Fillmenge, Ausfuehrungsstatus. Es gab kein realisiertes Ergebnis,
keine Gebuehren, keine Slippage, keine Haltedauer, keinen Ausstiegsgrund und
keine Strategieversion.

Damit waren genau die Kennzahlen, um die es in der Strategy Evolution Engine
geht, schlicht nicht berechenbar: Trefferquote, Erwartungswert, Profitfaktor,
Drawdown, Gebuehrenquote. Was es stattdessen gab, war Forward-Performance
(Kursbeobachtung 1 h / 4 h / 1 d / 5 d nach einer Entscheidung) -- ein
brauchbarer Stellvertreter fuer "haette sich der Einstieg gelohnt", aber kein
realisiertes Handelsergebnis.

DIESES MODUL AENDERT NICHTS AM HANDEL
=====================================
Es schreibt mit. Jede Funktion faengt ihre Fehler selbst ab und gibt im
Zweifel ``None`` zurueck. Ein kaputtes Ledger darf niemals einen Kauf oder
Verkauf verhindern -- Aufzeichnung ist nachrangig gegenueber dem Geldpfad.
Aus demselben Grund gibt es hier keine Aktivierungs-, Shadow- oder
Rollback-Mechanik; die beruehrt den Geldpfad und gehoert nach v8.2.

EHRLICHE LUECKEN
================
Nicht jeder Wert ist immer bekannt. Fehlt der Einstandspreis (etwa bei einer
Position, die vor v8.1.3 eroeffnet wurde), bleibt das Ergebnis ``NULL`` und
faellt aus der Statistik heraus. Es wird NIE als 0,00 verbucht -- eine Null
sieht aus wie ein Nullergebnis und verfaelscht jede Auswertung.
"""

from __future__ import annotations

import json
import logging
from datetime import datetime, timedelta, timezone
from typing import Any, Optional

from decision_analytics import _LOCK, _connect, _sample_quality, init_db

logger = logging.getLogger(__name__)

# Ein Ausstieg ohne erkannten Grund bekommt diesen Platzhalter, damit die
# Auswertung "unbekannt" von "Stop-Loss" unterscheiden kann.
EXIT_UNBEKANNT = "UNBEKANNT"


def init_ledger() -> None:
    """Legt die Tabelle an. Mehrfach aufrufbar."""
    init_db()
    with _LOCK, _connect() as con:
        con.executescript(
            """
            CREATE TABLE IF NOT EXISTS trades (
                trade_id INTEGER PRIMARY KEY AUTOINCREMENT,
                decision_id INTEGER,
                link_status TEXT NOT NULL DEFAULT 'LEGACY_UNLINKED',
                enter_tag TEXT NOT NULL DEFAULT '',
                broker TEXT NOT NULL,
                asset_type TEXT NOT NULL DEFAULT '',
                symbol TEXT NOT NULL,
                waehrung TEXT NOT NULL DEFAULT '',
                strategie_version TEXT NOT NULL DEFAULT '',
                entry_strategy_mode TEXT NOT NULL DEFAULT '',
                strategy_parameter_hash TEXT NOT NULL DEFAULT '',
                strategy_parameters_json TEXT NOT NULL DEFAULT '{}',
                marktphase TEXT NOT NULL DEFAULT '',
                paper INTEGER NOT NULL DEFAULT 1,

                eingestiegen_am TEXT NOT NULL,
                einstieg_preis REAL,
                einstieg_referenz REAL,
                menge REAL,
                einstieg_gebuehr REAL,

                ausgestiegen_am TEXT,
                ausstieg_preis REAL,
                ausstieg_referenz REAL,
                exit_grund TEXT,

                brutto_pnl REAL,
                gebuehren REAL,
                slippage_geschaetzt REAL,
                netto_pnl REAL,
                haltedauer_minuten REAL,
                mfe_pct REAL,
                mae_pct REAL,
                broker_position_id TEXT NOT NULL DEFAULT '',
                entry_order_id TEXT NOT NULL DEFAULT '',
                entry_fill_id TEXT NOT NULL DEFAULT '',
                entry_fill_ids_json TEXT NOT NULL DEFAULT '[]',
                client_order_id TEXT NOT NULL DEFAULT '',
                order_tag TEXT NOT NULL DEFAULT '',
                ownership_status TEXT NOT NULL DEFAULT '',
                entry_fee_currency_json TEXT NOT NULL DEFAULT '{}',
                broker_account_fingerprint TEXT NOT NULL DEFAULT '',
                reconciliation_status TEXT NOT NULL DEFAULT 'PENDING_CONFIRMATION',
                reconciliation_updated_at TEXT,
                notiz TEXT NOT NULL DEFAULT ''
            );
            CREATE INDEX IF NOT EXISTS idx_trades_offen
                ON trades(broker, symbol, ausgestiegen_am);
            CREATE INDEX IF NOT EXISTS idx_trades_zeit
                ON trades(eingestiegen_am);
            CREATE INDEX IF NOT EXISTS idx_trades_version
                ON trades(strategie_version, broker);
            CREATE TABLE IF NOT EXISTS trade_entry_fills (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                trade_id INTEGER NOT NULL,
                broker TEXT NOT NULL,
                order_id TEXT NOT NULL DEFAULT '',
                client_order_id TEXT NOT NULL DEFAULT '',
                fill_id TEXT NOT NULL,
                quantity REAL,
                price REAL,
                fee REAL,
                fee_currency TEXT NOT NULL DEFAULT '',
                filled_at TEXT,
                raw_json TEXT NOT NULL DEFAULT '{}',
                FOREIGN KEY(trade_id) REFERENCES trades(trade_id)
            );
            CREATE UNIQUE INDEX IF NOT EXISTS idx_trade_entry_fill_exact
                ON trade_entry_fills(broker, fill_id);
            CREATE INDEX IF NOT EXISTS idx_trade_entry_fills_trade
                ON trade_entry_fills(trade_id);
            """
        )
        columns = {str(r[1]) for r in con.execute("PRAGMA table_info(trades)").fetchall()}
        if "link_status" not in columns:
            con.execute("ALTER TABLE trades ADD COLUMN link_status TEXT NOT NULL DEFAULT 'LEGACY_UNLINKED'")
        if "enter_tag" not in columns:
            con.execute("ALTER TABLE trades ADD COLUMN enter_tag TEXT NOT NULL DEFAULT ''")
        if "entry_strategy_mode" not in columns:
            con.execute("ALTER TABLE trades ADD COLUMN entry_strategy_mode TEXT NOT NULL DEFAULT ''")
        if "strategy_parameter_hash" not in columns:
            con.execute("ALTER TABLE trades ADD COLUMN strategy_parameter_hash TEXT NOT NULL DEFAULT ''")
        if "strategy_parameters_json" not in columns:
            con.execute("ALTER TABLE trades ADD COLUMN strategy_parameters_json TEXT NOT NULL DEFAULT '{}'")
        if "broker_position_id" not in columns:
            con.execute("ALTER TABLE trades ADD COLUMN broker_position_id TEXT NOT NULL DEFAULT ''")
        if "entry_order_id" not in columns:
            con.execute("ALTER TABLE trades ADD COLUMN entry_order_id TEXT NOT NULL DEFAULT ''")
        if "entry_fill_id" not in columns:
            con.execute("ALTER TABLE trades ADD COLUMN entry_fill_id TEXT NOT NULL DEFAULT ''")
        if "entry_fill_ids_json" not in columns:
            con.execute("ALTER TABLE trades ADD COLUMN entry_fill_ids_json TEXT NOT NULL DEFAULT '[]'")
        if "client_order_id" not in columns:
            con.execute("ALTER TABLE trades ADD COLUMN client_order_id TEXT NOT NULL DEFAULT ''")
        if "order_tag" not in columns:
            con.execute("ALTER TABLE trades ADD COLUMN order_tag TEXT NOT NULL DEFAULT ''")
        if "ownership_status" not in columns:
            con.execute("ALTER TABLE trades ADD COLUMN ownership_status TEXT NOT NULL DEFAULT ''")
        if "entry_fee_currency_json" not in columns:
            con.execute("ALTER TABLE trades ADD COLUMN entry_fee_currency_json TEXT NOT NULL DEFAULT '{}'")
        if "broker_account_fingerprint" not in columns:
            con.execute(
                "ALTER TABLE trades ADD COLUMN broker_account_fingerprint "
                "TEXT NOT NULL DEFAULT ''")
        if "reconciliation_status" not in columns:
            con.execute(
                "ALTER TABLE trades ADD COLUMN reconciliation_status "
                "TEXT NOT NULL DEFAULT 'PENDING_CONFIRMATION'")
        if "reconciliation_updated_at" not in columns:
            con.execute("ALTER TABLE trades ADD COLUMN reconciliation_updated_at TEXT")
        con.execute(
            "CREATE UNIQUE INDEX IF NOT EXISTS idx_trades_entry_fill "
            "ON trades(broker, entry_fill_id) WHERE entry_fill_id <> ''")
        # Altdaten werden absichtlich nicht geraten oder nachtraeglich zugeordnet.
        con.execute("UPDATE trades SET link_status='LEGACY_UNLINKED' WHERE decision_id IS NULL")
        con.execute("UPDATE trades SET link_status='LINKED' WHERE decision_id IS NOT NULL")
        con.execute(
            "UPDATE trades SET reconciliation_status='CLOSED', "
            "reconciliation_updated_at=COALESCE(reconciliation_updated_at, ausgestiegen_am) "
            "WHERE ausgestiegen_am IS NOT NULL AND reconciliation_status<>'CLOSED'")


def _zahl(wert: Any) -> Optional[float]:
    """Zahl oder None -- niemals 0 als Ersatz fuer 'unbekannt'."""
    if wert is None or wert == "":
        return None
    try:
        zahl = float(wert)
    except (TypeError, ValueError):
        return None
    return zahl


def _jetzt() -> str:
    return datetime.now(timezone.utc).isoformat()


def _zeit(wert: Any) -> str:
    if isinstance(wert, datetime):
        d = wert if wert.tzinfo else wert.replace(tzinfo=timezone.utc)
        return d.astimezone(timezone.utc).isoformat()
    text = str(wert or "").strip()
    if not text:
        return _jetzt()
    try:
        d = datetime.fromisoformat(text.replace("Z", "+00:00"))
        return (d if d.tzinfo else d.replace(tzinfo=timezone.utc)).astimezone(timezone.utc).isoformat()
    except ValueError:
        return _jetzt()


def _version(vorgabe: str = "") -> str:
    if vorgabe:
        return str(vorgabe)
    try:
        import strategy_version
        return strategy_version.aktuell()
    except Exception:
        logger.debug("Strategieversion beim Schreiben nicht ermittelbar", exc_info=True)
        return ""


def _marktphase(vorgabe: str = "") -> str:
    """Die Marktphase zum Zeitpunkt des Einstiegs.

    Wird nichts uebergeben, wird sie NICHT geraten: eine falsch geratene
    Phase waere schlimmer als eine leere Spalte, weil sie eine Auswertung
    nach Marktphase still verfaelscht.
    """
    return str(vorgabe or "")


# ---------------------------------------------------------------------------
# Schreiben
# ---------------------------------------------------------------------------
def trade_open(*, broker: str, symbol: str, menge, einstieg_preis,
               asset_type: str = "", waehrung: str = "", decision_id=None,
               referenzpreis=None, gebuehr=None, paper: bool = True,
               strategie_version: str = "", marktphase: str = "",
               entry_strategy_mode: str = "", strategy_parameter_hash: str = "",
               strategy_parameters: dict | None = None,
               zeit=None, notiz: str = "", enter_tag: str = "",
               external: bool = False, broker_position_id: str = "",
               entry_order_id: str = "", entry_fill_id: str = "",
               entry_fill_ids: list | None = None, entry_fills: list | None = None,
               client_order_id: str = "", order_tag: str = "",
               ownership_status: str = "", entry_fee_by_currency: dict | None = None,
               broker_account_fingerprint: str = "",
               reconciliation_status: str = "CONFIRMED_OPEN") -> Optional[int]:
    """Einen Einstieg aufzeichnen. Gibt die trade_id zurueck oder None.

    ``referenzpreis`` ist der Kurs, mit dem die Entscheidung gerechnet hat.
    Aus der Differenz zum tatsaechlichen Fill entsteht spaeter die
    Slippage-Schaetzung -- ohne diesen Wert bleibt sie NULL.
    """
    try:
        init_ledger()
        if not decision_id and not external:
            logger.warning(
                "Neuer Trade ohne decision_id abgelehnt (%s %s). "
                "Manuelle/externe Bestaende muessen external=True tragen.",
                broker, symbol,
            )
            return None
        preis = _zahl(einstieg_preis)
        anzahl = _zahl(menge)
        if not preis or not anzahl or anzahl <= 0:
            logger.debug("Trade-Einstieg ohne Preis/Menge nicht aufgezeichnet: %s", symbol)
            return None
        with _LOCK, _connect() as con:
            fill_ids = [str(x).strip() for x in (entry_fill_ids or []) if str(x).strip()]
            stable_fill = str(entry_fill_id or (fill_ids[0] if fill_ids else "")).strip()
            if stable_fill or fill_ids:
                existing = con.execute(
                    """SELECT t.trade_id FROM trades t
                       LEFT JOIN trade_entry_fills f ON f.trade_id=t.trade_id
                       WHERE t.broker=? AND (t.entry_fill_id=? OR f.fill_id IN (%s))
                       LIMIT 1""" % ",".join("?" for _ in (fill_ids or [stable_fill])),
                    (str(broker or "").lower(), stable_fill, *(fill_ids or [stable_fill])),
                ).fetchone()
                if existing:
                    return int(existing[0])
            status = ("EXTERNAL_OBSERVE" if external else
                      str(reconciliation_status or "CONFIRMED_OPEN").upper())
            cur = con.execute(
                """INSERT INTO trades
                   (decision_id, link_status, enter_tag, broker, asset_type, symbol, waehrung, strategie_version,
                    entry_strategy_mode, strategy_parameter_hash, strategy_parameters_json,
                    marktphase, paper, eingestiegen_am, einstieg_preis, einstieg_referenz,
                    menge, einstieg_gebuehr, broker_position_id, entry_order_id,
                    entry_fill_id, entry_fill_ids_json, client_order_id, order_tag,
                    ownership_status, entry_fee_currency_json,
                    broker_account_fingerprint, reconciliation_status,
                    reconciliation_updated_at, notiz)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (int(decision_id) if decision_id else None,
                 "LINKED" if decision_id else "EXTERNAL",
                 str(enter_tag or "")[:160],
                 str(broker or "").lower(), str(asset_type or ""), str(symbol or "").upper(),
                 str(waehrung or ""), _version(strategie_version),
                 str(entry_strategy_mode or ""), str(strategy_parameter_hash or ""),
                 __import__("json").dumps(strategy_parameters or {}, ensure_ascii=False, sort_keys=True),
                 _marktphase(marktphase),
                 1 if paper else 0, _zeit(zeit), preis, _zahl(referenzpreis),
                 anzahl, _zahl(gebuehr), str(broker_position_id or "")[:160],
                 str(entry_order_id or "")[:160], stable_fill[:240],
                 json.dumps(fill_ids, ensure_ascii=False),
                 str(client_order_id or "")[:32], str(order_tag or "")[:16],
                 str(ownership_status or "")[:60],
                 json.dumps(entry_fee_by_currency or {}, ensure_ascii=False, sort_keys=True),
                 str(broker_account_fingerprint or "")[:64], status,
                 _jetzt(), str(notiz or "")[:300]),
            )
            trade_id = int(cur.lastrowid)
            for row in entry_fills or []:
                fill_id = str((row or {}).get("tradeId") or (row or {}).get("fill_id") or "").strip()
                if not fill_id:
                    continue
                con.execute(
                    """INSERT OR IGNORE INTO trade_entry_fills
                       (trade_id, broker, order_id, client_order_id, fill_id,
                        quantity, price, fee, fee_currency, filled_at, raw_json)
                       VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
                    (trade_id, str(broker or "").lower(),
                     str((row or {}).get("ordId") or entry_order_id or "")[:160],
                     str((row or {}).get("clOrdId") or client_order_id or "")[:32],
                     fill_id[:240], _zahl((row or {}).get("fillSz") or (row or {}).get("quantity")),
                     _zahl((row or {}).get("fillPx") or (row or {}).get("price")),
                     _zahl((row or {}).get("fee")), str((row or {}).get("feeCcy") or "")[:16],
                     str((row or {}).get("ts") or (row or {}).get("filled_at") or "")[:60],
                     json.dumps(row or {}, ensure_ascii=False, sort_keys=True, default=str)),
                )
            return trade_id
    except Exception as exc:
        logger.warning("Trade-Einstieg nicht aufgezeichnet (%s %s): %s", broker, symbol, exc)
        return None


def offener_trade(broker: str, symbol: str) -> Optional[dict]:
    """Der aelteste noch offene Trade dieses Symbols -- oder None."""
    try:
        init_ledger()
        with _LOCK, _connect() as con:
            zeile = con.execute(
                """SELECT * FROM trades
                   WHERE broker=? AND symbol=? AND ausgestiegen_am IS NULL
                   ORDER BY eingestiegen_am ASC LIMIT 1""",
                (str(broker or "").lower(), str(symbol or "").upper()),
            ).fetchone()
        return dict(zeile) if zeile else None
    except Exception as exc:
        logger.debug("Offener Trade nicht ermittelbar (%s %s): %s", broker, symbol, exc)
        return None


def trade_close(*, broker: str, symbol: str, ausstieg_preis, menge=None,
                exit_grund: str = "", gebuehr=None, referenzpreis=None,
                einstieg_preis=None, eingestiegen_am=None, netto_pnl=None,
                asset_type: str = "", waehrung: str = "", paper: bool = True,
                mfe_pct=None, mae_pct=None, zeit=None,
                notiz: str = "") -> Optional[int]:
    """Einen Ausstieg aufzeichnen. Gibt die trade_id zurueck oder None.

    Findet sich kein offener Trade -- etwa weil die Position vor v8.1.3
    eroeffnet wurde --, wird der Trade nachtraeglich angelegt, sofern
    Einstandspreis und Einstiegszeit uebergeben werden. Ohne Einstand bleibt
    das Ergebnis NULL statt 0.

    Bei einem Teilverkauf bleibt der Rest als offener Trade stehen.
    """
    try:
        init_ledger()
        exit_preis = _zahl(ausstieg_preis)
        if not exit_preis:
            logger.debug("Trade-Ausstieg ohne Preis nicht aufgezeichnet: %s", symbol)
            return None
        broker_name = str(broker or "").lower()
        symbol_name = str(symbol or "").upper()
        offen = offener_trade(broker_name, symbol_name)

        if offen is None:
            # Nachtraegliche Anlage: nur mit belastbarem Einstand sinnvoll.
            trade_id = trade_open(
                broker=broker_name, symbol=symbol_name, menge=menge,
                einstieg_preis=einstieg_preis, asset_type=asset_type,
                waehrung=waehrung, paper=paper, zeit=eingestiegen_am,
                notiz=(notiz or "nachtraeglich aus dem Verkaufspfad angelegt"),
                external=True)
            if trade_id is None:
                logger.info("Verkauf %s ohne bekannten Einstand -- kein Ledger-Eintrag.",
                            symbol_name)
                return None
            offen = offener_trade(broker_name, symbol_name)
            if offen is None:
                return None

        trade_id = int(offen["trade_id"])
        offene_menge = _zahl(offen.get("menge")) or 0.0
        verkauft = _zahl(menge)
        if verkauft is None or verkauft <= 0 or verkauft > offene_menge:
            verkauft = offene_menge
        rest = round(offene_menge - verkauft, 12)

        einstieg = _zahl(offen.get("einstieg_preis"))
        einstieg_gebuehr = _zahl(offen.get("einstieg_gebuehr")) or 0.0
        # Anteilige Einstiegsgebuehr bei einem Teilverkauf.
        anteil = (verkauft / offene_menge) if offene_menge > 0 else 1.0
        gebuehr_gesamt = (einstieg_gebuehr * anteil) + (_zahl(gebuehr) or 0.0)

        brutto = (exit_preis - einstieg) * verkauft if einstieg else None
        netto = _zahl(netto_pnl)
        if netto is None and brutto is not None:
            netto = brutto - gebuehr_gesamt

        # Slippage: Referenzkurs der Entscheidung gegen den echten Fill.
        # Positiv = schlechter als geplant, in Prozent des Referenzkurses.
        slippage = None
        referenz_ein = _zahl(offen.get("einstieg_referenz"))
        if referenz_ein and einstieg:
            slippage = 100.0 * (einstieg - referenz_ein) / referenz_ein
        referenz_aus = _zahl(referenzpreis)
        if referenz_aus:
            aus_slip = 100.0 * (referenz_aus - exit_preis) / referenz_aus
            slippage = aus_slip if slippage is None else (slippage + aus_slip)

        ein_zeit = str(offen.get("eingestiegen_am") or "")
        aus_zeit = _zeit(zeit)
        haltedauer = None
        try:
            haltedauer = round(
                (datetime.fromisoformat(aus_zeit) - datetime.fromisoformat(ein_zeit))
                .total_seconds() / 60.0, 2)
            if haltedauer < 0:
                haltedauer = None
        except (TypeError, ValueError):
            haltedauer = None

        with _LOCK, _connect() as con:
            con.execute(
                """UPDATE trades SET menge=?, ausgestiegen_am=?, ausstieg_preis=?,
                       ausstieg_referenz=?, exit_grund=?, brutto_pnl=?, gebuehren=?,
                       slippage_geschaetzt=?, netto_pnl=?, haltedauer_minuten=?,
                       mfe_pct=COALESCE(?, mfe_pct), mae_pct=COALESCE(?, mae_pct),
                       reconciliation_status='CLOSED', reconciliation_updated_at=?
                   WHERE trade_id=?""",
                (verkauft, aus_zeit, exit_preis, referenz_aus,
                 str(exit_grund or EXIT_UNBEKANNT)[:200], brutto,
                 gebuehr_gesamt if (brutto is not None or gebuehr_gesamt) else None,
                 slippage, netto, haltedauer, _zahl(mfe_pct), _zahl(mae_pct),
                 _jetzt(), trade_id),
            )
            if rest > 1e-12:
                # Teilverkauf: der Rest laeuft als eigener offener Trade weiter.
                con.execute(
                    """INSERT INTO trades
                       (decision_id, link_status, enter_tag, broker, asset_type, symbol, waehrung,
                        strategie_version, entry_strategy_mode, strategy_parameter_hash,
                        strategy_parameters_json, marktphase, paper, eingestiegen_am,
                        einstieg_preis, einstieg_referenz, menge, einstieg_gebuehr,
                        broker_position_id, entry_order_id, entry_fill_id,
                        entry_fill_ids_json, client_order_id, order_tag,
                        ownership_status, entry_fee_currency_json,
                        broker_account_fingerprint,
                        reconciliation_status, reconciliation_updated_at, notiz)
                       SELECT decision_id, link_status, enter_tag, broker, asset_type, symbol, waehrung,
                              strategie_version, entry_strategy_mode, strategy_parameter_hash,
                              strategy_parameters_json, marktphase, paper, eingestiegen_am,
                              einstieg_preis, einstieg_referenz, ?, ?, broker_position_id,
                              entry_order_id, '', '[]', client_order_id, order_tag,
                              ownership_status, entry_fee_currency_json,
                              broker_account_fingerprint,
                              'CONFIRMED_OPEN', ?, 'Rest nach Teilverkauf'
                       FROM trades WHERE trade_id=?""",
                    (rest, einstieg_gebuehr * (1.0 - anteil), _jetzt(), trade_id),
                )
        return trade_id
    except Exception as exc:
        logger.warning("Trade-Ausstieg nicht aufgezeichnet (%s %s): %s", broker, symbol, exc)
        return None


def mark_reconciled_closed(trade_id: int, *, grund: str, zeit=None,
                           notiz: str = "") -> bool:
    """Verwaisten Ledger-Eintrag ohne erfundenen Kurs sauber schliessen.

    Diese Funktion wird nur nach zwei vollstaendigen Brokerabgleichen ohne
    Bestand verwendet. Preis und P&L bleiben absichtlich NULL: der Trade ist
    nicht mehr offen, aber ein fehlender historischer Fill wird nicht geraten.
    """
    try:
        init_ledger()
        with _LOCK, _connect() as con:
            cur = con.execute(
                """UPDATE trades
                   SET ausgestiegen_am=?, exit_grund=?, notiz=?,
                       reconciliation_status='CLOSED', reconciliation_updated_at=?
                   WHERE trade_id=? AND ausgestiegen_am IS NULL""",
                (_zeit(zeit), str(grund or "Brokerabgleich")[:200],
                 str(notiz or "")[:300], _jetzt(), int(trade_id)),
            )
            return bool(cur.rowcount)
    except Exception as exc:
        logger.warning("Verwaister Trade %s nicht abgeglichen: %s", trade_id, exc)
        return False


def set_reconciliation_status(trade_id: int, status: str, *,
                              broker_position_id: str = "", notiz: str = "") -> bool:
    """Den Brokerbeweis eines offenen Trades ohne Handelswirkung aktualisieren."""
    try:
        init_ledger()
        target = str(status or "PENDING_CONFIRMATION").upper()[:64]
        with _LOCK, _connect() as con:
            cur = con.execute(
                """UPDATE trades SET reconciliation_status=?,
                       reconciliation_updated_at=?,
                       broker_position_id=CASE WHEN ?<>'' THEN ? ELSE broker_position_id END,
                       notiz=CASE WHEN ?<>'' THEN ? ELSE notiz END
                   WHERE trade_id=? AND ausgestiegen_am IS NULL""",
                (target, _jetzt(), str(broker_position_id or ""),
                 str(broker_position_id or "")[:160], str(notiz or ""),
                 str(notiz or "")[:300], int(trade_id)),
            )
            return bool(cur.rowcount)
    except Exception as exc:
        logger.warning("Reconciliation-Status fuer Trade %s nicht geschrieben: %s", trade_id, exc)
        return False


def confirm_open_trade(*, broker: str, symbol: str,
                       broker_position_id: str = "") -> bool:
    """Aeltesten lokalen Trade nur durch einen aktuellen Brokerbestand bestaetigen."""
    offen = offener_trade(broker, symbol)
    return bool(offen and set_reconciliation_status(
        int(offen["trade_id"]), "CONFIRMED_OPEN",
        broker_position_id=broker_position_id,
        notiz=("Aktueller Brokerbestand exakt bestaetigt" if broker_position_id else
               "Aktueller Brokerbestand bestaetigt")))


def mark_decision_reconciliation(decision_id: int, status: str, *,
                                 notiz: str = "", close_without_result: bool = False) -> int:
    """Alle offenen Ledgerzeilen einer Entscheidung anhand Brokerbeweis markieren.

    ``close_without_result`` wird nur bei exakt nachgewiesener geschlossener
    Broker-positionId verwendet. Ohne diesen Beweis bleibt die Zeile sichtbar
    unter "Klärung nötig", zählt aber nicht mehr als bestätigte offene Position.
    """
    try:
        init_ledger()
        target = str(status or "UNPROVABLE").upper()[:64]
        with _LOCK, _connect() as con:
            if close_without_result:
                cur = con.execute(
                    """UPDATE trades SET ausgestiegen_am=COALESCE(ausgestiegen_am, ?),
                           exit_grund=COALESCE(exit_grund, 'Brokerhistorie bestaetigt Schliessung'),
                           reconciliation_status='CLOSED', reconciliation_updated_at=?,
                           notiz=CASE WHEN ?<>'' THEN ? ELSE notiz END
                       WHERE decision_id=? AND ausgestiegen_am IS NULL""",
                    (_jetzt(), _jetzt(), str(notiz or ""), str(notiz or "")[:300],
                     int(decision_id)),
                )
            else:
                cur = con.execute(
                    """UPDATE trades SET reconciliation_status=?,
                           reconciliation_updated_at=?,
                           notiz=CASE WHEN ?<>'' THEN ? ELSE notiz END
                       WHERE decision_id=? AND ausgestiegen_am IS NULL""",
                    (target, _jetzt(), str(notiz or ""), str(notiz or "")[:300],
                     int(decision_id)),
                )
            return int(cur.rowcount or 0)
    except Exception as exc:
        logger.warning("Decision-Reconciliation %s nicht ins Ledger geschrieben: %s",
                       decision_id, exc)
        return 0


def hoechstkurs_melden(broker: str, symbol: str, kurs) -> None:
    """MFE/MAE fortschreiben, solange die Position laeuft.

    Ohne diese Werte laesst sich spaeter nicht sagen, ob ein Stop zu eng
    sass oder ein Ziel zu weit weg.
    """
    try:
        preis = _zahl(kurs)
        offen = offener_trade(broker, symbol)
        if not preis or not offen:
            return
        einstieg = _zahl(offen.get("einstieg_preis"))
        if not einstieg:
            return
        veraenderung = 100.0 * (preis - einstieg) / einstieg
        mfe = _zahl(offen.get("mfe_pct"))
        mae = _zahl(offen.get("mae_pct"))
        neu_mfe = veraenderung if mfe is None else max(mfe, veraenderung)
        neu_mae = veraenderung if mae is None else min(mae, veraenderung)
        if neu_mfe == mfe and neu_mae == mae:
            return
        with _LOCK, _connect() as con:
            con.execute("UPDATE trades SET mfe_pct=?, mae_pct=? WHERE trade_id=?",
                        (neu_mfe, neu_mae, int(offen["trade_id"])))
    except Exception as exc:
        logger.debug("MFE/MAE nicht fortgeschrieben (%s %s): %s", broker, symbol, exc)


# ---------------------------------------------------------------------------
# Auswerten
# ---------------------------------------------------------------------------
def _kennzahlen(trades: list[dict]) -> dict:
    """Die Kernkennzahlen einer Trademenge.

    Trades ohne bekanntes Ergebnis werden gezaehlt, aber nicht gerechnet --
    sie stehen als ``ohne_ergebnis`` daneben, damit niemand eine Trefferquote
    aus einer halb bekannten Stichprobe liest.
    """
    mit_ergebnis = [t for t in trades if t.get("netto_pnl") is not None]
    ohne = len(trades) - len(mit_ergebnis)
    n = len(mit_ergebnis)
    basis = {"trades": len(trades), "bewertbar": n, "ohne_ergebnis": ohne,
             "sample_quality": _sample_quality(n)}
    if n == 0:
        return basis

    ergebnisse = [float(t["netto_pnl"]) for t in mit_ergebnis]
    gewinne = [x for x in ergebnisse if x > 0]
    verluste = [x for x in ergebnisse if x < 0]
    summe_gewinn = sum(gewinne)
    summe_verlust = abs(sum(verluste))

    # Drawdown auf der kumulierten Ergebniskurve, chronologisch.
    chrono = sorted(mit_ergebnis, key=lambda t: str(t.get("ausgestiegen_am") or ""))
    kumuliert = 0.0
    hoch = 0.0
    drawdown = 0.0
    for t in chrono:
        kumuliert += float(t["netto_pnl"])
        hoch = max(hoch, kumuliert)
        drawdown = max(drawdown, hoch - kumuliert)

    gebuehren = sum(float(t.get("gebuehren") or 0.0) for t in mit_ergebnis)
    brutto = sum(float(t.get("brutto_pnl") or 0.0) for t in mit_ergebnis
                 if t.get("brutto_pnl") is not None)
    slippagen = [float(t["slippage_geschaetzt"]) for t in mit_ergebnis
                 if t.get("slippage_geschaetzt") is not None]
    haltedauern = [float(t["haltedauer_minuten"]) for t in mit_ergebnis
                   if t.get("haltedauer_minuten") is not None]

    basis.update({
        "trefferquote_pct": round(100.0 * len(gewinne) / n, 2),
        "erwartungswert": round(sum(ergebnisse) / n, 4),
        "summe_netto": round(sum(ergebnisse), 4),
        "mittlerer_gewinn": round(summe_gewinn / len(gewinne), 4) if gewinne else None,
        "mittlerer_verlust": round(-summe_verlust / len(verluste), 4) if verluste else None,
        # Ohne einen einzigen Verlust ist der Profitfaktor nicht definiert.
        # "unendlich" waere eine Aussage, die die Stichprobe nicht hergibt.
        "profitfaktor": round(summe_gewinn / summe_verlust, 3) if summe_verlust > 0 else None,
        "max_drawdown": round(drawdown, 4),
        "gebuehren_summe": round(gebuehren, 4),
        # Gebuehrenquote am Bruttoergebnis: wie viel des Rohertrags die
        # Kosten aufgefressen haben.
        "gebuehren_quote_pct": (round(100.0 * gebuehren / abs(brutto), 2)
                                if abs(brutto) > 1e-9 else None),
        "slippage_mittel_pct": (round(sum(slippagen) / len(slippagen), 4)
                                if slippagen else None),
        "haltedauer_minuten_mittel": (round(sum(haltedauern) / len(haltedauern), 1)
                                      if haltedauern else None),
    })
    return basis


def _gruppiere(trades: list[dict], schluessel: str) -> list[dict]:
    gruppen: dict[str, list[dict]] = {}
    for t in trades:
        wert = str(t.get(schluessel) or "").strip() or "UNBEKANNT"
        gruppen.setdefault(wert, []).append(t)
    ergebnis = [{"wert": k, **_kennzahlen(v)} for k, v in gruppen.items()]
    ergebnis.sort(key=lambda x: (-int(x["trades"]), str(x["wert"])))
    return ergebnis


def trade_snapshot(broker: str = "", tage: int = 90) -> dict:
    """Objektive Handelskennzahlen -- die Eingabe fuer Etappe B.

    Bewusst bereits aggregiert: ein Sprachmodell bekommt spaeter diesen
    Rueckgabewert und niemals die Datenbank. Ohne ``broker`` werden beide
    Domaenen getrennt UND zusammen ausgewiesen, weil Gebuehrenstruktur,
    Takt und Marktzeiten bei eToro und OKX verschieden sind.
    """
    try:
        init_ledger()
        lookback = max(1, int(tage))
        cutoff = (datetime.now(timezone.utc) - timedelta(days=lookback)).isoformat()
        sql = ("SELECT * FROM trades WHERE ausgestiegen_am IS NOT NULL "
               "AND ausgestiegen_am >= ?")
        werte: list[Any] = [cutoff]
        if broker:
            sql += " AND broker=?"
            werte.append(str(broker).lower())
        with _LOCK, _connect() as con:
            zeilen = [dict(r) for r in con.execute(sql, tuple(werte)).fetchall()]
            offene = con.execute(
                "SELECT COUNT(*) FROM trades WHERE ausgestiegen_am IS NULL"
                + (" AND broker=?" if broker else ""),
                (str(broker).lower(),) if broker else (),
            ).fetchone()[0]
    except Exception as exc:
        logger.warning("Trade-Snapshot nicht berechenbar: %s", exc)
        return {"fehler": str(exc), "trades": 0}

    ausgabe = {
        "generiert_am": _jetzt(),
        "zeitraum_tage": lookback,
        "broker": str(broker).lower() or "alle",
        "offene_positionen": int(offene or 0),
        "gesamt": _kennzahlen(zeilen),
        "je_broker": _gruppiere(zeilen, "broker"),
        "je_symbol": _gruppiere(zeilen, "symbol")[:40],
        "je_marktphase": _gruppiere(zeilen, "marktphase"),
        "je_exit_grund": _gruppiere(zeilen, "exit_grund"),
        "je_strategieversion": _gruppiere(zeilen, "strategie_version"),
        "aktuelle_strategieversion": _version(),
        "methodenhinweis": (
            "Nur geschlossene Trades. Trades ohne bekannten Einstand erscheinen "
            "als 'ohne_ergebnis' und gehen NICHT in Trefferquote, Erwartungswert "
            "oder Profitfaktor ein. Der Profitfaktor ist ohne einen einzigen "
            "Verlusttrade nicht definiert und wird dann nicht ausgewiesen. "
            "Slippage ist eine Schaetzung aus der "
            "Differenz zwischen Referenzkurs der Entscheidung und tatsaechlichem "
            "Fill, keine Broker-Messung."
        ),
    }
    return ausgabe


def offene_trades(broker: str = "") -> list[dict]:
    """Laufende Positionen im Ledger -- fuer Abgleich und Diagnose."""
    try:
        init_ledger()
        sql = "SELECT * FROM trades WHERE ausgestiegen_am IS NULL"
        werte: tuple = ()
        if broker:
            sql += " AND broker=?"
            werte = (str(broker).lower(),)
        sql += " ORDER BY eingestiegen_am ASC"
        with _LOCK, _connect() as con:
            return [dict(r) for r in con.execute(sql, werte).fetchall()]
    except Exception as exc:
        logger.debug("Offene Trades nicht lesbar: %s", exc)
        return []


def trade_liste(*, broker: str = "", tage: int = 90, limit: int = 250) -> list[dict]:
    """Chronologische Historie fuer die rein lesende WebUI-Auswertung."""
    try:
        init_ledger()
        cutoff = (datetime.now(timezone.utc) - timedelta(days=max(1, int(tage)))).isoformat()
        sql = "SELECT * FROM trades WHERE eingestiegen_am >= ?"
        werte: list[Any] = [cutoff]
        if broker:
            sql += " AND broker=?"
            werte.append(str(broker).lower())
        sql += " ORDER BY eingestiegen_am DESC, trade_id DESC LIMIT ?"
        werte.append(max(1, min(1000, int(limit))))
        with _LOCK, _connect() as con:
            return [dict(r) for r in con.execute(sql, tuple(werte)).fetchall()]
    except Exception as exc:
        logger.debug("Trade-Liste nicht lesbar: %s", exc)
        return []


def trade_detail(trade_id: int) -> Optional[dict]:
    """Ein Ledger-Trade anhand seiner unveraenderlichen ID."""
    try:
        init_ledger()
        with _LOCK, _connect() as con:
            row = con.execute("SELECT * FROM trades WHERE trade_id=?",
                              (int(trade_id),)).fetchone()
        return dict(row) if row else None
    except Exception as exc:
        logger.debug("Trade %s nicht lesbar: %s", trade_id, exc)
        return None


def trade_group(*, broker: str, symbol: str, eingestiegen_am: str) -> list[dict]:
    """Teilfills desselben Einstiegs fuer einen nachtraeglichen Brokerabgleich."""
    try:
        init_ledger()
        with _LOCK, _connect() as con:
            rows = con.execute(
                """SELECT * FROM trades WHERE broker=? AND symbol=?
                       AND eingestiegen_am=? ORDER BY trade_id ASC""",
                (str(broker or "").lower(), str(symbol or "").upper(),
                 str(eingestiegen_am or "")),
            ).fetchall()
        return [dict(x) for x in rows]
    except Exception as exc:
        logger.debug("Tradegruppe nicht lesbar: %s", exc)
        return []


__all__ = ["init_ledger", "trade_open", "trade_close", "mark_reconciled_closed",
           "set_reconciliation_status", "confirm_open_trade", "trade_snapshot",
           "mark_decision_reconciliation",
           "offener_trade", "offene_trades", "trade_liste", "trade_detail",
           "trade_group",
           "hoechstkurs_melden", "EXIT_UNBEKANNT"]
