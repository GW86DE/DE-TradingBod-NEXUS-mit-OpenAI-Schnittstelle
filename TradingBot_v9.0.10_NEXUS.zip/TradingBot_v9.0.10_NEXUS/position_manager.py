"""Positionsverwaltung und detaillierte Trade-/Telegram-Informationen."""
from __future__ import annotations

import json
import logging
import math
from dataclasses import asdict, dataclass
from datetime import datetime
from pathlib import Path
from typing import Dict, Iterable, Optional

import config
from instrument_identity import canonical_key, same_instrument
from safe_persistence import best_effort_json

logger = logging.getLogger(__name__)


def _now_iso() -> str:
    return datetime.now().astimezone().isoformat(timespec="seconds")


def _safe_float(value, default=0.0) -> float:
    try:
        v = float(value)
        return v if math.isfinite(v) else default
    except Exception:
        return default


def fmt_money(value, digits=2) -> str:
    return f"{_safe_float(value):,.{digits}f}".replace(",", "X").replace(".", ",").replace("X", ".")


def fmt_price(value, digits=6) -> str:
    """Preis lesbar im deutschen Zahlenformat, ohne unnoetige Nachkommastellen."""
    v = _safe_float(value)
    raw = f"{v:,.{digits}f}".rstrip("0").rstrip(".")
    return raw.replace(",", "X").replace(".", ",").replace("X", ".") if raw else "0"


def _als_id(wert):
    """Broker-IDs koennen als Zahl oder Zeichenkette geliefert werden."""
    try:
        return int(wert or 0)
    except (TypeError, ValueError):
        return 0


class _EinfacherKontrakt:
    """
    Ersatz-Kontrakt fuer Positionen, die nicht im aktuellen Universum
    stehen (z.B. manuell gekauft oder Broker gewechselt). Damit bleiben
    solche Positionen sichtbar, statt stillschweigend zu verschwinden.
    """

    def __init__(self, symbol, currency="USD", kennung=""):
        self.symbol = symbol
        self.localSymbol = symbol
        self.currency = currency
        self.conId = kennung


def protection_result_confirmed(result: dict | None) -> bool:
    """Sicherheitsentscheidung nur aus dem expliziten Adapter-Boolfeld.

    Freitext wie "Schutz vorhanden" hat absichtlich keinerlei Wirkung.
    """
    return bool((result or {}).get("protection_confirmed", False))


@dataclass
class PositionRecord:
    con_id: object
    symbol: str
    asset_type: str
    currency: str
    quantity: float
    avg_cost: float
    entry_time: str
    planned_stop: float = 0.0
    planned_take: float = 0.0
    planned_risk_amount: float = 0.0
    planned_risk_pct: float = 0.0
    entry_reason: str = ""
    profile: str = ""
    source: str = "BOT"
    # AUTO = Bot darf Strategie-/News-/Time-Exits ausloesen.
    # OBSERVE = Position zaehlt voll ins Risiko/Portfolio, wird aber nicht
    # automatisch veraendert. PENDING_TAKEOVER wird erst nach erfolgreicher
    # Schutzpruefung im Trading-Core zu AUTO.
    management_mode: str = "AUTO"
    management_note: str = ""
    last_manual_change: str = ""
    estimated_entry_cost: float = 0.0


class PositionManager:
    def __init__(self, path: str | Path | None = None):
        self.path = Path(path or getattr(config, "POSITION_STATE_FILE", "position_state.json"))
        self.records: Dict[str, PositionRecord] = {}
        self._load()

    def _load(self):
        if not self.path.exists():
            return
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
            for key, payload in data.get("positions", {}).items():
                payload=dict(payload)
                if "management_mode" not in payload:
                    payload["management_mode"] = "AUTO" if str(payload.get("source","")).upper()=="BOT" else "OBSERVE"
                self.records[str(key)] = PositionRecord(**payload)
        except Exception as exc:
            logger.warning("Positions-State konnte nicht geladen werden: %s", exc)

    def save(self):
        payload = {
            "updated_at": _now_iso(),
            "positions": {key: asdict(rec) for key, rec in self.records.items()},
        }
        best_effort_json(self.path, payload, label="Positions-State")

    def key(self, contract_or_con_id) -> str:
        """
        Eindeutiger Schluessel einer Position.
        Broker-APIs koennen numerische oder textuelle IDs liefern --
        deshalb wird nicht mehr auf int gezwungen.
        """
        if isinstance(contract_or_con_id, str):
            return contract_or_con_id
        kennung = getattr(contract_or_con_id, "conId", None)
        if kennung:
            return str(kennung)
        symbol = getattr(contract_or_con_id, "localSymbol", None) or getattr(contract_or_con_id, "symbol", None)
        return str(symbol or contract_or_con_id)

    def _symbol_of(self, contract_or_con_id) -> str:
        if isinstance(contract_or_con_id, str):
            return contract_or_con_id.upper()
        symbol = (getattr(contract_or_con_id, "localSymbol", None)
                  or getattr(contract_or_con_id, "symbol", None) or "")
        return str(symbol).upper()

    def _find_key_by_symbol(self, symbol: str, asset_type: str | None = None) -> Optional[str]:
        wanted = str(symbol or "").upper()
        if not wanted:
            return None
        for key, rec in self.records.items():
            if asset_type:
                if same_instrument(rec.symbol, rec.asset_type, wanted, asset_type):
                    return key
            elif str(rec.symbol or "").upper() == wanted:
                return key
        return None

    def _lookup_key(self, contract_or_con_id) -> str:
        direct = self.key(contract_or_con_id)
        if direct in self.records:
            return direct
        by_symbol = self._find_key_by_symbol(self._symbol_of(contract_or_con_id))
        return by_symbol or direct

    def get(self, contract_or_con_id) -> Optional[PositionRecord]:
        return self.records.get(self._lookup_key(contract_or_con_id))

    def get_by_symbol(self, symbol: str) -> Optional[PositionRecord]:
        key = self._find_key_by_symbol(symbol)
        return self.records.get(key) if key else None

    def remove(self, contract_or_con_id):
        self.records.pop(self.key(contract_or_con_id), None)
        self.save()

    def upsert_existing_position(self, contract, quantity, avg_cost, currency=None,
                                 asset_type="stock", schluessel=None):
        key = schluessel or self.key(contract)
        rec = self.records.get(key)
        if rec is None:
            rec = PositionRecord(
                con_id=_als_id(getattr(contract, "conId", 0)),
                symbol=getattr(contract, "localSymbol", None) or getattr(contract, "symbol", "?"),
                asset_type=asset_type,
                currency=currency or getattr(contract, "currency", ""),
                quantity=float(quantity),
                avg_cost=float(avg_cost),
                entry_time=_now_iso(),
                profile=getattr(config, "ACTIVE_PROFILE", ""),
                source="BROKER_EXISTING",
                management_mode="OBSERVE",
                management_note="Beim Broker bereits vorhanden; standardmaessig nur beobachten.",
            )
            self.records[key] = rec
        else:
            new_qty=float(quantity)
            if abs(new_qty-float(rec.quantity or 0)) > max(1e-9, abs(new_qty)*1e-8):
                # Normalerweise hat capture_new_fills die Menge bereits gesetzt.
                # Eine hiervon abweichende Broker-Menge ist daher eine manuelle
                # oder sonstige externe Aenderung und darf nicht still automatisch
                # weiterverwaltet werden.
                if str(rec.management_mode).upper()=="AUTO":
                    rec.source = "MIXED" if str(rec.source).upper()=="BOT" else rec.source
                    rec.management_mode = "OBSERVE"
                    rec.management_note = "Externe Broker-Mengenaenderung erkannt; Automatik pausiert."
                    rec.last_manual_change = _now_iso()
            rec.quantity = new_qty
            if avg_cost:
                rec.avg_cost = float(avg_cost)
        return rec

    def register_buy(self, contract, fill_qty, fill_price, currency, asset_type,
                     account_equity, stop_price, take_price, reason="", profile="",
                     estimated_entry_cost=0.0, source="BOT", management_mode=None):
        key = self._lookup_key(contract)
        fill_qty = abs(_safe_float(fill_qty))
        fill_price = _safe_float(fill_price)
        old = self.records.get(key)
        src=str(source or "BOT").upper()
        mode=(str(management_mode).upper() if management_mode else ("AUTO" if src=="BOT" else "OBSERVE"))
        # Eine eToro-Position kann im Depot bereits sichtbar sein, bevor der
        # Lookup-Fill geliefert wird. sync_with_broker() legt sie dann zuerst
        # als BROKER_EXISTING/OBSERVE an. Kommt spaeter der EXAKT ueber
        # orderId/referenceId/positionId bewiesene Bot-Fill, darf seine Menge
        # nicht ein zweites Mal addiert werden. Stattdessen wird genau dieser
        # Datensatz mit Einstand und Schutzplan zu BOT/AUTO hochgestuft.
        if (old and src == "BOT"
                and str(old.management_mode or "").upper() == "OBSERVE"
                and str(old.source or "").upper() in {"BROKER_EXISTING", "AMBIGUOUS", "MANUAL"}
                and abs(float(old.quantity or 0.0) - fill_qty)
                    <= max(1e-9, fill_qty * 1e-8)):
            risk_amount = max(0.0, (fill_price - _safe_float(stop_price)) * fill_qty)
            old.quantity = fill_qty
            old.avg_cost = fill_price
            old.planned_stop = _safe_float(stop_price)
            old.planned_take = _safe_float(take_price)
            old.planned_risk_amount = risk_amount
            old.planned_risk_pct = (risk_amount / account_equity) if account_equity > 0 else 0.0
            old.entry_reason = reason
            old.profile = profile or getattr(config, "ACTIVE_PROFILE", "")
            old.source = "BOT"
            old.management_mode = "AUTO"
            old.management_note = "Spaet bestaetigte Botposition exakt per Broker-ID uebernommen."
            old.last_manual_change = ""
            old.estimated_entry_cost = max(0.0, _safe_float(estimated_entry_cost))
            self.save()
            return old
        if old and old.quantity > 0:
            total_qty = old.quantity + fill_qty
            old.avg_cost = ((old.avg_cost * old.quantity) + (fill_price * fill_qty)) / total_qty
            old.quantity = total_qty
            old.estimated_entry_cost += max(0.0, _safe_float(estimated_entry_cost))
            # Jede manuelle Aufstockung einer Bot-Position macht die Herkunft
            # gemischt. Automatik wird sicherheitshalber deaktiviert, bis der
            # Nutzer die Verwaltung bewusst wieder uebernimmt.
            if src != "BOT":
                old.source = "MIXED" if str(old.source).upper()=="BOT" else src
                old.management_mode = "OBSERVE"
                old.management_note = "Manuelle Aufstockung erkannt; Bot-Verwaltung pausiert."
                old.last_manual_change = _now_iso()
            rec = old
        else:
            risk_amount = max(0.0, (fill_price - _safe_float(stop_price)) * fill_qty)
            risk_pct = (risk_amount / account_equity) if account_equity > 0 else 0.0
            rec = PositionRecord(
                con_id=_als_id(getattr(contract, "conId", 0)),
                symbol=getattr(contract, "localSymbol", None) or getattr(contract, "symbol", "?"),
                asset_type=asset_type,
                currency=currency or getattr(contract, "currency", ""),
                quantity=fill_qty,
                avg_cost=fill_price,
                entry_time=_now_iso(),
                planned_stop=_safe_float(stop_price),
                planned_take=_safe_float(take_price),
                planned_risk_amount=risk_amount,
                planned_risk_pct=risk_pct,
                entry_reason=reason,
                profile=profile or getattr(config, "ACTIVE_PROFILE", ""),
                source=src,
                management_mode=mode,
                management_note=("" if mode=="AUTO" else "Manueller/uebernommener Broker-Kauf: nur beobachten."),
                last_manual_change=(_now_iso() if src != "BOT" else ""),
                estimated_entry_cost=max(0.0, _safe_float(estimated_entry_cost)),
            )
            self.records[key] = rec
        self.save()
        return rec

    def register_sell(self, contract, fill_qty, fill_price, currency=None, estimated_exit_cost=0.0, execution_source="BOT"):
        key = self._lookup_key(contract)
        rec = self.records.get(key)
        qty = abs(_safe_float(fill_qty))
        px = _safe_float(fill_price)
        entry = rec.avg_cost if rec else 0.0
        entry_cost_share = 0.0
        if rec and rec.quantity > 0:
            entry_cost_share = max(0.0, rec.estimated_entry_cost) * min(1.0, qty / rec.quantity)
        exit_cost = max(0.0, _safe_float(estimated_exit_cost))
        gross = (px - entry) * qty if entry > 0 else 0.0
        pnl = gross - entry_cost_share - exit_cost if entry > 0 else 0.0
        invested = entry * qty + entry_cost_share if entry > 0 else 0.0
        pnl_pct = pnl / invested if invested > 0 else 0.0
        remaining = max(0.0, (rec.quantity - qty)) if rec else 0.0
        if rec:
            if remaining <= 1e-9:
                self.records.pop(key, None)
            else:
                rec.quantity = remaining
                rec.estimated_entry_cost = max(0.0, rec.estimated_entry_cost - entry_cost_share)
                if str(execution_source or "BOT").upper() != "BOT":
                    rec.source = "MIXED" if str(rec.source).upper()=="BOT" else rec.source
                    rec.management_mode = "OBSERVE"
                    rec.management_note = "Manueller Teilverkauf erkannt; Bot-Verwaltung pausiert."
                    rec.last_manual_change = _now_iso()
        self.save()
        return rec, pnl, pnl_pct, remaining

    def sync_with_broker(self, broker, instruments: Iterable, notify_missing=False):
        """
        Der Broker ist die Wahrheit: Positionen werden von eToro uebernommen.

        Die Zuordnung nutzt immer Asset-Typ + Symbol. Ein Kurzticker allein
        darf keine Aktie mit einer gleichnamigen Kryptowaehrung verbinden.
        """
        by_identity = {}
        for inst in instruments:
            try:
                by_identity[canonical_key(inst.name, inst.asset_type)] = inst
            except Exception as exc:
                logger.debug("Ungueltige Instrumentidentitaet im Universum: %s", exc)

        current = {}
        for pos in broker.positionen():
            qty = _safe_float(pos.quantity)
            if qty == 0:
                continue

            symbol = str(pos.symbol)
            try:
                pkey=canonical_key(symbol, pos.asset_type)
            except Exception:
                pkey=""
            info = by_identity.get(pkey)
            # Brokerpositionen mit unbekannter/mehrdeutiger Identitaet werden
            # sichtbar als OBSERVE uebernommen, aber nie einem anderen Asset
            # nur anhand des Kurztickers zugeordnet.
            schluessel = str(pos.broker_id or (pkey or symbol))

            kontrakt = getattr(info, "contract", None) if info else None
            if kontrakt is None:
                kontrakt = _EinfacherKontrakt(symbol, pos.currency, schluessel)

            # Broker-ID ist die kanonische ID. Nach Neustarts koennen lokale
            # Bot-Records noch unter einer Contract-ID liegen. Per Symbol
            # zusammenfuehren, damit der Einstand beim spaeteren Verkauf
            # nach einem Neustart wiedergefunden wird.
            existing_key = self._find_key_by_symbol(symbol, pos.asset_type)
            if existing_key and existing_key != schluessel and schluessel not in self.records:
                self.records[schluessel] = self.records.pop(existing_key)

            current[schluessel] = (kontrakt, qty, _safe_float(pos.avg_cost), info)
            self.upsert_existing_position(
                kontrakt, qty, _safe_float(pos.avg_cost),
                currency=pos.currency,
                asset_type=(info.asset_type if info else pos.asset_type),
                schluessel=schluessel,
            )
        # Positionen, die beim Broker nicht mehr existieren, werden nach einer
        # Karenzzeit entfernt. Ohne Karenz waere das riskant: ein gerade
        # ausgefuehrter Kauf taucht in der naechsten Positionsabfrage evtl.
        # noch nicht auf und wuerde faelschlich geloescht. Ohne Aufraeumen
        # wiederum sammeln sich Karteileichen an (z.B. manuell geschlossene
        # Positionen), die spaetere P&L-Berechnungen verfaelschen.
        karenz = float(getattr(config, "POSITION_STALE_MINUTES", 30)) * 60
        jetzt = datetime.now().astimezone()
        for key in list(self.records):
            if key in current:
                continue
            rec = self.records[key]
            try:
                alter = (jetzt - datetime.fromisoformat(rec.entry_time)).total_seconds()
            except Exception:
                alter = karenz + 1
            if alter > karenz:
                logger.info(
                    "Position %s existiert bei eToro nicht mehr -- Eintrag entfernt.",
                    rec.symbol,
                )
                self.records.pop(key, None)
        self.save()
        self._schreibe_anzeigedatei(broker)
        return current

    # -- Anzeige ------------------------------------------------------------
    def _schreibe_anzeigedatei(self, broker) -> None:
        """Eine Momentaufnahme fuer die Oberflaeche (neu in v8.1.5).

        Das Dashboard hat keine Brokerverbindung -- es liest Dateien. Bis
        v8.1.4 gab es fuer die Aktienseite keine, und deshalb stand auf der
        Hauptseite ZWEIMAL die Zahl der OKX-Positionen und KEIN EINZIGES MAL
        die der eToro-Positionen. Genau das hat Georg am 25.08.2026 gemeldet.

        Der Kryptoseite ihr Gegenstueck ist ``crypto_positions.json``.
        Best-effort: eine fehlende Anzeigedatei darf nie den Handel stoeren.
        """
        try:
            aktuelle_kurse = {}
            for pos in broker.positionen():
                aktuelle_kurse[str(pos.symbol).upper()] = {
                    "kurs": _safe_float(getattr(pos, "market_price", 0.0)),
                    "wert": _safe_float(getattr(pos, "market_value", 0.0)),
                    "unrealisiert": _safe_float(getattr(pos, "unrealized_pnl", 0.0)),
                    "broker_stop": getattr(pos, "broker_stop", None),
                    "broker_take": getattr(pos, "broker_take_profit", None),
                }
        except Exception:
            logger.debug("Kurse fuer die Anzeigedatei nicht abrufbar", exc_info=True)
            aktuelle_kurse = {}

        positionen = []
        for rec in self.records.values():
            kurs = aktuelle_kurse.get(str(rec.symbol).upper(), {})
            positionen.append({
                "symbol": rec.symbol,
                "asset_type": rec.asset_type,
                "waehrung": rec.currency,
                "menge": _safe_float(rec.quantity),
                "einstand": _safe_float(rec.avg_cost),
                # None statt 0, wenn der Kurs fehlt: 0 saehe aus wie ein
                # Totalverlust und waere eine Falschaussage.
                "kurs": kurs.get("kurs") or None,
                "wert": kurs.get("wert") or None,
                "unrealisiert": kurs.get("unrealisiert"),
                "stop": (kurs.get("broker_stop") if str(rec.management_mode or "").upper() == "OBSERVE"
                         else (_safe_float(rec.planned_stop) or None)),
                "ziel": (kurs.get("broker_take") if str(rec.management_mode or "").upper() == "OBSERVE"
                         else (_safe_float(rec.planned_take) or None)),
                "schutz_quelle": ("eToro read-only" if str(rec.management_mode or "").upper() == "OBSERVE"
                                    and (kurs.get("broker_stop") is not None or kurs.get("broker_take") is not None)
                                    else "lokaler Plan" if str(rec.management_mode or "").upper() == "AUTO" else "unbekannt"),
                "verwaltung": str(rec.management_mode or "").upper(),
                "herkunft": str(rec.source or "").upper(),
                "seit": rec.entry_time,
                "notiz": str(getattr(rec, "management_note", "") or ""),
            })
        positionen.sort(key=lambda x: str(x["symbol"]))
        best_effort_json(
            self.path.with_name("stock_positions.json"),
            {"updated_at": _now_iso(), "kurse_verfuegbar": bool(aktuelle_kurse),
             "positionen": positionen},
            label="Aktien-Anzeigedatei")

    def is_auto_managed(self, contract_or_symbol) -> bool:
        rec = self.get_by_symbol(contract_or_symbol) if isinstance(contract_or_symbol, str) else self.get(contract_or_symbol)
        return bool(rec and str(rec.management_mode).upper()=="AUTO")

    def set_observe_only(self, symbol: str, note: str = "Vom Nutzer auf Beobachten gesetzt") -> bool:
        rec=self.get_by_symbol(symbol)
        if not rec:return False
        rec.management_mode="OBSERVE"; rec.management_note=note; rec.last_manual_change=_now_iso(); self.save(); return True

    def request_takeover(self, symbol: str, stop: float, take: float,
                         aktueller_kurs: float | None = None) -> tuple[bool, str]:
        """Eine selbst gekaufte Position dem Bot uebergeben.

        GEAENDERT IN v8.1.5 -- der alte Test war
        ``stop < rec.avg_cost < take``, also gemessen am EINSTAND.

        Georg am 25.08.2026: "Zusaetzlich wollte ich heute in der GUI eine
        aktie die ich selber gekauft habe dem Bot uebergeben das er sie
        handeln soll. die funktion gibt es dort ja aber es wurde blockiert
        weil sie zu sehr im minus war."

        Er hat recht, und der alte Test war schlicht falsch gedacht. Bei einer
        Position, die 30 % im Minus steht, liegt der Einstand WEIT ueber dem
        aktuellen Kurs. Ein Stop unter dem Einstand haette dann ueber dem
        Marktpreis gelegen und sofort ausgeloest; ein Ziel ueber dem Einstand
        waere in unerreichbarer Ferne. Der Einstand ist Vergangenheit -- er
        sagt nichts darueber, wo Stop und Ziel sinnvoll liegen.

        Massgeblich ist der AKTUELLE KURS:

            Stop  <  aktueller Kurs  <  Ziel

        Zusaetzlich muss der Stop weiter weg sein als die Handelskosten der
        Runde; sonst frisst ein Stop, der bei der ersten Zuckung greift,
        garantiert Geld. Das ist dieselbe Regel wie beim Bot-Einstieg.

        Was sich NICHT aendert: Die Uebernahme setzt nur eine Anforderung.
        Handelbar wird die Position erst, wenn der laufende Kern den
        Broker-Schutz tatsaechlich bestaetigt hat (``confirm_takeover``).
        """
        rec = self.get_by_symbol(symbol)
        if not rec:
            return False, "Position nicht gefunden"

        stop = _safe_float(stop)
        take = _safe_float(take)
        kurs = _safe_float(aktueller_kurs) if aktueller_kurs is not None else 0.0
        if kurs <= 0:
            # Ohne aktuellen Kurs wird NICHT auf den Einstand ausgewichen --
            # genau das war der Fehler. Lieber ehrlich ablehnen.
            return False, ("Aktueller Kurs unbekannt. Ohne ihn lassen sich Stop "
                           "und Ziel nicht sinnvoll pruefen; bitte erneut "
                           "versuchen, sobald Kursdaten anliegen.")
        if stop <= 0 or take <= 0:
            return False, "Stop und Ziel muessen groesser als null sein"
        if stop >= kurs:
            return False, (f"Der Stop ({stop:.6g}) liegt nicht unter dem aktuellen "
                           f"Kurs ({kurs:.6g}) -- er wuerde sofort ausloesen")
        if take <= kurs:
            return False, (f"Das Ziel ({take:.6g}) liegt nicht ueber dem aktuellen "
                           f"Kurs ({kurs:.6g}) -- es waere schon erreicht")

        mindestabstand = self._stop_mindestabstand(rec, kurs)
        if (kurs - stop) < mindestabstand:
            return False, (f"Der Stop ist zu eng: {kurs - stop:.6g} Abstand, "
                           f"noetig sind mindestens {mindestabstand:.6g} "
                           "(Kauf- und Verkaufsgebuehren der Runde). Ein engerer "
                           "Stop verliert im Auslosefall garantiert Geld.")

        rec.planned_stop = stop
        rec.planned_take = take
        rec.management_mode = "PENDING_TAKEOVER"
        # Eine uebernommene Position gehoert nicht ins konfigurierte Universum
        # und muss es auch nicht. Diese Herkunft sagt: der Nutzer hat sie
        # gekauft, der Bot verwaltet sie ab jetzt.
        rec.source = "USER_MANAGED"
        hinweis = ""
        if rec.avg_cost > 0 and kurs < rec.avg_cost:
            offen = (kurs - rec.avg_cost) * _safe_float(rec.quantity)
            beim_stop = (stop - rec.avg_cost) * _safe_float(rec.quantity)
            hinweis = (f" Hinweis: Die Position steht mit {offen:,.2f} "
                       f"{rec.currency} im Minus. Greift der Stop, wird ein "
                       f"Verlust von rund {beim_stop:,.2f} {rec.currency} "
                       "realisiert.")
        rec.management_note = ("Uebernahme angefordert; wartet auf "
                               "Broker-Schutzpruefung." + hinweis)
        rec.last_manual_change = _now_iso()
        self.save()
        return True, rec.management_note

    @staticmethod
    def _stop_mindestabstand(rec, kurs: float) -> float:
        """Wie weit muss ein Stop mindestens weg sein, um nicht zu schaden?

        Ein Stop innerhalb der Handelskosten ist kein Schutz: er loest im
        Rauschen aus und verliert dabei sicher die Gebuehren beider Seiten.
        """
        try:
            from cost_engine import estimate_roundtrip
            kosten = estimate_roundtrip(
                _safe_float(rec.quantity), kurs, rec.asset_type, rec.currency,
                broker=None)
            gesamt = _safe_float(getattr(kosten, "total_cost", 0.0))
            menge = _safe_float(rec.quantity)
            if gesamt > 0 and menge > 0:
                faktor = float(getattr(config, "CRYPTO_STOP_KOSTEN_FAKTOR", 1.5))
                return (gesamt / menge) * max(1.0, faktor)
        except Exception:
            logger.debug("Kostenabstand nicht berechenbar", exc_info=True)
        # Sicherer Ersatzwert, wenn die Kostenschaetzung nicht laeuft.
        return abs(kurs) * 0.002

    def confirm_takeover(self, symbol: str, detail: str = "Schutz geprueft") -> bool:
        rec=self.get_by_symbol(symbol)
        if not rec:return False
        rec.management_mode="AUTO"; rec.source="USER_MANAGED"; rec.management_note=str(detail or "Schutz geprueft"); self.save(); return True

    def reject_takeover(self, symbol: str, detail: str) -> bool:
        rec=self.get_by_symbol(symbol)
        if not rec:return False
        rec.management_mode="OBSERVE"; rec.management_note=str(detail or "Uebernahme nicht moeglich"); self.save(); return True

    def portfolio_text(self, current_positions, title="DEPOT-STATUS"):
        lines = [str(title), f"Profil: {getattr(config, 'ACTIVE_PROFILE', 'unbekannt').upper()}"]
        if not current_positions:
            lines.append("Keine offenen Positionen.")
            return "\n".join(lines)
        lines.append(f"Offene Positionen: {len(current_positions)}")
        for _, (contract, qty, avg_cost, inst) in sorted(
                current_positions.items(), key=lambda x: getattr(x[1][0], 'symbol', '')):
            name = getattr(contract, "localSymbol", None) or getattr(contract, "symbol", "?")
            cur = getattr(contract, "currency", "")
            rec=self.get_by_symbol(name)
            owner=(getattr(rec,"source","") if rec else "")
            mode=(getattr(rec,"management_mode","") if rec else "")
            suffix=f" | {owner}/{mode}" if owner or mode else ""
            lines.append(f"• {name} | {qty:g} Stk. | EK {fmt_price(avg_cost)} {cur}{suffix}")
        return "\n".join(lines)
