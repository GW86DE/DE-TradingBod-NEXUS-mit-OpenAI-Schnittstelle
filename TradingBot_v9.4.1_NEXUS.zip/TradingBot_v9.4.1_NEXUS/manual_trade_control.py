"""Sichere WebUI-Auftraege fuer manuelle OKX-Positionsverwaltung.

Die WebUI besitzt absichtlich keine Brokerverbindung. Sie schreibt nur eine
eindeutige, einmalige Absicht. Der Handelskern fuehrt diese unter seiner
bestehenden OKX-Sitzung aus und schreibt das Ergebnis atomar zurueck.
"""

from __future__ import annotations

import json
import logging
import os
import threading
import time
import uuid
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
from pathlib import Path

from safe_persistence import atomic_write_json

logger = logging.getLogger(__name__)

DATEI = "manual_trade_commands.json"
LOCK_DATEI = "manual_coin_locks.json"
AKTIONEN = {"SET_PROTECTION", "SELL"}
LOCK_OPTIONEN = {"1H": 60, "6H": 360, "DAY": -1, "MANUAL": 0}
_LOCK = threading.RLock()


def _verifizierter_botnachweis(value: object) -> bool:
    """Nur explizite Fill-Nachweise berechtigen zu einer manuellen Order.

    Das Ledger verwendet bei neuen OKX-Trades den praeziseren Wert
    VERIFIED_BROKER_FILL_CHAIN. Dieser ist kein schwacher Ersatz, sondern der
    staerkere Nachweis aus instId, Konto, ordId/clOrdId und Fill-Kette.
    """
    return str(value or "").upper() in {
        "VERIFIED", "VERIFIED_BROKER_FILL_CHAIN",
    }


@contextmanager
def _process_lock():
    """Serialisiert WebUI und Handelskern auch ueber Prozessgrenzen."""
    path = _root() / ".manual_trade_control.lock"
    path.parent.mkdir(parents=True, exist_ok=True)
    handle = open(path, "a+b")
    gesperrt = False
    try:
        if os.name == "posix":
            import fcntl
            fcntl.flock(handle.fileno(), fcntl.LOCK_EX)
            gesperrt = True
        else:
            # v9.1: Unter Windows wurde die Datei bisher nur geoeffnet und
            # sonst nichts. WebUI (uvicorn) und Handelskern sind dort zwei
            # Prozesse -- im Lese-Aendern-Schreiben ging ein Update verloren,
            # und derselbe manuelle Verkauf konnte ein zweites Mal gesendet
            # werden. Vorlage ist instance_lock.py.
            import msvcrt
            for _ in range(50):
                try:
                    handle.seek(0)
                    msvcrt.locking(handle.fileno(), msvcrt.LK_LOCK, 1)
                    gesperrt = True
                    break
                except OSError:
                    time.sleep(0.1)
            if not gesperrt:
                raise TimeoutError(
                    "Auftragsdatei ist dauerhaft gesperrt; kein zweiter "
                    "Schreibzugriff, um einen Doppelauftrag auszuschliessen.")
        yield
    finally:
        try:
            if gesperrt and os.name == "posix":
                import fcntl
                fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
            elif gesperrt:
                import msvcrt
                handle.seek(0)
                msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
        except OSError:
            logger.warning("Auftragssperre konnte nicht sauber geloest werden",
                           exc_info=True)
        handle.close()


def _root() -> Path:
    value = os.getenv("TRADINGBOT_TEST_STATE_DIR", "").strip()
    return Path(value) if value else Path(__file__).resolve().parent


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _iso(value: datetime | None = None) -> str:
    return (value or _now()).isoformat()


def _read(name: str, default: dict) -> dict:
    path = _root() / name
    if not path.exists():
        return dict(default)
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else dict(default)
    except Exception:
        return dict(default)


def _write(name: str, value: dict) -> None:
    atomic_write_json(_root() / name, value)


def _open_trade(trade_id: int) -> dict:
    import trade_ledger
    row = trade_ledger.trade_detail(int(trade_id))
    if not row or row.get("ausgestiegen_am"):
        raise ValueError("Der Trade ist nicht mehr offen.")
    if str(row.get("broker") or "").lower() != "okx":
        raise ValueError("Manuelle Handelsaktionen sind hier nur fuer OKX verfuegbar.")
    if str(row.get("reconciliation_status") or "").upper() != "CONFIRMED_OPEN":
        raise ValueError("Der Trade ist nicht eindeutig als offen bestaetigt.")
    if not _verifizierter_botnachweis(row.get("ownership_status")):
        raise ValueError("Der Eigentumsnachweis des Bot-Trades fehlt.")
    return row


def request(trade_id: int, action: str, *, stop: float = 0.0,
            take_profit: float = 0.0, lock: str = "6H", actor: str = "webui",
            confirmation: str = "") -> dict:
    """Validierten Auftrag hinterlegen; niemals selbst eine Order senden."""
    row = _open_trade(trade_id)
    action = str(action or "").upper()
    if action not in AKTIONEN:
        raise ValueError("Unbekannte manuelle Aktion.")
    symbol = str(row.get("symbol") or "").upper()
    expected = f"{action} {symbol}"
    if str(confirmation or "").strip().upper() != expected:
        raise ValueError(f"Zur Bestaetigung exakt „{expected}“ eingeben.")
    payload = {
        "id": uuid.uuid4().hex, "trade_id": int(trade_id), "action": action,
        "symbol": symbol, "instrument": str(row.get("broker_position_id") or ""),
        "account_fingerprint": str(row.get("broker_account_fingerprint") or ""),
        "actor": str(actor or "")[:80], "created_at": _iso(), "status": "PENDING",
    }
    if action == "SET_PROTECTION":
        stop, take_profit = float(stop or 0.0), float(take_profit or 0.0)
        if stop <= 0 or take_profit <= 0 or stop >= take_profit:
            raise ValueError("Stop-Loss und Take-Profit muessen positiv sein; SL muss unter TP liegen.")
        payload.update(stop=stop, take_profit=take_profit)
    else:
        lock = str(lock or "6H").upper()
        if lock not in LOCK_OPTIONEN:
            raise ValueError("Unbekannte Wiedereinstiegssperre.")
        payload["lock"] = lock
    with _LOCK, _process_lock():
        data = _read(DATEI, {"commands": []})
        if any(int(x.get("trade_id") or 0) == int(trade_id)
               and str(x.get("status")) in {"PENDING", "PROCESSING", "UNCLEAR"}
               for x in data.get("commands", [])):
            raise ValueError("Fuer diesen Trade laeuft bereits ein manueller Auftrag.")
        data.setdefault("commands", []).append(payload)
        data["commands"] = data["commands"][-100:]
        _write(DATEI, data)
    return dict(payload)


def pending() -> list[dict]:
    with _LOCK, _process_lock():
        data = _read(DATEI, {"commands": []})
        changed = False
        for row in data.get("commands", []):
            if str(row.get("status")) != "PROCESSING":
                continue
            try:
                started = datetime.fromisoformat(
                    str(row.get("updated_at") or row.get("created_at") or "")
                    .replace("Z", "+00:00"))
                if started.tzinfo is None:
                    started = started.replace(tzinfo=timezone.utc)
            except ValueError:
                started = _now() - timedelta(hours=1)
            if (_now() - started).total_seconds() > 120:
                row.update(status="UNCLEAR", updated_at=_iso(),
                           detail=("Handelskern wurde waehrend der Ausfuehrung beendet. "
                                   "Kein automatischer Wiederholungsauftrag; zuerst OKX abgleichen."))
                changed = True
        if changed:
            _write(DATEI, data)
        return [dict(x) for x in data.get("commands", [])
                if str(x.get("status")) == "PENDING"]


def update(command_id: str, status: str, detail: str = "", **extra) -> None:
    with _LOCK, _process_lock():
        data = _read(DATEI, {"commands": []})
        for row in data.get("commands", []):
            if str(row.get("id")) == str(command_id):
                row.update(status=str(status), updated_at=_iso(), detail=str(detail)[:600], **extra)
                break
        _write(DATEI, data)


def overview() -> dict:
    with _LOCK, _process_lock():
        commands = list(reversed(_read(DATEI, {"commands": []}).get("commands", [])))[:25]
        locks = _active_locks(_read(LOCK_DATEI, {"locks": []}).get("locks", []))
    return {"commands": commands, "locks": locks}


def _active_locks(rows: list[dict]) -> list[dict]:
    now = _now()
    result = []
    for row in rows:
        until = str(row.get("until") or "")
        if until:
            try:
                if datetime.fromisoformat(until.replace("Z", "+00:00")) <= now:
                    continue
            except ValueError:
                # v9.1: fail-CLOSED. Ein unlesbares Ablaufdatum liess die
                # Sperre bis 9.0.15 spurlos verschwinden -- an einem
                # Sicherheitsgate ist das die falsche Richtung. Die Sperre
                # bleibt bestehen und kann von Hand freigegeben werden.
                logger.warning("Sperre %s hat ein unlesbares Ablaufdatum %r -- "
                               "sie bleibt aktiv.", row.get("id"), until)
                result.append(dict(row))
                continue
        if not row.get("released_at"):
            result.append(dict(row))
    return result


def add_lock(*, broker: str, account_fingerprint: str, symbol: str,
             duration: str, reason: str, actor: str) -> dict:
    duration = str(duration or "6H").upper()
    if duration not in LOCK_OPTIONEN:
        # v9.1: Vorher ein ungefangener KeyError. Der Aufrufer faengt nur
        # BrokerFehler/ValueError -- nach einem ERFOLGREICHEN Verkauf waere der
        # Auftrag auf PROCESSING haengen geblieben und spaeter UNCLEAR
        # geworden, obwohl alles sauber lief.
        raise ValueError(
            f"Unbekannte Sperrdauer {duration!r}; erlaubt sind "
            + ", ".join(sorted(LOCK_OPTIONEN)))
    minutes = LOCK_OPTIONEN[duration]
    now = _now()
    if minutes < 0:
        # Ende des lokalen Handelstags Europe/Berlin ohne zusaetzliche Abhaengigkeit.
        from zoneinfo import ZoneInfo
        # v9.1: die konfigurierte Zeitzone, nicht mehr fest Europe/Berlin.
        try:
            import config as _cfg
            zone = ZoneInfo(str(getattr(_cfg, "LOCAL_TIMEZONE", "Europe/Berlin")))
        except Exception:
            zone = ZoneInfo("Europe/Berlin")
        local = now.astimezone(zone)
        end = (local + timedelta(days=1)).replace(hour=0, minute=0, second=0, microsecond=0)
        until = end.astimezone(timezone.utc)
    elif minutes > 0:
        until = now + timedelta(minutes=minutes)
    else:
        until = None
    row = {"id": uuid.uuid4().hex, "broker": str(broker).lower(),
           "account_fingerprint": str(account_fingerprint), "symbol": str(symbol).upper(),
           "created_at": _iso(now), "until": _iso(until) if until else "",
           "duration": duration, "reason": str(reason)[:300], "actor": str(actor)[:80]}
    with _LOCK, _process_lock():
        data = _read(LOCK_DATEI, {"locks": []})
        data["locks"] = [x for x in _active_locks(data.get("locks", []))
                         if not (str(x.get("broker")) == row["broker"]
                                 and str(x.get("account_fingerprint")) == row["account_fingerprint"]
                                 and str(x.get("symbol")) == row["symbol"])] + [row]
        _write(LOCK_DATEI, data)
    return row


def lock_reason(broker: str, account_fingerprint: str, symbol: str) -> str:
    with _LOCK, _process_lock():
        rows = _active_locks(_read(LOCK_DATEI, {"locks": []}).get("locks", []))
    for row in rows:
        if (str(row.get("broker")) == str(broker).lower()
                and str(row.get("account_fingerprint")) == str(account_fingerprint)
                and str(row.get("symbol")) == str(symbol).upper()):
            until = row.get("until") or "manuell"
            return f"Manuelle Wiedereinstiegssperre bis {until}: {row.get('reason') or ''}".strip()
    return ""


def release_lock(lock_id: str, actor: str) -> bool:
    with _LOCK, _process_lock():
        data = _read(LOCK_DATEI, {"locks": []})
        changed = False
        for row in data.get("locks", []):
            if str(row.get("id")) == str(lock_id) and not row.get("released_at"):
                row.update(released_at=_iso(), released_by=str(actor)[:80]); changed = True
        if changed:
            _write(LOCK_DATEI, data)
        return changed
