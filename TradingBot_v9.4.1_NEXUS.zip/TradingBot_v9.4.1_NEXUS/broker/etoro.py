"""eToro Public-API Adapter (Demo/PAPER und Real/LIVE).

Sicherheitsprinzipien:
- getrennte API-Key-Paare fuer Demo und Real;
- keine automatische Wiederholung von Order-POSTs nach unklarem Transportfehler;
- X-Request-Id wird fuer Idempotenz/Lookup gespeichert;
- standardmaessig nur REAL-Settlement mit Hebel 1; CFD muss explizit erlaubt sein;
- vor neuen Trades offizielle What-if-Kosten und Eligibility verwenden;
- Stop-Loss/Take-Profit werden beim Oeffnen an eToro uebergeben.
"""
from __future__ import annotations

import logging
import hashlib
import math
import threading
import time
import uuid
from collections import deque
from datetime import date, datetime, timezone
from pathlib import Path
from typing import Any

import pandas as pd
import requests

import config
from safe_persistence import best_effort_json
from instrument_identity import canonical_key, etoro_market_symbol_matches, market_asset_type, normalize_user_symbol
from .base import (
    BrokerBase, BrokerFehler, VerbindungVerloren, OrderStatusUnklar, AuthentifizierungsFehler,
    NichtVerbunden, NichtUnterstuetzt, Position, Fill, OrderErgebnis,
)
from .history_safety import completed_bars_only, retry_call

logger = logging.getLogger(__name__)


def _api_value(row: dict, *names, default=None):
    """Ersten vorhandenen eToro-Wert lesen, ohne Gross-/Kleinschreibung zu raten.

    Die offiziellen Demo-Beispiele verwenden ``positionId``/``instrumentId``,
    reale Portfolioantworten teilweise ``positionID``/``instrumentID``. Die
    Normalisierung geschieht einmal am Adapterrand; der Kern sieht danach nur
    noch die kanonischen camelCase-Felder.
    """
    if not isinstance(row, dict):
        return default
    for name in names:
        if name in row and row[name] not in (None, ""):
            return row[name]
    return default


def _normalisiere_positionszeile(row: dict) -> dict:
    out = dict(row or {})
    mappings = {
        "positionId": ("positionId", "positionID", "PositionId", "PositionID"),
        "instrumentId": ("instrumentId", "instrumentID", "InstrumentId", "InstrumentID"),
        "orderId": ("orderId", "orderID", "OrderId", "OrderID"),
        "cid": ("cid", "CID", "Cid"),
        "mirrorId": ("mirrorId", "mirrorID", "MirrorId", "MirrorID"),
        "parentPositionId": (
            "parentPositionId", "parentPositionID", "ParentPositionId", "ParentPositionID"),
    }
    for target, names in mappings.items():
        value = _api_value(out, *names)
        if value not in (None, ""):
            out[target] = value
    return out


class _RollingLimiter:
    """Gleitender eToro-Limiter mit optional gleichmäßiger Taktung.

    Ein reines Rolling Window erlaubt zunächst einen großen Burst und zwingt
    den Scanner danach fast eine Minute zum Warten. Die Mindestdistanz verteilt
    die Aufrufe stattdessen über das Fenster und lässt Reserve für den
    Reconciliation-Worker.
    """

    def __init__(self, maximum: int, seconds: float = 60.0,
                 min_interval: float = 0.0):
        self.maximum = max(1, int(maximum))
        self.seconds = max(1.0, float(seconds))
        self.min_interval = max(0.0, float(min_interval))
        self._events = deque()
        self._lock = threading.Lock()
        self._last_acquired = 0.0

    def acquire(self, timeout: float = 30.0) -> bool:
        deadline = time.monotonic() + max(0.0, float(timeout))
        while True:
            with self._lock:
                now = time.monotonic()
                while self._events and now - self._events[0] >= self.seconds:
                    self._events.popleft()
                window_wait = (
                    self.seconds - (now - self._events[0])
                    if len(self._events) >= self.maximum else 0.0
                )
                spacing_wait = max(
                    0.0, self.min_interval - (now - self._last_acquired)
                ) if self._last_acquired else 0.0
                wait = max(window_wait, spacing_wait)
                if wait <= 0.0:
                    self._events.append(now)
                    self._last_acquired = now
                    return True
            if time.monotonic() + wait > deadline:
                return False
            time.sleep(min(0.25, max(0.01, wait)))


class EtoroBroker(BrokerBase):
    name = "etoro"

    def __init__(self, *, paper: bool | None = None, api_key: str | None = None,
                 user_key: str | None = None, session: requests.Session | None = None):
        self.paper = bool(config.PAPER_TRADING if paper is None else paper)
        if self.paper:
            self.api_key = (api_key or getattr(config, "ETORO_DEMO_API_KEY", "")).strip()
            self.user_key = (user_key or getattr(config, "ETORO_DEMO_USER_KEY", "")).strip()
        else:
            self.api_key = (api_key or getattr(config, "ETORO_LIVE_API_KEY", "")).strip()
            self.user_key = (user_key or getattr(config, "ETORO_LIVE_USER_KEY", "")).strip()
        fingerprint_source = f"etoro|{'demo' if self.paper else 'live'}|{self.user_key}"
        self._account_fingerprint = (
            hashlib.sha256(fingerprint_source.encode("utf-8")).hexdigest()[:24]
            if self.user_key else "")
        self.base_url = str(getattr(config, "ETORO_API_BASE_URL", "https://public-api.etoro.com")).rstrip("/")
        self.session = session or requests.Session()
        self._connected = False
        self._last_contact: str | None = None
        self._last_health = 0.0
        self._instrument_cache: dict[str, dict] = {}
        self._instrument_candidates: dict[str, list[dict]] = {}
        self._instrument_by_id: dict[int, dict] = {}
        self._eligibility: dict[str, dict] = {}
        self._cost_cache: dict[tuple, tuple[float, dict]] = {}
        self._fill_queue: list[Fill] = []
        self._seen_history: set[str] = set()
        self._last_history_poll = 0.0
        self._portfolio_cache: tuple[float, dict] | None = None
        self._current_position_ids: set[str] = set()
        self._current_position_map: dict[str, set[str]] = {}
        self._current_position_ids_known = False
        self._position_schema_logged = False
        self._history_cache: dict[str, tuple[float, list[dict]]] = {}
        self._all_instruments_loaded = False
        self._http_lock = threading.RLock()
        # Unter den offiziellen 60/Minute fuer Standardabfragen bzw.
        # 20/Minute fuer Ausfuehrungsaufrufe bleiben. Eligibility besitzt
        # ebenfalls ein eigenes 20/Minute-Fenster.
        self._limit_read = _RollingLimiter(54, min_interval=1.15)
        self._limit_execution = _RollingLimiter(18, min_interval=3.4)
        self._limit_eligibility = _RollingLimiter(18, min_interval=3.4)
        self._reconcile_stop = threading.Event()
        self._reconcile_thread = None
        self._private_stream = None
        # Kurzer Cache fuer Rates: Marktstatus und Marktqualitaet duerfen nicht
        # denselben eToro-Endpunkt direkt hintereinander doppelt belasten.
        self._rate_cache: dict[int, tuple[float, dict]] = {}

    def account_fingerprint(self) -> str:
        """Nicht umkehrbare Kontokennung; Zugangsdaten werden nie persistiert."""
        return str(self._account_fingerprint or "")

    # --------------------------- HTTP ---------------------------------
    def _headers(self, request_id: str | None = None, json_body=False) -> dict:
        h = {
            "x-api-key": self.api_key,
            "x-user-key": self.user_key,
            "x-request-id": request_id or str(uuid.uuid4()),
            "Accept": "application/json",
            "User-Agent": "TradingBot/6.0",
        }
        if json_body:
            h["Content-Type"] = "application/json"
        return h

    def _mark_contact(self):
        self._last_contact = datetime.now(timezone.utc).isoformat()
        self._connected = True

    def _request(self, method: str, path: str, *, params=None, payload=None,
                 request_id: str | None = None, safe_retry: bool = True) -> Any:
        if not self.api_key or not self.user_key:
            env = "DEMO" if self.paper else "LIVE"
            raise AuthentifizierungsFehler(f"eToro {env}: Public API Key/User Key fehlen")
        url = self.base_url + path
        if "/trading/execution/" in path:
            limiter = self._limit_execution
        elif path.endswith("/eligibility"):
            limiter = self._limit_eligibility
        else:
            limiter = self._limit_read
        if not limiter.acquire(timeout=float(getattr(config, "ETORO_RATE_LIMIT_WAIT_SECONDS", 30.0))):
            raise BrokerFehler(f"eToro Ratenfenster fuer {path} nicht rechtzeitig frei")
        attempts = 3 if safe_retry else 1
        last_exc = None
        for attempt in range(attempts):
            try:
                with self._http_lock:
                    resp = self.session.request(
                        method.upper(), url, params=params, json=payload,
                        headers=self._headers(request_id, payload is not None),
                        timeout=(5, float(getattr(config, "ETORO_REQUEST_TIMEOUT_SECONDS", 25))),
                    )
            except requests.RequestException as exc:
                last_exc = exc
                if attempt + 1 < attempts:
                    time.sleep(min(2.0, 0.25 * (2 ** attempt)))
                    continue
                self._connected = False
                raise VerbindungVerloren(f"eToro Netzwerkfehler: {exc}") from exc

            if resp.status_code in (401, 403):
                self._connected = False
                detail=resp.text[:350].replace("\n"," ")
                raise AuthentifizierungsFehler(
                    f"eToro Authentifizierung/Berechtigung fehlgeschlagen (HTTP {resp.status_code}). "
                    f"Pruefe x-api-key, x-user-key, Demo/Real-Umgebung und Read/Write-Scope. {detail}"
                )
            if resp.status_code == 429:
                retry_after = 1.0
                try:
                    retry_after = max(0.5, float(resp.headers.get("Retry-After", "1") or 1))
                except Exception:
                    __import__("logging").getLogger(__name__).debug("Best-effort-Ausnahme unterdrueckt", exc_info=True)
                if attempt + 1 < attempts:
                    time.sleep(min(10.0, retry_after))
                    continue
                raise BrokerFehler(f"eToro Rate-Limit (HTTP 429; retry_after={retry_after:g}s)")
            if resp.status_code >= 500:
                if attempt + 1 < attempts:
                    time.sleep(min(2.0, 0.5 * (2 ** attempt)))
                    continue
                self._connected = False
                raise VerbindungVerloren(f"eToro Serverfehler HTTP {resp.status_code}: {resp.text[:200]}")
            if not resp.ok:
                detail = resp.text[:500]
                try:
                    j = resp.json()
                    detail = j.get("detail") or j.get("title") or detail
                except Exception:
                    __import__("logging").getLogger(__name__).debug("Best-effort-Ausnahme unterdrueckt", exc_info=True)
                raise BrokerFehler(f"eToro HTTP {resp.status_code}: {detail}")
            self._mark_contact()
            if not resp.content:
                return {}
            try:
                return resp.json()
            except ValueError as exc:
                raise BrokerFehler(f"eToro lieferte ungueltiges JSON fuer {path}") from exc
        if last_exc:
            raise VerbindungVerloren(str(last_exc))
        raise BrokerFehler("eToro Anfrage fehlgeschlagen")

    def _path(self, demo: str, real: str) -> str:
        return demo if self.paper else real

    # --------------------------- Verbindung ----------------------------
    def _get_pnl_health(self) -> Any:
        """Environment-specific authenticated liveness probe.

        This endpoint is intentionally used for the heartbeat because a
        successful answer proves not just DNS/HTTPS, but also the selected
        DEMO/REAL account access. No order is created.
        """
        path = self._path(
            "/api/v1/trading/info/demo/pnl",
            "/api/v1/trading/info/real/pnl",
        )
        return self._request("GET", path)

    def diagnose_credentials(self) -> dict:
        """Multi-stage, read-only eToro connection diagnosis.

        Stages:
        1) authenticated identity (/api/v1/me),
        2) selected DEMO/REAL CID presence and scopes (diagnostic),
        3) selected environment P&L endpoint (definitive liveness),
        4) aggregate portfolio (account values used by the bot).

        No order is ever sent by this method.
        """
        env = "DEMO" if self.paper else "LIVE"
        steps=[]
        profile=self._request("GET","/api/v1/me")
        steps.append({"step":"identity","ok":True,"detail":"/api/v1/me beantwortet"})
        scopes=[str(x) for x in (profile.get("scopes") or profile.get("scopeNames") or [])]
        cid_key="demoCid" if self.paper else "realCid"
        cid=profile.get(cid_key)
        if cid in (None, "", 0, "0"):
            raise AuthentifizierungsFehler(
                f"eToro {env}: /api/v1/me liefert keine {cid_key}. "
                "Der User-Key passt vermutlich nicht zur gewaehlten Demo/Live-Umgebung."
            )
        steps.append({"step":"environment","ok":True,"detail":f"{cid_key} vorhanden"})

        env_token = "demo" if self.paper else "real"
        scope_read_ok = (not scopes) or any(
            (env_token in sc.lower()) and ("read" in sc.lower()) for sc in scopes
        )
        steps.append({
            "step":"scope", "ok":bool(scope_read_ok),
            "detail":("Read-Scope plausibel" if scope_read_ok else
                      f"Kein eindeutiger {env}-Read-Scope in Scope-Liste; Endpunkt-Test entscheidet."),
        })

        pnl=self._get_pnl_health()
        steps.append({"step":"pnl","ok":True,"detail":"Environment-P&L Endpunkt beantwortet"})
        agg=self._get_aggregate(force=True)
        steps.append({"step":"portfolio","ok":True,"detail":"Aggregate-Portfolio beantwortet"})
        totals=agg.get("accountTotals") or {} if isinstance(agg,dict) else {}
        return {
            "username":profile.get("username"), "demoCid":profile.get("demoCid"),
            "realCid":profile.get("realCid"), "selectedCid":cid,
            "scopes":scopes, "scope_read_ok":scope_read_ok,
            "scope_warning":("" if scope_read_ok else
                f"Scope-Liste enthaelt keinen eindeutigen {env}-Read-Scope; "
                "P&L und Portfolio waren dennoch erfolgreich."),
            "currency":(agg.get("accountCurrency") if isinstance(agg,dict) else None) or "USD",
            "equity":_float(totals.get("accountTotalValue")),
            "cash":_float(totals.get("accountAvailableCash")),
            "environment":env, "steps":steps, "pnl_available":pnl is not None,
            "last_contact":self._last_contact,
        }

    def connect(self) -> bool:
        if not self.api_key or not self.user_key:
            env = "DEMO" if self.paper else "LIVE"
            raise AuthentifizierungsFehler(
                f"eToro {env}-Keys fehlen. eToro-Setup ausfuehren; Demo und Live benoetigen getrennte Keys."
            )
        # Erst Identitaet/Scope, dann environment-spezifisches Portfolio pruefen.
        self.diagnose_credentials()
        self._connected = True
        self._start_reconciliation_worker()
        self._start_private_stream_best_effort()
        logger.info("eToro verbunden: %s", "DEMO/PAPER" if self.paper else "LIVE")
        return True

    def _start_reconciliation_worker(self) -> None:
        """Klaert angenommene Orders weiter, unabhaengig vom Scannerzyklus."""
        if self._reconcile_thread is not None and self._reconcile_thread.is_alive():
            return
        self._reconcile_stop.clear()

        def _run():
            interval = max(2.0, float(getattr(
                config, "ETORO_RECONCILIATION_INTERVAL_SECONDS", 5.0)))
            while not self._reconcile_stop.wait(interval):
                if not self._connected:
                    continue
                try:
                    import etoro_reconciliation
                    etoro_reconciliation.background_tick(
                        self, paper=bool(self.paper),
                        profile=str(getattr(config, "ACTIVE_PROFILE", "") or ""))
                except Exception as exc:
                    # Die persistente Domaenensperre bleibt bestehen. Der Worker
                    # darf den Hauptscanner wegen eines einzelnen GETs nie beenden.
                    logger.info("eToro-Reconciliation wartet weiter: %s", exc)

        self._reconcile_thread = threading.Thread(
            target=_run, name="etoro-reconciliation", daemon=True)
        self._reconcile_thread.start()

    def _start_private_stream_best_effort(self) -> None:
        """Private Pushs beschleunigen; REST bleibt die autoritative Wahrheit."""
        if not bool(getattr(config, "ETORO_PRIVATE_WS_ENABLED", True)):
            return
        try:
            from .etoro_stream import EtoroPrivateStream
            import etoro_reconciliation
            self._private_stream = EtoroPrivateStream(
                self.api_key, self.user_key,
                on_private_event=etoro_reconciliation.apply_stream_event,
                url=str(getattr(config, "ETORO_PRIVATE_WS_URL",
                                "wss://ws.etoro.com/ws")))
            if not self._private_stream.start():
                logger.warning("eToro-Privatstream nicht gestartet; REST-Abgleich aktiv.")
        except Exception as exc:
            self._private_stream = None
            logger.warning("eToro-Privatstream nicht verfuegbar (%s); REST-Abgleich aktiv.",
                           type(exc).__name__)

    def disconnect(self) -> None:
        self._connected = False
        self._reconcile_stop.set()
        if self._private_stream is not None:
            try:
                self._private_stream.stop()
            except Exception:
                logger.debug("eToro-Privatstream-Stopp fehlgeschlagen", exc_info=True)
        try:
            self.session.close()
        except Exception:
            __import__("logging").getLogger(__name__).debug("Best-effort-Ausnahme unterdrueckt", exc_info=True)

    def is_connected(self) -> bool:
        return bool(self._connected)

    def health_check(self, force: bool = False) -> bool:
        """Authenticated broker liveness, not merely a local flag."""
        now = time.monotonic()
        ttl = float(getattr(config, "BROKER_HEALTHCHECK_SECONDS", 30))
        if not force and self._connected and now - self._last_health < ttl:
            return True
        self._get_pnl_health()
        self._last_health = now
        return True

    def last_contact(self) -> str | None:
        return self._last_contact

    def stream_status(self) -> dict:
        if self._private_stream is None:
            return {"running": False, "connected": False,
                    "authenticated": False, "subscribed": False,
                    "last_error": "nicht gestartet"}
        return self._private_stream.status().as_dict()

    def ist_paper(self) -> bool:
        return self.paper

    # --------------------------- Konto ---------------------------------
    def _get_aggregate(self, force=False) -> dict:
        now = time.monotonic()
        if not force and self._portfolio_cache:
            ts, data = self._portfolio_cache
            if now - ts <= float(getattr(config, "BROKER_ACCOUNT_CACHE_SECONDS", 10)):
                return data
        path = self._path(
            "/api/v1/trading/info/demo/aggregate-portfolio",
            "/api/v1/trading/info/aggregate-portfolio",
        )
        data = self._request("GET", path)
        self._portfolio_cache = (now, data)
        return data

    def kontowert(self) -> float:
        d = self._get_aggregate()
        return _float((d.get("accountTotals") or {}).get("accountTotalValue"))

    def verfuegbares_cash(self) -> float | None:
        """Frei verwendbares Cash ABZUEGLICH schwebender eigener Kaeufe (v9.3).

        Bis 9.2 wurde fuer jeden Kandidaten der rohe Brokerstand gelesen. Ist
        Kandidat A angenommen, aber die Belastung bei eToro noch nicht
        verbucht, sah Kandidat B dasselbe Geld ein zweites Mal. Die
        Domaenensperre (assert_domain_available) faengt das heute ab -- aber
        erst beim Absenden, nicht schon bei der Planung. Hier wird das Geld
        bereits vor der Entscheidung zurueckgestellt.
        """
        d = self._get_aggregate()
        roh = _float((d.get("accountTotals") or {}).get("accountAvailableCash"))
        return max(0.0, roh - self.reservierte_mittel())

    def reservierte_mittel(self) -> float:
        """Kapital, das durch noch ungeklaerte eigene Kaeufe gebunden ist."""
        try:
            import etoro_reconciliation
            offen = etoro_reconciliation.offene_kaufabsichten()
        except Exception:
            logger.debug("Reservierungen nicht lesbar", exc_info=True)
            return 0.0
        puffer = 1.0 + max(0.0, float(getattr(
            config, "RESERVIERUNG_PUFFER_PCT", 0.01)))
        summe = 0.0
        for satz in offen:
            if bool(satz.get("paper")) != bool(self.paper):
                continue
            summe += abs(float(satz.get("reserved_cash") or 0.0)) * puffer
        return summe

    def kontowaehrung(self) -> str:
        try:
            return str(self._get_aggregate().get("accountCurrency") or "USD").upper()
        except Exception:
            return "USD"

    # --------------------------- Instrumente ---------------------------
    @staticmethod
    def _symbol(inst) -> str:
        kind = str(getattr(inst, "asset_type", "stock") or "stock").lower()
        return normalize_user_symbol(getattr(inst, "name", inst), kind)

    @staticmethod
    def _cache_key(inst) -> str:
        return canonical_key(getattr(inst, "name", inst), getattr(inst, "asset_type", "stock"))

    @staticmethod
    def _normalize_market_symbol(value: str) -> str:
        raw = str(value or "").upper().strip()
        for suffix in ("/USD", "-USD", ".USD", ".US"):
            if raw.endswith(suffix):
                raw = raw[:-len(suffix)]
                break
        return raw

    def _load_all_instruments(self, force: bool = False) -> None:
        """Lädt eToros Instrument-Stammdaten in EINEM Market-Data-Call.

        Das vermeidet beim Start 200+ Search-Aufrufe und hält die gemeinsame
        120/min Market-Data-Quote frei für Kurse/Historie.
        """
        if self._all_instruments_loaded and not force:
            return
        data = self._request("GET", "/api/v1/market-data/instruments")
        rows = data.get("instrumentDisplayDatas") or []
        for item in rows:
            try:
                iid = int(item.get("instrumentID") or item.get("instrumentId"))
            except Exception:
                continue
            symbol_full = str(item.get("symbolFull") or item.get("internalSymbolFull") or "").upper().strip()
            if not symbol_full:
                continue
            norm = self._normalize_market_symbol(symbol_full)
            normalized = dict(item)
            normalized["instrumentId"] = iid
            normalized["symbol"] = symbol_full
            normalized["symbolFull"] = symbol_full
            normalized["_detected_asset_type"] = market_asset_type(symbol_full, metadata=normalized)
            self._instrument_candidates.setdefault(norm, []).append(normalized)
            self._instrument_by_id[iid] = normalized
        self._all_instruments_loaded = True

    def _resolve(self, inst) -> dict:
        sym = self._symbol(inst)
        kind = str(getattr(inst, "asset_type", "") or "").lower()
        if kind not in ("stock", "crypto"):
            raise NichtUnterstuetzt(f"eToro Asset-Typ nicht unterstuetzt: {kind or '?'}")
        key = self._cache_key(inst)
        if key in self._instrument_cache:
            return self._instrument_cache[key]
        try:
            self._load_all_instruments()
        except BrokerFehler:
            pass

        candidates = []
        for row in self._instrument_candidates.get(sym, []):
            full = str(row.get("symbolFull") or row.get("symbol") or "")
            detected = row.get("_detected_asset_type")
            if etoro_market_symbol_matches(sym, kind, full) and (detected in (None, kind)):
                candidates.append(row)
        if len(candidates) == 1:
            exact = candidates[0]
        elif len(candidates) > 1:
            typed = [x for x in candidates if x.get("_detected_asset_type") == kind]
            if len(typed) == 1:
                exact = typed[0]
            else:
                raise NichtUnterstuetzt(f"eToro Instrument mehrdeutig: {kind}:{sym}")
        else:
            # Search ist nur ein Fallback; auch dessen Antwort wird asset-sicher gefiltert.
            data = self._request("GET", "/api/v1/market-data/search", params={"internalSymbolFull": sym})
            items = data.get("items", data if isinstance(data, list) else []) or []
            filtered=[]
            for item in items:
                full=str(item.get("internalSymbolFull") or item.get("symbolFull") or item.get("symbol") or "").upper().strip()
                detected=market_asset_type(full, metadata=item)
                if etoro_market_symbol_matches(sym, kind, full) and detected in (None, kind):
                    filtered.append((item,full,detected))
            if len(filtered) != 1:
                raise NichtUnterstuetzt(f"eToro Instrument nicht eindeutig gefunden: {kind}:{sym}")
            item,full,detected=filtered[0]
            exact=dict(item); exact["symbolFull"]=full; exact["symbol"]=full; exact["_detected_asset_type"]=detected
            exact["instrumentId"] = int(exact.get("instrumentId") or exact.get("instrumentID"))
            self._instrument_by_id[exact["instrumentId"]]=exact

        exact = dict(exact)
        exact["_bot_asset_type"] = kind
        exact["_bot_symbol"] = sym
        exact["symbol"] = str(exact.get("symbolFull") or exact.get("symbol") or sym).upper()
        self._instrument_cache[key] = exact
        self._instrument_by_id[int(exact["instrumentId"])] = exact
        return exact

    def _eligibility_for(self, inst) -> dict:
        sym = self._symbol(inst)
        key = self._cache_key(inst)
        if key in self._eligibility:
            return self._eligibility[key]
        resolved = self._resolve(inst)
        path = self._path(
            "/api/v2/trading/info/demo/eligibility",
            "/api/v2/trading/info/eligibility",
        )
        data = self._request("POST", path, payload={
            "instrumentIds": [resolved["instrumentId"]], "currency": "USD"
        })
        rows = data.get("eligibilities") or []
        if not rows:
            raise NichtUnterstuetzt(f"eToro: keine Trading-Eligibility fuer {sym}")
        row = rows[0]
        self._eligibility[key] = row
        return row

    def _settlement(self, inst) -> str:
        row = self._eligibility_for(inst)
        if not bool(row.get("allowOpenPosition", False)):
            raise NichtUnterstuetzt(f"eToro: {self._symbol(inst)} darf fuer dieses Konto nicht eroeffnet werden")
        configs = row.get("leverageConfigs") or []
        real = None; cfd = None
        for c in configs:
            st = str(c.get("settlementType") or "").lower()
            direction = str(c.get("direction") or "").lower()
            vals = [int(v) for v in (c.get("leverageValues") or []) if str(v).isdigit()]
            if direction not in ("long", "buy", "") or 1 not in vals:
                continue
            if st in ("real", "underlying", "asset"):
                real = str(c.get("settlementType"))
            elif st == "cfd":
                cfd = str(c.get("settlementType"))
        if real:
            return real
        if cfd and bool(getattr(config, "ETORO_ALLOW_CFD", False)):
            return cfd
        raise NichtUnterstuetzt(
            f"eToro: {self._symbol(inst)} ist fuer dieses Konto nicht als REAL/Hebel 1 freigegeben"
            + ("; CFD waere verfuegbar, ist aber aus Sicherheitsgruenden deaktiviert" if cfd else "")
        )

    def _validate_protection(self, inst, settlement: str, reference: float, stop: float, take_profit: float) -> None:
        """Prueft SL/TP gegen die konto-/instrumentbezogenen eToro-Grenzen.

        Wir veraendern die Strategiepreise NICHT stillschweigend. Passt ein
        geplanter Schutz nicht zu eToros aktuell gemeldeter Eligibility, wird
        der Kauf fail-closed ausgelassen.
        """
        ref = float(reference or 0); sl = float(stop or 0); tp = float(take_profit or 0)
        if ref <= 0 or sl <= 0 or tp <= 0 or not (sl < ref < tp):
            raise BrokerFehler("eToro: Stop/Take-Profit oder Referenzpreis ungueltig")
        row = self._eligibility_for(inst)
        chosen = None
        for c in row.get("leverageConfigs") or []:
            st = str(c.get("settlementType") or "").lower()
            direction = str(c.get("direction") or "").lower()
            vals = []
            for v in c.get("leverageValues") or []:
                try: vals.append(int(v))
                except Exception: __import__("logging").getLogger(__name__).debug("Best-effort-Ausnahme unterdrueckt", exc_info=True)
            if st == str(settlement).lower() and direction in ("long", "buy", "") and 1 in vals:
                chosen = c; break
        if not chosen:
            raise NichtUnterstuetzt(f"eToro: keine passende Eligibility fuer {self._symbol(inst)} / {settlement} / Hebel 1")
        if not bool(chosen.get("allowStopLossTakeProfit", True)):
            raise NichtUnterstuetzt(f"eToro: Stop-Loss/Take-Profit fuer {self._symbol(inst)} nicht erlaubt")
        sl_pct = (ref - sl) / ref * 100.0
        tp_pct = (tp - ref) / ref * 100.0
        min_sl = _float(chosen.get("minStopLossPercentage"), -1)
        max_sl = _float(chosen.get("maxStopLossPercentage"), -1)
        min_tp = _float(chosen.get("minTakeProfitPercentage"), -1)
        max_tp = _float(chosen.get("maxTakeProfitPercentage"), -1)
        if min_sl >= 0 and sl_pct + 1e-9 < min_sl:
            raise NichtUnterstuetzt(f"eToro: geplanter Stop {sl_pct:.2f}% liegt unter Minimum {min_sl:.2f}%")
        if max_sl >= 0 and sl_pct - 1e-9 > max_sl:
            raise NichtUnterstuetzt(f"eToro: geplanter Stop {sl_pct:.2f}% liegt ueber Maximum {max_sl:.2f}%")
        if min_tp >= 0 and tp_pct + 1e-9 < min_tp:
            raise NichtUnterstuetzt(f"eToro: geplantes Take-Profit {tp_pct:.2f}% liegt unter Minimum {min_tp:.2f}%")
        if max_tp >= 0 and tp_pct - 1e-9 > max_tp:
            raise NichtUnterstuetzt(f"eToro: geplantes Take-Profit {tp_pct:.2f}% liegt ueber Maximum {max_tp:.2f}%")

    def instrument_metadata(self, instrument) -> dict:
        """Liefert nur Stammdaten fuer deterministische Universums-Pruefungen.

        Keine Order, kein Settlement-Wechsel und keine KI-Seitenwirkung. Die
        asset-sichere _resolve()-Logik bleibt die einzige Symbolaufloesung.
        """
        row = self._resolve(instrument)
        display = str(
            row.get("instrumentDisplayName") or row.get("displayName") or
            row.get("instrumentName") or row.get("name") or ""
        ).strip()
        return {
            "instrument_id": int(row.get("instrumentId")),
            "symbol_full": str(row.get("symbolFull") or row.get("symbol") or "").upper(),
            "asset_type": str(row.get("_detected_asset_type") or row.get("_bot_asset_type") or ""),
            "instrument_type": str(row.get("instrumentType") or row.get("assetType") or ""),
            "display_name": display,
        }

    def instrument_handelbar(self, instrument) -> tuple[bool, str]:
        if getattr(instrument, "asset_type", "") not in ("stock", "crypto"):
            return False, "eToro-Adapter handelt in diesem Bot nur Aktien und Krypto"
        # EU-Symbole koennen an mehreren Boersen mehrdeutig sein. Bis wir eine
        # Exchange-ID im Watchlistmodell fuehren, vermeiden wir falsche Treffer.
        if getattr(instrument, "asset_type", "") == "stock" and str(getattr(instrument, "currency", "USD")).upper() != "USD":
            return False, "EU-Aktie bei eToro noch nicht eindeutig per Exchange gemappt"
        try:
            self._resolve(instrument)
            self._settlement(instrument)
            return True, ""
        except BrokerFehler as exc:
            return False, str(exc)

    def qualifiziere(self, instrumente: list) -> tuple[list, list]:
        self._load_all_instruments()
        candidates, failed = [], []
        for inst in instrumente:
            if getattr(inst, "asset_type", "") not in ("stock", "crypto"):
                failed.append((inst.name, "eToro-Adapter handelt nur Aktien und Krypto")); continue
            if getattr(inst, "asset_type", "") == "stock" and str(getattr(inst, "currency", "USD")).upper() != "USD":
                failed.append((inst.name, "EU-Aktie noch nicht eindeutig per Exchange gemappt")); continue
            try:
                candidates.append((inst, self._resolve(inst)))
            except BrokerFehler as exc:
                failed.append((inst.name, str(exc)))

        # eToro erlaubt bis zu 100 Instrument-IDs je Eligibility-Abfrage.
        path = self._path("/api/v2/trading/info/demo/eligibility", "/api/v2/trading/info/eligibility")
        for i in range(0, len(candidates), 100):
            batch = candidates[i:i+100]
            ids = [r["instrumentId"] for _, r in batch]
            if not ids:
                continue
            data = self._request("POST", path, payload={"instrumentIds": ids, "currency": "USD"})
            rows = data.get("eligibilities") or []
            by_id = {}
            for row in rows:
                try:
                    by_id[int(row.get("instrumentId") or row.get("instrumentID"))] = row
                except Exception:
                    __import__("logging").getLogger(__name__).debug("Best-effort-Ausnahme unterdrueckt", exc_info=True)
            for inst, r in batch:
                row = by_id.get(r["instrumentId"])
                if row:
                    self._eligibility[self._cache_key(inst)] = row

        ok = []
        for inst, _ in candidates:
            try:
                self._settlement(inst)
                ok.append(inst)
            except BrokerFehler as exc:
                failed.append((inst.name, str(exc)))
        return ok, failed

    # --------------------------- Marktdaten ----------------------------
    def _rate_row(self, instrument, *, force: bool = False) -> dict | None:
        r = self._resolve(instrument)
        return self._rate_row_by_id(int(r["instrumentId"]), force=force)

    def _rate_row_by_id(self, iid: int, *, force: bool = False) -> dict | None:
        """Kurszeile direkt ueber die instrumentId (v9.3).

        Der Positionssnapshot kennt die instrumentId bereits; ein zweiter
        Umweg ueber _resolve() waere unnoetig und koennte fehlschlagen, wenn
        das Instrument nicht im aktuellen Universum steht.
        """
        iid = int(iid)
        ttl = max(0.0, float(getattr(config, "ETORO_MARKET_DATA_CACHE_SECONDS", 3)))
        cached = self._rate_cache.get(iid)
        if not force and cached and time.time() - cached[0] <= ttl:
            return dict(cached[1])
        data = self._request("GET", "/api/v1/market-data/instruments/rates",
                             params={"instrumentIds": str(iid)})
        rows = data.get("rates") or []
        for row in rows:
            try:
                row_iid = int(row.get("instrumentID") or row.get("instrumentId") or -1)
            except Exception:
                row_iid = -1
            if row_iid == iid:
                self._rate_cache[iid] = (time.time(), dict(row))
                return dict(row)
        return None

    @classmethod
    def _rate_age_seconds(cls, row: dict | None):
        """Alter der Kurszeile in Sekunden, oder ``None`` wenn unbekannt."""
        stamp = cls._rate_timestamp(row)
        if not stamp:
            return None
        try:
            gemessen = datetime.fromisoformat(str(stamp).replace("Z", "+00:00"))
        except (TypeError, ValueError):
            return None
        if gemessen.tzinfo is None:
            gemessen = gemessen.replace(tzinfo=timezone.utc)
        return max(0.0, (datetime.now(timezone.utc) - gemessen).total_seconds())

    @staticmethod
    def _rate_timestamp(row: dict | None):
        if not isinstance(row, dict):
            return None
        return (row.get("date") or row.get("timestamp") or row.get("updateTime")
                or row.get("lastUpdated") or row.get("lastUpdate"))

    @staticmethod
    def _quote_age_seconds(value) -> float | None:
        if value in (None, ""):
            return None
        try:
            if isinstance(value, (int, float)):
                n=float(value)
                # Millisekunden-Epoch erkennen.
                if n > 10_000_000_000:
                    n /= 1000.0
                dt=datetime.fromtimestamp(n, tz=timezone.utc)
            else:
                txt=str(value).strip().replace("Z", "+00:00")
                dt=datetime.fromisoformat(txt)
                if dt.tzinfo is None:
                    dt=dt.replace(tzinfo=timezone.utc)
                dt=dt.astimezone(timezone.utc)
            return max(0.0, (datetime.now(timezone.utc)-dt).total_seconds())
        except Exception:
            return None

    @staticmethod
    def _explicit_market_flag(row: dict | None) -> tuple[bool | None, str]:
        """Use an explicit flag/status only if eToro actually returned one.

        The public documentation does not guarantee a universal isOpen field,
        therefore unknown/numeric values are never guessed.
        """
        if not isinstance(row, dict):
            return None, ""
        for key in ("isMarketOpen", "marketOpen", "isOpen", "isTradable", "tradable"):
            if key in row and isinstance(row.get(key), bool):
                return bool(row.get(key)), f"{key}={row.get(key)}"
        for key in ("marketStatus", "tradingStatus", "status", "state"):
            if key not in row:
                continue
            value=str(row.get(key) or "").strip().upper().replace(" ", "_")
            if value in {"OPEN", "OPENED", "TRADING", "TRADEABLE", "TRADABLE", "ACTIVE"}:
                return True, f"{key}={value}"
            if value in {"CLOSED", "CLOSE", "HALTED", "HALT", "SUSPENDED", "INACTIVE", "DISABLED"}:
                return False, f"{key}={value}"
        return None, ""

    def market_session_status(self, instrument) -> dict:
        """Read-only broker probe used by market_session.py.

        It deliberately does not pretend that a fresh quote equals REGULAR
        market hours. It only reports broker-side evidence; the exchange clock
        is evaluated separately by market_session.py.
        """
        row=self._rate_row(instrument)
        if not row:
            return {"broker_tradable": None, "quote_age_seconds": None,
                    "source": "eToro Public API rates", "detail": "kein Rate-Datensatz"}
        flag, raw=self._explicit_market_flag(row)
        ts=self._rate_timestamp(row)
        age=self._quote_age_seconds(ts)
        detail=[]
        if raw:
            detail.append(raw)
        if age is not None:
            detail.append(f"Quote-Alter {age:.0f}s")
        else:
            detail.append("Quote-Alter unbekannt")
        return {"broker_tradable": flag, "quote_age_seconds": age,
                "timestamp": ts, "source": "eToro Public API rates",
                "detail": "; ".join(detail)}

    def latest_bid_ask(self, instrument):
        row = self._rate_row(instrument)
        if row:
            return {"bid": _float(row.get("bid")), "ask": _float(row.get("ask")),
                    "last": _float(row.get("lastExecution")), "timestamp": self._rate_timestamp(row),
                    "source": "eToro Public API rates"}
        return None

    def historie(self, instrument, dauer: str, kerzengroesse: str,
                 nur_handelszeiten: bool = True) -> pd.DataFrame:
        r = self._resolve(instrument)
        interval_map = {
            "1 min": "OneMinute", "5 mins": "FiveMinutes", "5 min": "FiveMinutes",
            "10 mins": "TenMinutes", "15 mins": "FifteenMinutes",
            "30 mins": "ThirtyMinutes", "1 hour": "OneHour", "4 hours": "FourHours",
            "1 day": "OneDay", "1 week": "OneWeek",
        }
        interval = interval_map.get(str(kerzengroesse).strip().lower(), "OneHour")
        # Core braucht fuer Indikatoren typischerweise deutlich <1000 Bars.
        digits = "".join(ch for ch in str(dauer) if ch.isdigit())
        n = int(digits or 30)
        count = min(1000, max(80, n * (24 if "d" in str(dauer).lower() else 1)))

        def fetch():
            data = self._request(
                "GET",
                f"/api/v1/market-data/instruments/{r['instrumentId']}/history/candles/desc/{interval}/{count}",
            )
            outer = data.get("candles") or []
            rows = []
            for group in outer:
                rows.extend(group.get("candles") or [])
            if not rows:
                return pd.DataFrame(columns=["open","high","low","close","volume"])
            df = pd.DataFrame(rows)
            rename = {"fromDate": "date"}
            df = df.rename(columns=rename)
            df["date"] = pd.to_datetime(df["date"], utc=True, errors="coerce")
            df = df.dropna(subset=["date"]).sort_values("date").set_index("date")
            for col in ("open","high","low","close","volume"):
                df[col] = pd.to_numeric(df.get(col), errors="coerce")
            return completed_bars_only(df[["open","high","low","close","volume"]].dropna(subset=["close"]), kerzengroesse)
        return retry_call(fetch, label=f"eToro Historie {self._symbol(instrument)}")

    # --------------------------- Portfolio -----------------------------
    def _pnl(self, *, force: bool = False) -> dict:
        """Der autoritative Portfolio-Snapshot (v9.3).

        Bis 9.2 holten Positionen, Cash, Orders und der positionId-Abgleich
        diesen Stand JEDER FUER SICH. Innerhalb eines Zyklus konnten sie
        damit unterschiedliche Brokerstaende sehen -- eine Position war im
        einen Aufruf schon da und im naechsten noch nicht. Fuer eine
        Zuordnung ueber exakte positionIds ist das nicht tragbar.

        Der Snapshot bekommt eine Generation (``snapshot_id``) und eine
        kurze Lebensdauer. ``force=True`` erneuert ihn bewusst -- etwa zur
        Orderbestaetigung; alle darauf aufbauenden Zuordnungen benutzen dann
        dieselbe Generation.
        """
        ttl = max(0.0, float(getattr(
            config, "ETORO_PORTFOLIO_SNAPSHOT_SECONDS", 2.0)))
        jetzt = time.monotonic()
        cached = getattr(self, "_pnl_snapshot", None)
        if not force and cached and (jetzt - cached[0]) <= ttl:
            return cached[1]
        path = self._path("/api/v1/trading/info/demo/pnl", "/api/v1/trading/info/real/pnl")
        data = self._request("GET", path)
        if isinstance(data, dict):
            self._pnl_generation = int(getattr(self, "_pnl_generation", 0)) + 1
            data = dict(data)
            data["_snapshot_id"] = (f"etoro:{'demo' if self.paper else 'live'}:"
                                    f"{self._pnl_generation}")
            data["_snapshot_at"] = datetime.now(timezone.utc).isoformat()
        self._pnl_snapshot = (jetzt, data)
        return data

    def portfolio_snapshot_id(self) -> str:
        """Generation des zuletzt gelesenen Portfolio-Snapshots."""
        cached = getattr(self, "_pnl_snapshot", None)
        return str((cached[1] if cached else {}).get("_snapshot_id") or "")

    @staticmethod
    def _all_positions(pnl: dict) -> list[dict]:
        cp = pnl.get("clientPortfolio") or {}
        out = list(cp.get("positions") or [])
        for mirror in cp.get("mirrors") or []:
            out.extend(mirror.get("positions") or [])
        return [_normalisiere_positionszeile(x) for x in out if isinstance(x, dict)]

    @staticmethod
    def _all_orders(pnl: dict) -> list[dict]:
        cp = pnl.get("clientPortfolio") or {}
        out = []
        for key in ("orders", "ordersForOpen", "ordersForClose", "ordersForCloseMultiple"):
            out.extend(cp.get(key) or [])
        for mirror in cp.get("mirrors") or []:
            for key in ("orders", "ordersForOpen", "ordersForClose", "ordersForCloseMultiple"):
                out.extend(mirror.get(key) or [])
        return [_normalisiere_positionszeile(x) for x in out if isinstance(x, dict)]

    @staticmethod
    def _symbolkern(wert) -> str:
        """Vergleichbare Form eines Symbols (SPGI, SPGI.US, spgi)."""
        roh = str(wert or "").strip().upper()
        for suffix in (".US", ".DE", ".L", ".PA", ".MI", ".AS", ".SW"):
            if roh.endswith(suffix):
                return roh[: -len(suffix)]
        return roh

    def _symbol_for_id(self, iid: int) -> str:
        if iid not in self._instrument_by_id:
            try:
                self._load_all_instruments()
            except Exception:
                __import__("logging").getLogger(__name__).debug("Best-effort-Ausnahme unterdrueckt", exc_info=True)
        if iid in self._instrument_by_id:
            row=self._instrument_by_id[iid]
            return str(row.get("symbolFull") or row.get("symbol") or iid).upper()
        return f"ETORO_{iid}"

    def positionen(self) -> list:
        pnl = self._pnl()
        if not self._position_schema_logged:
            cp = pnl.get("clientPortfolio") or {}
            raw_rows = list(cp.get("positions") or [])
            for mirror in cp.get("mirrors") or []:
                raw_rows.extend(mirror.get("positions") or [])
            id_fields = sorted({
                key for row in raw_rows if isinstance(row, dict)
                for key in row
                if str(key).lower() in {"positionid", "instrumentid"}
            })
            logger.info(
                "eToro-Portfolio-ID-Diagnose %s: %d Depotzeile(n), "
                "erkannte ID-Felder=%s, Snapshot=%s",
                "DEMO" if self.paper else "LIVE", len(raw_rows),
                id_fields or ["KEINE"], str(pnl.get("_snapshot_id") or "?"))
            self._position_schema_logged = True
        all_rows = self._all_positions(pnl)
        snapshot_id = str(pnl.get("_snapshot_id") or "")
        environment = "DEMO" if self.paper else "LIVE"
        # Eine offene Zeile ohne positionId darf niemals zu einem per Symbol
        # geratenen Bestand werden. Das ist ein Brokerprotokollfehler und
        # sperrt den eToro-Zyklus fail-closed.
        missing_ids = [
            sorted(str(k) for k in row.keys())
            for row in all_rows
            if bool(row.get("isBuy", True))
            and max(0.0, _float(row.get("units"))) > 0
            and row.get("positionId") in (None, "")
        ]
        if missing_ids:
            logger.error(
                "eToro-Depotzeile ohne positionId (%s, Snapshot %s, Felder=%s)",
                environment, snapshot_id or "unbekannt", missing_ids[:3])
            raise BrokerFehler(
                "eToro-Depot liefert eine offene Position ohne normalisierbare "
                "positionId; Aktienhandel bleibt sicher gesperrt")
        # Diese Menge ist die aktuelle Brokerwahrheit fuer die
        # Neustart-Reconciliation. Eine gespeicherte FILLED-Order allein darf
        # niemals wieder eine offene Position erzeugen.
        self._current_position_ids = {
            str(row.get("positionId")) for row in all_rows
            if row.get("positionId") not in (None, "")
            and bool(row.get("isBuy", True))
            and max(0.0, _float(row.get("units"))) > 0
        }
        self._current_position_map = {}
        for row in all_rows:
            pid = str(row.get("positionId") or "")
            iid = int(row.get("instrumentId") or row.get("instrumentID") or 0)
            if pid and iid and bool(row.get("isBuy", True)) and _float(row.get("units")) > 0:
                self._current_position_map.setdefault(self._symbol_for_id(iid), set()).add(pid)
        self._current_position_ids_known = True
        out = []
        for row in all_rows:
            if not bool(row.get("isBuy", True)):
                continue  # Bot eroeffnet keine Shorts.
            iid = int(row.get("instrumentId") or 0)
            pid = str(row.get("positionId") or "")
            qty = max(0.0, _float(row.get("units")))
            if qty <= 0:
                continue
            if iid <= 0:
                raise BrokerFehler(
                    f"eToro-Position {pid} ohne instrumentId; Aktienhandel gesperrt")
            avg = _float(row.get("openRate"))
            # v9.3: Ein FEHLENDES pnL ist unbekannt, nicht null. _float()
            # machte daraus 0.0 -- im Dashboard stand deshalb "Buchwert
            # +0,00" fuer eine frisch gekaufte Position (MSFT, 31.08.2026).
            # Das sieht aus wie ausgeglichen und ist eine Falschaussage.
            pnl_sum = (_float(row.get("pnL")) if row.get("pnL") is not None else None)
            symbol = self._symbol_for_id(iid)
            rate, quelle, alter = self._positionskurs(iid, [row])
            md=self._instrument_by_id.get(iid,{})
            asset_type=str(md.get("_bot_asset_type") or md.get("_detected_asset_type") or "unknown")
            stop_value = _float(row.get("stopLossRate") or row.get("stopLoss")) or None
            take_value = _float(row.get("takeProfitRate") or row.get("takeProfit")) or None
            out.append(Position(symbol=symbol, quantity=qty, avg_cost=avg, currency="USD",
                                asset_type=asset_type, broker_id=pid, position_ids=(pid,),
                                instrument_id=str(iid), snapshot_id=snapshot_id,
                                account_fingerprint=self.account_fingerprint(),
                                broker_environment=environment,
                                market_price=(rate or 0.0),
                                market_value=qty*rate if rate else 0.0,
                                unrealized_pnl=pnl_sum,
                                price_source=quelle, price_age_seconds=alter,
                                broker_stop=stop_value, broker_take_profit=take_value))
        return out

    def _positionskurs(self, iid: int, rows: list) -> tuple:
        """Belastbarer Kurs einer offenen Position (v9.3).

        Bis 9.2 galt ausschliesslich ``closeRate``. Bei einer frisch
        eroeffneten Position ist der oft noch nicht gesetzt -- der Kurs wurde
        0, der Marktwert 0, und in der Oberflaeche war die Position damit
        nicht uebernehmbar ("Kein aktueller Kurs"). Der Rates-Endpunkt liegt
        im Adapter bereits vor und liefert Bid/Ask/Last.

        Rueckgabe: (kurs oder None, quelle, alter_in_sekunden oder None).
        """
        rate = max((_float(r.get("closeRate")) for r in rows), default=0.0)
        if rate > 0:
            return rate, "ETORO_PNL_CLOSE_RATE", 0.0
        row = None
        try:
            row = self._rate_row_by_id(iid)
        except Exception:
            logger.debug("Rates-Fallback fuer %s nicht abrufbar", iid, exc_info=True)
        if isinstance(row, dict):
            alter = self._rate_age_seconds(row)
            for feld, quelle in (("bid", "ETORO_RATES_BID"),
                                 ("ask", "ETORO_RATES_ASK"),
                                 ("lastExecution", "ETORO_RATES_LAST"),
                                 ("last", "ETORO_RATES_LAST")):
                wert = _float(row.get(feld))
                if wert > 0:
                    return wert, quelle, alter
        # Kein erfundener Kurs. Die Oberflaeche zeigt "unbekannt".
        return None, "UNBEKANNT", None

    def current_position_ids(self, *, force: bool = False) -> set[str]:
        """Exakte aktuell offene eToro-positionIds, niemals Symbolraten."""
        if force:
            self._pnl(force=True)
        if force or not self._current_position_ids_known:
            self.positionen()
        return set(self._current_position_ids)

    def current_position_evidence(self) -> dict[str, set[str]]:
        """Letzter erfolgreich gelesener Depot-Snapshot nach Symbol."""
        if not self._current_position_ids_known:
            return {}
        return {symbol: set(ids) for symbol, ids in self._current_position_map.items()}

    def trade_history(self, min_date: str, *, max_pages: int = 12) -> list[dict]:
        """Geschlossene Positionen paginiert und mit exakter positionId.

        Der kurze Cache verhindert, dass Fill-Polling und Reconciliation den
        gleichen Endpunkt unmittelbar doppelt belasten.
        """
        key = str(min_date or date.today().isoformat())
        cached = self._history_cache.get(key)
        if cached and time.monotonic() - cached[0] < 10.0:
            return [dict(x) for x in cached[1]]
        path = self._path(
            "/api/v1/trading/info/trade/demo/history",
            "/api/v1/trading/info/trade/history")
        rows: list[dict] = []
        seen_pages: set[tuple] = set()
        page_size = 200
        for page in range(1, max(1, int(max_pages)) + 1):
            data = self._request("GET", path, params={
                "minDate": key, "page": page, "pageSize": page_size
            })
            batch = data if isinstance(data, list) else (
                data.get("items") or data.get("trades") or [])
            if not isinstance(batch, list) or not batch:
                break
            batch = [_normalisiere_positionszeile(x)
                     for x in batch if isinstance(x, dict)]
            signature = tuple(
                (str(x.get("positionId") or ""), str(x.get("closeTimestamp") or ""))
                for x in batch[:5])
            if signature in seen_pages:
                break
            seen_pages.add(signature)
            rows.extend(dict(x) for x in batch)
            if len(batch) < page_size:
                break
        unique: dict[tuple[str, str], dict] = {}
        for row in rows:
            unique[(str(row.get("positionId") or ""),
                    str(row.get("closeTimestamp") or ""))] = row
        result = list(unique.values())
        self._history_cache[key] = (time.monotonic(), result)
        return [dict(x) for x in result]

    # --------------------------- Fills ---------------------------------
    def fills(self) -> list:
        queued = self._fill_queue[:]
        self._fill_queue.clear()
        # Exact reconciled BUY executions survive process restarts. Repeated
        # delivery is safe because the persistent FillTracker deduplicates the
        # stable fill_id before accounting.
        try:
            from etoro_reconciliation import recovered_buy_fills
            current_ids = (self.current_position_ids(force=False)
                           if self._current_position_ids_known else set())
            queued.extend(recovered_buy_fills(
                paper=bool(self.paper), current_position_ids=current_ids,
                account_fingerprint=self.account_fingerprint()))
        except Exception as exc:
            logger.warning("Persistierte eToro-Kauffills konnten nicht gelesen werden: %s", exc)
        # Closed trades from today make SELL accounting restart-safe.
        now = time.monotonic()
        if now - self._last_history_poll >= 10.0:
            self._last_history_poll = now
            try:
                rows = self.trade_history(date.today().isoformat(), max_pages=3)
                for row in rows:
                    if not bool(row.get("isBuy", True)):
                        continue  # nur Long-Positionen des Bots
                    pid = str(row.get("positionId") or "")
                    ts = str(row.get("closeTimestamp") or "")
                    fid = f"etoro-close:{pid}:{ts}"
                    if fid in self._seen_history:
                        continue
                    self._seen_history.add(fid)
                    iid = int(row.get("instrumentId") or 0)
                    symbol = self._symbol_for_id(iid)
                    queued.append(Fill(
                        fill_id=fid, order_id=f"close:{pid}:{ts}", symbol=symbol,
                        side="SELL", quantity=abs(_float(row.get("units"))),
                        price=_float(row.get("closeRate")), currency="USD",
                        asset_type=str((self._instrument_by_id.get(iid,{}) or {}).get("_bot_asset_type") or (self._instrument_by_id.get(iid,{}) or {}).get("_detected_asset_type") or "unknown"),
                        broker_id=pid, timestamp=ts,
                        explicit_fees=abs(_float(row.get("fees"))),
                        execution_reason=str(
                            row.get("closeReason") or row.get("closingReason")
                            or row.get("closeType") or row.get("exitReason") or ""),
                    ))
            except VerbindungVerloren:
                raise
            except Exception as exc:
                logger.debug("eToro Trade-History konnte nicht gelesen werden: %s", exc)
        return queued

    # --------------------------- Kosten --------------------------------
    def dynamic_cost_quote(self, instrument, quantity: float, price: float,
                           *, action: str = "open") -> dict | None:
        if action != "open":
            raise NichtUnterstuetzt("eToro Cost-Quote fuer Pre-Trade wird derzeit fuer action=open verwendet")
        r = self._resolve(instrument)
        settlement = self._settlement(instrument)
        qty = abs(float(quantity))
        key = (r["instrumentId"], round(qty, 8), settlement.lower(), "open")
        cached = self._cost_cache.get(key)
        ttl = max(5, int(getattr(config, "ETORO_COST_CACHE_SECONDS", 300)))
        if cached and time.monotonic() - cached[0] < ttl:
            return cached[1]
        path = self._path("/api/v2/trading/info/demo/costs", "/api/v2/trading/info/costs")
        data = self._request("POST", path, payload={
            "action": "open", "transaction": "buy", "instrumentId": r["instrumentId"],
            "settlementType": settlement, "orderType": "mkt", "leverage": 1,
            "units": qty, "orderCurrency": "usd",
        })
        comp = {}
        for item in data.get("costs") or []:
            # eToro dokumentiert camelCase-Namen; intern normalisieren wir auf
            # lowercase, damit API-Schreibweisen die Kostenpruefung nicht
            # unbemerkt auf 0 fallen lassen koennen.
            key_name = str(item.get("costType") or "").strip().lower()
            if key_name:
                comp[key_name] = comp.get(key_name, 0.0) + abs(_float(item.get("amount")))
        result = {
            "symbol": r["symbol"], "instrument_id": r["instrumentId"],
            "settlement_type": settlement, "components": comp,
            "currency": (data.get("costs") or [{}])[0].get("currency", "USD") if data.get("costs") else "USD",
            "last_updated": data.get("lastUpdated") or datetime.now(timezone.utc).isoformat(),
            "source": "eToro Public API what-if costs",
        }
        self._cost_cache[key] = (time.monotonic(), result)
        best_effort_json(Path(__file__).resolve().parent.parent / "etoro_cost_status.json", result,
                         label="eToro-Kostenstatus")
        return result

    # --------------------------- Orders --------------------------------
    def _lookup_order(self, *, order_id=None, reference_id=None) -> dict:
        path = self._path("/api/v2/trading/info/demo/orders:lookup", "/api/v2/trading/info/orders:lookup")
        params = {"orderId": order_id} if order_id is not None else {"referenceId": reference_id}
        return self._request("GET", path, params=params)

    def _wait_open_order(self, *, order_id=None, reference_id=None, timeout=15.0) -> dict:
        deadline = time.monotonic() + max(2.0, timeout)
        last = {}
        while time.monotonic() < deadline:
            for key, value in (("order_id", order_id), ("reference_id", reference_id)):
                if value in (None, ""):
                    continue
                try:
                    # Official API anchors are deliberately separate requests.
                    candidate = self._lookup_order(**{key: value})
                    if candidate:
                        last = candidate
                        break
                except BrokerFehler:
                    # A fresh accepted order can transiently return 404. Retry
                    # with pacing and then try the independent referenceId.
                    continue
            status = last.get("status") or {}
            sid = int(status.get("id") or 0)
            if sid in (3, 4, 5, 10):
                return last
            time.sleep(0.6)
        return last

    def kaufe_mit_absicherung(self, instrument, menge: float, referenzpreis: float,
                              stop: float, take_profit: float) -> OrderErgebnis:
        if not self._connected:
            raise NichtVerbunden("eToro nicht verbunden")
        r = self._resolve(instrument)
        settlement = self._settlement(instrument)
        qty = abs(float(menge))
        if qty <= 0 or stop <= 0 or take_profit <= 0:
            raise BrokerFehler("eToro Kauf: Menge/Stop/Take-Profit ungueltig")
        self._validate_protection(instrument, settlement, referenzpreis, stop, take_profit)
        if bool(getattr(config, "ETORO_REQUIRE_LIVE_PROTECTION_QUOTE", True)):
            # Der Signalpreis kann mehrere Sekunden alt sein. eToro validiert
            # SL/TP aber gegen den Preis bei Orderannahme; genau daraus kamen
            # die protokollierten Min-pip-Ablehnungen. Unmittelbar vor dem POST
            # wird daher gegen einen frischen Brief-/Letzten Kurs erneut
            # fail-closed geprueft, ohne den Strategie-Stop still zu veraendern.
            live_row = self._rate_row(instrument, force=True)
            live_reference = _float((live_row or {}).get("ask")) or _float(
                (live_row or {}).get("lastExecution"))
            if live_reference <= 0:
                raise BrokerFehler(
                    "eToro Kauf blockiert: frischer Schutz-Referenzkurs nicht abrufbar")
            self._validate_protection(
                instrument, settlement, live_reference, stop, take_profit)
        # Kostenquelle vor Order zwingend ansprechen. Dadurch bleibt der Kauf
        # fail-closed, wenn eToro seine aktuell gueltigen Kosten nicht liefert.
        if bool(getattr(config, "ETORO_REQUIRE_COST_QUOTE", True)):
            self.dynamic_cost_quote(instrument, qty, referenzpreis, action="open")
        reqid = str(uuid.uuid4())
        context = dict(getattr(self, "_nexus_submit_context", {}) or {})
        if context.get("decision_id"):
            from etoro_reconciliation import register_reference
            register_reference(int(context["decision_id"]), reqid)
        payload = {
            "action": "open", "transaction": "buy", "instrumentId": r["instrumentId"],
            "settlementType": settlement, "orderType": "mkt", "leverage": 1,
            "units": qty, "orderCurrency": "usd", "stopLossRate": float(stop),
            "takeProfitRate": float(take_profit), "stopLossType": "fixed",
        }
        # v3 antwortet bewusst asynchron mit HTTP 202. Die Ausfuehrung wird
        # danach ausschliesslich ueber den offiziellen v2-Lookup bewiesen.
        path = self._path("/api/v3/trading/execution/demo/orders", "/api/v3/trading/execution/orders")
        try:
            accepted = self._request("POST", path, payload=payload, request_id=reqid, safe_retry=False)
        except VerbindungVerloren as exc:
            # NIEMALS blind erneut POSTen. eToro dokumentiert referenceId als
            # Lookup-Anker, falls die Antwort verloren ging.
            try:
                time.sleep(1.0)
                accepted = self._lookup_order(reference_id=reqid)
            except Exception:
                raise OrderStatusUnklar(
                    f"eToro Kaufstatus nach Transportfehler unklar; Order NICHT wiederholt. referenceId={reqid}: {exc}",
                    reference_id=reqid,
                ) from exc
        oid = accepted.get("orderId")
        broker_reference = str(accepted.get("referenceId") or reqid)
        if context.get("decision_id"):
            from etoro_reconciliation import accepted as persist_accepted
            persist_accepted(int(context["decision_id"]), order_id=str(oid or ""), reference_id=broker_reference)
        try:
            data = self._wait_open_order(order_id=oid, reference_id=broker_reference)
            if not data:
                raise OrderStatusUnklar(
                    "eToro Order nach Annahme noch nicht auffindbar; NICHT wiederholen",
                    reference_id=broker_reference, order_ids=[oid] if oid else [], accepted=True,
                    profile=str(context.get("profile") or ""), intent=payload)
        except (VerbindungVerloren, BrokerFehler) as exc:
            if isinstance(exc, OrderStatusUnklar):
                raise
            raise OrderStatusUnklar(
                f"eToro Order nach Annahme nicht abschliessend lesbar; NICHT wiederholen. referenceId={reqid}: {exc}",
                reference_id=broker_reference, order_ids=[oid] if oid else [], accepted=True,
                profile=str(context.get("profile") or ""), intent=payload,
            ) from exc
        status = data.get("status") or {}
        sid = int(status.get("id") or 0)
        executions = [_normalisiere_positionszeile(ex)
                      for ex in (data.get("positionExecutions") or [])
                      if isinstance(ex, dict)]
        filled = 0.0; value = 0.0; fees = 0.0
        pending_fills: list[Fill] = []
        for ex in executions:
            op = ex.get("openingData") or {}
            # remainingUnits is the unfilled rest, never an executed quantity.
            q = abs(_float(op.get("units") or ex.get("filledUnits")))
            px = _float(op.get("avgPrice"))
            if q > 0 and px > 0:
                filled += q; value += q * px
                fees += abs(_float(op.get("fees"))) + abs(_float(op.get("taxes")))
                pending_fills.append(Fill(
                    fill_id=f"etoro-open:{oid}:{ex.get('positionId')}:{op.get('executionTime')}",
                    order_id=str(oid or reqid), symbol=str(r.get("symbolFull") or r["symbol"]).upper(), side="BUY", quantity=q,
                    price=px, currency="USD", asset_type=getattr(instrument, "asset_type", "stock"),
                    broker_id=str(ex.get("positionId") or ""), timestamp=op.get("executionTime"),
                    explicit_fees=abs(_float(op.get("fees"))) + abs(_float(op.get("taxes"))),
                ))
        avg = value / filled if filled > 0 else 0.0
        if sid in (4, 10) and filled <= 0:
            if context.get("decision_id"):
                from etoro_reconciliation import apply_broker_evidence
                apply_broker_evidence(int(context["decision_id"]), data)
            raise BrokerFehler(f"eToro Kauf abgelehnt: {status.get('errorMessage') or status.get('name')}")
        position_ids=[str(ex.get("positionId")) for ex in executions
                      if ex.get("positionId") is not None]
        result = OrderErgebnis(
            order_ids=[str(oid or reqid)], status=str(status.get("name") or "accepted"),
            filled_quantity=filled, avg_fill_price=avg,
            stop_order_platziert=bool(filled > 0 and stop > 0),
            take_order_platziert=bool(filled > 0 and take_profit > 0),
            hinweis=f"eToro {('DEMO' if self.paper else 'LIVE')} · settlement={settlement} · fees={fees:.4f}",
            reference_id=broker_reference, position_ids=position_ids, paper=bool(self.paper),
            requested_quantity=qty, remaining_quantity=max(0.0, qty-filled),
            terminal=bool(sid in (3, 4, 5, 10)), raw_status=str(status.get("name") or ""),
        )
        if context.get("decision_id"):
            from etoro_reconciliation import (
                apply_broker_evidence, record_for, verify_broker_truth,
            )
            decision_id = int(context["decision_id"])
            apply_broker_evidence(decision_id, data)
            # v9.3: Fuer die Orderbestaetigung ausdruecklich einen frischen
            # Snapshot erzwingen -- ein 2 Sekunden alter Stand koennte die
            # gerade eroeffnete positionId noch nicht enthalten.
            self._pnl(force=True)
            current_ids = self.current_position_ids(force=False)
            verify_broker_truth(
                self, paper=bool(self.paper),
                profile=str(context.get("profile") or ""),
                account_fingerprint=self.account_fingerprint(),
                current_position_ids=current_ids,
            )
            proof = record_for(decision_id)
            if (not bool(proof.get("position_verified"))
                    or str(proof.get("broker_position_status") or "") != "OPEN_CONFIRMED"):
                raise OrderStatusUnklar(
                    "eToro meldet eine Ausfuehrung, die positionId ist im aktuellen "
                    "Depot aber noch nicht bestaetigt; kein lokaler Trade und kein "
                    "erneuter Kauf.",
                    reference_id=broker_reference, order_ids=[str(oid)] if oid else [],
                    accepted=True, profile=str(context.get("profile") or ""),
                    intent=payload,
                )
        # Erst nach dem exakten Depotbeweis in die Geld-/Ledger-Pipeline
        # geben. Ohne Submit-Kontext bleibt das alte Adapterverhalten nur fuer
        # isolierte Diagnoseaufrufe erhalten; produktive Orders tragen immer
        # eine decision_id.
        self._fill_queue.extend(pending_fills)
        return result

    def schliesse_position(self, instrument, menge: float, referenzpreis: float = 0.0,
                           *, position_ids=None, snapshot_id: str = "",
                           instrument_id: str = "") -> OrderErgebnis:
        """Nur exakt bewiesene eToro-Position-Lines schliessen."""
        r = self._resolve(instrument)
        expected_instrument_id = int(instrument_id or r["instrumentId"])
        target = abs(float(menge))
        if target <= 0:
            return OrderErgebnis(status="keine_menge")
        expected = {str(x) for x in (position_ids or []) if str(x).strip()}
        if not expected:
            raise BrokerFehler("eToro-Verkauf ohne bewiesene positionId blockiert")
        pnl = self._pnl(force=True)
        current_snapshot = str(pnl.get("_snapshot_id") or "")
        rows = [x for x in self._all_positions(pnl)
                if str(x.get("positionId") or "") in expected
                and bool(x.get("isBuy", True))]
        found = {str(x.get("positionId") or "") for x in rows}
        if found != expected:
            raise BrokerFehler(
                "eToro-Verkauf blockiert: nicht alle bewiesenen positionIds "
                f"sind im frischen Depot-Snapshot {current_snapshot or '?'} offen")
        wrong_instrument = [x for x in rows
                            if int(x.get("instrumentId") or 0) != expected_instrument_id]
        if wrong_instrument:
            raise BrokerFehler(
                "eToro-Verkauf blockiert: positionId und Instrument widersprechen sich")
        available = sum(abs(_float(x.get("units"))) for x in rows)
        if target > available + max(1e-8, available * 1e-7):
            raise BrokerFehler(
                f"eToro-Verkauf blockiert: Zielmenge {target:g} ist groesser "
                f"als die bewiesene Menge {available:g}")
        remaining = target; order_ids = []
        for row in rows:
            if remaining <= 1e-10:
                break
            pos_units = abs(_float(row.get("units")))
            q = min(pos_units, remaining)
            if q <= 0:
                continue
            pid = int(row.get("positionId"))
            reqid = str(uuid.uuid4())
            path = self._path(
                f"/api/v1/trading/execution/demo/market-close-orders/positions/{pid}",
                f"/api/v1/trading/execution/market-close-orders/positions/{pid}",
            )
            payload = {
                ("InstrumentID" if self.paper else "InstrumentId"):
                    int(row.get("instrumentId") or r["instrumentId"]),
                "UnitsToDeduct": q,
            }
            try:
                resp = self._request("POST", path, payload=payload, request_id=reqid, safe_retry=False)
            except VerbindungVerloren as exc:
                # Close wird ebenfalls nicht blind wiederholt. Der Bot resynct;
                # Sicherheitspfad bleibt aktiv und kann den Restbestand erneut sehen.
                raise OrderStatusUnklar(
                    f"eToro Close-Status unklar; Close NICHT blind wiederholt (Position {pid}, request {reqid}): {exc}",
                    reference_id=reqid,
                ) from exc
            ofc = resp.get("orderForClose") or {}
            oid = ofc.get("orderID") or ofc.get("orderId")
            if oid:
                order_ids.append(str(oid))
            remaining -= q
        if not order_ids:
            raise BrokerFehler(f"eToro: keine offene Position fuer {r['symbol']} zum Schliessen gefunden")
        return OrderErgebnis(
            order_ids=order_ids, status="submitted", filled_quantity=0.0,
            position_ids=sorted(expected),
            hinweis=("Close-Orders fuer exakt bewiesene positionIds uebermittelt; "
                     "Fill wird ueber Trade-History verbucht"), paper=bool(self.paper))

    def offene_orders(self) -> list:
        pnl = self._pnl(); out = []
        for o in self._all_orders(pnl):
            iid = int(o.get("instrumentId") or o.get("instrumentID") or 0)
            out.append({
                "symbol": self._symbol_for_id(iid), "side": "BUY" if bool(o.get("isBuy", True)) else "SELL",
                "qty": o.get("amountInUnits") or o.get("unitsToDeduct") or o.get("units") or "?",
                "type": o.get("orderType", "?"), "status": o.get("statusId", "open"),
                "order_id": o.get("orderId"), "asset_type": str((self._instrument_by_id.get(iid,{}) or {}).get("_bot_asset_type") or (self._instrument_by_id.get(iid,{}) or {}).get("_detected_asset_type") or "unknown"),
            })
        return out

    def hat_offene_order(self, instrument, seite: str = "BUY") -> bool:
        wanted = seite.upper()
        target = self._cache_key(instrument)
        for o in self.offene_orders():
            try:
                if canonical_key(o.get("symbol", ""), o.get("asset_type", "")) == target and wanted in str(o.get("side", "")).upper():
                    return True
            except Exception:
                continue
        return False

    def storniere_offene_orders(self, instrument) -> int:
        # Nur Pending OPEN-Orders stornieren; SL/TP an offenen Positionen werden
        # nicht als getrennte Pending-Orders behandelt und bleiben unangetastet.
        sym = self._symbol(instrument); count = 0
        for o in self.offene_orders():
            if o.get("symbol") != sym or "BUY" not in str(o.get("side", "")).upper():
                continue
            oid = o.get("order_id")
            if not oid:
                continue
            path = self._path(f"/api/v2/trading/execution/demo/orders/{oid}",
                              f"/api/v2/trading/execution/orders/{oid}")
            self._request("DELETE", path, safe_retry=False)
            count += 1
        return count

    def verwaiste_orders_aufraeumen(self) -> int:
        # eToro SL/TP gehoeren zur Position, daher keine getrennten Schutzorders.
        return 0

    def reconcile_position_protection(self, instrument, quantity: float,
                                      stop: float, take_profit: float,
                                      *, position_ids=None,
                                      update_requested: bool = False,
                                      instrument_id: str = "") -> dict:
        """Schutz fuer exakt ausgewaehlte positionIds setzen und bestaetigen."""
        r = self._resolve(instrument)
        expected_instrument_id = int(instrument_id or r["instrumentId"])
        expected = {str(x) for x in (position_ids or []) if str(x).strip()}
        if not expected:
            return {"checked": True, "changed": False,
                    "protection_confirmed": False,
                    "detail": "keine bewiesene positionId; Schutz nicht veraendert"}

        def selected_rows(*, force=False):
            pnl = self._pnl(force=force)
            rows = [x for x in self._all_positions(pnl)
                    if str(x.get("positionId") or "") in expected
                    and bool(x.get("isBuy", True))]
            return pnl, rows

        pnl, rows = selected_rows(force=True)
        found = {str(x.get("positionId") or "") for x in rows}
        if found != expected:
            return {"checked": True, "changed": False,
                    "protection_confirmed": False,
                    "snapshot_id": str(pnl.get("_snapshot_id") or ""),
                    "detail": "nicht alle ausgewaehlten positionIds sind offen"}
        if any(int(x.get("instrumentId") or 0) != expected_instrument_id for x in rows):
            return {"checked": True, "changed": False,
                    "protection_confirmed": False,
                    "detail": "positionId und Instrument widersprechen sich"}

        changed = False
        if update_requested:
            for row in rows:
                pid = str(row.get("positionId"))
                path = self._path(
                    f"/api/v2/trading/demo/positions/{pid}",
                    f"/api/v2/trading/positions/{pid}")
                self._request(
                    "PATCH", path,
                    payload={"stopLossRate": float(stop),
                             "takeProfitRate": float(take_profit),
                             "stopLossType": "fixed"},
                    request_id=str(uuid.uuid4()), safe_retry=False)
            changed = True
            # 202 bedeutet nur angenommen. Kein zweiter PATCH: lediglich
            # frische Depot-Snapshots bis zur exakten Bestaetigung lesen.
            deadline = time.monotonic() + float(getattr(
                config, "ETORO_PROTECTION_CONFIRM_SECONDS", 12.0))
            while time.monotonic() < deadline:
                time.sleep(0.8)
                pnl, rows = selected_rows(force=True)
                if self._protection_values_match(rows, expected, stop, take_profit):
                    break

        confirmed = self._protection_values_match(rows, expected, stop, take_profit)
        return {
            "checked": True, "changed": changed,
            "protection_confirmed": confirmed,
            "snapshot_id": str(pnl.get("_snapshot_id") or ""),
            "position_ids": sorted(expected),
            "detail": ("gewuenschter eToro-Stop und Take-Profit exakt bestaetigt"
                       if confirmed else
                       "eToro hat die gewuenschten Stop-/Take-Profit-Werte "
                       "noch nicht exakt bestaetigt"),
        }

    @staticmethod
    def _protection_values_match(rows, expected, stop, take_profit) -> bool:
        if {str(x.get("positionId") or "") for x in rows} != set(expected):
            return False
        for row in rows:
            actual_stop = _float(row.get("stopLossRate") or row.get("stopLoss"))
            actual_take = _float(row.get("takeProfitRate") or row.get("takeProfit"))
            stop_tol = max(1e-7, abs(float(stop)) * 1e-6)
            take_tol = max(1e-7, abs(float(take_profit)) * 1e-6)
            if (bool(row.get("isNoStopLoss", False))
                    or abs(actual_stop - float(stop)) > stop_tol
                    or abs(actual_take - float(take_profit)) > take_tol):
                return False
        return bool(rows)

    def unterstuetzt_krypto_stop(self) -> bool:
        return True

    def unterstuetzt_bruchstuecke(self, asset_type: str = "stock") -> bool:
        return True


def _float(value, default=0.0) -> float:
    try:
        v = float(value)
        return v if math.isfinite(v) else default
    except Exception:
        return default
