"""OKX-EEA-Anbindung (Spot) fuer TradingBot v8.1.1 NEXUS.

WARUM DIESES MODUL EXISTIERT
============================
Bis v6.0 lief Krypto ueber eToro. Das hatte drei Nachteile:

    1. eToro liefert fuer Krypto keine belastbaren Orderbuch-/Tickdaten,
       also war eine echte Marktqualitaets-Bewertung unmoeglich.
    2. eToro kennt keinen echten Broker-Stop fuer Krypto -- der Schutz lag
       ausschliesslich clientseitig und wirkte nur bei laufendem Programm.
    3. Aktien und Krypto teilten sich einen einzigen Kontostand, wodurch ein
       Krypto-Verlust die Aktienseite mitbremste.

OKX loest alle drei Punkte: vollstaendige Instrumentmetadaten (tickSz/lotSz/
minSz/state/listTime), echte Algo-Orders fuer Stop-Loss und Take-Profit und
ein eigenes, getrenntes Konto.

AUFBAU
======
    OKXClient   -- reine REST-Schicht, kennt keine Handelslogik.
                   Wird auch vom CryptoUniverseSelector benutzt, damit die
                   Universumsauswahl keinen Trading-Adapter braucht.
    OKXBroker   -- BrokerBase-Umsetzung fuer den Geldpfad.

SICHERHEITSGRUNDSAETZE (uebernommen aus dem eToro-Pfad)
=======================================================
- Ein unklarer Transportzustand nach einem POST wird NIEMALS als Misserfolg
  gewertet. Es gilt OrderStatusUnklar; der Bot sendet keinen blinden zweiten
  Kauf.
- Jede Order bekommt eine eigene clOrdId. Damit laesst sich nach einem
  Abbruch eindeutig feststellen, ob die Order angekommen ist.
- Geheimnisse (Key/Secret/Passphrase) tauchen in keiner Ausnahme, keinem
  Log und keiner Fehlermeldung auf.
- Demo- und Live-Zugang sind vollstaendig getrennte Schluesselsaetze. Ein
  Demo-Key kann technisch nicht live handeln und umgekehrt.
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
import logging
import re
import threading
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation, ROUND_DOWN, ROUND_HALF_UP, ROUND_UP
from typing import Any, Iterable, Optional
from urllib.parse import urlencode

import pandas as pd
import requests

from .base import (
    AuthentifizierungsFehler,
    BrokerBase,
    BrokerFehler,
    Fill,
    NichtUnterstuetzt,
    NichtVerbunden,
    OrderErgebnis,
    OrderStatusUnklar,
    Position,
    VerbindungVerloren,
    Zeitabweichung,
)
from .history_safety import completed_bars_only, retry_call

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Konstanten
# ---------------------------------------------------------------------------
OKX_BASE_URL = "https://eea.okx.com"

# OKX-Kerzengroessen. Der Bot spricht die IB-artige Schreibweise ("15 mins"),
# OKX erwartet "15m"/"1H"/"1D".
BAR_MAP = {
    "1 min": "1m", "1 mins": "1m",
    "3 mins": "3m", "3 min": "3m",
    "5 mins": "5m", "5 min": "5m",
    "15 mins": "15m", "15 min": "15m",
    "30 mins": "30m", "30 min": "30m",
    "1 hour": "1H", "1 hours": "1H",
    "2 hours": "2H", "4 hours": "4H", "6 hours": "6H", "12 hours": "12H",
    "1 day": "1D", "1 days": "1D",
    "1 week": "1W",
}

BAR_SECONDS = {
    "1m": 60, "3m": 180, "5m": 300, "15m": 900, "30m": 1800,
    "1H": 3600, "2H": 7200, "4H": 14400, "6H": 21600, "12H": 43200,
    "1D": 86400, "1W": 604800,
}

# Fehlercodes, bei denen ein erneuter Versuch sinnlos ist.
_AUTH_CODES = {"50100", "50101", "50103", "50104", "50105",
               "50106", "50107", "50111", "50112", "50113", "50114"}

# 50102 bedeutet laut OKX nicht "falscher API-Key", sondern ein abgelaufenes
# 30-Sekunden-Zeitfenster. Der Fehler muss deshalb wiederholbar bleiben.
_TIME_CODES = {"50102"}

# Fehlercodes, die eine Ueberlast/Sperre bedeuten -- kurz warten hilft.
_RATE_CODES = {"50011", "50061", "58102"}

# Codes, bei denen OKX AUSDRUECKLICH offenlaesst, ob die Order angekommen ist.
# 50004 lautet woertlich: "Endpoint request timeout (does not indicate success
# or failure of order, please check order status)". Bis 9.0.15 landeten diese
# Codes im Zweig "fachliche Ablehnung ist eindeutig" -- der Bot hat die Order
# danach VERGESSEN (REJECTED + clear_pending). Eine tatsaechlich angenommene
# Order wurde damit zu einer unbekannten, ungeschuetzten Position.
_UNKLARE_ORDER_CODES = {"50001", "50004", "50005", "50013", "50026"}

# "Duplicated client order ID". Das ist der BEWEIS, dass die Order bei OKX
# liegt -- nicht das Gegenteil. Da die clOrdId deterministisch aus der
# decision_id entsteht, tritt der Code nach jedem Wiederanlauf derselben
# Entscheidung auf. Er gehoert deshalb in den Nachweispfad, nicht in die
# Ablehnung.
_DOPPELTE_CLORDID = "51016"

# Storno-Codes, die aus Sicht des Aufrufers ein ERFOLG sind: das Ziel "keine
# offene Order mehr" ist erreicht. Bis 9.0.15 blockierten sie den Ausstieg
# genau dann, wenn die Schutzorder gerade ausgeloest war -- also im
# aktivsten Marktmoment.
_STORNO_ERLEDIGT_CODES = {"51400", "51401", "51402", "51405", "51410"}

_CLORDID_RE = re.compile(r"[^A-Za-z0-9]")


# ---------------------------------------------------------------------------
# Hilfsfunktionen
# ---------------------------------------------------------------------------
def _f(value: Any, default: float = 0.0) -> float:
    """Robuste Zahlwandlung; OKX liefert alle Zahlen als String."""
    try:
        if value is None or value == "":
            return default
        return float(value)
    except (TypeError, ValueError):
        return default


def _dec(value: Any) -> Optional[Decimal]:
    try:
        if value is None or value == "":
            return None
        return Decimal(str(value))
    except (InvalidOperation, TypeError, ValueError):
        return None


def quantize_down(value: float, step: Any) -> float:
    """Rundet auf ein Vielfaches von 'step' ABWAERTS.

    Abwaerts ist hier bewusst richtig: eine Menge darf nie groesser werden,
    als der Bot berechnet hat, und ein Verkauf darf nie mehr anfordern, als
    tatsaechlich im Konto liegt.
    """
    d_step = _dec(step)
    d_val = _dec(value)
    if d_val is None:
        return 0.0
    if not d_step or d_step <= 0:
        return float(d_val)
    n = (d_val / d_step).to_integral_value(rounding=ROUND_DOWN)
    return float(n * d_step)


def quantize_up(value: float, step: Any) -> float:
    """Rundet fuer eine sichere Kauf-Preisgrenze auf die Tickgroesse auf."""
    d_step = _dec(step)
    d_val = _dec(value)
    if d_val is None:
        return 0.0
    if not d_step or d_step <= 0:
        return float(d_val)
    n = (d_val / d_step).to_integral_value(rounding=ROUND_UP)
    return float(n * d_step)


def quantize_price(value: float, tick: Any) -> float:
    """Rundet einen Preis auf die Tick-Groesse (kaufmaennisch)."""
    d_step = _dec(tick)
    d_val = _dec(value)
    if d_val is None:
        return 0.0
    if not d_step or d_step <= 0:
        return float(d_val)
    n = (d_val / d_step).to_integral_value(rounding=ROUND_HALF_UP)
    return float(n * d_step)


def format_decimal(value: float, step: Any) -> str:
    """Formatiert eine Zahl exakt so genau wie die Schrittweite es verlangt.

    OKX lehnt sowohl 1e-08-Notation als auch ueberzaehlige Nachkommastellen
    ab. Deshalb wird ueber Decimal formatiert statt ueber f-Strings.
    """
    d_step = _dec(step)
    d_val = _dec(value) or Decimal(0)
    if d_step and d_step > 0:
        exponent = -d_step.as_tuple().exponent
        quant = Decimal(1).scaleb(-max(0, int(exponent)))
        d_val = d_val.quantize(quant, rounding=ROUND_DOWN)
    # normalize() entfernt ueberfluessige Nullen, 'f' verhindert die
    # Exponentialschreibweise -- OKX lehnt '5E-8' ab.
    return format(d_val.normalize(), "f")


def make_client_order_id(prefix: str = "TBN8") -> str:
    """Eindeutige, OKX-konforme Client-Order-ID (nur A-Z a-z 0-9, max. 32)."""
    raw = f"{prefix}{uuid.uuid4().hex}"
    return _CLORDID_RE.sub("", raw)[:32]


def client_order_id_for_decision(decision_id: int) -> str:
    """Deterministische clOrdId, die vor dem ersten POST speicherbar ist."""
    raw = f"N9{int(decision_id)}"
    return _CLORDID_RE.sub("", raw)[:32]


def okx_timestamp(epoch_seconds: Optional[float] = None) -> str:
    """ISO-8601-Zeitstempel in Millisekunden, wie OKX ihn signiert erwartet."""
    now = (datetime.now(timezone.utc) if epoch_seconds is None else
           datetime.fromtimestamp(float(epoch_seconds), timezone.utc))
    return now.strftime("%Y-%m-%dT%H:%M:%S.") + f"{now.microsecond // 1000:03d}Z"


def normalize_inst_id(symbol: Any, quote: str = "EUR") -> str:
    """Wandelt 'BTC', 'BTC/EUR', 'btc-eur' einheitlich nach 'BTC-EUR'."""
    text = str(symbol or "").strip().upper().replace("/", "-").replace("_", "-")
    if not text:
        return ""
    if "-" in text:
        return text
    return f"{text}-{str(quote or 'EUR').upper()}"


def base_currency(inst_id: str) -> str:
    return str(inst_id or "").split("-")[0].upper()


# ---------------------------------------------------------------------------
# Ratenbegrenzung
# ---------------------------------------------------------------------------
class RateLimiter:
    """Einfacher Token-Bucket je Endpunktgruppe.

    OKX begrenzt pro Endpunkt und Konto. Der Bot bleibt bewusst deutlich
    unter den offiziellen Grenzen: ein gesperrter Schluessel kostet mehr als
    ein paar Millisekunden Wartezeit.
    """

    def __init__(self, rate: float, per_seconds: float = 1.0):
        self.capacity = max(1.0, float(rate))
        self.tokens = self.capacity
        self.rate = self.capacity / max(0.001, float(per_seconds))
        self.updated = time.monotonic()
        self._lock = threading.Lock()

    def acquire(self, timeout: float = 10.0) -> bool:
        deadline = time.monotonic() + max(0.0, timeout)
        while True:
            with self._lock:
                now = time.monotonic()
                self.tokens = min(self.capacity, self.tokens + (now - self.updated) * self.rate)
                self.updated = now
                if self.tokens >= 1.0:
                    self.tokens -= 1.0
                    return True
                fehlend = (1.0 - self.tokens) / self.rate
            if time.monotonic() + fehlend > deadline:
                return False
            time.sleep(min(0.25, max(0.005, fehlend)))


# ---------------------------------------------------------------------------
# Instrumentmetadaten
# ---------------------------------------------------------------------------
@dataclass
class OKXInstrument:
    """Alles, was der Bot ueber ein OKX-Spotinstrument wissen muss."""
    inst_id: str
    base_ccy: str
    quote_ccy: str
    state: str = ""
    tick_size: str = "0.00000001"
    lot_size: str = "0.00000001"
    min_size: str = "0"
    max_market_size: str = ""
    list_time_ms: int = 0
    # Bei OKX Unified USD kann ein Markt wie UNI-USD mit mehreren
    # Abrechnungswaehrungen gehandelt werden. quoteCcy beschreibt den Markt,
    # tradeQuoteCcyList die fuer Orders tatsaechlich erlaubten Guthaben.
    trade_quote_ccy_list: tuple[str, ...] = ()

    @property
    def ist_live(self) -> bool:
        return str(self.state or "").lower() == "live"

    @property
    def alter_tage(self) -> float:
        if self.list_time_ms <= 0:
            return 0.0
        return max(0.0, (time.time() * 1000.0 - float(self.list_time_ms)) / 86_400_000.0)

    @classmethod
    def from_api(cls, row: dict) -> "OKXInstrument":
        trade_quotes = row.get("tradeQuoteCcyList") or []
        if isinstance(trade_quotes, str):
            trade_quotes = [trade_quotes]
        return cls(
            inst_id=str(row.get("instId", "")).upper(),
            base_ccy=str(row.get("baseCcy", "")).upper(),
            quote_ccy=str(row.get("quoteCcy", "")).upper(),
            state=str(row.get("state", "")),
            tick_size=str(row.get("tickSz") or "0.00000001"),
            lot_size=str(row.get("lotSz") or "0.00000001"),
            min_size=str(row.get("minSz") or "0"),
            max_market_size=str(row.get("maxMktSz") or ""),
            list_time_ms=int(_f(row.get("listTime"), 0.0)),
            trade_quote_ccy_list=tuple(dict.fromkeys(
                str(x).upper() for x in trade_quotes if str(x).strip()
            )),
        )


@dataclass
class OKXTicker:
    """Ein Ticker-Datensatz, reduziert auf die fuer uns relevanten Felder."""
    inst_id: str
    last: float = 0.0
    bid: float = 0.0
    ask: float = 0.0
    vol_24h_base: float = 0.0
    vol_24h_quote: float = 0.0
    open_24h: float = 0.0
    high_24h: float = 0.0
    low_24h: float = 0.0
    timestamp_ms: int = 0

    @property
    def spread_pct(self) -> float:
        """Relative Spanne bezogen auf die Mitte. 0 bei unbrauchbaren Daten."""
        if self.bid <= 0 or self.ask <= 0 or self.ask < self.bid:
            return 0.0
        mitte = (self.bid + self.ask) / 2.0
        if mitte <= 0:
            return 0.0
        return (self.ask - self.bid) / mitte

    @property
    def change_24h_pct(self) -> float:
        if self.open_24h <= 0 or self.last <= 0:
            return 0.0
        return (self.last - self.open_24h) / self.open_24h

    @classmethod
    def from_api(cls, row: dict) -> "OKXTicker":
        return cls(
            inst_id=str(row.get("instId", "")).upper(),
            last=_f(row.get("last")),
            bid=_f(row.get("bidPx")),
            ask=_f(row.get("askPx")),
            vol_24h_base=_f(row.get("vol24h")),
            vol_24h_quote=_f(row.get("volCcy24h")),
            open_24h=_f(row.get("open24h")),
            high_24h=_f(row.get("high24h")),
            low_24h=_f(row.get("low24h")),
            timestamp_ms=int(_f(row.get("ts"), 0.0)),
        )


# ---------------------------------------------------------------------------
# REST-Schicht
# ---------------------------------------------------------------------------
class OKXClient:
    """Schlanke, threadsichere REST-Schicht fuer die OKX-V5-API.

    Bewusst OHNE Handelslogik: dieses Objekt wird auch von der
    Universumsauswahl benutzt, die nur oeffentliche Marktdaten braucht und
    keinerlei Orderrechte besitzen soll.
    """

    def __init__(self, api_key: str = "", api_secret: str = "",
                 passphrase: str = "", *, demo: bool = True,
                 base_url: str = OKX_BASE_URL, timeout: float = 15.0):
        self._key = str(api_key or "").strip()
        self._secret = str(api_secret or "").strip()
        self._passphrase = str(passphrase or "").strip()
        self.demo = bool(demo)
        self.base_url = str(base_url or OKX_BASE_URL).rstrip("/")
        self.timeout = float(timeout)

        self.session = requests.Session()
        self.session.headers.update({
            "Content-Type": "application/json",
            "Accept": "application/json",
            "User-Agent": "TradingBot-v8-NEXUS",
        })

        self._public_limit = RateLimiter(10, 1.0)
        self._private_limit = RateLimiter(5, 1.0)
        self._order_limit = RateLimiter(8, 2.0)

        self._instruments: dict[str, OKXInstrument] = {}
        self._instruments_at = 0.0
        self._public_instruments: dict[str, OKXInstrument] = {}
        self._public_instruments_at = 0.0
        self._lock = threading.RLock()
        self._last_contact: Optional[str] = None
        # Differenz OKX-Serverzeit minus lokale Systemzeit. Sie wird mit dem
        # oeffentlichen /public/time-Endpunkt bestimmt und fuer signierte
        # REST- sowie WebSocket-Anfragen verwendet.
        self._clock_offset_seconds = 0.0

    # -- Grundlagen ---------------------------------------------------------
    @property
    def hat_zugangsdaten(self) -> bool:
        return bool(self._key and self._secret and self._passphrase)

    def last_contact(self) -> Optional[str]:
        return self._last_contact

    def _signature(self, timestamp: str, method: str, request_path: str, body: str) -> str:
        message = f"{timestamp}{method.upper()}{request_path}{body}"
        digest = hmac.new(self._secret.encode("utf-8"), message.encode("utf-8"), hashlib.sha256).digest()
        return base64.b64encode(digest).decode("ascii")

    @staticmethod
    def _query_string(params: Optional[dict]) -> str:
        if not params:
            return ""
        teile = [(str(k), str(v)) for k, v in params.items() if v not in (None, "")]
        return ("?" + urlencode(teile)) if teile else ""

    def _headers(self, method: str, request_path: str, body: str, private: bool) -> dict:
        headers: dict[str, str] = {}
        if self.demo and private:
            # Der Demo-Header gehoert zu Konto-/Orderaufrufen. Oeffentliche
            # Marktmetadaten werden wie bei Freqtrade aus dem echten
            # Spotkatalog gelesen; sonst kann der Simulationskatalog aktuelle
            # EEA-/Unified-USD-Instrumente ausblenden.
            headers["x-simulated-trading"] = "1"
        if not private:
            return headers
        if not self.hat_zugangsdaten:
            raise AuthentifizierungsFehler(
                "OKX-Zugangsdaten unvollstaendig (Key, Secret und Passphrase noetig)."
            )
        timestamp = okx_timestamp(time.time() + self._clock_offset_seconds)
        headers.update({
            "OK-ACCESS-KEY": self._key,
            "OK-ACCESS-SIGN": self._signature(timestamp, method, request_path, body),
            "OK-ACCESS-TIMESTAMP": timestamp,
            "OK-ACCESS-PASSPHRASE": self._passphrase,
        })
        return headers

    def _limiter(self, private: bool, is_order: bool) -> RateLimiter:
        if is_order:
            return self._order_limit
        return self._private_limit if private else self._public_limit

    def request(self, method: str, path: str, *, params: Optional[dict] = None,
                body: Optional[dict] = None, private: bool = False,
                is_order: bool = False) -> list:
        """Fuehrt einen Aufruf aus und liefert die 'data'-Liste zurueck.

        Fehlerbehandlung nach Schwere:
            Netzwerkfehler bei GET     -> VerbindungVerloren (harmlos)
            Netzwerkfehler bei Order   -> OrderStatusUnklar  (niemals blind wiederholen)
            401/Auth-Fehlercode        -> AuthentifizierungsFehler (Warten hilft nicht)
            sonstiger Fachfehler       -> BrokerFehler
        """
        method = method.upper()
        query = self._query_string(params)
        request_path = f"/api/v5{path}{query}"
        body_text = json.dumps(body, separators=(",", ":")) if body is not None else ""
        url = f"{self.base_url}{request_path}"

        limiter = self._limiter(private, is_order)
        if not limiter.acquire(timeout=12.0):
            raise VerbindungVerloren("OKX-Ratenbegrenzung: kein freies Zeitfenster erhalten.")

        try:
            headers = self._headers(method, request_path, body_text, private)
        except AuthentifizierungsFehler:
            raise
        if is_order and path == "/trade/order":
            # OKX dokumentiert die Anfrage-Verfallszeit ausdruecklich nur fuer
            # "Place order / Place multiple orders / Amend order". v9.1: Ein
            # STORNO darf niemals verfallen -- sonst glaubt der Bot, storniert
            # zu haben, waehrend die Schutzorder noch liegt.
            # OKX kann Order-Anfragen nach einer vom Client gesetzten Frist
            # verwerfen. Das verhindert, dass eine durch Netzstau alte Order
            # erst deutlich spaeter im Matching ankommt. Bei einer unklaren
            # Antwort bleibt die bestehende fail-closed-Logik aktiv: niemals
            # blind erneut senden, sondern clOrdId pruefen.
            try:
                import config as _cfg
                sekunden = float(getattr(_cfg, "OKX_ORDER_REQUEST_EXPIRY_SECONDS", 12.0))
            except Exception:
                sekunden = 12.0
            sekunden = max(2.0, min(60.0, sekunden))
            headers["expTime"] = str(int((time.time() + self._clock_offset_seconds
                                           + sekunden) * 1000))

        try:
            response = self.session.request(
                method, url, headers=headers,
                data=body_text if body_text else None,
                timeout=self.timeout,
            )
        except requests.RequestException as exc:
            # Bewusst nur den Ausnahmetyp melden: manche Bibliotheken haengen
            # die vollstaendige URL inklusive Parametern an die Meldung.
            if is_order:
                raise OrderStatusUnklar(
                    f"OKX-Order: Transportzustand unklar ({type(exc).__name__}).",
                ) from None
            raise VerbindungVerloren(f"OKX nicht erreichbar ({type(exc).__name__}).") from None

        try:
            payload = response.json()
        except ValueError:
            if response.status_code == 401:
                raise AuthentifizierungsFehler(
                    "OKX lehnt die Zugangsdaten ab (HTTP 401).")
            if response.status_code == 429:
                raise VerbindungVerloren("OKX-Ratenbegrenzung erreicht (HTTP 429).")
            if response.status_code >= 500:
                if is_order:
                    raise OrderStatusUnklar(
                        f"OKX-Order: Serverfehler HTTP {response.status_code}.")
                raise VerbindungVerloren(
                    f"OKX-Serverfehler HTTP {response.status_code}.")
            if is_order:
                raise OrderStatusUnklar("OKX-Order: Antwort nicht lesbar.")
            raise VerbindungVerloren(f"OKX-Antwort nicht lesbar (HTTP {response.status_code}).")

        code = str(payload.get("code", ""))
        data = payload.get("data") or []
        # Bei Order-/Sammelantworten kann OKX oben code=0 melden und eine
        # konkrete Ablehnung nur als sCode im Datensatz liefern.
        #
        # v9.1: Beim Stornieren sind "Order existiert nicht", "bereits
        # storniert" und "bereits ausgefuehrt" fachlich ERFOLGE -- das Ziel
        # "keine offene Order mehr" ist erreicht. Vorher kippte eine solche
        # Zeile den ganzen Aufruf und blockierte damit den Ausstieg.
        storniert = path.startswith("/trade/cancel")
        erfolgscodes = _STORNO_ERLEDIGT_CODES if storniert else frozenset()
        detail_code, detail_msg = self._first_detail(data, erfolgscodes=erfolgscodes)
        msg = str(payload.get("msg", "")).strip() or "ohne Meldung"
        code_out = detail_code or code
        msg_out = detail_msg or msg
        # OKX nutzt bei Sammelanfragen code="2" fuer "teilweise erfolgreich".
        # Ohne diese Zeile galt ein Teilerfolg als Totalausfall.
        if code in ("0", "2") and not detail_code:
            code = "0"
        # Beim Stornieren kann der AEUSSERE Code "1" lauten (alle Zeilen
        # fehlgeschlagen), obwohl jede einzelne Zeile nur sagt: "die Order gibt
        # es nicht mehr". Fachlich ist das der gewuenschte Zustand. Ohne diese
        # Auswertung blieb code_out="1" stehen und der Ausstieg blieb blockiert.
        if storniert and not detail_code and data:
            alle = self._alle_details(data)
            if alle and all(c in ("0", *_STORNO_ERLEDIGT_CODES) for c, _ in alle):
                code = "0"

        # Wichtig: OKX kann auch bei einem Zeitfehler HTTP 401 liefern. Erst
        # den strukturierten Fehlercode auswerten, dann den HTTP-Status.
        meldung_klein = str(msg_out).lower()
        zeitfehler = (code_out in _TIME_CODES or
                      ("timestamp" in meldung_klein and
                       any(wort in meldung_klein for wort in
                           ("expired", "expire", "invalid", "difference"))))
        if zeitfehler:
            raise Zeitabweichung(
                f"OKX-Zeitfenster abgelaufen ({code_out or response.status_code}): {msg_out}")
        if response.status_code == 401:
            raise AuthentifizierungsFehler("OKX lehnt die Zugangsdaten ab (HTTP 401).")
        if response.status_code == 429:
            raise VerbindungVerloren("OKX-Ratenbegrenzung erreicht (HTTP 429).")
        if response.status_code >= 500:
            if is_order:
                raise OrderStatusUnklar(f"OKX-Order: Serverfehler HTTP {response.status_code}.")
            raise VerbindungVerloren(f"OKX-Serverfehler HTTP {response.status_code}.")

        if code == "0" and not detail_code:
            self._last_contact = datetime.now(timezone.utc).isoformat()
            return list(data)

        if code_out in _AUTH_CODES:
            raise AuthentifizierungsFehler(f"OKX-Zugangsfehler {code_out}: {msg_out}")
        if code_out in _RATE_CODES:
            raise VerbindungVerloren(f"OKX-Ueberlast {code_out}: {msg_out}")
        if is_order and code_out in _UNKLARE_ORDER_CODES:
            # v9.1: OKX sagt zu diesen Codes ausdruecklich, dass sie WEDER
            # Erfolg NOCH Misserfolg bedeuten. Sie duerfen deshalb nie als
            # Ablehnung durchgehen -- sonst vergisst der Bot eine Order, die
            # beim Broker liegt, und die Position bleibt ungeschuetzt.
            raise OrderStatusUnklar(
                f"OKX-Order: Ausgang unbestimmt ({code_out}): {msg_out}")
        if is_order:
            # Fachliche Ablehnung ist eindeutig: die Order wurde NICHT
            # angenommen. Das ist kein unklarer Zustand.
            raise BrokerFehler(f"OKX lehnt die Order ab ({code_out}): {msg_out}")
        raise BrokerFehler(f"OKX-Fehler {code_out}: {msg_out}")

    @staticmethod
    def _first_detail(data: list, *, erfolgscodes: frozenset = frozenset()) -> tuple[str, str]:
        """Die erste wirklich fehlgeschlagene Zeile einer Sammelantwort.

        v9.1: ``erfolgscodes`` erlaubt es dem Aufrufer, Codes als Erfolg zu
        werten, die es fachlich sind -- beim Stornieren etwa "Order existiert
        nicht mehr". Ohne das kippte eine einzige solche Zeile den ganzen
        Aufruf, obwohl das Ziel erreicht war.
        """
        for row in data or []:
            if not isinstance(row, dict):
                continue
            code = str(row.get("sCode", ""))
            if code in ("", "0") or code in erfolgscodes:
                continue
            return code, str(row.get("sMsg", ""))
        return "", ""

    @staticmethod
    def _alle_details(data: list) -> list[tuple[str, str]]:
        """Ergebnis JE ZEILE einer Sammelantwort (fuer Storno-Batches)."""
        return [(str(r.get("sCode", "0")), str(r.get("sMsg", "")))
                for r in data or [] if isinstance(r, dict) and "sCode" in r]

    # -- Oeffentliche Marktdaten -------------------------------------------
    def instruments(self, *, force: bool = False, max_age: float = 3600.0) -> dict[str, OKXInstrument]:
        """SPOT-Regeln; mit Zugangsdaten kontospezifisch samt tradeQuoteCcyList."""
        with self._lock:
            frisch = (time.time() - self._instruments_at) < max_age
            if self._instruments and frisch and not force:
                return dict(self._instruments)
        if self.hat_zugangsdaten:
            rows = self.request(
                "GET", "/account/instruments", params={"instType": "SPOT"},
                private=True)
        else:
            rows = self.request("GET", "/public/instruments", params={"instType": "SPOT"})
        gefunden = {}
        for row in rows:
            inst = OKXInstrument.from_api(row)
            if inst.inst_id:
                gefunden[inst.inst_id] = inst
        with self._lock:
            self._instruments = gefunden
            self._instruments_at = time.time()
        return dict(gefunden)

    def public_instruments(self, *, force: bool = False,
                           max_age: float = 3600.0) -> dict[str, OKXInstrument]:
        """Breiter oeffentlicher SPOT-Katalog fuer die Entdeckungsstufe.

        Dieser Katalog ist niemals ein Ausfuehrungsbeweis. Fuer Orders und
        den handelbaren Pool bleibt ``instruments()`` mit Zugangsdaten die
        autoritative kontospezifische Schnittmenge samt tradeQuoteCcyList.
        """
        with self._lock:
            frisch = (time.time() - self._public_instruments_at) < max_age
            if self._public_instruments and frisch and not force:
                return dict(self._public_instruments)
        rows = self.request(
            "GET", "/public/instruments", params={"instType": "SPOT"})
        gefunden = {}
        for row in rows:
            inst = OKXInstrument.from_api(row)
            if inst.inst_id:
                gefunden[inst.inst_id] = inst
        with self._lock:
            self._public_instruments = gefunden
            self._public_instruments_at = time.time()
        return dict(gefunden)

    def instrument(self, inst_id: str) -> Optional[OKXInstrument]:
        inst_id = normalize_inst_id(inst_id)
        alle = self.instruments()
        if inst_id in alle:
            return alle[inst_id]
        alle = self.instruments(force=True)
        return alle.get(inst_id)

    def tickers(self) -> dict[str, OKXTicker]:
        """Alle SPOT-Ticker in EINEM Aufruf.

        Genau das ist der guenstige Vorfilter aus dem CCXT-Lernpunkt: ein
        Request liefert Preis, Bid/Ask und 24h-Volumen fuer alle Maerkte.
        """
        rows = self.request("GET", "/market/tickers", params={"instType": "SPOT"})
        return {t.inst_id: t for t in (OKXTicker.from_api(r) for r in rows) if t.inst_id}

    def ticker(self, inst_id: str) -> Optional[OKXTicker]:
        rows = self.request("GET", "/market/ticker", params={"instId": normalize_inst_id(inst_id)})
        return OKXTicker.from_api(rows[0]) if rows else None

    def orderbook(self, inst_id: str, depth: int = 20) -> dict:
        rows = self.request("GET", "/market/books",
                            params={"instId": normalize_inst_id(inst_id), "sz": int(depth)})
        if not rows:
            return {"bids": [], "asks": []}
        row = rows[0]
        return {
            "bids": [(_f(p), _f(q)) for p, q, *_ in (row.get("bids") or [])],
            "asks": [(_f(p), _f(q)) for p, q, *_ in (row.get("asks") or [])],
            "timestamp_ms": int(_f(row.get("ts"), 0.0)),
        }

    def candles(self, inst_id: str, bar: str = "15m", limit: int = 300,
                *, nur_abgeschlossen: bool = True) -> pd.DataFrame:
        """Kerzen als DataFrame (aeltest zuerst) mit UTC-Zeitindex.

        OKX markiert die laufende Kerze mit confirm='0'. Genau diese Kerze
        darf niemals in ein Signal einfliessen, sonst entsteht Repainting:
        ein Signal, das im Backtest existiert, live aber nie so aussah.
        """
        inst_id = normalize_inst_id(inst_id)
        limit = max(1, min(300, int(limit)))
        rows = self.request("GET", "/market/candles",
                            params={"instId": inst_id, "bar": bar, "limit": limit})
        if not rows:
            return pd.DataFrame(columns=["open", "high", "low", "close", "volume"])

        datensaetze = []
        for row in rows:
            if len(row) < 6:
                continue
            confirm = str(row[8]) if len(row) > 8 else "1"
            if nur_abgeschlossen and confirm == "0":
                continue
            datensaetze.append({
                "date": pd.to_datetime(int(_f(row[0], 0.0)), unit="ms", utc=True),
                "open": _f(row[1]), "high": _f(row[2]), "low": _f(row[3]),
                "close": _f(row[4]), "volume": _f(row[5]),
                "quote_volume": _f(row[7]) if len(row) > 7 else 0.0,
            })
        if not datensaetze:
            return pd.DataFrame(columns=["open", "high", "low", "close", "volume"])
        df = pd.DataFrame(datensaetze).sort_values("date").set_index("date")
        return df[["open", "high", "low", "close", "volume", "quote_volume"]]

    def historical_candles(self, inst_id: str, bar: str = "15m", limit: int = 100,
                           *, end_ms: int | None = None,
                           nur_abgeschlossen: bool = True) -> pd.DataFrame:
        """Abgeschlossene historische Kerzen bis zu einem Zeitstempel.

        Ausschliesslich fuer rueckblickende Diagnose/Charts. Der Endpunkt ist
        oeffentlich und besitzt keinerlei Order- oder Kontorechte. OKX nennt
        den Cursor ``after``: Er liefert Kerzen, die aelter als ``end_ms`` sind.
        """
        inst_id = normalize_inst_id(inst_id)
        limit = max(1, min(100, int(limit)))
        params = {"instId": inst_id, "bar": bar, "limit": limit}
        if end_ms is not None:
            params["after"] = int(end_ms)
        rows = self.request("GET", "/market/history-candles", params=params)
        datensaetze = []
        for row in rows or []:
            if len(row) < 6:
                continue
            confirm = str(row[8]) if len(row) > 8 else "1"
            if nur_abgeschlossen and confirm == "0":
                continue
            datensaetze.append({
                "date": pd.to_datetime(int(_f(row[0], 0.0)), unit="ms", utc=True),
                "open": _f(row[1]), "high": _f(row[2]), "low": _f(row[3]),
                "close": _f(row[4]), "volume": _f(row[5]),
                "quote_volume": _f(row[7]) if len(row) > 7 else 0.0,
            })
        if not datensaetze:
            return pd.DataFrame(columns=["open", "high", "low", "close", "volume", "quote_volume"])
        df = pd.DataFrame(datensaetze).drop_duplicates("date").sort_values("date").set_index("date")
        return df[["open", "high", "low", "close", "volume", "quote_volume"]]

    def server_time_ms(self) -> int:
        lokal_vorher = time.time()
        rows = self.request("GET", "/public/time")
        lokal_nachher = time.time()
        server_ms = int(_f(rows[0].get("ts"), 0.0)) if rows else 0
        if server_ms:
            lokal_mitte = (lokal_vorher + lokal_nachher) / 2.0
            self._clock_offset_seconds = (server_ms / 1000.0) - lokal_mitte
        return server_ms

    @property
    def clock_offset_seconds(self) -> float:
        return float(self._clock_offset_seconds)

    # -- Konto --------------------------------------------------------------
    def balances(self) -> dict[str, dict]:
        """Guthaben je Waehrung: {'EUR': {'cash':..,'frozen':..,'eq_usd':..}}"""
        rows = self.request("GET", "/account/balance", private=True)
        out: dict[str, dict] = {}
        for konto in rows:
            for detail in konto.get("details") or []:
                ccy = str(detail.get("ccy", "")).upper()
                if not ccy:
                    continue
                out[ccy] = {
                    "cash": _f(detail.get("availBal")),
                    "gesamt": _f(detail.get("cashBal")) or _f(detail.get("eq")),
                    "frozen": _f(detail.get("frozenBal")),
                    "eq_usd": _f(detail.get("eqUsd")),
                }
        return out

    def total_equity_usd(self) -> float:
        rows = self.request("GET", "/account/balance", private=True)
        if not rows:
            return 0.0
        return _f(rows[0].get("totalEq"))

    def trade_fee(self, inst_type: str = "SPOT", inst_id: str = "") -> dict:
        """Der tatsaechliche Gebuehrensatz dieses Kontos.

        OKX liefert Maker/Taker als NEGATIVE Bruchzahlen ("-0.0035" = 0,35 %).
        Bis v8.1.3 nahm der Bot pauschal 0,10 % an -- das ist der Tarif MIT
        eroeffnetem Derivate-Konto (X-Perps). Ohne eines sind es 0,35 %, und
        die Kostenhuerde war damit nur halb so hoch wie noetig.
        """
        params = {"instType": str(inst_type or "SPOT").upper()}
        if inst_id:
            params["instId"] = normalize_inst_id(inst_id)
        rows = self.request("GET", "/account/trade-fee", params=params, private=True)
        if not rows:
            return {}
        zeile = rows[0]
        return {
            "maker": abs(_f(zeile.get("maker"))),
            "taker": abs(_f(zeile.get("taker"))),
            "stufe": str(zeile.get("level", "") or ""),
        }

    def account_config(self) -> dict:
        rows = self.request("GET", "/account/config", private=True)
        return dict(rows[0]) if rows else {}

    def account_snapshot(self, *, fills_limit: int = 20) -> dict:
        """Vollstaendige, aber ausschliesslich lesende OKX-Kontoaufnahme.

        Der normale Handelszyklus verwendet weiter gezielte, sparsame
        Einzelaufrufe. Diese Aufnahme ist nur fuer ``crypto_diagnose --voll``
        gedacht: Sie macht sichtbar, ob EEA-Demo, Guthaben, Gebuehren,
        Standardorders, beide Schutzorderarten und Fills wirklich vom selben
        Konto gelesen werden. Ein einzelner optionaler Endpunkt macht die
        Diagnose nicht unbrauchbar; er steht stattdessen unter ``fehler``.
        """
        fehler: dict[str, str] = {}

        def lese(name: str, fn, standard):
            try:
                return fn()
            except Exception as exc:
                fehler[name] = type(exc).__name__
                return standard

        konto = lese("konto_config", self.account_config, {})
        snapshot = {
            "zeit": datetime.now(timezone.utc).isoformat(),
            "eea_endpoint": self.base_url,
            "demo": self.demo,
            "konto_config": {
                # Keine Geheimnisse und keine UID: nur die Betriebsmerkmale,
                # die fuer Spot-/Key-Pruefung relevant sind.
                "acctLv": str(konto.get("acctLv", "") or ""),
                "posMode": str(konto.get("posMode", "") or ""),
                "perm": konto.get("perm") or "",
            },
            "guthaben": lese("guthaben", self.balances, {}),
            "equity_usd": lese("equity_usd", self.total_equity_usd, 0.0),
            "gebuehren": lese("gebuehren", lambda: self.trade_fee("SPOT"), {}),
            "offene_standard_orders": lese("offene_standard_orders", self.pending_orders, []),
            "schutzorders_oco": lese(
                "schutzorders_oco", lambda: self.pending_algo_orders(ord_type="oco"), []),
            "schutzorders_conditional": lese(
                "schutzorders_conditional",
                lambda: self.pending_algo_orders(ord_type="conditional"), []),
            "letzte_fills": lese(
                "letzte_fills", lambda: self.fills(limit=max(1, min(100, int(fills_limit)))), []),
        }
        snapshot["fehler"] = fehler
        snapshot["vollstaendig"] = not bool(fehler)
        return snapshot

    # -- Orders -------------------------------------------------------------
    def place_order(self, body: dict) -> dict:
        rows = self.request("POST", "/trade/order", body=body, private=True, is_order=True)
        return rows[0] if rows else {}

    def order_status(self, inst_id: str, *, ord_id: str = "", cl_ord_id: str = "") -> dict:
        params = {"instId": normalize_inst_id(inst_id)}
        if ord_id:
            params["ordId"] = ord_id
        elif cl_ord_id:
            params["clOrdId"] = cl_ord_id
        else:
            raise BrokerFehler("Orderabfrage ohne ordId/clOrdId ist nicht moeglich.")
        rows = self.request("GET", "/trade/order", params=params, private=True)
        return rows[0] if rows else {}

    def pending_orders(self, inst_id: str = "") -> list[dict]:
        params = {"instType": "SPOT"}
        if inst_id:
            params["instId"] = normalize_inst_id(inst_id)
        return self.request("GET", "/trade/orders-pending", params=params, private=True)

    def cancel_order(self, inst_id: str, ord_id: str) -> dict:
        rows = self.request("POST", "/trade/cancel-order",
                            body={"instId": normalize_inst_id(inst_id), "ordId": str(ord_id)},
                            private=True, is_order=True)
        return rows[0] if rows else {}

    def place_algo_order(self, body: dict) -> dict:
        rows = self.request("POST", "/trade/order-algo", body=body, private=True, is_order=True)
        return rows[0] if rows else {}

    def pending_algo_orders(self, inst_id: str = "", ord_type: str = "oco") -> list[dict]:
        params = {"instType": "SPOT", "ordType": ord_type}
        if inst_id:
            params["instId"] = normalize_inst_id(inst_id)
        return self.request("GET", "/trade/orders-algo-pending", params=params, private=True)

    def algo_order_details(self, algo_id: str) -> dict:
        """Eine Algo-Order samt eventuell erzeugter normaler ordId."""
        if not str(algo_id or "").strip():
            return {}
        rows = self.request("GET", "/trade/order-algo",
                            params={"algoId": str(algo_id)}, private=True)
        return rows[0] if rows else {}

    def cancel_algo_orders(self, eintraege: list[dict]) -> list[dict]:
        if not eintraege:
            return []
        return self.request("POST", "/trade/cancel-algos", body=eintraege,
                            private=True, is_order=True)

    def amend_algo_order(self, body: dict) -> dict:
        rows = self.request("POST", "/trade/amend-algos", body=body,
                            private=True, is_order=True)
        return rows[0] if rows else {}

    def fills(self, inst_id: str = "", limit: int = 100) -> list[dict]:
        params = {"instType": "SPOT", "limit": str(max(1, min(100, int(limit))))}
        if inst_id:
            params["instId"] = normalize_inst_id(inst_id)
        return self.request("GET", "/trade/fills", params=params, private=True)

    def fills_history(self, inst_id: str = "", *, limit: int = 100,
                      after: str = "", before: str = "") -> list[dict]:
        """Archivierte Spot-Fills (OKX: bis zu drei Monate) seitenweise."""
        params = {"instType": "SPOT", "limit": str(max(1, min(100, int(limit))))}
        if inst_id:
            params["instId"] = normalize_inst_id(inst_id)
        if after:
            params["after"] = str(after)
        if before:
            params["before"] = str(before)
        return self.request("GET", "/trade/fills-history", params=params, private=True)

    def fills_history_paginated(self, inst_id: str = "", *,
                                max_pages: int = 20) -> list[dict]:
        """Historie vollstaendig, dedupliziert und mit Endlosschleifenschutz."""
        rows: list[dict] = []
        seen_ids: set[str] = set()
        after = ""
        for _page in range(max(1, int(max_pages))):
            batch = self.fills_history(inst_id, limit=100, after=after)
            fresh = []
            for row in batch:
                fid = str(row.get("tradeId") or "")
                key = fid or f"{row.get('ordId')}:{row.get('ts')}:{row.get('fillSz')}"
                if key in seen_ids:
                    continue
                seen_ids.add(key); fresh.append(dict(row))
            rows.extend(fresh)
            if len(batch) < 100 or not fresh:
                break
            # v9.1: OKX paginiert /trade/fills[-history] ueber billId, nicht
            # ueber tradeId. Mit dem falschen Cursor war ab Seite 2 Schluss --
            # genau im Beweispfad fuer extern ausgefuehrte Verkaeufe.
            next_after = str(batch[-1].get("billId") or "")
            if not next_after or next_after == after:
                break
            after = next_after
        return rows


# ---------------------------------------------------------------------------
# Broker-Adapter
# ---------------------------------------------------------------------------
class OKXBroker(BrokerBase):
    """OKX-Spot-Adapter fuer den Geldpfad.

    Der Adapter handelt ausschliesslich SPOT im Cash-Modus (tdMode='cash').
    Margin, Futures, Swaps und Optionen sind bewusst NICHT umgesetzt: sie
    koennen ein Konto ueber den Einsatz hinaus belasten, was der Bot
    strukturell nicht absichern kann.
    """

    name = "OKX"

    def __init__(self, *, api_key: str = "", api_secret: str = "",
                 passphrase: str = "", demo: Optional[bool] = None,
                 quote_ccy: str = "", allowed_quotes: Optional[Iterable[str]] = None,
                 client: Optional[OKXClient] = None):
        import config

        if demo is None:
            demo = not bool(getattr(config, "OKX_LIVE_TRADING", False))
        self.demo = bool(demo)
        self.quote_ccy = str(quote_ccy or getattr(config, "OKX_QUOTE_CCY", "EUR")).upper()
        configured = allowed_quotes or getattr(
            config, "OKX_ALLOWED_QUOTE_CCY", ("EUR", "USD", "USDC"))
        self.allowed_quotes = tuple(dict.fromkeys(
            str(x).upper() for x in configured
            if str(x).upper() in {"EUR", "USD", "USDC"}
        )) or ("EUR", "USD", "USDC")
        if self.quote_ccy not in self.allowed_quotes:
            self.quote_ccy = self.allowed_quotes[0]
        self.max_clock_drift = float(getattr(config, "OKX_MAX_CLOCK_DRIFT_SECONDS", 25.0))

        if client is not None:
            self.client = client
        else:
            key = api_key or self._cfg(config, "OKX_DEMO_API_KEY", "OKX_API_KEY")
            secret = api_secret or self._cfg(config, "OKX_DEMO_API_SECRET", "OKX_API_SECRET")
            phrase = passphrase or self._cfg(config, "OKX_DEMO_API_PASSPHRASE", "OKX_API_PASSPHRASE")
            self.client = OKXClient(
                key, secret, phrase, demo=self.demo,
                base_url=str(getattr(config, "OKX_BASE_URL", OKX_BASE_URL)),
                timeout=float(getattr(config, "OKX_TIMEOUT_SECONDS", 15.0)),
            )

        self._connected = False
        self._equity_cache: tuple[float, float] = (0.0, 0.0)
        # Gemessener Taker-Satz (Wert, Zeitpunkt). Wird stuendlich erneuert.
        self._gebuehr_cache: tuple[float, float] = (0.0, 0.0)
        # Ergebnis der letzten Stornierung -- damit ein Fehlschlag nicht nur
        # im Protokoll steht, sondern gemeldet werden kann.
        self.letzte_stornierung: dict = {}
        self._last_health = 0.0
        self._lock = threading.RLock()
        self._stream = None
        self._account_fingerprint = ""
        self._last_rest_balance_at = 0.0
        self._rest_balance_cache: dict[str, dict] = {}
        self._quote_rate_cache: tuple[float, dict[tuple[str, str], float]] = (0.0, {})
        self._health_failures = 0
        self._health_state = "OFFLINE"
        self._health_detail = "noch nicht verbunden"
        self._last_health_success_at = 0.0

    def _trade_quote_ccy(self, meta: OKXInstrument, *, require_cash: bool = False) -> str:
        """Zulaessige Abrechnungswaehrung fuer genau dieses Instrument.

        Ein USD-Markt ist bei OKX Unified USD nicht auf USD-Guthaben
        beschraenkt. Entscheidend ist tradeQuoteCcyList. Ohne explizite Liste
        gilt aus Kompatibilitaetsgruenden nur die normale quoteCcy.
        """
        accepted = tuple(dict.fromkeys(
            str(x).upper() for x in (meta.trade_quote_ccy_list or (meta.quote_ccy,))
            if str(x).strip()
        ))
        permitted = tuple(self.allowed_quotes)
        if not set(accepted).intersection(permitted):
            raise BrokerFehler(
                f"{meta.inst_id}: keine erlaubte tradeQuoteCcy; OKX meldet "
                f"{', '.join(accepted) or 'keine'}, Bot erlaubt "
                f"{', '.join(permitted) or 'keine'}."
            )
        candidates = tuple(dict.fromkeys(
            [self.quote_ccy, *self.allowed_quotes]
        ))
        balances = self.client.balances() if require_cash else {}
        for ccy in candidates:
            if ccy not in accepted or ccy not in permitted:
                continue
            if require_cash and float((balances.get(ccy) or {}).get("cash", 0.0) or 0.0) <= 0:
                continue
            return ccy
        if require_cash:
            raise BrokerFehler(
                f"{meta.inst_id}: keine der von OKX erlaubten Abrechnungswaehrungen "
                f"({', '.join(accepted) or 'keine'}) besitzt frei verfuegbares Guthaben."
            )
        raise BrokerFehler(
            f"{meta.inst_id}: keine erlaubte tradeQuoteCcy; OKX meldet "
            f"{', '.join(accepted) or 'keine'}."
        )

    def _cfg(self, config, demo_name: str, live_name: str) -> str:
        """Demo- und Live-Schluessel sind strikt getrennt.

        Ein versehentlich im Live-Feld hinterlegter Demo-Key darf niemals
        still fuer den anderen Modus verwendet werden.
        """
        name = demo_name if self.demo else live_name
        return str(getattr(config, name, "") or "").strip()

    # -- Verbindung ---------------------------------------------------------
    def connect(self) -> bool:
        if not self.client.hat_zugangsdaten:
            raise AuthentifizierungsFehler(
                "OKX-Zugangsdaten fehlen. Bitte API-Key, Secret und Passphrase "
                f"fuer den {'Demo' if self.demo else 'Live'}-Modus hinterlegen."
            )
        server_ms = self.client.server_time_ms()
        drift = abs(float(getattr(self.client, "clock_offset_seconds", 0.0))) \
            if server_ms else float("inf")
        if drift > self.max_clock_drift:
            raise Zeitabweichung(
                f"OKX {'DEMO' if self.demo else 'LIVE'} voruebergehend blockiert: "
                f"Systemzeit weicht {drift:.1f} s ab (Maximum "
                f"{self.max_clock_drift:.1f} s). NTP synchronisieren; der Bot versucht "
                "die Verbindung automatisch erneut."
            )

        # Private Aufrufe beweisen, dass Schluessel UND Passphrase stimmen.
        self.client.instruments(force=True)
        account_cfg = self.client.account_config()
        # Nur ein irreversibler Hash wird persistiert. Dadurch kann ein
        # importierter Trade nicht still mit Demo/Live oder einem anderen
        # Unterkonto vermischt werden, ohne UID/Schluessel preiszugeben.
        account_marker = "|".join((
            "demo" if self.demo else "live", str(self.client.base_url),
            str(account_cfg.get("uid") or account_cfg.get("mainUid") or ""),
            str(account_cfg.get("subAcct") or account_cfg.get("label") or ""),
        ))
        self._account_fingerprint = hashlib.sha256(
            account_marker.encode("utf-8")).hexdigest()[:24]
        raw_permissions = account_cfg.get("perm") or ""
        if isinstance(raw_permissions, (list, tuple, set)):
            permission_items = raw_permissions
        else:
            permission_items = str(raw_permissions).replace(";", ",").split(",")
        permissions = {str(item).strip().lower() for item in permission_items if str(item).strip()}
        if not self.demo and "withdraw" in permissions:
            raise AuthentifizierungsFehler(
                "OKX LIVE blockiert: Der API-Key besitzt Withdraw-Rechte. "
                "Bitte einen Key nur mit Read + Trade anlegen."
            )
        if not self.demo and permissions and "trade" not in permissions:
            raise AuthentifizierungsFehler("OKX LIVE blockiert: Dem API-Key fehlt Trade-Recht.")
        equity = self.client.total_equity_usd()
        with self._lock:
            self._equity_cache = (float(equity), time.time())
            self._connected = True
            self._health_failures = 0
            self._health_state = "ONLINE"
            self._health_detail = "REST authentifiziert"
            self._last_health_success_at = time.time()
        self._start_stream_best_effort()
        logger.info("OKX verbunden (%s), Kontowert %.2f USD",
                    "DEMO" if self.demo else "LIVE", equity)
        return True

    def account_fingerprint(self) -> str:
        return str(self._account_fingerprint or "")

    def protection_exit_order_ids(self, algo_id: str) -> set[str]:
        """Vom Broker belegte normale Order-IDs einer Schutzorder."""
        try:
            row = self.client.algo_order_details(str(algo_id or ""))
        except BrokerFehler:
            return set()
        ids: set[str] = set()
        direct = str(row.get("ordId") or "").strip()
        if direct:
            ids.add(direct)
        raw_list = row.get("ordIdList") or row.get("ordIds") or []
        if isinstance(raw_list, str):
            raw_list = [x for x in re.split(r"[,;\s]+", raw_list) if x]
        for value in raw_list if isinstance(raw_list, (list, tuple, set)) else []:
            if isinstance(value, dict):
                value = value.get("ordId")
            if str(value or "").strip():
                ids.add(str(value).strip())
        return ids

    def historical_fills(self, symbol: str, *, since: str = "") -> list[dict]:
        """Alle archivierten Fills eines Basiswerts seit einem UTC-Zeitpunkt."""
        rows = self.client.fills_history_paginated(
            max_pages=int(getattr(__import__("config"), "OKX_FILL_HISTORY_MAX_PAGES", 20)))
        wanted = str(symbol or "").upper()
        since_ms = 0
        if since:
            try:
                dt = datetime.fromisoformat(str(since).replace("Z", "+00:00"))
                if dt.tzinfo is None:
                    dt = dt.replace(tzinfo=timezone.utc)
                since_ms = int(dt.timestamp() * 1000)
            except (TypeError, ValueError):
                since_ms = 0
        result = [
            dict(row) for row in rows
            if base_currency(str(row.get("instId") or "")) == wanted
            and int(_f(row.get("ts"), 0.0)) >= since_ms
        ]
        result.sort(key=lambda x: (int(_f(x.get("ts"), 0.0)),
                                   str(x.get("tradeId") or "")))
        return result

    def external_exit_evidence(self, *, inst_id: str, since: str,
                               expected_qty: float) -> dict:
        """Belegt einen broker-/manuell ausgefuehrten Verkauf mit echten Fills.

        Symbolnaehe allein reicht nicht: Instrument, Richtung, Zeitpunkt,
        tradeId und die fast vollstaendige Sollmenge muessen zusammenpassen.
        """
        inst_id = normalize_inst_id(inst_id)
        meta = self.client.instrument(inst_id)
        if meta is None:
            return {}
        archived = self.historical_fills(meta.base_ccy, since=since)
        try:
            recent = self.client.fills(inst_id, limit=100)
        except BrokerFehler:
            recent = []
        since_ms = 0
        try:
            opened = datetime.fromisoformat(str(since).replace("Z", "+00:00"))
            if opened.tzinfo is None:
                opened = opened.replace(tzinfo=timezone.utc)
            since_ms = int(opened.timestamp() * 1000)
        except (TypeError, ValueError):
            pass
        combined: dict[str, dict] = {}
        for row in [*archived, *recent]:
            key = str(row.get("tradeId") or "")
            if key and int(_f(row.get("ts"), 0.0)) >= since_ms:
                combined[key] = dict(row)
        rows = [row for row in combined.values()
                if normalize_inst_id(str(row.get("instId") or "")) == inst_id
                and str(row.get("side") or "").lower() == "sell"
                and str(row.get("tradeId") or "").strip()]
        rows.sort(key=lambda row: (int(_f(row.get("ts"), 0.0)),
                                   str(row.get("tradeId") or "")))
        if not rows:
            return {}
        # Nur die juengste, zur aktuell verschwundenen Buchmenge passende
        # Verkaufsgruppe verwenden. Aeltere Teilverkaeufe duerfen weder
        # Menge noch Gebuehren ein zweites Mal in diesen Abschluss tragen.
        selected: list[dict] = []
        selected_qty = 0.0
        target = max(0.0, float(expected_qty or 0.0))
        for row in reversed(rows):
            rest = target - selected_qty if target > 0 else _f(row.get("fillSz"))
            menge = _f(row.get("fillSz"))
            if target > 0 and menge > rest > 0:
                # v9.1: Die Zeile, die die Zielmenge ueberschreitet, wird
                # ANTEILIG gekuerzt statt vollstaendig uebernommen. Vorher
                # hing die Schleife die Zeile immer erst an und prueft danach
                # -- ein bereits abgerechneter Teilverkauf floss damit
                # vollstaendig in Menge, Durchschnittspreis und Gebuehren
                # dieses Abschlusses ein. Genau das verbietet der Kommentar
                # zwei Absaetze weiter oben.
                anteil = rest / menge if menge > 0 else 0.0
                gekuerzt = dict(row)
                gekuerzt["fillSz"] = rest
                if _f(row.get("fee")):
                    gekuerzt["fee"] = _f(row.get("fee")) * anteil
                gekuerzt["_anteilig_gekuerzt"] = True
                selected.append(gekuerzt)
                selected_qty += rest
                break
            selected.append(row)
            selected_qty += menge
            if target > 0 and selected_qty + max(_f(meta.lot_size), target * 0.001) >= target:
                break
        rows = list(reversed(selected))
        quantity = sum(_f(row.get("fillSz")) for row in rows)
        lot = max(_f(meta.lot_size), 1e-12)
        expected = target
        if expected <= 0 or quantity + max(lot, expected * 0.001) < expected:
            return {}
        weighted = sum(_f(row.get("fillSz")) * _f(row.get("fillPx")) for row in rows)
        average = weighted / quantity if quantity > 0 else 0.0
        fees: dict[str, float] = {}
        fee_quote = 0.0
        for row in rows:
            ccy = str(row.get("feeCcy") or "").upper()
            cost = -_f(row.get("fee"))
            if not ccy or cost == 0:
                continue
            fees[ccy] = fees.get(ccy, 0.0) + cost
            if ccy == meta.base_ccy:
                fee_quote += cost * average
            elif ccy == meta.quote_ccy:
                fee_quote += cost
            else:
                # v9.1: Eine Gebuehr in einer DRITTEN erlaubten Waehrung wurde
                # bisher 1:1 zur Quote addiert -- eine EUR-Gebuehr auf einem
                # USD-Markt landete ungerechnet in fees_quote. Sie bleibt
                # weiterhin einzeln in ``fees`` sichtbar, faelscht aber die
                # Quotesumme nicht mehr. Genau die Regel "USD ist nicht USDC",
                # die der Rest des Codes strikt einhaelt.
                logger.info(
                    "Gebuehr in %s auf dem Markt %s wird nicht in die "
                    "Quotesumme uebernommen (kein beobachteter Kurs).",
                    ccy, inst_id)
        return {
            "confirmed": True, "inst_id": inst_id, "quantity": quantity,
            "avg_price": average, "fees": fees, "fees_quote": fee_quote,
            "fill_ids": [str(row.get("tradeId")) for row in rows],
            "order_ids": sorted({str(row.get("ordId")) for row in rows if row.get("ordId")}),
            "closed_at": datetime.fromtimestamp(
                max(int(_f(row.get("ts"), 0.0)) for row in rows) / 1000.0,
                tz=timezone.utc).isoformat(),
        }

    def order_fills(self, inst_id: str, ord_id: str, *, expected_qty: float = 0.0,
                    attempts: int = 4) -> list[dict]:
        """Echte OKX-Transaktionen genau einer Order, nach tradeId dedupliziert."""
        inst_id = normalize_inst_id(inst_id)
        ord_id = str(ord_id or "")
        found: dict[str, dict] = {}
        for attempt in range(max(1, int(attempts))):
            try:
                rows = self.client.fills(inst_id, limit=100)
            except BrokerFehler:
                rows = []
            for row in rows:
                if str(row.get("ordId") or "") != ord_id:
                    continue
                fill_id = str(row.get("tradeId") or "")
                if fill_id:
                    found[fill_id] = dict(row)
            total = sum(_f(row.get("fillSz")) for row in found.values())
            if found and (expected_qty <= 0 or total >= expected_qty - max(1e-12, expected_qty * 1e-9)):
                break
            if attempt + 1 < max(1, int(attempts)):
                time.sleep(0.45 * (attempt + 1))
        if not found:
            try:
                archived = self.client.fills_history_paginated(inst_id, max_pages=3)
            except BrokerFehler:
                archived = []
            for row in archived:
                if str(row.get("ordId") or "") == ord_id and str(row.get("tradeId") or ""):
                    found[str(row["tradeId"])] = dict(row)
        return sorted(found.values(), key=lambda row: (
            int(_f(row.get("ts") or row.get("fillTime"), 0.0)),
            str(row.get("tradeId") or "")))

    def _order_result_from_evidence(self, *, meta: OKXInstrument, status: dict,
                                    cl_ord_id: str, requested_qty: float,
                                    reference_price: float) -> OrderErgebnis:
        """Orderstatus und echte tradeId-Fills zu einem Beweis zusammenfuehren."""
        ord_id = str(status.get("ordId") or "")
        gross_status = _f(status.get("accFillSz"))
        fills = self.order_fills(meta.inst_id, ord_id, expected_qty=gross_status) if ord_id else []
        gross_fills = sum(_f(row.get("fillSz")) for row in fills)
        gross = gross_fills or gross_status
        weighted = sum(_f(row.get("fillSz")) * _f(row.get("fillPx")) for row in fills)
        avg = (weighted / gross_fills if gross_fills > 0 else
               _f(status.get("avgPx")) or float(reference_price or 0.0))
        fees: dict[str, float] = {}
        base_fee_delta = 0.0
        quote_fee_value = 0.0
        for row in fills:
            ccy = str(row.get("feeCcy") or "").upper()
            raw_fee = _f(row.get("fee"))
            if not ccy or raw_fee == 0:
                continue
            cost = -raw_fee  # OKX: negative=Gebuehr, positiv=Rabatt
            fees[ccy] = fees.get(ccy, 0.0) + cost
            if ccy == meta.base_ccy:
                base_fee_delta += raw_fee
                quote_fee_value += cost * avg
            elif ccy == meta.quote_ccy:
                quote_fee_value += cost
            else:
                # v9.1: keine ungerechnete Fremdwaehrung in der Quotesumme.
                # Sie bleibt in ``fees`` einzeln sichtbar.
                logger.info("Gebuehr in %s bleibt ausserhalb der Quotesumme "
                            "des Marktes %s.", ccy, meta.inst_id)
        net = max(0.0, gross + base_fee_delta)
        state = str(status.get("state") or "unknown").lower()
        terminal = state in {"filled", "canceled", "cancelled", "rejected", "expired", "mmp_canceled"}
        tolerance = max(1e-12, gross_status * 1e-9)
        evidence_complete = bool(
            terminal and ((gross_status <= 0 and gross_fills <= 0) or
                          (fills and (gross_status <= 0 or
                                      abs(gross_fills - gross_status) <= tolerance))))
        trade_quote = str(status.get("tradeQuoteCcy") or
                          self._trade_quote_ccy(meta, require_cash=False))
        return OrderErgebnis(
            order_ids=[ord_id] if ord_id else [], status=state,
            filled_quantity=net, gross_filled_quantity=gross,
            avg_fill_price=avg, reference_id=cl_ord_id,
            client_order_id=cl_ord_id,
            order_tag=str(status.get("tag") or getattr(__import__("config"), "OKX_ORDER_TAG", "NEXUS"))[:16],
            position_ids=[meta.inst_id], paper=self.demo,
            requested_quantity=float(requested_qty or 0.0),
            remaining_quantity=max(0.0, float(requested_qty or 0.0) - gross),
            terminal=terminal, raw_status=state, trade_quote_ccy=trade_quote,
            fills=[dict(row) for row in fills],
            fill_ids=[str(row.get("tradeId")) for row in fills if str(row.get("tradeId") or "")],
            fill_evidence_complete=evidence_complete,
            fees={key: round(value, 16) for key, value in fees.items()},
            fees_quote=float(quote_fee_value or 0.0),
            # v9.3: Alles, was den Ausgang nachtraeglich erklaert. Bis 9.2
            # landete davon nur ein Satz Freitext im Hinweis -- cancelSource
            # und sCode wurden verworfen.
            execution_evidence={
                "ord_id": ord_id,
                "cl_ord_id": cl_ord_id,
                "inst_id": meta.inst_id,
                "ord_type": str(status.get("ordType") or ""),
                "requested_qty": float(requested_qty or 0.0),
                "filled_qty": float(gross or 0.0),
                "limit_price": _f(status.get("px")) or float(reference_price or 0.0),
                "avg_price": float(avg or 0.0),
                "state": state,
                "cancel_source": str(status.get("cancelSource") or ""),
                "cancel_source_reason": str(status.get("cancelSourceReason") or ""),
                "s_code": str(status.get("sCode") or ""),
                "s_msg": str(status.get("sMsg") or status.get("msg") or ""),
                "broker_time_ms": str(status.get("uTime") or status.get("cTime") or ""),
            },
        )

    def reconcile_order_evidence(self, intent: dict) -> OrderErgebnis | None:
        """Persistierte clOrdId/ordId ohne zweiten POST gegen OKX klaeren."""
        inst_id = normalize_inst_id(intent.get("inst_id") or "")
        meta = self.client.instrument(inst_id)
        if meta is None:
            return None
        ord_id = str(intent.get("ord_id") or intent.get("order_id") or "")
        cl_ord_id = str(intent.get("cl_ord_id") or intent.get("client_order_id") or
                        intent.get("reference_id") or "")
        try:
            status = self.client.order_status(
                inst_id, ord_id=ord_id, cl_ord_id="" if ord_id else cl_ord_id)
        except BrokerFehler:
            return None
        if not status:
            return None
        result = self._order_result_from_evidence(
            meta=meta, status=status, cl_ord_id=cl_ord_id,
            requested_qty=float(intent.get("qty") or 0.0),
            reference_price=float(intent.get("signal_price") or 0.0))
        if result.fill_evidence_complete and result.filled_quantity > 0:
            protection = self.reconcile_position_protection(
                meta.inst_id, result.filled_quantity,
                float(intent.get("stop") or 0.0),
                float(intent.get("take") or intent.get("take_profit") or 0.0))
            confirmed = bool(protection.get("protection_confirmed"))
            result.stop_order_platziert = confirmed
            result.take_order_platziert = confirmed
            result.hinweis = str(protection.get("detail") or "")
        return result

    def _start_stream_best_effort(self) -> None:
        """Account-/Orderstream starten; REST bleibt bei jedem Fehler nutzbar."""
        try:
            from .okx_stream import OKXPrivateStream
            self._stream = OKXPrivateStream(
                getattr(self.client, "_key", ""), getattr(self.client, "_secret", ""),
                getattr(self.client, "_passphrase", ""),
                demo=self.demo,
                time_offset_seconds=float(getattr(
                    self.client, "clock_offset_seconds", 0.0)),
            )
            if not self._stream.start():
                logger.warning("OKX-Privatstream nicht gestartet; REST-Fallback aktiv.")
        except Exception as exc:
            self._stream = None
            logger.warning("OKX-Privatstream nicht verfuegbar (%s); REST-Fallback aktiv.",
                           type(exc).__name__)

    def disconnect(self) -> None:
        with self._lock:
            self._connected = False
        if self._stream is not None:
            try:
                self._stream.stop()
            except Exception:
                logger.debug("OKX-Stream-Stopp fehlgeschlagen", exc_info=True)
        try:
            self.client.session.close()
        except Exception:
            logger.debug("Best-effort-Ausnahme unterdrueckt", exc_info=True)

    def is_connected(self) -> bool:
        return bool(self._connected)

    def health_check(self, force: bool = False) -> bool:
        """Authentifizierter Kontotest mit echtem DEGRADED-Zwischenzustand.

        Ein einzelner Timeout ist kein Verbindungsabbruch. Nur harte
        Authentifizierungs-/Zeitfehler oder mehrere REST-Fehler in Folge
        setzen den Broker offline.
        """
        now = time.monotonic()
        import config
        ttl = float(getattr(config, "BROKER_HEALTHCHECK_SECONDS", 30))
        if not force and self._connected and now - self._last_health < ttl:
            return True
        try:
            server_ms = self.client.server_time_ms()
            drift = abs(float(getattr(self.client, "clock_offset_seconds", 0.0))) \
                if server_ms else float("inf")
            if drift > self.max_clock_drift:
                raise Zeitabweichung(
                    f"OKX-Systemzeit weicht {drift:.1f} s ab; NTP wird benoetigt.")
            # Ein oeffentlicher Zeitabruf allein beweist weder Key noch Konto.
            self.client.account_config()
            self._last_health = now
            self._connected = True
            self._health_failures = 0
            self._health_state = "ONLINE"
            self._health_detail = "REST authentifiziert"
            self._last_health_success_at = time.time()
            try:
                from decision_analytics import heartbeat_record
                heartbeat_record("okx", "ONLINE", self._health_detail,
                                 last_contact=self.last_contact())
            except Exception:
                logger.debug("OKX-Heartbeat nicht persistierbar", exc_info=True)
            return True
        except Exception as exc:
            self._health_failures += 1
            hard = isinstance(exc, (AuthentifizierungsFehler, Zeitabweichung))
            threshold = max(2, int(getattr(config, "OKX_HEALTH_FAILURE_THRESHOLD", 3)))
            offline = hard or self._health_failures >= threshold
            self._connected = not offline
            self._health_state = "OFFLINE" if offline else "DEGRADED"
            self._health_detail = (
                f"REST-Pruefung {self._health_failures}/{threshold} fehlgeschlagen: "
                f"{type(exc).__name__}: {exc}")
            logger.warning("OKX %s: %s", self._health_state, self._health_detail)
            try:
                from decision_analytics import heartbeat_record
                heartbeat_record("okx", self._health_state, self._health_detail,
                                 last_contact=self.last_contact())
            except Exception:
                logger.debug("OKX-Heartbeat nicht persistierbar", exc_info=True)
            return not offline

    def last_contact(self) -> Optional[str]:
        return self.client.last_contact()

    def stream_status(self) -> dict:
        if self._stream is None:
            return {
                "running": False, "connected": False, "authenticated": False,
                "last_message": None, "last_error": "nicht gestartet",
                "reconnects": 0, "mode": "demo" if self.demo else "live",
            }
        return self._stream.status().as_dict()

    def connection_components(self) -> dict:
        stream = self.stream_status()
        return {
            "overall": self._health_state,
            "rest_state": self._health_state,
            "rest_failures": int(self._health_failures),
            "rest_detail": self._health_detail,
            "last_rest_success": (
                datetime.fromtimestamp(self._last_health_success_at, timezone.utc).isoformat()
                if self._last_health_success_at else None),
            "ws_connected": bool(stream.get("connected")),
            "ws_authenticated": bool(stream.get("authenticated")),
            "ws_last_message": stream.get("last_message"),
            "account_last_update": stream.get("last_account_update"),
            "orders_last_update": stream.get("last_order_update"),
            "pong_last_update": stream.get("last_pong"),
        }

    def konto_snapshot(self, *, fills_limit: int = 20) -> dict:
        """Read-only Kontoaufnahme fuer Diagnose und Inbetriebnahme.

        Diese Methode setzt keine Orders, cancelt nichts und startet keinen
        Kauf. Sie ist absichtlich am Broker angebunden, damit Diagnose und
        Handelskern dieselben EEA-Endpunkte sowie denselben Demo-Header nutzen.
        """
        daten = self.client.account_snapshot(fills_limit=fills_limit)
        daten.update({
            "modus": "DEMO" if self.demo else "LIVE",
            "quote_ccy": self.quote_ccy,
            "allowed_quotes": list(self.allowed_quotes),
            "stream": self.stream_status(),
        })
        return daten

    def _balances_stream_or_rest(self) -> dict[str, dict]:
        import config as _cfg
        now = time.monotonic()
        interval = max(10.0, float(getattr(
            _cfg, "OKX_REST_BALANCE_REFRESH_SECONDS", 60.0)))
        stream_balances = None
        if self._stream is not None:
            stream_balances = self._stream.balances()
        # Regelmaessiger REST-Checkpoint ist die autoritative Vollsicht. Der
        # WebSocket beschleunigt Deltas, darf aber keinen alten Kontostand
        # unbegrenzt konservieren.
        if now - self._last_rest_balance_at >= interval:
            balances = self.client.balances()
            self._rest_balance_cache = {k: dict(v) for k, v in balances.items()}
            self._last_rest_balance_at = now
            if self._stream is not None:
                self._stream.replace_balances(balances)
            return balances
        if stream_balances is not None:
            return stream_balances
        if self._rest_balance_cache:
            return {k: dict(v) for k, v in self._rest_balance_cache.items()}
        balances = self.client.balances()
        self._rest_balance_cache = {k: dict(v) for k, v in balances.items()}
        self._last_rest_balance_at = now
        return balances

    # -- Konto --------------------------------------------------------------
    def kontowert(self) -> float:
        with self._lock:
            wert, gesetzt = self._equity_cache
        if wert and (time.time() - gesetzt) < 20.0:
            return wert
        wert = self.client.total_equity_usd()
        with self._lock:
            self._equity_cache = (float(wert), time.time())
        return float(wert)

    def gebuehrensatz(self) -> float:
        """Taker-Satz dieses Kontos -- gemessen, nicht angenommen.

        Faellt die Abfrage aus, gilt der KONSERVATIVERE der beiden Werte:
        der zuletzt gemessene oder der eingestellte. Eine zu niedrig
        angenommene Gebuehr macht schlechte Trades rechnerisch gut.
        """
        import config as _cfg
        angenommen = float(getattr(_cfg, "OKX_TAKER_FEE_PCT", 0.0035))
        with self._lock:
            wert, gesetzt = getattr(self, "_gebuehr_cache", (0.0, 0.0))
        if wert and (time.time() - gesetzt) < 3600.0:
            return max(wert, angenommen)
        try:
            daten = self.client.trade_fee("SPOT")
            taker = float(daten.get("taker") or 0.0)
        except Exception as exc:
            # Der konservativere Wert gilt: ein zu niedrig angenommener Satz
            # macht schlechte Trades rechnerisch gut.
            logger.info("OKX-Gebuehrensatz nicht abrufbar (%s) -- es gilt der "
                        "hoehere von gemessen %.4f %% und eingestellt %.4f %%.",
                        exc, wert * 100, angenommen * 100)
            return max(wert, angenommen)
        if taker <= 0:
            return max(wert, angenommen)
        with self._lock:
            self._gebuehr_cache = (taker, time.time())
        if abs(taker - angenommen) > 1e-6:
            logger.warning("OKX-Gebuehrensatz gemessen: %.4f %% (eingestellt "
                           "%.4f %%). Es gilt der gemessene Wert.",
                           taker * 100, angenommen * 100)
        return taker

    def handelbares_kapital(self, eigene_positionen=()) -> float:
        """Kapital, ueber das der Bot wirklich verfuegt -- in der Quotewaehrung.

        NICHT ``totalEq``. Das Gesamtvermoegen des Kontos enthaelt auch
        Bestaende, die der Bot nie gekauft hat. Am 25.08.2026 hat der
        Risikotopf mit rund 174.000 gerechnet, obwohl nur 4.600 EUR frei
        waren -- die geplante Order war 189 % des verfuegbaren Guthabens.

        ``eigene_positionen`` sind (symbol, menge, preis)-Tripel der
        Positionen, die dem Bot gehoeren. Alte (menge, preis)-Paare bleiben
        lesbar. Ihr Marktwert zaehlt mit, weil er jederzeit wieder zu Cash
        werden kann.
        """
        # NUR die eingestellte Handelswaehrung. EUR und USDC zu einer Zahl zu
        # addieren waere dieselbe Einheitenmischung, die dieser Umbau
        # abschaffen soll -- bei EUR/USD rund 8 % Fehler in der
        # Positionsgroesse.
        frei = self.verfuegbares_cash(self.quote_ccy)
        if frei is None:
            # Unbekannt ist nicht null, aber auch kein Freibrief: der Aufrufer
            # behaelt dann den letzten bekannten Kontowert.
            return 0.0
        eigen = 0.0
        for eintrag in eigene_positionen or ():
            try:
                if isinstance(eintrag, dict):
                    menge, preis = eintrag.get("menge"), eintrag.get("preis")
                elif len(eintrag) >= 3 and isinstance(eintrag[0], str):
                    _, menge, preis = eintrag[:3]
                else:
                    menge, preis = eintrag[:2]
                wert = abs(float(menge)) * abs(float(preis))
            except (TypeError, ValueError, IndexError):
                continue
            if wert == wert and wert not in (float("inf"), float("-inf")):
                eigen += wert
        return round(float(frei) + eigen, 8)

    def kontowaehrung(self) -> str:
        # Die Positionsgroesse rechnet in der Handelswaehrung, nicht in USD.
        return str(self.quote_ccy or "EUR").upper()

    def ist_paper(self) -> bool:
        return bool(self.demo)

    def verfuegbares_cash(self, quote_ccy: str = "") -> float | None:
        try:
            guthaben = self._balances_stream_or_rest()
        except BrokerFehler:
            return None
        eintrag = guthaben.get(str(quote_ccy or self.quote_ccy).upper())
        return float(eintrag.get("cash", 0.0)) if eintrag else 0.0

    # -- Instrumente --------------------------------------------------------
    def _inst_id(self, instrument) -> str:
        contract = getattr(instrument, "contract", None)
        symbol = (getattr(contract, "localSymbol", None) or
                  getattr(instrument, "name", None) or
                  getattr(contract, "symbol", None) or instrument)
        text = str(symbol or "").strip().upper().replace("/", "-").replace("_", "-")
        if "-" in text:
            return text
        alle = self.client.instruments()
        candidates = []
        for meta in alle.values():
            if meta.base_ccy != text or not meta.ist_live:
                continue
            try:
                self._trade_quote_ccy(meta)
            except BrokerFehler:
                continue
            quote_rank = (0 if meta.quote_ccy == self.quote_ccy else
                          1 + self.allowed_quotes.index(meta.quote_ccy)
                          if meta.quote_ccy in self.allowed_quotes else
                          100 if meta.quote_ccy == "USD" else 999)
            candidates.append((quote_rank, meta.inst_id))
        if not candidates:
            return normalize_inst_id(text, self.quote_ccy)
        return sorted(candidates)[0][1]

    def trade_quote_for_instrument(self, instrument, *, require_cash: bool = False) -> str:
        inst_id = self._inst_id(instrument)
        meta = self.client.instrument(inst_id)
        if meta is None:
            raise BrokerFehler(f"{inst_id}: Instrumentmetadaten fehlen")
        return self._trade_quote_ccy(meta, require_cash=require_cash)

    def quote_conversion_rate(self, source: str, target: str) -> float | None:
        """Beobachteter Spot-Kreuzkurs ohne angenommene Stablecoin-Paritaet."""
        source, target = str(source).upper(), str(target).upper()
        if source == target:
            return 1.0
        now = time.monotonic()
        cached_at, cached = self._quote_rate_cache
        key = (source, target)
        if now - cached_at <= 10.0 and key in cached:
            return cached[key]
        tickers = self.client.tickers()
        graph: dict[str, dict[str, float]] = {}
        for inst_id, ticker in tickers.items():
            last = float(getattr(ticker, "last", 0.0) or 0.0)
            parts = str(inst_id).upper().split("-")
            if len(parts) != 2 or last <= 0:
                continue
            base, quote = parts
            graph.setdefault(base, {})[quote] = last
            graph.setdefault(quote, {})[base] = 1.0 / last
        queue = [(source, 1.0, 0)]
        visited = {source}
        result = None
        while queue:
            ccy, rate, hops = queue.pop(0)
            if hops >= 3:
                continue
            for nxt, edge in sorted(graph.get(ccy, {}).items()):
                if nxt in visited or edge <= 0:
                    continue
                value = rate * edge
                if nxt == target:
                    result = value
                    queue = []
                    break
                visited.add(nxt)
                queue.append((nxt, value, hops + 1))
        fresh = dict(cached) if now - cached_at <= 10.0 else {}
        if result and result > 0:
            fresh[key] = result
        self._quote_rate_cache = (now, fresh)
        return result

    def instrument_handelbar(self, instrument) -> tuple[bool, str]:
        asset = str(getattr(instrument, "asset_type", "crypto")).lower()
        if asset != "crypto":
            return False, "OKX handelt in dieser Version ausschliesslich Krypto-Spot."
        inst_id = self._inst_id(instrument)
        try:
            meta = self.client.instrument(inst_id)
        except BrokerFehler as exc:
            return False, f"OKX-Instrumentpruefung nicht moeglich: {exc}"
        if meta is None:
            return False, f"{inst_id} ist bei OKX nicht als Spot-Instrument bekannt."
        if not meta.ist_live:
            return False, f"{inst_id} ist bei OKX nicht handelbar (Status {meta.state})."
        try:
            self._trade_quote_ccy(meta)
        except BrokerFehler as exc:
            return False, str(exc)
        return True, ""

    def qualifiziere(self, instrumente: list) -> tuple[list, list]:
        nutzbar, abgelehnt = [], []
        for inst in instrumente or []:
            ok, grund = self.instrument_handelbar(inst)
            if ok:
                nutzbar.append(inst)
            else:
                abgelehnt.append((getattr(inst, "name", str(inst)), grund))
        return nutzbar, abgelehnt

    # -- Marktdaten ---------------------------------------------------------
    def historie(self, instrument, dauer: str, kerzengroesse: str,
                 nur_handelszeiten: bool = True) -> pd.DataFrame:
        inst_id = self._inst_id(instrument)
        bar = BAR_MAP.get(str(kerzengroesse).strip().lower(), "15m")
        limit = self._kerzenanzahl(dauer, bar)

        def hole():
            df = self.client.candles(inst_id, bar=bar, limit=limit, nur_abgeschlossen=True)
            if df.empty:
                return pd.DataFrame(columns=["open", "high", "low", "close", "volume"])
            schmal = df[["open", "high", "low", "close", "volume"]].dropna(subset=["close"])
            return completed_bars_only(schmal, kerzengroesse)

        return retry_call(hole, label=f"OKX Historie {inst_id}")

    @staticmethod
    def _kerzenanzahl(dauer: str, bar: str) -> int:
        """Uebersetzt '2 D'/'260 D' in eine sinnvolle Kerzenanzahl."""
        text = str(dauer or "").strip().lower()
        ziffern = "".join(ch for ch in text if ch.isdigit())
        n = int(ziffern or 30)
        sekunden = BAR_SECONDS.get(bar, 900)
        if "d" in text:
            gesamt = n * 86400
        elif "w" in text:
            gesamt = n * 604800
        else:
            gesamt = n * 3600
        return max(80, min(300, int(gesamt / max(1, sekunden)) + 2))

    def latest_bid_ask(self, instrument):
        inst_id = self._inst_id(instrument)
        try:
            t = self.client.ticker(inst_id)
        except BrokerFehler:
            return None
        if t is None:
            return None
        return {
            "bid": t.bid, "ask": t.ask, "last": t.last,
            "timestamp": datetime.fromtimestamp(t.timestamp_ms / 1000.0, timezone.utc).isoformat()
            if t.timestamp_ms else None,
            "source": "OKX v5 market/ticker",
        }

    def execution_quote(self, instrument, quantity: float, *, side: str) -> dict:
        """Preis fuer die *gesamte* Menge aus einem frischen OKX-Orderbuch.

        Ein Ticker-``last`` beweist nur einen vergangenen Abschluss. Er sagt
        nicht, zu welchem Preis die eigene Menge jetzt gekauft oder verkauft
        werden kann. Deshalb summiert dieser Pfad die Gegenseite des Buches
        vollstaendig auf und bricht bei fehlender Tiefe oder alten Daten ab.
        """
        import config
        inst_id = self._inst_id(instrument)
        qty = float(quantity or 0.0)
        if qty <= 0:
            raise BrokerFehler(f"{inst_id}: Ausfuehrungsmenge muss positiv sein.")
        depth = max(20, min(400, int(getattr(config, "OKX_EXECUTION_BOOK_DEPTH", 100))))
        book = self.client.orderbook(inst_id, depth=depth)
        ts_ms = int(book.get("timestamp_ms") or 0)
        max_age = max(0.5, float(getattr(config, "OKX_ORDERBOOK_MAX_AGE_SECONDS", 3.0)))
        age = (time.time() * 1000.0 - ts_ms) / 1000.0 if ts_ms else float("inf")
        if age < -5.0 or age > max_age:
            raise BrokerFehler(
                f"{inst_id}: Orderbuch ist nicht frisch genug ({age:.1f} s; "
                f"Maximum {max_age:.1f} s). Order blockiert.")
        sell = str(side or "").lower() == "sell"
        levels = list(book.get("bids" if sell else "asks") or [])
        levels.sort(key=lambda row: float(row[0]), reverse=sell)
        remaining = qty
        value = 0.0
        worst = 0.0
        used_levels = 0
        for raw_price, raw_qty in levels:
            price, available = float(raw_price or 0.0), float(raw_qty or 0.0)
            if price <= 0 or available <= 0:
                continue
            take = min(remaining, available)
            value += take * price
            remaining -= take
            worst = price
            used_levels += 1
            if remaining <= max(1e-12, qty * 1e-10):
                break
        if remaining > max(1e-12, qty * 1e-10) or not used_levels:
            raise BrokerFehler(
                f"{inst_id}: Orderbuchtiefe reicht fuer {qty:g} {base_currency(inst_id)} "
                "nicht aus. Order blockiert.")
        best = float(levels[0][0])
        vwap = value / qty
        slippage = ((vwap - best) / best if not sell else (best - vwap) / best)
        return {
            "inst_id": inst_id, "side": "sell" if sell else "buy",
            "quantity": qty, "best": best, "vwap": vwap, "worst": worst,
            "slippage_pct": max(0.0, slippage), "book_age_seconds": max(0.0, age),
            "levels": used_levels, "timestamp_ms": ts_ms,
        }

    # -- Positionen ---------------------------------------------------------
    def positionen(self) -> list:
        """Spot-Bestaende als Positionen.

        Wichtig: OKX kennt bei Spot keine 'Position' mit Einstandspreis. Der
        Einstand wird deshalb aus den eigenen Fills rekonstruiert und vom
        PositionManager gefuehrt. Hier wird der Marktwert geliefert, nicht
        ein erfundener Einstand.
        """
        guthaben = self._balances_stream_or_rest()
        tickers: dict[str, OKXTicker] = {}
        # Auch nicht fuer neue Botorders freigegebene Settlementwaehrungen
        # bleiben Cash und duerfen nie als Krypto-Position erscheinen.
        cash_ccys = set(self.allowed_quotes) | {"EUR", "USDC", "USD", "USDG", "USDT"}
        interessant = [c for c in guthaben if c not in cash_ccys
                        and guthaben[c].get("gesamt", 0.0) > 0]
        if interessant:
            try:
                tickers = self.client.tickers()
            except BrokerFehler:
                tickers = {}

        out: list[Position] = []
        for ccy in interessant:
            eintrag = guthaben[ccy]
            menge = float(eintrag.get("gesamt", 0.0))
            inst_id = next((f"{ccy}-{quote}" for quote in self.allowed_quotes
                            if f"{ccy}-{quote}" in tickers), f"{ccy}-{self.quote_ccy}")
            quote = inst_id.rsplit("-", 1)[-1]
            preis = ((tickers[inst_id].bid or tickers[inst_id].last)
                     if inst_id in tickers else 0.0)
            if menge <= 0:
                continue
            out.append(Position(
                symbol=ccy, quantity=menge, avg_cost=0.0, currency=quote,
                asset_type="crypto", broker_id=inst_id,
                market_price=preis, market_value=menge * preis, unrealized_pnl=0.0,
            ))
        return out

    def fills(self) -> list:
        rows = self.client.fills(limit=100)
        out: list[Fill] = []
        for row in rows:
            inst_id = str(row.get("instId", "")).upper()
            menge = _f(row.get("fillSz"))
            if menge <= 0:
                continue
            out.append(Fill(
                fill_id=str(row.get("tradeId", "")),
                order_id=str(row.get("ordId", "")),
                symbol=base_currency(inst_id),
                side=str(row.get("side", "")).upper(),
                quantity=menge,
                price=_f(row.get("fillPx")),
                currency=inst_id.rsplit("-", 1)[-1] if "-" in inst_id else self.quote_ccy,
                asset_type="crypto",
                broker_id=inst_id,
                timestamp=self._iso(row.get("ts")),
                quantity_is_cumulative=False,
                # OKX liefert Gebuehren negativ (Abgang aus dem Konto).
                # v9.1: Bei einem SPOT-KAUF belastet OKX die Gebuehr in der
                # BASISwaehrung (feeCcy="BTC"), beim Verkauf in der Quote.
                # Ohne Umrechnung erschienen Kaufgebuehren um Groessenordnungen
                # zu niedrig -- und die Kostenhuerde eines Trades damit auch.
                explicit_fees=self._gebuehr_in_quote(row, inst_id) or None,
            ))
        return out

    @staticmethod
    def _gebuehr_in_quote(row: dict, inst_id: str) -> float:
        """Fill-Gebuehr in der Quotewaehrung des Marktes.

        OKX nennt die Waehrung der Gebuehr in ``feeCcy``. Stimmt sie mit der
        Basiswaehrung ueberein, muss mit dem Fillpreis umgerechnet werden.
        """
        betrag = abs(_f(row.get("fee")))
        if betrag <= 0:
            return 0.0
        fee_ccy = str(row.get("feeCcy") or "").upper()
        if fee_ccy and fee_ccy == base_currency(inst_id).upper():
            preis = _f(row.get("fillPx"))
            return betrag * preis if preis > 0 else 0.0
        return betrag

    @staticmethod
    def _iso(ms: Any) -> Optional[str]:
        wert = int(_f(ms, 0.0))
        if wert <= 0:
            return None
        return datetime.fromtimestamp(wert / 1000.0, timezone.utc).isoformat()

    # -- Orders -------------------------------------------------------------
    def kaufe_mit_absicherung(self, instrument, menge: float, referenzpreis: float,
                              stop: float, take_profit: float) -> OrderErgebnis:
        """Marktkauf in Basiswaehrung, danach OCO-Schutz beim Broker.

        Die Menge wird bewusst in der BASISWAEHRUNG angegeben (tgtCcy=
        base_ccy). Bei einem Spot-Marktkauf interpretiert OKX 'sz' sonst als
        Betrag in der Quotewaehrung -- dann kauft der Bot fuer 0,05 EUR
        statt 0,05 BTC. Genau diese Verwechslung ist ein klassischer
        Totalausfall in Krypto-Anbindungen.
        """
        if float(referenzpreis or 0.0) <= 0 or float(stop or 0.0) <= 0 or float(take_profit or 0.0) <= 0:
            raise BrokerFehler(
                "OKX-Kauf blockiert: Einstieg, Stop-Loss und Take-Profit muessen "
                "vor der Order als positive Preise feststehen."
            )
        if not (float(stop) < float(referenzpreis) < float(take_profit)):
            raise BrokerFehler(
                "OKX-Kauf blockiert: fuer einen Spot-Long muss Stop < Einstieg < Ziel gelten."
            )
        if not self.demo:
            from broker_live_arming import status as live_arm_status
            armed, detail, _ = live_arm_status("okx")
            if not armed:
                raise BrokerFehler(
                    "OKX LIVE-Einstieg blockiert: " + detail +
                    ". Ausstiege bleiben weiterhin erlaubt."
                )
        inst_id = self._inst_id(instrument)
        meta = self.client.instrument(inst_id)
        if meta is None or not meta.ist_live:
            raise BrokerFehler(f"{inst_id} ist bei OKX nicht handelbar.")

        sz = quantize_down(menge, meta.lot_size)
        if sz <= 0 or sz < _f(meta.min_size):
            raise BrokerFehler(
                f"{inst_id}: Menge {menge:g} liegt unter der OKX-Mindestgroesse "
                f"({meta.min_size} {meta.base_ccy})."
            )

        submit_context = dict(getattr(self, "_nexus_submit_context", {}) or {})
        cl_ord_id = str(submit_context.get("client_order_id") or make_client_order_id())[:32]
        # Eine noch offene Verkaufs-/Schutzorder kann Bestand einfrieren oder
        # nach einem neuen Einstieg feuern. Solange sie nicht eindeutig zum
        # bestehenden Positionsbuch gehoert, ist ein weiterer Kauf verboten.
        if self.hat_offene_order(instrument, "SELL", include_algos=True):
            raise BrokerFehler(
                f"{inst_id}: offene Verkaufs- oder Schutzorder vorhanden; "
                "neuer Einstieg bis zum Abgleich blockiert.")

        import config
        quote = self.execution_quote(instrument, sz, side="buy")
        max_slippage = max(0.0, float(getattr(
            config, "OKX_MAX_ENTRY_SLIPPAGE_PCT", 0.006)))
        if float(quote["slippage_pct"]) > max_slippage:
            raise BrokerFehler(
                f"{inst_id}: erwartete Kauf-Slippage {quote['slippage_pct'] * 100:.3f}% "
                f"ueber Limit {max_slippage * 100:.3f}%. Order blockiert.")
        limit_px = quantize_up(float(quote["worst"]), meta.tick_size)
        trade_quote = self._trade_quote_ccy(meta, require_cash=True)
        body = {
            "instId": inst_id,
            "tdMode": "cash",
            "side": "buy",
            # FOK: entweder die gesamte geplante Botmenge innerhalb der
            # Preisgrenze oder gar nichts. Keine unerkannte Teilposition.
            "ordType": "fok",
            "px": format_decimal(limit_px, meta.tick_size),
            "sz": format_decimal(sz, meta.lot_size),
            "tradeQuoteCcy": trade_quote,
            "clOrdId": cl_ord_id,
            "tag": str(submit_context.get("order_tag") or
                       getattr(__import__("config"), "OKX_ORDER_TAG", "NEXUS"))[:16],
        }

        try:
            antwort = self.client.place_order(body)
        except OrderStatusUnklar as exc:
            # Nachsehen, ob die Order trotzdem angekommen ist. Der clOrdId
            # macht das eindeutig -- ohne ihn bliebe nur Raten.
            gefunden = self._suche_order(inst_id, cl_ord_id)
            if gefunden:
                antwort = gefunden
                logger.warning("OKX-Kauf %s: Transport unklar, Order per clOrdId wiedergefunden.", inst_id)
            else:
                raise OrderStatusUnklar(str(exc), reference_id=cl_ord_id) from None
        except BrokerFehler as exc:
            # v9.1: "Duplicated client order ID" heisst, dass die Order bei OKX
            # BEREITS LIEGT -- es ist ein Nachweis, keine Ablehnung. Die
            # clOrdId entsteht deterministisch aus der decision_id, also tritt
            # der Code nach jedem Wiederanlauf derselben Entscheidung auf.
            # Bis 9.0.15 wurde die Order daraufhin verworfen und die real
            # gefuellte Position verschwand aus dem Positionsbuch.
            if _DOPPELTE_CLORDID not in str(exc):
                raise
            gefunden = self._suche_order(inst_id, cl_ord_id)
            if gefunden:
                antwort = gefunden
                logger.warning(
                    "OKX-Kauf %s: clOrdId bereits vergeben -- bestehende Order "
                    "uebernommen statt neu zu senden.", inst_id)
            else:
                raise OrderStatusUnklar(
                    f"OKX meldet die clOrdId als vergeben, liefert die Order aber "
                    f"nicht zurueck ({exc}). Kein zweiter Versuch.",
                    reference_id=cl_ord_id) from None

        ord_id = str(antwort.get("ordId", ""))
        try:
            status = self._warte_auf_fill(inst_id, ord_id, cl_ord_id)
        except OrderStatusUnklar as exc:
            raise OrderStatusUnklar(
                str(exc), reference_id=cl_ord_id,
                order_ids=[ord_id] if ord_id else [], accepted=True,
                intent={"inst_id": inst_id, "qty": sz,
                        "signal_price": referenzpreis,
                        "stop": stop, "take": take_profit,
                        "cl_ord_id": cl_ord_id, "ord_id": ord_id}) from None
        ergebnis = self._order_result_from_evidence(
            meta=meta, status=status, cl_ord_id=cl_ord_id,
            requested_qty=sz, reference_price=referenzpreis)
        ergebnis.trade_quote_ccy = trade_quote
        ergebnis.execution_quote = quote
        if ergebnis.gross_filled_quantity > 0 and not ergebnis.fill_evidence_complete:
            raise OrderStatusUnklar(
                f"OKX-Order {ord_id or cl_ord_id} ausgefuehrt, echte tradeId-Fills noch nicht vollstaendig sichtbar.",
                reference_id=cl_ord_id, order_ids=[ord_id] if ord_id else [],
                accepted=True,
                intent={"inst_id": inst_id, "qty": sz, "signal_price": referenzpreis,
                        "stop": stop, "take": take_profit,
                        "cl_ord_id": cl_ord_id, "ord_id": ord_id})

        if ergebnis.filled_quantity <= 0:
            ergebnis.hinweis = (
                "FOK-Kauf wurde nicht vollstaendig innerhalb der Preisgrenze "
                "ausgefuehrt; es wurde keine Position angelegt.")
            return ergebnis
        # Der Schutz wird absichtlich erst vom Engine-Pfad gesetzt, nachdem
        # Position, Ledger und Fill-Kette dauerhaft geschrieben wurden.
        ergebnis.stop_order_platziert = False
        ergebnis.take_order_platziert = False
        ergebnis.hinweis = "Kauf bestaetigt; Schutz folgt nach dauerhafter Verbuchung."
        return ergebnis

    def _suche_order(self, inst_id: str, cl_ord_id: str) -> dict:
        """Nach unklarem Transport pruefen, ob die Order doch existiert."""
        for versuch in range(3):
            time.sleep(0.8 * (versuch + 1))
            try:
                gefunden = self.client.order_status(inst_id, cl_ord_id=cl_ord_id)
            except BrokerFehler:
                continue
            if gefunden and str(gefunden.get("ordId", "")):
                return gefunden
        return {}

    def _warte_auf_fill(self, inst_id: str, ord_id: str, cl_ord_id: str,
                        sekunden: float = 12.0) -> dict:
        """Wartet kurz auf die endgueltige Ausfuehrung der Marktorder."""
        ende = time.time() + max(1.0, sekunden)
        letzter: dict = {}
        leere_antworten = 0
        while time.time() < ende:
            if self._stream is not None:
                stream_row = self._stream.order(ord_id=ord_id, cl_ord_id=cl_ord_id)
                if stream_row:
                    letzter = stream_row
                    zustand = str(letzter.get("state", "")).lower()
                    if zustand in ("filled", "canceled"):
                        return letzter
            try:
                letzter = self.client.order_status(inst_id, ord_id=ord_id, cl_ord_id=cl_ord_id)
            except BrokerFehler as exc:
                logger.debug("OKX-Orderabfrage %s: %s", inst_id, exc)
                time.sleep(0.7)
                continue
            if not letzter:
                # Die Order ist dem Broker unbekannt. Weiterfragen bringt
                # nichts und haelt nur den Handelszyklus auf.
                leere_antworten += 1
                if leere_antworten >= 3:
                    logger.warning("OKX kennt Order %s/%s nicht -- Abfrage beendet.",
                                   ord_id or "-", cl_ord_id or "-")
                    return letzter
                time.sleep(0.7)
                continue
            leere_antworten = 0
            zustand = str(letzter.get("state", "")).lower()
            if zustand in ("filled", "canceled"):
                return letzter
            time.sleep(0.7)
        return letzter

    def _setze_schutz(self, meta: OKXInstrument, menge: float,
                      stop: float, take_profit: float, *,
                      trade_quote_ccy: str = "",
                      protection_client_id: str = "") -> dict:
        """Legt eine OCO-Algo-Order fuer Stop-Loss und Gewinnziel an.

        OCO heisst: greift eine Seite, wird die andere automatisch storniert.
        Das verhindert die klassische Doppelausfuehrung, bei der Stop UND
        Ziel feuern und der Bot am Ende short steht.
        """
        sz = quantize_down(menge, meta.lot_size)
        if sz <= 0 or sz < _f(meta.min_size):
            return {"stop": False, "take": False,
                    "hinweis": "Restmenge zu klein fuer eine Schutzorder; Client-Stop bleibt aktiv."}

        stop_px = quantize_price(stop, meta.tick_size) if stop and stop > 0 else 0.0
        take_px = quantize_price(take_profit, meta.tick_size) if take_profit and take_profit > 0 else 0.0
        if stop_px <= 0 and take_px <= 0:
            return {"stop": False, "take": False, "hinweis": "Keine Schutzpreise uebergeben."}

        import config
        algo_cl_id = str(protection_client_id or make_client_order_id("TBP9"))[:32]
        # Idempotenz: nach einem unklaren POST oder Neustart niemals blind
        # dieselbe Schutzorder ein zweites Mal senden.
        for existing in self.offene_schutzorders(meta.inst_id):
            if str(existing.get("algoClOrdId") or "") == algo_cl_id:
                return {
                    "stop": stop_px > 0, "take": take_px > 0,
                    "checked": True,
                    "algo_id": str(existing.get("algoId") or ""),
                    "algo_client_id": algo_cl_id,
                    "hinweis": "Vorhandener Broker-Schutz eindeutig wiedergefunden.",
                }

        stop_limit_pct = max(0.0, float(getattr(
            config, "OKX_STOP_LIMIT_SLIPPAGE_PCT", 0.01)))
        stop_order_px = quantize_down(stop_px * (1.0 - stop_limit_pct), meta.tick_size)
        # v9.1: Bei Cent- und Sub-Cent-Coins faellt der abgeschlagene
        # Limitpreis unter einen Tick und wird auf 0 abgerundet. OKX lehnt die
        # GESAMTE OCO ab -- und die Position lief bis 9.0.15 ohne jeden
        # Broker-Schutz weiter, waehrend hier "stop: True" gemeldet wurde.
        if stop_px > 0 and stop_order_px <= 0:
            stop_order_px = quantize_down(stop_px, meta.tick_size)
        if stop_px > 0 and stop_order_px <= 0:
            return {"stop": False, "take": False, "checked": True,
                    "hinweis": ("Stop-Limitpreis liegt unter einem Tick; "
                                "Broker-Schutz nicht setzbar. Client-Stop bleibt aktiv.")}
        body = {
            "instId": meta.inst_id,
            "tdMode": "cash",
            "side": "sell",
            "ordType": "oco" if (stop_px > 0 and take_px > 0) else "conditional",
            "sz": format_decimal(sz, meta.lot_size),
            # v9.1: tradeQuoteCcy ist fuer /trade/order dokumentiert, NICHT fuer
            # /trade/order-algo. Validiert OKX den unbekannten Parameter, wird
            # jede Schutzorder abgelehnt -- der Kauf laeuft dann dauerhaft ohne
            # Broker-Stop. Der Verkauf erfolgt ohnehin in der Quote des instId.
            "algoClOrdId": algo_cl_id,
        }
        if stop_px > 0:
            body["slTriggerPx"] = format_decimal(stop_px, meta.tick_size)
            # Kein unbeschraenkter Marktverkauf. Unterhalb dieser Grenze
            # bleibt die Position bestehen und wird sichtbar als ungeschuetzt
            # gemeldet, statt wie DOGE mit beliebigem Verlust verkauft.
            body["slOrdPx"] = format_decimal(stop_order_px, meta.tick_size)
            body["slTriggerPxType"] = "last"
        if take_px > 0:
            body["tpTriggerPx"] = format_decimal(take_px, meta.tick_size)
            body["tpOrdPx"] = format_decimal(take_px, meta.tick_size)
            body["tpTriggerPxType"] = "last"

        try:
            placed = self.client.place_algo_order(body)
            return {"stop": stop_px > 0, "take": take_px > 0,
                    "checked": True,
                    "algo_id": str(placed.get("algoId") or ""),
                    "algo_client_id": algo_cl_id, "hinweis": ""}
        except OrderStatusUnklar:
            # Unklar heisst hier: eventuell liegt der Schutz doch. Nicht
            # blind erneut senden -- der Reconcile-Lauf raeumt das auf.
            return {"stop": False, "take": False, "checked": False,
                    "algo_client_id": algo_cl_id,
                    "hinweis": "Schutzorder-Zustand unklar; wird beim naechsten Abgleich geprueft."}
        except BrokerFehler as exc:
            logger.warning("OKX-Schutzorder %s abgelehnt: %s", meta.inst_id, exc)
            return {"stop": False, "take": False, "checked": True,
                    "algo_client_id": algo_cl_id,
                    "hinweis": f"Broker-Schutz abgelehnt ({exc}); Client-Stop bleibt aktiv."}

    def schliesse_position(self, instrument, menge: float,
                           referenzpreis: float = 0.0) -> OrderErgebnis:
        self.letzte_stornierung = {}
        inst_id = self._inst_id(instrument)
        meta = self.client.instrument(inst_id)
        if meta is None:
            raise BrokerFehler(f"{inst_id} ist bei OKX unbekannt.")

        import config
        planned = quantize_down(float(menge or 0.0), meta.lot_size)
        if planned <= 0:
            return OrderErgebnis(status="keine_menge", filled_quantity=0.0, paper=self.demo)
        # Erst pruefen, ob die volle Menge aktuell innerhalb der erlaubten
        # Preisgrenze verkauft werden kann. Bis dahin bleibt der Schutz aktiv.
        quote = self.execution_quote(instrument, planned, side="sell")
        max_slippage = max(0.0, float(getattr(
            config, "OKX_MAX_EXIT_SLIPPAGE_PCT", 0.01)))
        if float(quote["slippage_pct"]) > max_slippage:
            raise BrokerFehler(
                f"{inst_id}: erwartete Verkaufs-Slippage {quote['slippage_pct'] * 100:.3f}% "
                f"ueber Limit {max_slippage * 100:.3f}%; Schutz bleibt aktiv.")

        # Erst jetzt den Schutz entfernen: eine Algo-Order kann Guthaben
        # einfrieren und der neue FOK-Verkauf wuerde sonst abgelehnt.
        self.storniere_offene_orders(instrument)
        if self.letzte_stornierung.get("fehler"):
            raise BrokerFehler("Schutzorder konnte nicht sicher storniert werden; Verkauf nicht gesendet.")

        # OKX bestaetigt die Stornierung vor der Freigabe des eingefrorenen
        # Guthabens. Ein einmaliger Balance-Read erzeugte deshalb bei LINK/
        # ONDO einen FOK mit Menge null. Polling ist begrenzt und sendet keine
        # Order, solange Schutz oder Guthaben noch nicht eindeutig frei sind.
        release_timeout = max(2.0, float(getattr(config, "OKX_CANCEL_RELEASE_TIMEOUT", 10.0)))
        deadline = time.time() + release_timeout
        verfuegbar = 0.0
        while time.time() < deadline:
            algos = self.offene_schutzorders(inst_id, strict=True)
            standard = [row for row in self.client.pending_orders(inst_id)
                        if str(row.get("side") or "").lower() == "sell"]
            verfuegbar = float(self.client.balances().get(meta.base_ccy, {}).get("cash", 0.0))
            if not algos and not standard and verfuegbar + float(meta.lot_size) >= planned:
                break
            time.sleep(0.5)
        else:
            raise BrokerFehler(
                f"{inst_id}: Schutzstorno/Guthabenfreigabe nach {release_timeout:.0f}s "
                "nicht bestaetigt; keine Verkaufsorder gesendet.")

        sz = quantize_down(min(float(menge or 0.0), verfuegbar), meta.lot_size)
        if sz <= 0:
            return OrderErgebnis(status="keine_menge", filled_quantity=0.0, paper=self.demo,
                                 hinweis=f"Kein verfuegbares {meta.base_ccy}-Guthaben zum Verkauf.")
        if sz < _f(meta.min_size):
            return OrderErgebnis(status="unter_mindestgroesse", filled_quantity=0.0, paper=self.demo,
                                 hinweis=f"Restmenge {sz:g} liegt unter OKX-Minimum {meta.min_size}.")

        # Nach der Freigabe ist das alte Orderbuch veraltet. Neu messen und
        # den FOK-Limitpreis bis zur konfigurierten Verlustgrenze erlauben.
        # Das bleibt preisbegrenzt, ist aber nicht mehr auf den exakten,
        # millisekundenalten schlechtesten Bid festgenagelt.
        quote = self.execution_quote(instrument, sz, side="sell")
        if float(quote["slippage_pct"]) > max_slippage:
            raise BrokerFehler(
                f"{inst_id}: Verkaufs-Slippage nach Schutzstorno {quote['slippage_pct'] * 100:.3f}% "
                f"ueber Limit {max_slippage * 100:.3f}%; Order nicht gesendet.")
        best = float(quote.get("best") or quote.get("vwap") or quote["worst"])
        limit_px = quantize_down(best * (1.0 - max_slippage), meta.tick_size)
        cl_ord_id = make_client_order_id("TBS9")
        trade_quote = self._trade_quote_ccy(meta)
        body = {
            "instId": inst_id, "tdMode": "cash", "side": "sell", "ordType": "fok",
            "px": format_decimal(limit_px, meta.tick_size),
            "sz": format_decimal(sz, meta.lot_size),
            "tradeQuoteCcy": trade_quote,
            "clOrdId": cl_ord_id,
            "tag": str(getattr(__import__("config"), "OKX_ORDER_TAG", "NEXUS"))[:16],
        }
        try:
            antwort = self.client.place_order(body)
        except OrderStatusUnklar as exc:
            gefunden = self._suche_order(inst_id, cl_ord_id)
            if not gefunden:
                raise OrderStatusUnklar(str(exc), reference_id=cl_ord_id) from None
            antwort = gefunden

        ord_id = str(antwort.get("ordId", ""))
        status = self._warte_auf_fill(inst_id, ord_id, cl_ord_id)
        result = self._order_result_from_evidence(
            meta=meta, status=status, cl_ord_id=cl_ord_id,
            requested_qty=sz, reference_price=referenzpreis)
        result.trade_quote_ccy = trade_quote
        result.execution_quote = quote
        if result.filled_quantity <= 0:
            cancel_source = str(status.get("cancelSource") or "")
            broker_detail = str(status.get("sMsg") or status.get("msg") or "")
            result.hinweis = (
                "FOK-Verkauf wurde nicht vollstaendig innerhalb der Preisgrenze "
                "ausgefuehrt; Broker-Schutz muss sofort erneuert werden."
                + (f" OKX cancelSource={cancel_source}." if cancel_source else "")
                + (f" {broker_detail}" if broker_detail else ""))
        return result

    def offene_orders(self) -> list:
        out = []
        for row in self.client.pending_orders():
            out.append({
                "order_id": str(row.get("ordId", "")),
                "symbol": base_currency(str(row.get("instId", ""))),
                "instrument": str(row.get("instId", "")),
                "side": str(row.get("side", "")).upper(),
                "quantity": _f(row.get("sz")),
                "price": _f(row.get("px")),
                "status": str(row.get("state", "")),
                "typ": "order",
            })
        try:
            for row in self.client.pending_algo_orders():
                out.append({
                    "order_id": str(row.get("algoId", "")),
                    "symbol": base_currency(str(row.get("instId", ""))),
                    "instrument": str(row.get("instId", "")),
                    "side": str(row.get("side", "")).upper(),
                    "quantity": _f(row.get("sz")),
                    "price": _f(row.get("slTriggerPx")) or _f(row.get("tpTriggerPx")),
                    "status": str(row.get("state", "")),
                    "typ": "schutz",
                })
        except BrokerFehler as exc:
            logger.debug("OKX-Algo-Orders nicht abrufbar: %s", exc)
        return out

    def hat_offene_order(self, instrument, seite: str = "BUY", *,
                         include_algos: bool = False) -> bool:
        inst_id = self._inst_id(instrument)
        try:
            offen = self.client.pending_orders(inst_id)
        except BrokerFehler as exc:
            logger.warning("%s: offene Standardorders nicht sicher pruefbar: %s; "
                           "Order vorsorglich als offen behandelt.", inst_id, exc)
            return True
        gesucht = str(seite or "BUY").lower()
        if any(str(r.get("side", "")).lower() == gesucht for r in offen):
            return True
        if include_algos and gesucht == "sell":
            try:
                return any(str(r.get("side", "")).lower() == "sell"
                           for r in self.offene_schutzorders(inst_id, strict=True))
            except BrokerFehler as exc:
                logger.warning("%s: Schutzorders nicht sicher pruefbar: %s; "
                               "neuer Einstieg blockiert.", inst_id, exc)
                return True
        return False

    # Schutzorders koennen als OCO (Stop UND Ziel) oder als "conditional"
    # (nur eines von beiden) angelegt sein. Bis v8.1.3 wurde nur nach OCO
    # gefragt -- eine conditional-Order wurde weder storniert noch als
    # vorhanden erkannt: doppelter Schutz und blockiertes Guthaben.
    # v9.1: "trigger" und "move_order_stop" ergaenzt. Eine im OKX-Web von Hand
    # angelegte Trigger-Verkaufsorder war fuer hat_offene_order() unsichtbar --
    # der Bot haette trotz blockiertem Bestand neu eingestiegen.
    ALGO_ARTEN = ("oco", "conditional", "trigger", "move_order_stop")

    def offene_schutzorders(self, inst_id: str, *, strict: bool = False) -> list[dict]:
        """Alle Schutzorders eines Instruments, ueber alle Algo-Arten."""
        gefunden: list[dict] = []
        gesehen: set[str] = set()
        fehler: list[str] = []
        for art in self.ALGO_ARTEN:
            try:
                for zeile in self.client.pending_algo_orders(inst_id, ord_type=art):
                    kennung = str(zeile.get("algoId", ""))
                    if kennung and kennung not in gesehen:
                        gesehen.add(kennung)
                        gefunden.append(zeile)
            except BrokerFehler as exc:
                logger.warning("OKX-Algo-Abfrage %s (%s): %s", inst_id, art, exc)
                fehler.append(f"{art}: {exc}")
        if strict and fehler:
            raise BrokerFehler("Schutzorders nicht vollstaendig pruefbar: " + "; ".join(fehler))
        return gefunden

    def storniere_offene_orders(self, instrument) -> int:
        """Offene Orders und Schutzorders entfernen.

        Rueckgabe ist die Anzahl. Ein Fehlschlag wird NICHT verschluckt: er
        landet in ``self.letzte_stornierung`` und wird vom Aufrufer gemeldet.
        Bleibt Guthaben eingefroren, wird der folgende Verkauf sonst
        stillschweigend zu einer Teilausfuehrung -- genau das SOL-Muster vom
        25.08.2026.
        """
        inst_id = self._inst_id(instrument)
        anzahl = 0
        fehler = []

        def _erledigt(exc: BrokerFehler) -> bool:
            """Ist "Order weg" schon der gewuenschte Zustand?

            v9.1: 51400 "does not exist", 51401 "already canceled", 51402
            "already completed" und 51410 "already under cancelling" bedeuten
            fachlich: das Ziel ist erreicht. Bis 9.0.15 galten sie als Fehler
            und blockierten den Ausstieg genau dann, wenn die Schutzorder
            gerade ausgeloest war -- also im aktivsten Marktmoment.
            """
            return any(code in str(exc) for code in _STORNO_ERLEDIGT_CODES)

        try:
            for row in self.client.pending_orders(inst_id):
                try:
                    self.client.cancel_order(inst_id, str(row.get("ordId", "")))
                    anzahl += 1
                except BrokerFehler as exc:
                    if _erledigt(exc):
                        anzahl += 1
                    else:
                        raise
        except BrokerFehler as exc:
            logger.warning("OKX-Stornierung %s: %s", inst_id, exc)
            fehler.append(str(exc))
        try:
            algos = self.offene_schutzorders(inst_id)
            eintraege = [{"instId": inst_id, "algoId": str(r.get("algoId", ""))}
                         for r in algos if r.get("algoId")]
            if eintraege:
                try:
                    self.client.cancel_algo_orders(eintraege)
                except BrokerFehler as exc:
                    if not _erledigt(exc):
                        raise
                anzahl += len(eintraege)
        except BrokerFehler as exc:
            logger.warning("OKX-Algo-Stornierung %s: %s", inst_id, exc)
            fehler.append(str(exc))
        self.letzte_stornierung = {"inst_id": inst_id, "anzahl": anzahl,
                                   "fehler": fehler}
        return anzahl

    def verwaiste_orders_aufraeumen(self) -> int:
        """Schutzorders zu Symbolen ohne Guthaben entfernen."""
        entfernt = 0
        try:
            guthaben = self.client.balances()
            algos = []
            for art in self.ALGO_ARTEN:
                algos.extend(self.client.pending_algo_orders(ord_type=art))
            standard = self.client.pending_orders()
        except BrokerFehler:
            return 0
        for row in algos:
            inst_id = str(row.get("instId", ""))
            ccy = base_currency(inst_id)
            if float(guthaben.get(ccy, {}).get("gesamt", 0.0)) > 0:
                continue
            try:
                self.client.cancel_algo_orders([{"instId": inst_id, "algoId": str(row.get("algoId", ""))}])
                entfernt += 1
            except BrokerFehler:
                logger.debug("Verwaiste Algo-Order %s nicht entfernbar", inst_id, exc_info=True)
        for row in standard:
            inst_id = str(row.get("instId", ""))
            if str(row.get("side") or "").lower() != "sell":
                continue
            ccy = base_currency(inst_id)
            if float(guthaben.get(ccy, {}).get("gesamt", 0.0)) > 0:
                continue
            try:
                self.client.cancel_order(inst_id, str(row.get("ordId") or ""))
                entfernt += 1
            except BrokerFehler:
                logger.debug("Verwaiste Standardorder %s nicht entfernbar", inst_id,
                             exc_info=True)
        return entfernt

    def reconcile_position_protection(self, instrument, quantity: float,
                                      stop: float, take_profit: float, *,
                                      protection_client_id: str = "",
                                      trade_quote_ccy: str = "") -> dict:
        """Prueft nach Neustart/Reconnect, ob der Broker-Schutz noch liegt."""
        inst_id = self._inst_id(instrument)
        meta = self.client.instrument(inst_id)
        if meta is None:
            return {"checked": True, "changed": False, "protection_confirmed": False,
                    "detail": f"{inst_id} bei OKX unbekannt"}
        try:
            algos = self.offene_schutzorders(inst_id, strict=True)
            standard_sells = [r for r in self.client.pending_orders(inst_id)
                              if str(r.get("side") or "").lower() == "sell"]
        except BrokerFehler as exc:
            # Nicht abrufbar ist NICHT dasselbe wie bestaetigt fehlend. Die
            # WebUI darf bei einem Transportfehler keinen falschen
            # Schutzverlust behaupten und der Bot darf keine zweite OCO
            # blind platzieren.
            return {"checked": False, "changed": False, "protection_confirmed": False,
                    "detail": f"Schutzstatus nicht abfragbar: {exc}"}

        # Nach einem Algo-Trigger kann der Schutz als normale SELL-Order
        # weiterlaufen. Beides zaehlt zur Deckung und darf nicht dupliziert
        # werden.
        abgedeckt = (sum(_f(r.get("sz")) for r in algos)
                     + sum(_f(r.get("sz")) - _f(r.get("accFillSz"))
                           for r in standard_sells))
        soll = quantize_down(quantity, meta.lot_size)
        if abgedeckt >= soll * 0.999 and soll > 0:
            active = next(iter(algos), {})
            return {"checked": True, "changed": False, "protection_confirmed": True,
                    "algo_id": str(active.get("algoId") or ""),
                    "algo_client_id": str(active.get("algoClOrdId") or protection_client_id),
                    "detail": f"Broker-Schutz vorhanden ({abgedeckt:g} {meta.base_ccy})"}

        fehlend = max(0.0, soll - abgedeckt)
        if fehlend <= 0:
            return {"checked": True, "changed": False, "protection_confirmed": False,
                    "detail": "Keine Menge zu schuetzen"}
        schutz = self._setze_schutz(
            meta, fehlend, stop, take_profit,
            protection_client_id=protection_client_id,
            trade_quote_ccy=trade_quote_ccy)
        bestaetigt = bool(schutz.get("stop"))
        return {"checked": bool(schutz.get("checked", True)),
                "changed": bestaetigt, "protection_confirmed": bestaetigt,
                "algo_id": str(schutz.get("algo_id") or ""),
                "algo_client_id": str(schutz.get("algo_client_id") or protection_client_id),
                "detail": schutz.get("hinweis") or f"Schutz fuer {fehlend:g} {meta.base_ccy} nachgezogen"}

    def amend_position_protection(self, instrument, quantity: float,
                                  stop: float, take_profit: float, *,
                                  algo_id: str, trade_quote_ccy: str = "") -> dict:
        """Aendert genau eine belegte OKX-OCO und verifiziert das Ergebnis."""
        inst_id = self._inst_id(instrument)
        meta = self.client.instrument(inst_id)
        if meta is None:
            raise BrokerFehler(f"{inst_id} ist bei OKX unbekannt.")
        expected_qty = quantize_down(quantity, meta.lot_size)
        active = [row for row in self.offene_schutzorders(inst_id, strict=True)
                  if str(row.get("algoId") or "") == str(algo_id or "")]
        if len(active) != 1:
            raise BrokerFehler("Die zu aendernde Schutzorder ist nicht exakt einmal aktiv.")
        row = active[0]
        covered = quantize_down(_f(row.get("sz")), meta.lot_size)
        if expected_qty <= 0 or abs(covered - expected_qty) > max(_f(meta.lot_size), expected_qty * 0.001):
            raise BrokerFehler("Schutzordermenge stimmt nicht mit der Botposition ueberein.")
        stop_px = quantize_price(stop, meta.tick_size)
        take_px = quantize_price(take_profit, meta.tick_size)
        max_slippage = max(0.0, float(getattr(__import__("config"), "OKX_MAX_EXIT_SLIPPAGE_PCT", 0.01)))
        stop_order_px = quantize_down(stop_px * (1.0 - max_slippage), meta.tick_size)
        body = {
            "instId": inst_id, "algoId": str(algo_id),
            "newSlTriggerPx": format_decimal(stop_px, meta.tick_size),
            "newSlOrdPx": format_decimal(stop_order_px, meta.tick_size),
            "newSlTriggerPxType": "last",
            "newTpTriggerPx": format_decimal(take_px, meta.tick_size),
            "newTpOrdPx": format_decimal(take_px, meta.tick_size),
            "newTpTriggerPxType": "last",
        }
        self.client.amend_algo_order(body)
        # Erfolg des POST ist noch kein Beweis. Die aktive Brokerorder muss
        # die neuen Werte bei einer frischen Abfrage tatsaechlich zeigen.
        for _ in range(8):
            time.sleep(0.4)
            matches = [item for item in self.offene_schutzorders(inst_id, strict=True)
                       if str(item.get("algoId") or "") == str(algo_id)]
            if len(matches) == 1:
                current = matches[0]
                if (abs(_f(current.get("slTriggerPx")) - stop_px) <= _f(meta.tick_size)
                        and abs(_f(current.get("tpTriggerPx")) - take_px) <= _f(meta.tick_size)):
                    return {"checked": True, "protection_confirmed": True,
                            "algo_id": str(algo_id),
                            "algo_client_id": str(current.get("algoClOrdId") or ""),
                            "stop": stop_px, "take_profit": take_px,
                            "detail": "Manueller TP/SL bei OKX aktiv und rueckgelesen."}
        raise OrderStatusUnklar(
            "OKX nahm die TP/SL-Aenderung an, der neue Zustand konnte aber nicht bestaetigt werden.",
            reference_id=str(algo_id))

    # -- Faehigkeiten -------------------------------------------------------
    def unterstuetzt_krypto_stop(self) -> bool:
        """OKX kann echte Broker-Stops (Algo-Orders) -- eToro konnte das nicht."""
        return True

    def unterstuetzt_bruchstuecke(self, asset_type: str = "crypto") -> bool:
        return True

    def beschreibung(self) -> str:
        return (f"OKX EEA Spot ({'DEMO' if self.demo else 'LIVE'}, "
                f"Quotes {', '.join(self.allowed_quotes)})")


__all__ = [
    "OKXBroker", "OKXClient", "OKXInstrument", "OKXTicker", "RateLimiter",
    "normalize_inst_id", "base_currency", "quantize_down", "quantize_up", "quantize_price",
    "format_decimal", "make_client_order_id", "client_order_id_for_decision",
    "okx_timestamp",
    "BAR_MAP", "BAR_SECONDS", "OKX_BASE_URL",
]
