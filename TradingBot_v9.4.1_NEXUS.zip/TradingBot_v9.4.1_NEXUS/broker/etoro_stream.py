"""Privater eToro-WebSocket als schneller Reconciliation-Hinweisgeber.

Die Push-Nachricht ist kein alleiniger Eigentumsbeweis. Sie weckt und
bereichert nur die persistente Beweiskette; der REST-Lookup und der exakte
positionId-Abgleich bleiben autoritativ.
"""
from __future__ import annotations

import json
import logging
import threading
import time
import uuid
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from typing import Callable

logger = logging.getLogger(__name__)


@dataclass
class StreamStatus:
    running: bool = False
    connected: bool = False
    authenticated: bool = False
    subscribed: bool = False
    last_message: str | None = None
    last_private_event: str | None = None
    last_error: str = ""
    reconnects: int = 0

    def as_dict(self) -> dict:
        return asdict(self)


class EtoroPrivateStream:
    URL = "wss://ws.etoro.com/ws"

    def __init__(self, api_key: str, user_key: str,
                 on_private_event: Callable[[dict], None] | None = None,
                 *, url: str = ""):
        self._api_key = str(api_key or "")
        self._user_key = str(user_key or "")
        self._callback = on_private_event
        self.url = str(url or self.URL)
        self._status = StreamStatus()
        self._lock = threading.RLock()
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._app = None

    def start(self) -> bool:
        if not self._api_key or not self._user_key:
            return False
        try:
            import websocket  # noqa: F401
        except Exception:
            self._set_error("Paket websocket-client fehlt; REST-Reconciliation bleibt aktiv")
            return False
        if self._thread and self._thread.is_alive():
            return True
        self._stop.clear()
        with self._lock:
            self._status.running = True
        self._thread = threading.Thread(
            target=self._run, name="etoro-private-stream", daemon=True)
        self._thread.start()
        return True

    def stop(self) -> None:
        self._stop.set()
        app = self._app
        if app is not None:
            try:
                app.close()
            except Exception:
                logger.debug("eToro-WebSocket konnte nicht geschlossen werden", exc_info=True)
        with self._lock:
            self._status.running = False
            self._status.connected = False
            self._status.authenticated = False
            self._status.subscribed = False

    def status(self) -> StreamStatus:
        with self._lock:
            return StreamStatus(**asdict(self._status))

    def _run(self) -> None:
        import websocket
        backoff = 1.0
        while not self._stop.is_set():
            try:
                self._app = websocket.WebSocketApp(
                    self.url, on_open=self._on_open, on_message=self._on_message,
                    on_error=self._on_error, on_close=self._on_close)
                self._app.run_forever(ping_interval=25, ping_timeout=10)
            except Exception as exc:
                self._set_error(f"{type(exc).__name__}: WebSocket-Lauf abgebrochen")
            if self._stop.wait(backoff):
                break
            with self._lock:
                self._status.reconnects += 1
            backoff = min(30.0, backoff * 2.0)

    def _send(self, operation: str, data: dict) -> None:
        app = self._app
        if app is None:
            return
        app.send(json.dumps({"id": str(uuid.uuid4()), "operation": operation,
                             "data": data}, separators=(",", ":")))

    def _on_open(self, _app) -> None:
        with self._lock:
            self._status.connected = True
            self._status.last_error = ""
        self._send("Authenticate", {"userKey": self._user_key,
                                    "apiKey": self._api_key})

    def _on_message(self, _app, message) -> None:
        now = datetime.now(timezone.utc).isoformat()
        with self._lock:
            self._status.last_message = now
        try:
            payload = json.loads(message)
        except (TypeError, ValueError):
            return
        operation = str(payload.get("operation") or "")
        if operation == "Authenticate":
            if payload.get("success") is True:
                with self._lock:
                    self._status.authenticated = True
                self._send("Subscribe", {"topics": ["private"], "snapshot": False})
            else:
                self._set_error("eToro-WebSocket-Authentifizierung abgelehnt")
            return
        if operation == "Subscribe":
            with self._lock:
                self._status.subscribed = payload.get("success") is True
            return
        for envelope in payload.get("messages") or []:
            if str(envelope.get("topic") or "") != "private":
                continue
            try:
                content = json.loads(envelope.get("content") or "{}")
            except (TypeError, ValueError):
                continue
            event = {"message_id": str(envelope.get("id") or ""),
                     "message_type": str(envelope.get("type") or ""),
                     "received_at_utc": now, "content": content}
            with self._lock:
                self._status.last_private_event = now
            if self._callback:
                try:
                    self._callback(event)
                except Exception:
                    logger.warning("eToro-Privatevent konnte nicht verarbeitet werden",
                                   exc_info=True)

    def _on_error(self, _app, error) -> None:
        self._set_error(f"{type(error).__name__}: WebSocket-Fehler")

    def _on_close(self, _app, code, reason) -> None:
        with self._lock:
            self._status.connected = False
            self._status.authenticated = False
            self._status.subscribed = False
        if code and not self._stop.is_set():
            self._set_error(f"WebSocket geschlossen ({code})")

    def _set_error(self, text: str) -> None:
        with self._lock:
            self._status.last_error = str(text)[:300]


__all__ = ["EtoroPrivateStream", "StreamStatus"]
