"""Positionsgroesse und Risikogrenzen mit persistentem Tages-/Gesamtrisiko.

v5.2:
- Tagesverlustlimit, Trade-Zähler, Verlustserien-Cooldown und Kostenstatus
  werden atomar in risk_state.json gespeichert und überleben Neustarts.
- Bei beschädigter Risk-Datei fällt der Bot auf die sichere Seite und blockiert
  neue Käufe für den aktuellen Tag.
- Zusätzlich werden kumulierte realisierte Gewinne/Verluste für das Dashboard
  gespeichert.
"""
from dataclasses import dataclass, field, fields
from datetime import date, datetime, timedelta, timezone
from zoneinfo import ZoneInfo
from pathlib import Path
import json
import logging
import math
import os
import config
from safe_persistence import atomic_write_json

logger = logging.getLogger(__name__)


def _handelstag_heute() -> date:
    """Kanonischer Handelstag in der vom Nutzer eingestellten Zeitzone.

    Tageslimits muessen zusammen mit Logbuch, Telegram und WebUI um lokale
    Mitternacht wechseln. UTC fuehrte in Deutschland zu einem Reset um 02:00
    bzw. 01:00 Uhr und damit zu widerspruechlichen Tagesergebnissen.
    """
    try:
        zone = ZoneInfo(str(getattr(config, "LOCAL_TIMEZONE", "Europe/Berlin")))
        return datetime.now(zone).date()
    except Exception:
        logger.warning("LOCAL_TIMEZONE ungueltig; lokaler Systemtag wird verwendet")
        return date.today()


def _utc_heute() -> date:
    """Rueckwaertskompatibler Name; liefert ab 9.0.14 den lokalen Handelstag."""
    return _handelstag_heute()


def _gueltige_heutige_daten() -> set[date]:
    """Nur der lokale Handelstag ist fuer Tageslimits gueltig."""
    return {_handelstag_heute()}


def _zustandswurzel() -> Path:
    """Wo die Zustandsdateien liegen.

    Offline- und Integrationstests duerfen niemals den echten Handelszustand
    veraendern; volltest.py und die Testskripte setzen dafuer
    ``TRADINGBOT_TEST_STATE_DIR``.
    """
    test_dir = os.getenv("TRADINGBOT_TEST_STATE_DIR", "").strip()
    return Path(test_dir) if test_dir else Path(__file__).resolve().parent



@dataclass
class RiskState:
    current_date: date = field(default_factory=_handelstag_heute)
    realized_pnl_today: float = 0.0
    open_positions: int = 0
    trading_halted: bool = False
    crypto_exposure: float = 0.0
    consecutive_losses: int = 0
    cooldown_until: datetime | None = None
    trades_today: int = 0
    estimated_costs_today: float = 0.0
    gross_profit_today: float = 0.0
    gross_loss_today: float = 0.0
    net_profit_today: float = 0.0
    net_loss_today: float = 0.0
    unknown_pnl_trades_today: int = 0
    # Zweite Tagesbremse: Equity-Verlust inkl. unrealisierter P&L. Sie blockiert
    # ausschliesslich neue Kaeufe und laesst Schutz-/Verkaufslogik weiterlaufen.
    day_start_equity: float = 0.0
    last_equity: float = 0.0
    equity_guard_halted: bool = False
    equity_drawdown_pct: float = 0.0
    # Die Equity-Bremse darf nur Werte vergleichen, die mit derselben
    # Kapitalbasis berechnet wurden. Aendert sich z. B. durch einen Kauf oder
    # eine Versionsmigration die Menge der bewiesenen Botpositionen, ist ein
    # alter Cash+Positionen-Startwert nicht mit einem neuen Cash-only-Wert
    # vergleichbar.
    equity_basis_key: str = ""
    equity_basis_changed_at: str = ""
    # Eine Broker-Order kann in mehrere Teil-Fills zerfallen. Der Tages-Tradezaehler
    # zaehlt die logische Verkaufsorder nur einmal; P&L bleibt fill-genau.
    counted_trade_ids_today: list[str] = field(default_factory=list)

    # Kumulierte Werte; werden bei Datumswechsel NICHT zurückgesetzt.
    lifetime_realized_pnl: float = 0.0
    lifetime_gross_profit: float = 0.0
    lifetime_gross_loss: float = 0.0
    lifetime_estimated_costs: float = 0.0
    lifetime_net_profit: float = 0.0
    lifetime_net_loss: float = 0.0
    lifetime_unknown_pnl_trades: int = 0

    @staticmethod
    def default_path(path=None) -> Path:
        """Der Pfad der Zustandsdatei -- immer absolut.

        v8.1.5: Ein RELATIVER Name wurde hier frueher unveraendert
        zurueckgegeben und loeste damit gegen das ARBEITSVERZEICHNIS auf.
        Beim Start als systemd-Dienst ist das ein anderer Ordner als das
        Botverzeichnis -- die Tagesbremse haette dort nach jedem Neustart bei
        null angefangen, ohne dass es jemand bemerkt. ``risk_pots`` hatte
        genau deshalb schon eine eigene Wurzelaufloesung; jetzt gilt sie
        ueberall.
        """
        wurzel = _zustandswurzel()
        if path is not None:
            kandidat = Path(path)
            return kandidat if kandidat.is_absolute() else wurzel / kandidat.name
        configured = Path(getattr(config, "RISK_STATE_FILE", "risk_state_etoro.json"))
        # Ein Test, der absichtlich einen absoluten Temp-Pfad in config setzt,
        # muss genau diesen Pfad testen koennen.
        if configured.is_absolute():
            return configured
        return wurzel / configured.name

    def _payload(self) -> dict:
        data = {}
        for f in fields(self):
            value = getattr(self, f.name)
            if isinstance(value, date) and not isinstance(value, datetime):
                data[f.name] = value.isoformat()
            elif isinstance(value, datetime):
                data[f.name] = value.isoformat()
            else:
                data[f.name] = value
        return data

    def save(self, path=None) -> None:
        target = self.default_path(path)
        try:
            atomic_write_json(target, self._payload(), retries=8)
        except Exception as exc:
            # RiskState ist sicherheitskritisch. Wir loggen deutlich; der Zustand
            # bleibt im RAM aktiv. Windows/OneDrive-Kurzzeitsperren werden bereits
            # durch atomic_write_json mit Backoff abgefangen.
            logger.error("RiskState konnte nicht gespeichert werden: %s", exc)

    @classmethod
    def load(cls, path=None):
        target = cls.default_path(path)
        if not target.exists():
            obj = cls()
            obj.save(target)
            return obj
        try:
            raw = json.loads(target.read_text(encoding="utf-8"))
            allowed = {f.name for f in fields(cls)}
            kwargs = {k: v for k, v in raw.items() if k in allowed}
            if isinstance(kwargs.get("current_date"), str):
                kwargs["current_date"] = date.fromisoformat(kwargs["current_date"])
            if isinstance(kwargs.get("cooldown_until"), str) and kwargs["cooldown_until"]:
                kwargs["cooldown_until"] = datetime.fromisoformat(kwargs["cooldown_until"])
            elif kwargs.get("cooldown_until") in ("", None):
                kwargs["cooldown_until"] = None
            obj = cls(**kwargs)
            obj.reset_if_new_day(persist=False)

            # v5.2/v5.2.1 konnten einen Verkauf ohne gefundenen Einstand als
            # exakt 0,00 P&L verbuchen. Ein alter State mit Trades + Kosten,
            # aber komplett leeren P&L-Buckets ist deshalb nicht vertrauenswuerdig.
            # Wir erfinden keinen Betrag, sondern markieren den historischen
            # Tages-P&L als unvollstaendig.
            legacy_unknown_missing = "unknown_pnl_trades_today" not in raw
            legacy_zero_pnl = (
                int(getattr(obj, "trades_today", 0) or 0) > 0
                and float(getattr(obj, "estimated_costs_today", 0) or 0) > 0
                and abs(float(getattr(obj, "realized_pnl_today", 0) or 0)) < 1e-12
                and abs(float(getattr(obj, "gross_profit_today", 0) or 0)) < 1e-12
                and abs(float(getattr(obj, "gross_loss_today", 0) or 0)) < 1e-12
                and abs(float(getattr(obj, "net_profit_today", 0) or 0)) < 1e-12
                and abs(float(getattr(obj, "net_loss_today", 0) or 0)) < 1e-12
            )
            if legacy_unknown_missing and legacy_zero_pnl:
                obj.unknown_pnl_trades_today = max(
                    int(getattr(obj, "unknown_pnl_trades_today", 0) or 0),
                    int(getattr(obj, "trades_today", 0) or 0),
                )
                obj.lifetime_unknown_pnl_trades = max(
                    int(getattr(obj, "lifetime_unknown_pnl_trades", 0) or 0),
                    obj.unknown_pnl_trades_today,
                )
            obj.save(target)
            return obj
        except Exception as exc:
            logger.exception("RiskState beschädigt/unlesbar: %s", exc)
            # Fail-safe: Keine neuen Käufe bis der Zustand bewusst geprüft wird.
            obj = cls(trading_halted=True)
            obj.save(target)
            return obj

    def reset_if_new_day(self, persist=True):
        today = _handelstag_heute()
        if self.current_date not in _gueltige_heutige_daten():
            self.current_date = today
            self.realized_pnl_today = 0.0
            self.trading_halted = False
            self.consecutive_losses = 0
            self.cooldown_until = None
            self.trades_today = 0
            self.estimated_costs_today = 0.0
            self.gross_profit_today = 0.0
            self.gross_loss_today = 0.0
            self.net_profit_today = 0.0
            self.net_loss_today = 0.0
            self.unknown_pnl_trades_today = 0
            self.day_start_equity = 0.0
            self.last_equity = 0.0
            self.equity_guard_halted = False
            self.equity_drawdown_pct = 0.0
            self.counted_trade_ids_today = []
            if persist:
                self.save()

    def _count_logical_trade(self, trade_id=None) -> bool:
        """Zaehlt eine logische Verkaufsorder hoechstens einmal pro Tag."""
        if not trade_id:
            self.trades_today += 1
            return True
        key = str(trade_id)[:200]
        if key in self.counted_trade_ids_today:
            return False
        self.counted_trade_ids_today.append(key)
        # Begrenzen, damit eine kaputte Fremdquelle die State-Datei nicht aufblaeht.
        if len(self.counted_trade_ids_today) > 1000:
            self.counted_trade_ids_today = self.counted_trade_ids_today[-1000:]
        self.trades_today += 1
        return True

    def register_realized_pnl(self, pnl, account_equity, gross_pnl=None, trade_id=None,
                              max_daily_loss_pct=None):
        self.reset_if_new_day(persist=False)
        pnl = float(pnl)
        gross = float(pnl if gross_pnl is None else gross_pnl)

        self.realized_pnl_today += pnl
        self.lifetime_realized_pnl += pnl
        self._count_logical_trade(trade_id)

        # Dashboard-Gewinne/-Verluste sind NETTO nach den explizit
        # modellierten Broker-/Regulatorikgebuehren. Grosswerte bleiben
        # separat fuer die Kostenquoten-Bremse erhalten.
        if pnl > 0:
            self.net_profit_today += pnl
            self.lifetime_net_profit += pnl
        elif pnl < 0:
            self.net_loss_today += abs(pnl)
            self.lifetime_net_loss += abs(pnl)

        if gross > 0:
            self.gross_profit_today += gross
            self.lifetime_gross_profit += gross
        elif gross < 0:
            self.gross_loss_today += abs(gross)
            self.lifetime_gross_loss += abs(gross)

        if pnl < 0:
            self.consecutive_losses += 1
            limit = int(getattr(config, "LOSS_STREAK_LIMIT", 4))
            if self.consecutive_losses >= limit:
                self.cooldown_until = datetime.now() + timedelta(
                    minutes=int(getattr(config, "LOSS_STREAK_COOLDOWN_MINUTES", 60))
                )
        elif pnl > 0:
            self.consecutive_losses = 0

        daily_limit = (float(max_daily_loss_pct)
                       if max_daily_loss_pct is not None
                       else float(getattr(config, "MAX_DAILY_LOSS_PCT", 0.02)))
        if account_equity > 0 and self.realized_pnl_today <= -abs(
            account_equity * daily_limit
        ):
            self.trading_halted = True

        self.save()


    def update_equity_guard(self, account_equity: float, *, basis_key: str = "") -> bool:
        """Aktualisiert die unrealisierte Tagesverlustbremse.

        Rueckgabe True bedeutet: neue Kaeufe sind gesperrt. Bestehende
        Positionen, Stops und Verkaeufe bleiben bewusst unberuehrt.
        """
        self.reset_if_new_day(persist=False)
        try:
            equity = float(account_equity)
        except Exception:
            return bool(self.equity_guard_halted)
        if not math.isfinite(equity) or equity <= 0:
            return bool(self.equity_guard_halted)
        changed = False
        basis = str(basis_key or "").strip()[:500]
        if basis and basis != str(self.equity_basis_key or ""):
            vorher = str(self.equity_basis_key or "") or "LEGACY/UNBEKANNT"
            self.equity_basis_key = basis
            self.equity_basis_changed_at = datetime.now(timezone.utc).isoformat()
            self.day_start_equity = equity
            self.last_equity = equity
            self.equity_drawdown_pct = 0.0
            self.equity_guard_halted = False
            logger.warning(
                "Equity-Berechnungsbasis geaendert (%s -> %s); Tagesbasis "
                "kontrolliert auf %.2f neu gesetzt.", vorher, basis, equity,
            )
            self.save()
            return False
        if self.day_start_equity <= 0:
            self.day_start_equity = equity
            changed = True
        self.last_equity = equity
        dd = (equity - self.day_start_equity) / self.day_start_equity if self.day_start_equity > 0 else 0.0
        self.equity_drawdown_pct = float(dd)
        limit = abs(float(getattr(config, "MAX_UNREALIZED_DAILY_LOSS_PCT", 0.03)))
        if limit > 0 and dd <= -limit and not self.equity_guard_halted:
            self.equity_guard_halted = True
            changed = True
            logger.error(
                "Equity-Tagesbremse aktiviert: %.2f%% <= -%.2f%%. Nur neue Kaeufe gesperrt.",
                dd * 100.0, limit * 100.0,
            )
        if changed:
            self.save()
        return bool(self.equity_guard_halted)

    def register_unknown_pnl_trade(self, trade_id=None):
        """Merkt einen Verkauf, dessen Einstand nicht sicher bekannt ist.

        Wichtig: Es wird absichtlich KEINE 0 als Gewinn/Verlust gebucht.
        Auch hier zaehlen mehrere Teil-Fills derselben Brokerorder nur als
        ein logischer Trade fuer MAX_TRADES_PER_DAY.
        """
        self.reset_if_new_day(persist=False)
        self.unknown_pnl_trades_today += 1
        self.lifetime_unknown_pnl_trades += 1
        self._count_logical_trade(trade_id)
        self.save()

    def register_estimated_cost(self, amount):
        try:
            value = max(0.0, float(amount))
        except Exception:
            return
        self.estimated_costs_today += value
        self.lifetime_estimated_costs += value
        self.save()

    def cooldown_active(self):
        return self.cooldown_until is not None and datetime.now() < self.cooldown_until

    def cost_ratio(self):
        if self.gross_profit_today <= 0:
            return 0.0
        return max(0.0, self.estimated_costs_today) / self.gross_profit_today

    def cost_pressure_active(self):
        if not bool(getattr(config, "COST_RATIO_GUARD_ENABLED", True)):
            return False
        if self.trades_today < int(getattr(config, "COST_RATIO_MIN_TRADES", 5)):
            return False
        if self.gross_profit_today <= 0:
            return False
        return self.cost_ratio() > float(
            getattr(config, "COST_RATIO_MAX_OF_GROSS_PROFIT", 0.30)
        )


def calculate_stop_take(entry_price, side, atr_value=None, asset_type="stock"):
    use_atr = (
        config.USE_ATR_STOPS
        and atr_value is not None
        and math.isfinite(float(atr_value))
        and atr_value > 0
    )
    if use_atr:
        stop_distance = atr_value * config.ATR_STOP_MULTIPLIER
        take_distance = atr_value * config.ATR_TAKE_MULTIPLIER
    else:
        stop_distance = entry_price * config.STOP_LOSS_PCT
        take_distance = entry_price * config.TAKE_PROFIT_PCT
    if side == "BUY":
        stop = entry_price - stop_distance
        take = entry_price + take_distance
    else:
        stop = entry_price + stop_distance
        take = entry_price - take_distance
    floor = 0.00000001 if asset_type == "crypto" else 0.01
    return (
        round(max(stop, floor), 8 if asset_type == "crypto" else 4),
        round(max(take, floor), 8 if asset_type == "crypto" else 4),
    )


def _step_round_down(qty, step):
    if qty <= 0:
        return 0.0
    return math.floor(qty / step) * step


def size_new_position(
    account_equity,
    entry_price,
    stop_price,
    max_capital_pct=None,
    asset_type="stock",
):
    if account_equity <= 0 or entry_price <= 0 or stop_price <= 0:
        return 0.0
    if asset_type == "crypto":
        risk_pct = config.CRYPTO_RISK_PER_TRADE_PCT
        cap_pct = (
            max_capital_pct
            if max_capital_pct is not None
            else config.CRYPTO_MAX_POSITION_PCT
        )
        step = config.CRYPTO_QUANTITY_STEP
    else:
        risk_pct = config.RISK_PER_TRADE_PCT
        cap_pct = (
            max_capital_pct if max_capital_pct is not None else config.MAX_POSITION_PCT
        )
        step = 1.0
    stop_distance = abs(entry_price - stop_price)
    if stop_distance <= 0:
        return 0.0
    qty_risk = (account_equity * risk_pct) / stop_distance
    qty_cap = (account_equity * cap_pct) / entry_price
    qty = _step_round_down(min(qty_risk, qty_cap), step)
    return int(qty) if asset_type != "crypto" else round(qty, 8)


def can_open_new_position(risk_state):
    """Darf ein neuer Einstieg stattfinden?

    Wer hier einen Grund ergaenzt, muss ihn auch in ``kaufsperre_grund()``
    ergaenzen -- sonst erscheint er als falsche Meldung. Ein Test wacht
    darueber.
    """
    return not kaufsperre_grund(risk_state)


def kaufsperre_grund(risk_state) -> str:
    """Der Grund, der neue Kaeufe gerade sperrt -- leer heisst: erlaubt.

    Bis v8.1.4 stand die Begruendung in live_trader und kannte vier der sechs
    Gruende. Die Equity-Tagesbremse fehlte und fiel in einen Sammelzweig
    "Positionslimit erreicht (offen=…)". Am 25.08.2026 war das mit 243
    Meldungen der haeufigste Ablehnungsgrund des Tages -- und er war falsch.

    Jetzt gibt es genau eine Quelle fuer Entscheidung UND Begruendung.
    """
    risk_state.reset_if_new_day()

    grenze_positionen = int(getattr(config, "MAX_OPEN_POSITIONS", 0) or 0)
    if grenze_positionen <= 0:
        return ("Konfigurationsfehler: MAX_OPEN_POSITIONS muss mindestens 1 sein "
                f"(steht auf {grenze_positionen})")

    if risk_state.trading_halted:
        verlust = float(getattr(risk_state, "realized_pnl_today", 0.0) or 0.0)
        return (f"Tagesverlustlimit erreicht (heute realisiert {verlust:+.2f})")

    if bool(getattr(risk_state, "equity_guard_halted", False)):
        dd = float(getattr(risk_state, "equity_drawdown_pct", 0.0) or 0.0) * 100
        grenze = abs(float(getattr(config, "MAX_UNREALIZED_DAILY_LOSS_PCT", 0.03))) * 100
        return (f"Equity-Tagesbremse aktiv: {dd:+.2f} % seit Tagesbeginn "
                f"(Grenze -{grenze:.2f} %). Verkaeufe und Stops laufen weiter.")

    if risk_state.cooldown_active():
        rest = getattr(risk_state, "cooldown_until", None)
        return (f"Verlustserien-Cooldown aktiv bis {rest}" if rest
                else "Verlustserien-Cooldown aktiv")

    if risk_state.cost_pressure_active():
        quote = float(risk_state.cost_ratio()) * 100
        grenze = float(getattr(config, "COST_RATIO_MAX_OF_GROSS_PROFIT", 0.30)) * 100
        return f"Kostenquote zu hoch: {quote:.1f} % > {grenze:.0f} %"

    grenze_trades = int(getattr(config, "MAX_TRADES_PER_DAY", 20))
    if risk_state.trades_today >= grenze_trades:
        return (f"Maximale Trades pro Tag erreicht "
                f"({risk_state.trades_today}/{grenze_trades})")

    if risk_state.open_positions >= grenze_positionen:
        return (f"Positionslimit erreicht "
                f"(offen={risk_state.open_positions}, Limit={grenze_positionen})")

    return ""
