"""Krypto-Handelsmaschine fuer OKX -- laeuft rund um die Uhr (v8.1.1 NEXUS).

ABGRENZUNG
==========
Diese Maschine ist bewusst ein EIGENER Prozessteil neben dem bestehenden
Aktienkern (live_trader.py). Gruende:

    1. Der Aktienkern ist erprobt. Ein Umbau seiner Hauptschleife waere das
       groesste Regressionsrisiko des ganzen Projekts.
    2. Krypto hat einen voellig anderen Takt (Minuten statt Stunden) und
       darf nicht auf einen langsamen Aktienzyklus warten.
    3. Faellt eine Seite aus, laeuft die andere weiter.

WAS GETEILT WIRD
================
    Candidate Gate      identische deterministische Kaufkaskade
    Strategie           dieselben Indikatoren und Signalregeln
    Kostenrechnung      dieselbe Netto-Edge-Pruefung, mit OKX-Gebuehren
    Entscheidungslog    dasselbe Journal, ergaenzt um Quellenangaben

WAS GETRENNT IST
================
    Kontostand, Risikogrenzen, Tagesbremse, Universum, Takt.

SICHERHEITSREIHENFOLGE JE KAUF
==============================
    Universum -> Signal -> Stop/Ziel -> Groesse -> Kosten -> Candidate Gate
    -> Order -> Broker-Schutz (OCO) -> Buchung -> Protokoll

Die KI kommt in dieser Kette NICHT vor. Sie beeinflusst ausschliesslich,
WELCHE Werte ueberhaupt beobachtet werden.
"""

from __future__ import annotations

import json
import logging
import math
import os
import threading
import time
from dataclasses import asdict, dataclass, field
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Iterable, Optional

import config
from broker.base import (
    AuthentifizierungsFehler, BrokerFehler, OrderStatusUnklar, VerbindungVerloren,
)
from broker.okx import (base_currency, client_order_id_for_decision,
                        normalize_inst_id)
from contracts import Instrument, SimpleContract
from decision_source import (
    BROKER, CANDIDATE_GATE, DAFUER, DAGEGEN, Entscheidungsprotokoll, LUNA,
    MARKT, NEUTRAL, NUTZER, RISK_GATE, TECHNIK, UNIVERSE, speichere as speichere_quellen,
)
from safe_persistence import atomic_write_json
from decision_analytics import (mark_execution, record_order_result,
                                record_system_error)
from scheduler_v7 import POSITIONEN, SCAN, UNIVERSUM, Taktgeber

logger = logging.getLogger(__name__)


def _tickeralter_grenze(cfg) -> float:
    """Ab welchem Alter ein Krypto-Ticker nicht mehr als frisch gilt.

    Seit v8.1.5 in der WebUI einstellbar und ohne Neustart wirksam. Die
    Schwelle entscheidet nur, ob ein Kurs BENUTZT wird -- sie kann keine
    Order groesser oder ungeschuetzter machen.
    """
    try:
        import live_settings
        wert = live_settings.handelsschwellen().get("CRYPTO_TICKER_MAX_AGE_SECONDS")
        if wert is not None:
            return max(5.0, float(wert))
    except Exception:
        logger.debug("Tickeraltergrenze nicht lesbar; Standard aus config", exc_info=True)
    return max(5.0, float(getattr(cfg, "CRYPTO_TICKER_MAX_AGE_SECONDS", 120)))


def _fillzeitpunkt(ergebnis) -> str:
    """Der Zeitstempel des FRUEHESTEN Fills einer Order (ISO, UTC).

    OKX liefert je Fill ein ``ts``. Ohne diesen Wert wuerde die Haltedauer ab
    der lokalen Verbuchung laufen -- nach einem Absturz mit nachtraeglicher
    Aufklaerung waere das die falsche Uhr.
    """
    zeiten = []
    for fill in (getattr(ergebnis, "fills", None) or []):
        roh = None
        if isinstance(fill, dict):
            roh = fill.get("ts") or fill.get("timestamp") or fill.get("zeit")
        else:
            roh = (getattr(fill, "ts", None) or getattr(fill, "timestamp", None))
        if roh in (None, ""):
            continue
        try:
            if isinstance(roh, (int, float)) or str(roh).isdigit():
                ms = float(roh)
                if ms <= 0:
                    continue
                zeiten.append(datetime.fromtimestamp(ms / 1000.0, timezone.utc))
            else:
                stempel = datetime.fromisoformat(str(roh).replace("Z", "+00:00"))
                zeiten.append(stempel if stempel.tzinfo else
                              stempel.replace(tzinfo=timezone.utc))
        except (TypeError, ValueError, OSError, OverflowError):
            continue
    return min(zeiten).isoformat() if zeiten else ""


def _kerzengroesse_sekunden(text: str) -> float:
    """"15 mins" -> 900. Unbekanntes ergibt 900 als sichere Vorgabe."""
    roh = str(text or "").strip().lower()
    zahl = "".join(ch for ch in roh if ch.isdigit())
    try:
        wert = float(zahl) if zahl else 15.0
    except ValueError:
        wert = 15.0
    if "hour" in roh or "std" in roh or roh.endswith("h"):
        return wert * 3600.0
    if "day" in roh or "tag" in roh or roh.endswith("d"):
        return wert * 86400.0
    if "sec" in roh:
        return wert
    return wert * 60.0


def _ist_positiv(wert) -> bool:
    """Echte positive Zahl? NaN und Unendlich fallen durch.

    ``float("nan") <= 0`` ist False -- ein NaN-Kontostand liefe damit durch
    jede Fallunterscheidung hindurch und gaelte als "stimmt mit dem Buch
    ueberein".
    """
    try:
        zahl = float(wert)
    except (TypeError, ValueError):
        return False
    return math.isfinite(zahl) and zahl > 0


def meldungen_sicherheit(titel: str, text: str, *, handlung: str = "") -> str:
    """Sicherheitsmeldung -- lokal gekapselt, damit ein Importfehler nie
    einen Verkaufspfad abbricht."""
    try:
        import meldungen
        return meldungen.sicherheit(titel, text, handlung=handlung)
    except Exception:
        return f"SICHERHEIT · {titel}\n{text}" + (f"\nWas jetzt: {handlung}" if handlung else "")


def _state_root() -> Path:
    return Path(os.getenv("TRADINGBOT_TEST_STATE_DIR", "").strip() or
                Path(__file__).resolve().parent)


# ---------------------------------------------------------------------------
# Positionsbuch
# ---------------------------------------------------------------------------
# Herkunft und Verwaltungsmodus einer Position. Bewusst dieselbe Idee wie auf
# der Aktienseite (position_manager: source / management_mode): Was der Bot
# nicht selbst gekauft hat, verkauft er auch nicht.
HERKUNFT_BOT = "BOT"
HERKUNFT_BROKER = "BROKER_BESTAND"
VERWALTUNG_AUTO = "AUTO"
VERWALTUNG_MANUELL = "MANUELL"
VERWALTUNG_BEOBACHTEN = "BEOBACHTEN"

# Unterhalb dieser Abweichung gilt Kontostand == Buchmenge (Rundung, Staub).
MENGEN_TOLERANZ = 0.02


def fill_anchored_stop_take(*, strategy_mode: str, fill_price: float,
                            filled_quantity: float, entry_fee_quote: float,
                            exit_fee_pct: float, signal_price: float,
                            planned_stop: float, planned_take: float) -> tuple[float, float]:
    """Verankert Schutzwerte ausschliesslich am echten Broker-Fill.

    Die Funktion ist rein und damit gegen die reale DOGE-Fehlerklasse
    testbar: Weder Signalkurs noch ein Kurs aus einem anderen Quote-Markt
    duerfen im Freqtrade-Modus Stop oder ROI-Ziel bestimmen.
    """
    fill = float(fill_price or 0.0)
    quantity = float(filled_quantity or 0.0)
    if fill <= 0 or quantity <= 0:
        raise ValueError("Fillpreis und Fillmenge muessen positiv sein")
    if str(strategy_mode or "") == "FREQTRADE_SAMPLE":
        from freqtrade_sample_strategy import STOPLOSS, roi_exit_price
        entry_fee_pct = max(0.0, float(entry_fee_quote or 0.0) / (fill * quantity))
        return (
            fill * (1.0 + float(STOPLOSS)),
            roi_exit_price(fill, 0.04, entry_fee_pct=entry_fee_pct,
                           exit_fee_pct=float(exit_fee_pct or 0.0)),
        )
    signal = float(signal_price or 0.0)
    return (
        fill * (float(planned_stop or 0.0) / signal) if signal > 0 else float(planned_stop or 0.0),
        fill * (float(planned_take or 0.0) / signal) if signal > 0 else float(planned_take or 0.0),
    )



@dataclass
class KryptoPosition:
    """Eine offene Kryptoposition mit ihren Schutzwerten."""
    symbol: str
    inst_id: str
    menge: float
    einstieg: float
    stop: float
    take_profit: float
    eroeffnet_am: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    order_id: str = ""
    referenz: str = ""
    broker_schutz: bool = False
    hoechstkurs: float = 0.0
    paper: bool = True
    # Ab v8.1.4: Woher stammt die Position, und darf der Bot sie automatisch
    # verwalten? Die Aktienseite fuehrt dieselbe Unterscheidung seit v6
    # (source / management_mode). Ohne sie hat der Bot am 25.08.2026 einen
    # Fremdbestand von 0,94 BTC mitverkauft.
    herkunft: str = HERKUNFT_BOT
    verwaltung: str = VERWALTUNG_AUTO
    verwaltungsnotiz: str = ""
    # v9.2: WARUM die Verwaltung eingeschraenkt ist -- getrennt von der Frage,
    # OB die Position dem Bot gehoert. "" heisst: kein Sonderfall.
    management_status: str = ""
    # v9.2: Zu WELCHEM OKX-Konto der Bestand gehoert. Ohne dieses Feld lief
    # die Kontopruefung in strategy_migration ins Leere -- ein Bestand aus
    # dem Demokonto haette nach einem Umschalten auf Live migriert werden
    # koennen.
    account_fingerprint: str = ""
    # v9.2: Nachweis einer ausdruecklichen Strategie-Migration. Ohne diese
    # Felder waere ein Hashwechsel im Nachhinein nicht nachvollziehbar.
    strategy_migrated_at: str = ""
    strategy_migrated_from_version: str = ""
    strategy_migrated_from_hash: str = ""
    strategy_migration_reason: str = ""
    strategy_migration_actor: str = ""
    decision_id: int | None = None
    # Immutable strategy identity from the entry fill. The global runtime
    # switch never rewrites these fields.
    entry_strategy_mode: str = "NEXUS_STANDARD"
    strategy_name: str = "NEXUS Standard Krypto"
    strategy_version: str = "NEXUS-STANDARD-LEGACY"
    strategy_parameter_hash: str = ""
    strategy_parameters: dict = field(default_factory=dict)
    trade_quote_ccy: str = ""
    # Ein OKX-Spot-Guthaben ist keine Position. Erst diese unveraenderliche
    # Brokerkette beweist, dass genau diese Teilmenge vom Bot gekauft wurde.
    client_order_id: str = ""
    order_tag: str = ""
    fill_ids: list[str] = field(default_factory=list)
    ownership_verified: bool = False
    entry_fee_by_currency: dict = field(default_factory=dict)
    entry_fee_quote: float = 0.0
    protection_algo_id: str = ""
    protection_client_order_id: str = ""
    protection_status: str = "PENDING"
    manual_changed_at: str = ""
    manual_changed_by: str = ""
    exit_state: str = "IDLE"
    exit_retry_after: str = ""
    exit_last_notice_at: str = ""
    exit_last_detail: str = ""

    @property
    def darf_automatisch_verkaufen(self) -> bool:
        """Nur eigene Positionen unter Automatik werden vom Bot geschlossen."""
        from crypto_strategy_mode import strategy_is_resolved
        return (str(self.herkunft).upper() == HERKUNFT_BOT
                and str(self.verwaltung).upper() == VERWALTUNG_AUTO
                and bool(self.ownership_verified)
                and bool(str(self.order_id or "").strip())
                and bool(str(self.client_order_id or self.referenz or "").strip())
                and bool([x for x in self.fill_ids if str(x).strip()])
                and strategy_is_resolved(self.strategy_snapshot()))

    @property
    def ist_bewiesene_botposition(self) -> bool:
        return (str(self.herkunft).upper() == HERKUNFT_BOT
                and bool(self.ownership_verified)
                and bool(str(self.order_id or "").strip())
                and bool(str(self.client_order_id or self.referenz or "").strip())
                and bool([x for x in self.fill_ids if str(x).strip()]))

    @property
    def darf_schutz_ausfuehren(self) -> bool:
        """Darf der Bot fuer diese Position selbst VERKAUFEN?

        Das ist eine Frage der Verwaltung, nicht des Eigentums. Eine pausierte
        Position wird weiter ueberwacht und geschuetzt -- verkauft wird sie
        nicht (siehe ``safety_monitoring_enabled``).
        """
        return self.ist_bewiesene_botposition and str(self.verwaltung).upper() in {
            VERWALTUNG_AUTO, VERWALTUNG_MANUELL}

    # -----------------------------------------------------------------------
    # v9.2: Drei getrennte Fragen statt einer vermischten
    # -----------------------------------------------------------------------
    # In v9.1 hing der Eigentumsnachweis am Verwaltungsmodus. Eine Aenderung
    # von STARTUP_CANDLES hat deshalb den Strategie-Hash veraendert, die
    # Position auf BEOBACHTEN gesetzt -- und damit BNB, LINK und XLM zu
    # "externem Bestand ohne ID-Kette" gemacht, obwohl orderId, clOrdId und
    # echte tradeIds vollstaendig vorlagen.
    #
    # DIE REGEL, die das kuenftig verhindert:
    #   In den Eigentumsnachweis darf NICHTS eingehen, was ein
    #   Software-Update aendern kann.
    # Der Nachweis besteht ausschliesslich aus dem, was der Broker vergeben
    # hat. Strategie, Parameter und Verwaltungsmodus bestimmen hoechstens,
    # WELCHE Logik verwalten darf -- niemals, OB die Position dem Bot gehoert.

    @property
    def ownership_chain_complete(self) -> bool:
        """Gehoert diese Position nachweislich dem Bot?

        Nur brokerseitig vergebene Werte. Ueberlebt jedes Update.
        """
        return self.ist_bewiesene_botposition

    @property
    def blocks_reentry(self) -> bool:
        """Sperrt diese Position einen erneuten Einstieg in denselben Wert?

        Bewusst unabhaengig vom Verwaltungsmodus: auch eine pausierte oder
        manuell verwaltete Botposition darf nicht ein zweites Mal gekauft
        werden.
        """
        return self.ownership_chain_complete and float(self.menge or 0.0) > 0

    @property
    def safety_monitoring_enabled(self) -> bool:
        """Laeuft die Sicherheitsueberwachung fuer diese Position?

        Mengenabgleich, Erkennung externer Verkaeufe, Pruefung und
        Wiederherstellung des Broker-Schutzes und die Anzeige laufen fuer
        JEDE bewiesene Botposition -- auch fuer eine pausierte. Nur das
        automatische VERKAUFEN haengt am Verwaltungsmodus.
        """
        return self.ownership_chain_complete and str(self.verwaltung).upper() in {
            VERWALTUNG_AUTO, VERWALTUNG_MANUELL, VERWALTUNG_BEOBACHTEN}

    @property
    def strategy_execution_enabled(self) -> bool:
        """Darf die Einstiegsstrategie Ausgaenge ausloesen?"""
        from crypto_strategy_mode import strategy_is_resolved
        return (self.ownership_chain_complete
                and str(self.verwaltung).upper() == VERWALTUNG_AUTO
                and strategy_is_resolved(self.strategy_snapshot()))

    def strategy_snapshot(self) -> dict:
        return {
            "entry_strategy_mode": str(self.entry_strategy_mode or ""),
            "strategy_name": str(self.strategy_name or ""),
            "strategy_version": str(self.strategy_version or ""),
            "parameter_hash": str(self.strategy_parameter_hash or ""),
            "parameters": dict(self.strategy_parameters or {}),
        }

    def pausiere(self, grund: str, *, status: str = "") -> None:
        """Automatik aus -- Ueberwachung und Schutz laufen weiter.

        v9.2: ``status`` benennt den Grund maschinenlesbar. Der
        Eigentumsnachweis bleibt davon unberuehrt.
        """
        self.verwaltung = VERWALTUNG_BEOBACHTEN
        self.verwaltungsnotiz = str(grund)[:300]
        self.management_status = str(status or "")[:60]

    def manuell(self, actor: str, grund: str) -> None:
        self.verwaltung = VERWALTUNG_MANUELL
        self.verwaltungsnotiz = str(grund)[:300]
        self.manual_changed_at = datetime.now(timezone.utc).isoformat()
        self.manual_changed_by = str(actor or "")[:80]

    def als_dict(self) -> dict:
        return asdict(self)


class KryptoPositionsbuch:
    """Persistentes Positionsbuch der Kryptoseite.

    OKX kennt bei Spot keine 'Position' mit Einstandspreis -- nur Guthaben.
    Einstieg, Stop und Ziel muss der Bot deshalb selbst fuehren. Ohne
    Persistenz waeren diese Werte nach einem Neustart verloren und der Bot
    wuesste nicht mehr, wo sein Stop liegt.
    """

    def __init__(self, datei: Optional[Path] = None):
        self.datei = Path(datei or _state_root() / "crypto_positions.json")
        self.positionen: dict[str, KryptoPosition] = {}
        self._lock = threading.RLock()
        self.laden()

    def laden(self) -> None:
        if not self.datei.exists():
            return
        try:
            roh = json.loads(self.datei.read_text(encoding="utf-8"))
        except Exception:
            logger.warning("Krypto-Positionsbuch unlesbar -- starte leer.", exc_info=True)
            return
        with self._lock:
            self.positionen = {}
            for eintrag in roh.get("positionen", []):
                try:
                    p = KryptoPosition(**{k: v for k, v in eintrag.items()
                                          if k in KryptoPosition.__dataclass_fields__})
                    if (str(eintrag.get("herkunft") or HERKUNFT_BOT).upper() == HERKUNFT_BOT
                            and not str(eintrag.get("entry_strategy_mode") or "")):
                        # A pre-9.0 position has no persistent strategy proof.
                        # Never guess its exit engine during an automatic migration.
                        p.entry_strategy_mode = ""
                        p.strategy_name = ""
                        p.strategy_version = ""
                        p.strategy_parameter_hash = ""
                        p.strategy_parameters = {}
                        p.pausiere("Legacy-Position ohne belegte Einstiegsstrategie; explizite Migration erforderlich")
                    # Vor 9.0.9 wurde aus der orderId eine kuenstliche Fill-ID
                    # gebaut. Sie ist kein OKX-tradeId-Beweis und darf keine
                    # Verkaufsautomatik freischalten.
                    p.fill_ids = [str(x) for x in (p.fill_ids or [])
                                  if str(x).strip() and not str(x).startswith("okx-entry:")]
                    p.ownership_verified = bool(
                        p.ownership_verified and p.order_id
                        and (p.client_order_id or p.referenz) and p.fill_ids)
                    self.positionen[p.symbol.upper()] = p
                except Exception:
                    logger.debug("Ungueltiger Positionseintrag uebersprungen", exc_info=True)

    def speichern(self) -> None:
        with self._lock:
            payload = {"version": 2, "gespeichert": datetime.now(timezone.utc).isoformat(),
                       "positionen": [p.als_dict() for p in self.positionen.values()]}
        try:
            atomic_write_json(self.datei, payload)
        except Exception:
            logger.warning("Krypto-Positionsbuch nicht speicherbar", exc_info=True)

    def setze(self, position: KryptoPosition) -> None:
        with self._lock:
            self.positionen[position.symbol.upper()] = position
        self.speichern()

    def hole(self, symbol: str) -> Optional[KryptoPosition]:
        with self._lock:
            return self.positionen.get(str(symbol).upper())

    def entferne(self, symbol: str) -> None:
        with self._lock:
            self.positionen.pop(str(symbol).upper(), None)
        self.speichern()

    def symbole(self) -> list[str]:
        with self._lock:
            return sorted(self.positionen)

    def alle(self) -> list[KryptoPosition]:
        with self._lock:
            return list(self.positionen.values())

    def aktive(self) -> list[KryptoPosition]:
        """Nur exakt belegte, automatisch verwaltete Botpositionen.

        OKX-Spot-Salden und pausierte Legacy-Hinweise sind keine offenen
        Trades und duerfen weder Positionszaehler noch WebUI befuellen.
        """
        with self._lock:
            return [p for p in self.positionen.values()
                    if p.darf_schutz_ausfuehren]


# ---------------------------------------------------------------------------
# Handelsmaschine
# ---------------------------------------------------------------------------
class CryptoEngine:
    """Fuehrt Universumspflege, Signalsuche und Positionsueberwachung aus."""

    def __init__(self, *, hub, risiko, universum, taktgeber: Optional[Taktgeber] = None,
                 ai_router=None, melder=None, cfg=None):
        self.cfg = cfg or config
        self.hub = hub
        self.risiko = risiko
        self.universum = universum
        self.takt = taktgeber or Taktgeber(cfg=self.cfg)
        self.ai = ai_router
        # Symbole, deren Fremdbestand bereits gemeldet wurde -- damit die
        # Meldung nicht in jedem Minutentakt erneut kommt.
        self._gemeldeter_ueberhang: set = set()
        # Wie oft in Folge wurde fuer ein Symbol kein Guthaben gemeldet?
        # Ein einzelner Ausfall darf keine Position abrechnen.
        self._fehlender_bestand: dict = {}
        # Zweifache Bestaetigung fuer offene Ledger-Zeilen, zu denen weder
        # Positionsbuch noch Brokerbestand existieren. Ein einzelner leerer
        # Snapshot darf die Historie nicht schliessen.
        self._fehlender_ledger_bestand: dict[int, int] = {}
        # Handelsbereitschaft: neue Kaeufe erst nach Anlaufsperre und wenn
        # alle fachlichen Voraussetzungen erfuellt sind (v8.1.4).
        from trading_ready import Handelsbereitschaft
        self.bereitschaft = Handelsbereitschaft("okx", cfg=self.cfg, melder=self._melde)
        self.melder = melder
        self.buch = KryptoPositionsbuch()
        self.letzter_universumslauf: Optional[dict] = None
        self.letzter_fehler = ""
        self._exposure_sperre: list[str] = []
        # Die Klassifizierung ist nicht nur ein Logeintrag: Die WebUI muss
        # klar zeigen, dass OKX-Demo-Startguthaben keine offenen Bot-Orders
        # sind. Bis zur ersten Reconciliation bleibt die Anzeige leer statt
        # etwas zu erfinden.
        self._letzte_exposure: dict = {}
        self.zyklen = 0
        self._selector = None
        self._last_exposure_alert: tuple[str, float] = ("", 0.0)

    # -- Zugriffe -----------------------------------------------------------
    @property
    def broker(self):
        return self.hub.broker("okx")

    @property
    def topf(self):
        return self.risiko.topf("okx")

    def _selektor(self):
        if self._selector is None:
            from universe.crypto_selector import CryptoUniverseSelector
            broker = self.broker
            if broker is None:
                return None
            self._selector = CryptoUniverseSelector(broker.client, cfg=self.cfg)
        return self._selector

    def _instrument(self, symbol: str, inst_id: str = "") -> Instrument:
        symbol = str(symbol).upper()
        broker = self.broker
        inst_id = str(inst_id or "").upper()
        if not inst_id:
            member = self.universum.zustand.hole("okx", symbol)
            inst_id = str(getattr(member, "inst_id", "") or "").upper()
        quote = (inst_id.rsplit("-", 1)[-1] if "-" in inst_id else
                 str(getattr(broker, "quote_ccy", "EUR")))
        inst_id = inst_id or normalize_inst_id(symbol, quote)
        contract = SimpleContract(symbol, quote, localSymbol=inst_id)
        return Instrument(name=symbol, contract=contract,
                          asset_type="crypto", currency=quote, sector="crypto",
                          exchange="OKX")

    def _melde(self, text: str, *, wichtig: bool = False, klasse: str = "") -> None:
        """Eine Meldung zustellen.

        ``klasse`` erlaubt es, ein Ereignis ausdruecklich als KRITISCH zu
        kennzeichnen -- solche Meldungen werden nie gedrosselt.
        """
        logger.info(text)
        if self.melder is None:
            return
        try:
            self.melder(text, wichtig=wichtig, klasse=klasse)
        except TypeError:
            # Aeltere Melder kennen "klasse" nicht.
            try:
                self.melder(text, wichtig=wichtig)
            except Exception:
                logger.debug("Meldung konnte nicht zugestellt werden", exc_info=True)
        except Exception:
            logger.debug("Meldung konnte nicht zugestellt werden", exc_info=True)

    # -- Hauptzyklus --------------------------------------------------------
    def zyklus(self) -> dict:
        """Ein Durchlauf. Macht nur, was laut Taktgeber faellig ist."""
        self.zyklen += 1
        ergebnis = {"zeit": datetime.now(timezone.utc).isoformat(), "arbeiten": []}

        broker = self.broker
        if broker is None or not broker.is_connected():
            self.hub.verbinde("okx")
            broker = self.broker
            if broker is None or not broker.is_connected():
                ergebnis["hinweis"] = "OKX nicht verbunden"
                self.bereitschaft.melde(
                    "broker_verbunden", False,
                    "OKX nicht authentifiziert; automatische Wiederverbindung laeuft")
                self._write_runtime(ergebnis)
                return ergebnis

        self.topf.neuer_tag_pruefen()
        # Nur die eigenen Positionen zaehlen zum handelbaren Kapital.
        werte = self.risiko.aktualisiere_kontowerte(self.hub, self._eigene_positionen)
        self.bereitschaft.melde("broker_verbunden", self.broker is not None
                                and self.broker.is_connected())
        self.bereitschaft.melde("guthaben", bool(werte.get("okx")),
                                f"handelbar {werte.get('okx', 0):.2f}")
        self._melde_bereitschaft()

        # Positionen zuerst: Schutz geht immer vor neuen Chancen.
        if self.takt.faellig("crypto", POSITIONEN)[0]:
            try:
                ergebnis["positionen"] = self.pruefe_positionen()
                ergebnis["arbeiten"].append(POSITIONEN)
            finally:
                self.takt.markiere("crypto", POSITIONEN)

        if self.takt.faellig("crypto", UNIVERSUM)[0]:
            try:
                ergebnis["universum"] = self.universumslauf()
                ergebnis["arbeiten"].append(UNIVERSUM)
            finally:
                self.takt.markiere("crypto", UNIVERSUM)

        if self.takt.faellig("crypto", SCAN)[0]:
            # v9.2: Der Rasterpunkt steht VOR dem Lauf fest. Ein Scan, der
            # eine Kerzengrenze ueberschreitet, wird sonst der neuen Kerze
            # zugeordnet, obwohl er auf der alten entschieden hat -- und die
            # neue Kerze faellt aus.
            scan_token = self.takt.rasterlauf_beginnen(
                "crypto", SCAN, raster_sekunden=self._scan_raster_sekunden())
            try:
                ergebnis["scan"] = self.scan()
                ergebnis["arbeiten"].append(SCAN)
                if scan_token.get("kerzenschluss_utc"):
                    ergebnis["kerzenschluss_utc"] = scan_token["kerzenschluss_utc"]
            finally:
                self.takt.rasterlauf_abschliessen("crypto", SCAN, scan_token)

        self._write_runtime(ergebnis)
        return ergebnis

    def _write_runtime(self, cycle: dict) -> None:
        """Getrennter OKX-Heartbeat; die eToro-Datei wird nie ueberschrieben."""
        try:
            from safe_persistence import best_effort_json
            payload = self.status()
            payload.update({
                "running": True,
                "online": bool(self.broker is not None and self.broker.is_connected()),
                "last_heartbeat": datetime.now(timezone.utc).isoformat(),
                "last_cycle": cycle,
            })
            broker_state = self.hub.zustaende().get("okx", {}) if hasattr(self.hub, "zustaende") else {}
            payload.update({
                "connection_state": broker_state.get("status", "UNBEKANNT"),
                "last_broker_contact": broker_state.get("letzter_kontakt", ""),
                "last_connection_error": broker_state.get("letzter_fehler", ""),
                "health_interval_seconds": float(getattr(self.cfg, "BROKER_HEALTHCHECK_SECONDS", 30)),
            })
            if self.broker is not None and hasattr(self.broker, "stream_status"):
                payload["position_stream"] = self.broker.stream_status()
            if self.broker is not None and hasattr(self.broker, "connection_components"):
                payload["connection_components"] = self.broker.connection_components()
            best_effort_json(_state_root() / "runtime_status_okx.json", payload,
                             label="OKX Runtime-Status", durable=False)
        except Exception:
            logger.debug("OKX Runtime-Status nicht schreibbar", exc_info=True)

    # -- Universum ----------------------------------------------------------
    def universumslauf(self) -> dict:
        """Waehlt das Krypto-Universum neu und meldet die Aenderungen."""
        selektor = self._selektor()
        if selektor is None:
            return {"ok": False, "grund": "OKX nicht verbunden"}
        favoriten = self._favoriten()
        try:
            # Favoriten erhalten nur eine garantiert vollstaendige Pruefung
            # im OKX-Katalog. Sie bestehen trotzdem alle harten Filter und
            # werden erst bei ausreichend gutem Rang/Bewaehrung handelbar.
            auswahl = selektor.auswahl(bar=self._okx_bar(), favoriten=favoriten)
        except (VerbindungVerloren, BrokerFehler) as exc:
            self.letzter_fehler = str(exc)
            logger.warning("Krypto-Universumslauf fehlgeschlagen: %s", exc)
            return {"ok": False, "grund": str(exc)}

        diff = self.universum.lauf(auswahl,
                                   offene_positionen=self.buch.symbole(),
                                   favoriten=favoriten)
        # v8.1.4: Zaehlen, welcher Filter wie viele Werte verwirft. Am
        # 25.08.2026 bestanden 2 von 581 Instrumenten die harten Filter --
        # welcher Filter dafuer verantwortlich war, stand nirgends.
        import universe_diagnose
        diagnose = universe_diagnose.protokolliere(auswahl)
        self.letzter_universumslauf = {
            "zeit": datetime.now(timezone.utc).isoformat(),
            "diff": diff.als_dict(),
            "pool": auswahl.get("pool"),
            "katalog": auswahl.get("katalog_gesamt"),
            "dauer": auswahl.get("dauer_sekunden"),
            "diagnose": diagnose,
        }
        if diff.hat_aenderungen:
            self._melde(f"Krypto-Universum: {diff.kurzfassung()}"
                        + (f" | neu: {', '.join(diff.aufgenommen)}" if diff.aufgenommen else "")
                        + (f" | Beobachtung: {', '.join(diff.beobachtung_gestartet)}"
                           if diff.beobachtung_gestartet else "")
                        + (f" | raus: {', '.join(diff.entfernt)}" if diff.entfernt else ""))
        self.bereitschaft.melde("universum", True,
                                f"{auswahl.get('pool', 0)} im Pool")
        return {"ok": True, "aenderungen": diff.kurzfassung(),
                "handelbar": len(self.universum.handelbare_symbole("okx"))}

    def _okx_bar(self) -> str:
        from broker.okx import BAR_MAP
        return BAR_MAP.get(str(getattr(self.cfg, "CRYPTO_BAR_SIZE", "15 mins")).lower(), "15m")

    def _favoriten(self) -> list[str]:
        try:
            from favorites import load_favorites
            eintraege = load_favorites()
        except Exception:
            logger.debug("Favoriten nicht lesbar", exc_info=True)
            return []
        return [str(f.symbol).upper() for f in eintraege
                if str(getattr(f, "asset_type", "")).lower() == "crypto"]

    # -- Positionsueberwachung ---------------------------------------------
    def pruefe_positionen(self) -> dict:
        """Schutz nachziehen, Ausstiege pruefen, Buch mit dem Broker abgleichen."""
        # Auch Wartungs-/Migrationstests koennen den Abgleich ohne einen
        # initialisierten Broker-Hub aufrufen. Dann bleibt die sichere
        # Zwei-Snapshot-Regel aktiv, nur die Historiennachladung entfaellt.
        try:
            broker = self.broker
        except (AttributeError, KeyError):
            broker = None
        if broker is None:
            return {"ok": False, "grund": "OKX nicht verbunden"}

        bericht = {"geprueft": 0, "geschlossen": [], "schutz_ergaenzt": [],
                   "abgeglichen": [], "manuelle_klaerung": []}
        try:
            bericht["manuelle_auftraege"] = self._verarbeite_manuelle_auftraege(broker)
        except Exception as exc:
            logger.exception("Manuelle OKX-Auftraege nicht verarbeitbar: %s", exc)
            bericht["manuelle_auftraege"] = []
        try:
            import okx_reconciliation_actions
            bericht["manuelle_klaerung"] = okx_reconciliation_actions.verarbeite(
                self, broker)
        except Exception as exc:
            logger.warning("Manuelle OKX-Klaerungsaktionen nicht verarbeitbar: %s", exc,
                           exc_info=True)

        # Persistierte, unklare Orders werden zuerst und ausschliesslich ueber
        # clOrdId/ordId abgefragt. Es gibt hier bewusst keinen zweiten POST.
        try:
            if hasattr(broker, "reconcile_order_evidence"):
                self._reconcile_pending_okx_orders(broker)
        except Exception as exc:
            logger.warning("OKX-Order-Reconciliation fehlgeschlagen: %s", exc,
                           exc_info=True)

        try:
            bestaende = {p.symbol.upper(): p for p in broker.positionen()}
        except BrokerFehler as exc:
            return {"ok": False, "grund": f"Bestaende nicht abrufbar: {exc}"}
        try:
            bericht["verwaiste_schutzorders_entfernt"] = int(
                broker.verwaiste_orders_aufraeumen()
                if hasattr(broker, "verwaiste_orders_aufraeumen") else 0)
        except BrokerFehler as exc:
            logger.warning("Verwaiste OKX-Schutzorders nicht pruefbar: %s", exc)

        for position in self.buch.alle():
            bericht["geprueft"] += 1
            symbol = position.symbol.upper()
            bestand = bestaende.get(symbol)

            # Ein beobachteter Legacy-/Kontohinweis ist keine Botposition.
            # Bis 9.0.11 wurde er trotzdem gegen den Gesamtsaldo verglichen;
            # daraus entstand die falsche Meldung zu 0,996348 ETH.
            #
            # v9.2: Die Grenze verlaeuft jetzt am EIGENTUM, nicht am
            # Verwaltungsmodus. Eine bewiesene, aber pausierte Botposition
            # wurde vorher komplett uebersprungen -- ohne Mengenabgleich, ohne
            # Erkennung externer Verkaeufe und ohne Pruefung des
            # Broker-Schutzes. Das ist der gefaehrlichste Zustand ueberhaupt:
            # echtes Geld, das niemand mehr beobachtet. Verkauft wird eine
            # pausierte Position weiterhin nicht -- das haengt an
            # darf_schutz_ausfuehren, weiter unten.
            if not position.safety_monitoring_enabled:
                bericht.setdefault("nur_beobachtet", []).append(symbol)
                continue
            if not position.darf_schutz_ausfuehren:
                bericht.setdefault("ueberwacht_ohne_automatik", []).append(symbol)

            # 1. Abgleich zwischen Kontostand und Positionsbuch.
            #
            #    ACHTUNG, das ist die Stelle, an der am 25.08.2026 ein
            #    Fremdbestand von 0,94 BTC verkauft wurde. Bis 8.1.3 stand
            #    hier "position.menge = bestand.quantity" -- der Bot hat also
            #    den GESAMTEN Kontostand der Waehrung als seine Position
            #    uebernommen. broker.positionen() liefert bei OKX Spot aber
            #    Guthaben, keine Positionen; das steht so im Adapter.
            #
            #    Ab 8.1.4 wird nach RICHTUNG unterschieden:
            #      weniger im Konto  -> Buch nach unten korrigieren (sicher)
            #      mehr   im Konto   -> Ueberhang gehoert dem Bot NICHT
            if bestand is None or not _ist_positiv(getattr(bestand, "quantity", 0.0)):
                # NICHT sofort loeschen. Ein einzelner Nullstand kann auch ein
                # unvollstaendiger Guthaben-Schnappschuss sein (Stream-Snapshot,
                # Transfer ins Funding-Konto). Erst nach zwei Zyklen in Folge
                # gilt die Position als geschlossen -- vorher wuerde ein
                # erfundenes Ergebnis in die Tagesverlustgrenze wandern.
                self._fehlender_bestand[symbol] = self._fehlender_bestand.get(symbol, 0) + 1
                if self._fehlender_bestand[symbol] < 2:
                    self._melde(f"Krypto {symbol}: kein Guthaben gemeldet. Wird im "
                                f"naechsten Takt erneut geprueft, bevor die Position "
                                f"geschlossen wird.", wichtig=False)
                    continue
                self._fehlender_bestand.pop(symbol, None)
                self._position_verschwunden(position, bericht)
                continue
            self._fehlender_bestand.pop(symbol, None)

            konto = float(bestand.quantity)
            if not _ist_positiv(konto):
                # NaN oder Unendlich: laeuft durch jeden Vergleich hindurch und
                # wuerde stillschweigend als "stimmt mit dem Buch ueberein"
                # gelten. Lieber diesen Takt ueberspringen.
                logger.warning("Krypto %s: unbrauchbarer Kontostand %r -- Takt "
                               "uebersprungen.", symbol, bestand.quantity)
                continue
            # 9.0.14 hat nach einem externen Vollverkauf die Buchmenge auf
            # den nicht handelbaren Reststaub verkleinert (ONDO 0,002515).
            # Dadurch ist Konto==Buch und eine normale Abweichungspruefung
            # findet den Verkauf nie wieder. Die urspruengliche Ledger-Menge
            # plus echte OKX-Sell-Fills reparieren auch diesen Altzustand.
            dust_price = float(getattr(bestand, "market_price", 0.0) or
                               self._letzter_kurs(position) or position.einstieg)
            if not self._rest_lohnt_sich(position, konto, dust_price):
                try:
                    import trade_ledger
                    open_trade = trade_ledger.offener_trade("okx", symbol) or {}
                    original_qty = max(float(position.menge),
                                       float(open_trade.get("menge") or 0.0))
                except Exception:
                    original_qty = float(position.menge)
                evidence = self._externer_verkaufsbeweis(position, original_qty)
                if evidence and original_qty > position.menge:
                    self._position_extern_geschlossen(
                        position, evidence, bericht, residual=konto,
                        close_quantity=original_qty)
                    continue
            abweichung = abs(konto - position.menge) / max(position.menge, 1e-12)
            if abweichung > MENGEN_TOLERANZ:
                if konto < position.menge:
                    # Extern verkauft, Schutzorder gezogen oder Teilausfuehrung.
                    # Nach unten korrigieren ist immer sicher.
                    alt_menge = position.menge
                    evidence = self._externer_verkaufsbeweis(position, alt_menge)
                    restkurs = float(getattr(bestand, "market_price", 0.0) or
                                     self._letzter_kurs(position) or position.einstieg)
                    if evidence and not self._rest_lohnt_sich(position, konto, restkurs):
                        self._position_extern_geschlossen(position, evidence, bericht,
                                                          residual=konto,
                                                          close_quantity=alt_menge)
                        continue
                    position.menge = konto
                    self.buch.setze(position)
                    bericht["abgeglichen"].append(symbol)
                    self._melde(
                        f"Krypto {symbol}: Bestand kleiner als im Buch "
                        f"({konto:g} statt {alt_menge:g}) -- Buchmenge nach unten "
                        f"korrigiert. Moegliche Ursache: Schutzorder ausgeloest "
                        f"oder extern verkauft.", wichtig=True)
                else:
                    # MEHR im Konto als im Buch. Der Ueberhang ist NICHT die
                    # Position des Bots. Das Buch bleibt, wie es ist.
                    #
                    # v9.1: Vorher wurde hier KEIN Fill-Nachweis geholt --
                    # nur im Zweig "konto < menge". Genau daran hing ein
                    # Zweitverkauf: war der eigene Verkauf bereits ausgefuehrt,
                    # die Verbuchung aber verloren (Prozessabbruch, unklarer
                    # Zustand), und lag Fremdbestand desselben Coins im Konto,
                    # dann galt weiter die veraltete Buchmenge -- und der
                    # naechste Stop verkaufte sie ein zweites Mal, aus dem
                    # Bestand des Nutzers. Das ist das Schadensmuster vom
                    # 25.08.2026 ueber einen anderen Weg.
                    beweis = self._externer_verkaufsbeweis(position, position.menge)
                    if beweis:
                        self._melde(
                            f"Krypto {symbol}: eigener Verkauf ueber echte OKX-Fills "
                            f"belegt, waehrend {konto:g} im Konto liegen. Die Position "
                            "wird geschlossen; der Rest gehoert nicht zum Bot.",
                            wichtig=True, klasse="KRITISCH")
                        self._position_extern_geschlossen(
                            position, beweis, bericht, residual=konto)
                        continue
                    ueberhang = konto - position.menge
                    bericht.setdefault("fremdbestand", []).append(
                        {"symbol": symbol, "menge": round(ueberhang, 12)})
                    # Ein zusaetzliches Konto-Asset ist bei Spot normal und
                    # weder Fehler noch Einstiegssperre. Nur die bewiesene
                    # Botmenge bleibt verwaltet.
                    self._gemeldeter_ueberhang.add(symbol)
            else:
                self._gemeldeter_ueberhang.discard(symbol)

            # Der letzte gehandelte Tickerpreis ist nicht zwingend fuer
            # unsere volle Menge ausfuehrbar. Stop, Ziel und Strategie sehen
            # deshalb nur den aktuellen Full-size-Verkaufs-VWAP aus dem Buch.
            try:
                ausfuehrbar = broker.execution_quote(
                    self._instrument(symbol, position.inst_id),
                    position.menge, side="sell")
                preis = float(ausfuehrbar.get("vwap") or 0.0)
            except AttributeError:
                # BrokerBase-Kompatibilitaet fuer alte Paper-/Testadapter.
                # Der echte OKXBroker besitzt execution_quote immer.
                preis = float(bestand.market_price or 0.0)
            except BrokerFehler as exc:
                logger.warning("Krypto %s: ausfuehrbarer Verkaufspreis nicht sicher "
                               "messbar; kein Ausstieg in diesem Takt (%s)", symbol, exc)
                continue
            if preis <= 0:
                continue
            position.hoechstkurs = max(position.hoechstkurs, preis)

            # 2. Broker-Schutz nachziehen, falls er fehlt.
            #
            # v9.1: Auch dann, wenn ein Verkauf mittendrin abgebrochen ist.
            # ``exit_state`` blieb bis 9.0.15 auf SUBMITTING stehen und wurde
            # NIRGENDS ausgewertet -- die einzigen Leser waren der
            # Dataclass-Default und ein Anzeigefeld der WebUI. Ein Prozesstod
            # zwischen Storno und Verkauf hinterliess damit eine Position, die
            # sich fuer geschuetzt hielt und es nicht war.
            exit_unterbrochen = str(getattr(position, "exit_state", "")).upper() in {
                "SUBMITTING", "MANUAL_EXIT_PENDING"}
            if not position.broker_schutz or exit_unterbrochen:
                try:
                    try:
                        zustand = broker.reconcile_position_protection(
                            self._instrument(symbol, position.inst_id), position.menge,
                            position.stop, position.take_profit,
                            protection_client_id=position.protection_client_order_id,
                            trade_quote_ccy=position.trade_quote_ccy)
                    except TypeError:
                        zustand = broker.reconcile_position_protection(
                            self._instrument(symbol, position.inst_id), position.menge,
                            position.stop, position.take_profit)
                    position.broker_schutz = bool(zustand.get("protection_confirmed"))
                    position.protection_algo_id = str(
                        zustand.get("algo_id") or position.protection_algo_id or "")
                    position.protection_client_order_id = str(
                        zustand.get("algo_client_id") or
                        position.protection_client_order_id)
                    position.protection_status = (
                        "ACTIVE" if position.broker_schutz else
                        "MISSING" if bool(zustand.get("checked")) else "PENDING")
                    if exit_unterbrochen and position.broker_schutz:
                        # Der abgebrochene Verkauf ist abgeschlossen behandelt:
                        # die Position ist wieder geschuetzt und darf normal
                        # weiterlaufen.
                        position.exit_state = "IDLE"
                        self._melde(
                            f"Krypto {symbol}: unterbrochener Verkauf erkannt, "
                            "Broker-Schutz wurde neu gesetzt.",
                            wichtig=True, klasse="KRITISCH")
                    self.buch.setze(position)
                    self._ledger_schutz_synchronisieren(
                        position, str(zustand.get("detail") or ""))
                    if position.broker_schutz:
                        bericht["schutz_ergaenzt"].append(symbol)
                except BrokerFehler as exc:
                    logger.warning("Schutzabgleich %s: %s", symbol, exc)

            # 3. Client-Stop als zweite Sicherung. Der Broker-Schutz ist die
            #    erste; diese Pruefung greift, wenn er fehlt oder nicht zog.
            #    Eine pausierte oder fremde Position wurde bereits oben als
            #    reiner Kontobestand ausgeschlossen.
            if preis <= position.stop:
                self._schliesse(position, preis, "Stop-Loss erreicht",
                                allow_manual=True)
                bericht["geschlossen"].append(symbol)
                continue
            if position.take_profit > 0 and preis >= position.take_profit:
                self._schliesse(position, preis, "Gewinnziel erreicht",
                                allow_manual=True)
                bericht["geschlossen"].append(symbol)
                continue

            if str(position.verwaltung).upper() == VERWALTUNG_AUTO:
                strategy_exit, strategy_reason = self._strategy_exit(position, preis)
                if strategy_exit:
                    self._schliesse(position, preis, strategy_reason)
                    bericht["geschlossen"].append(symbol)
                    continue

            # MFE/MAE bewusst ERST HIER: die Aufzeichnung schreibt in SQLite
            # und darf die Stop- und Zielpruefung der naechsten Position
            # unter keinen Umstaenden verzoegern.
            try:
                import trade_ledger
                trade_ledger.hoechstkurs_melden("okx", symbol, preis)
            except Exception:
                logger.debug("MFE/MAE OKX nicht fortgeschrieben", exc_info=True)

        # 4. Verwaiste offene Ledger-Zeilen abgleichen. Sie werden niemals
        #    automatisch verkauft oder einer Position zugeraten. Fehlt auch
        #    beim zweiten vollstaendigen Broker-Snapshot jeder Bestand, wird
        #    nur der offene Status beendet; Preis und P&L bleiben unbekannt.
        try:
            bericht["ledger_reconciliation"] = self._offene_ledger_abgleichen(bestaende)
        except Exception as exc:
            logger.warning("OKX-Ledgerabgleich fehlgeschlagen: %s", exc, exc_info=True)
            bericht["ledger_reconciliation"] = {"ok": False, "grund": str(exc)}

        # 5. Guthaben klassifizieren statt nur aufzuzaehlen.
        #    Vorher stand hier alle paar Minuten "OKX-Guthaben ohne
        #    Positionsbuch-Eintrag: BTC, XRP, USD, ETH" -- und warf damit
        #    Cash (USD), manuelle Altbestaende und echte ungeklaerte
        #    Exposure in einen Topf. Nur der letzte Fall ist gefaehrlich.
        try:
            import exposure_klassifizierung as ek
            import trade_ledger
            guthaben = broker.client.balances() if hasattr(broker, "client") else {}
            preise = {p.symbol.upper(): float(p.market_price or 0.0)
                      for p in broker.positionen()}
            einstufung = ek.klassifiziere(
                guthaben,
                positionsbuch=self.buch.alle(),
                offene_orders=[{"symbol": s} for s in self._offene_order_symbole()],
                ledger_trades=trade_ledger.offene_trades("okx"),
                preise=preise, cfg=self.cfg)
            bericht["exposure"] = einstufung
            self._letzte_exposure = dict(einstufung)
            logger.info("OKX-Guthaben: %s", ek.kurzfassung(einstufung))
            if einstufung.get("einstiege_gesperrt"):
                self._exposure_sperre = einstufung.get("sperrgruende", [])
                alert_text = "; ".join(self._exposure_sperre)
                old_text, old_at = self._last_exposure_alert
                cooldown = max(60.0, float(getattr(
                    self.cfg, "OKX_EXPOSURE_ALERT_COOLDOWN_SECONDS", 900.0)))
                if alert_text != old_text or time.time() - old_at >= cooldown:
                    self._melde("Krypto: neue Einstiege gesperrt -- ungeklaerter Bestand: "
                                + alert_text, wichtig=True)
                    self._last_exposure_alert = (alert_text, time.time())
            else:
                self._exposure_sperre = []
                self._last_exposure_alert = ("", 0.0)
        except Exception as exc:
            logger.warning("Guthabenklassifizierung fehlgeschlagen: %s", exc, exc_info=True)

        bericht["ok"] = True
        self.topf.setze_offene_positionen(len(self.buch.aktive()))
        # Der Abgleich ist einmal vollstaendig durchgelaufen -- das ist die
        # wichtigste Bedingung der Anlaufsperre. Ohne sie haette der Bot am
        # 25.08.2026 einen Fremdbestand als eigene Position uebernommen.
        self.bereitschaft.melde("reconciliation", True,
                                f"{bericht['geprueft']} Positionen geprueft")
        return bericht

    def _offene_ledger_abgleichen(self, bestaende: dict) -> dict:
        """Offene OKX-Ledgerzeilen gegen Buch und echten Bestand pruefen."""
        import trade_ledger

        buch_positionen = {str(p.symbol).upper(): p for p in self.buch.alle()}
        geschlossen: list[int] = []
        residual: list[dict] = []
        history_recovered: list[dict] = []
        account_mismatch: list[dict] = []
        gesehen: set[int] = set()
        # Der Datenbankabgleich wird auch von Migration/Diagnose ohne einen
        # vollstaendig gestarteten Broker-Hub verwendet.
        try:
            broker = self.broker
        except (AttributeError, KeyError):
            broker = None
        current_fingerprint = (broker.account_fingerprint()
                               if broker is not None and hasattr(broker, "account_fingerprint")
                               else "")

        # 9.0.12 konnte eine OKX-tradeId eines anderen Instruments fuer
        # identisch halten (z.B. LINK tradeId=1 und ONDO tradeId=1). Dadurch
        # blieb eine beweisbare Position ohne Ledgerzeile. Aus dem haltbaren
        # Positionsbuch wird dieser Eintrag jetzt idempotent rekonstruiert.
        existing_orders = {str(t.get("entry_order_id") or "")
                           for t in trade_ledger.offene_trades("okx")}
        repaired_ledgers: list[dict] = []
        for p in buch_positionen.values():
            if (not p.darf_schutz_ausfuehren or not p.order_id
                    or str(p.order_id) in existing_orders):
                continue
            try:
                trade_id = trade_ledger.trade_open(
                    broker="okx", symbol=p.symbol, menge=p.menge,
                    einstieg_preis=p.einstieg, asset_type="crypto",
                    waehrung=p.trade_quote_ccy, decision_id=p.decision_id,
                    paper=bool(p.paper), zeit=p.eroeffnet_am,
                    broker_position_id=p.inst_id, entry_order_id=p.order_id,
                    entry_fill_id=(p.fill_ids[0] if p.fill_ids else ""),
                    entry_fill_ids=list(p.fill_ids or []),
                    client_order_id=p.client_order_id or p.referenz,
                    order_tag=p.order_tag,
                    ownership_status="VERIFIED_BROKER_FILL_CHAIN",
                    entry_fee_by_currency=dict(p.entry_fee_by_currency or {}),
                    broker_account_fingerprint=current_fingerprint,
                    reconciliation_status="CONFIRMED_OPEN",
                    notiz="Ledger aus verifiziertem Positionsbuch 9.0.13 rekonstruiert")
            except Exception:
                logger.warning("Ledger-Rekonstruktion %s fehlgeschlagen", p.symbol,
                               exc_info=True)
                trade_id = None
            if trade_id:
                trade_ledger.set_protection(
                    trade_id, algo_id=p.protection_algo_id,
                    client_order_id=p.protection_client_order_id,
                    status=p.protection_status)
                repaired_ledgers.append({"trade_id": trade_id, "symbol": p.symbol})
                existing_orders.add(str(p.order_id))
        offen = trade_ledger.offene_trades("okx")

        def historical_exit(trade: dict) -> dict | None:
            """Noch nicht verbuchte SELL-Fills nach einem Einstieg nachladen."""
            if broker is None or not hasattr(broker, "historical_fills"):
                return None
            rows = broker.historical_fills(
                str(trade.get("symbol") or ""),
                since=str(trade.get("eingestiegen_am") or ""))
            sells = [r for r in rows if str(r.get("side") or "").lower() == "sell"
                     and float(r.get("fillSz") or 0) > 0
                     and float(r.get("fillPx") or 0) > 0]
            protection_algo_id = str(trade.get("protection_algo_id") or "")
            if protection_algo_id:
                proven_orders = (broker.protection_exit_order_ids(protection_algo_id)
                                 if hasattr(broker, "protection_exit_order_ids") else set())
                if not proven_orders:
                    # Ohne algoId -> ordId -> Fill-Kette darf ein manueller
                    # Verkauf desselben Symbols nicht dem Bot zugerechnet werden.
                    return None
                sells = [r for r in sells if str(r.get("ordId") or "") in proven_orders]
            if not sells:
                return None
            group = trade_ledger.trade_group(
                broker="okx", symbol=str(trade.get("symbol") or ""),
                eingestiegen_am=str(trade.get("eingestiegen_am") or ""))
            already = sum(float(x.get("menge") or 0) for x in group
                          if x.get("ausgestiegen_am"))
            remaining_skip = max(0.0, already)
            unbooked: list[tuple[float, float, float]] = []
            for row in sells:
                qty = float(row.get("fillSz") or 0)
                if remaining_skip >= qty - 1e-12:
                    remaining_skip -= qty
                    continue
                if remaining_skip > 0:
                    qty -= remaining_skip; remaining_skip = 0.0
                if qty > 1e-12:
                    unbooked.append((qty, float(row.get("fillPx") or 0),
                                     abs(float(row.get("fee") or 0))))
            open_qty = float(trade.get("menge") or 0)
            available = sum(x[0] for x in unbooked)
            sold = min(open_qty, available)
            if sold <= 1e-12:
                return None
            left = sold; value = 0.0; fees = 0.0
            for qty, price, fee in unbooked:
                used = min(left, qty)
                if used <= 0:
                    break
                value += used * price
                fees += fee * (used / qty)
                left -= used
            avg = value / sold if sold > 0 else 0.0
            try:
                closed_id = trade_ledger.trade_close(
                    broker="okx", symbol=str(trade.get("symbol") or ""),
                    ausstieg_preis=avg, menge=sold,
                    exit_grund="OKX-Fill-Historie nachgeladen",
                    gebuehr=fees, einstieg_preis=trade.get("einstieg_preis"),
                    eingestiegen_am=trade.get("eingestiegen_am"),
                    asset_type="crypto", waehrung=str(trade.get("waehrung") or ""),
                    paper=bool(trade.get("paper", 1)),
                    notiz="Paginiert aus /trade/fills-history rekonstruiert")
            except Exception as exc:
                logger.warning("OKX-Historienfill %s konnte nicht ins Ledger geschrieben werden: %s",
                               trade.get("symbol"), exc, exc_info=True)
                return None
            return ({"trade_id": int(closed_id or trade.get("trade_id") or 0),
                     "symbol": str(trade.get("symbol") or ""),
                     "nachgebucht": sold, "preis": avg}
                    if closed_id else None)

        for trade in offen:
            trade_id = int(trade.get("trade_id") or 0)
            symbol = str(trade.get("symbol") or "").upper()
            if not trade_id or not symbol:
                continue
            gesehen.add(trade_id)
            stored_fingerprint = str(trade.get("broker_account_fingerprint") or "")
            if stored_fingerprint and current_fingerprint and stored_fingerprint != current_fingerprint:
                trade_ledger.set_reconciliation_status(
                    trade_id, "ACCOUNT_MISMATCH",
                    notiz="Trade stammt aus einem anderen OKX Demo/Live-/Unterkonto")
                account_mismatch.append({"trade_id": trade_id, "symbol": symbol})
                continue

            position = buch_positionen.get(symbol)
            if position is not None:
                try:
                    stored_fills = set(json.loads(
                        str(trade.get("entry_fill_ids_json") or "[]")))
                except (TypeError, ValueError, json.JSONDecodeError):
                    stored_fills = set()
                if str(trade.get("entry_fill_id") or "").strip():
                    stored_fills.add(str(trade.get("entry_fill_id")))
                position_fills = {str(x) for x in (position.fill_ids or []) if str(x)}
                # v9.2: NUR die Broker-ID-Kette entscheidet ueber Eigentum.
                # Vorher stand hier position.darf_schutz_ausfuehren -- damit war
                # der Verwaltungsmodus Teil des Eigentumsnachweises. Eine wegen
                # eines Strategieproblems pausierte Position galt dadurch als
                # "Lokaler Eintrag ohne identische ordId/clOrdId/tradeId-Kette",
                # obwohl die Kette vollstaendig vorlag.
                exact = bool(
                    position.ownership_chain_complete
                    and str(trade.get("entry_order_id") or "") == str(position.order_id or "")
                    and bool(stored_fills & position_fills)
                    and (not str(trade.get("client_order_id") or "")
                         or str(trade.get("client_order_id")) ==
                         str(position.client_order_id or position.referenz or "")))
                self._fehlender_ledger_bestand.pop(trade_id, None)
                if exact:
                    # v9.2: Ein Strategieproblem wird getrennt ausgewiesen. Die
                    # Position bleibt bestaetigt -- sie gehoert dem Bot.
                    zusatz = ""
                    if str(getattr(position, "management_status", "")):
                        zusatz = (f"; Verwaltung: {position.management_status} "
                                  "(Eigentumsnachweis unveraendert)")
                    trade_ledger.set_reconciliation_status(
                        trade_id, "CONFIRMED_OPEN",
                        broker_position_id=str(position.inst_id or ""),
                        notiz="ordId, clOrdId und echte OKX-tradeId-Fills stimmen ueberein"
                              + zusatz)
                else:
                    trade_ledger.set_reconciliation_status(
                        trade_id, "EXTERNAL_OBSERVE",
                        broker_position_id=str(position.inst_id or ""),
                        notiz=("Lokaler Eintrag ohne identische ordId/clOrdId/tradeId-Kette; "
                               "Kontoguthaben bleibt unangetastet"))
                    residual.append({"trade_id": trade_id, "symbol": symbol,
                                     "status": "EXTERNAL_OBSERVE"})
                continue

            # Fehlende/alte REST-Seiten duerfen einen Verkauf nicht unsichtbar
            # lassen. Vor der Guthabenbewertung wird die archivierte Fill-
            # Historie paginiert nachgeladen und bereits verbuchte Teilfills
            # werden mengenbasiert abgezogen.
            try:
                recovered = historical_exit(trade)
            except Exception as exc:
                logger.warning("OKX-Fill-Historie %s nicht lesbar: %s", symbol, exc)
                recovered = None
            if recovered:
                history_recovered.append(recovered)
                refreshed = trade_ledger.offener_trade("okx", symbol)
                if refreshed is None:
                    self._fehlender_ledger_bestand.pop(trade_id, None)
                    continue
                trade = refreshed
                trade_id = int(trade.get("trade_id") or trade_id)
                gesehen.add(trade_id)
            bestand = bestaende.get(symbol)
            konto = float(getattr(bestand, "quantity", 0.0) or 0.0) if bestand else 0.0
            konto_preis = float(getattr(bestand, "market_price", 0.0) or 0.0) if bestand else 0.0
            dust_limit = float(getattr(getattr(self, "cfg", config),
                                       "OKX_DUST_VALUE_LIMIT", 1.0))
            if _ist_positiv(konto) and konto_preis > 0 and konto * konto_preis <= dust_limit:
                if trade_ledger.mark_reconciled_closed(
                        trade_id,
                        grund="Nicht handelbarer OKX-Rundungsrest (Staub)",
                        notiz=(f"Rest {konto:g} {symbol} im Wert von rund "
                               f"{konto * konto_preis:.4f}; kein Auto-Verkauf, "
                               "keine Einstiegssperre")):
                    geschlossen.append(trade_id)
                    self._fehlender_ledger_bestand.pop(trade_id, None)
                continue

            # Ein migrierter Alteintrag ohne irgendeinen Eigentumsbeweis darf
            # nicht allein deshalb fuer immer als Bot-Position gelten, weil
            # dasselbe Asset als frei verfuegbares Kontoguthaben existiert.
            # Genau das ist beim gemeldeten SOL-Fall passiert: Der Ledger kannte
            # weder decision/order/fill noch Positionsbuch, OKX meldete aber ein
            # reales SOL-Guthaben. Zwei vollstaendige, gleiche Snapshots schliessen
            # hier nur den unbeweisbaren Ledger-Eintrag. Das SOL-Guthaben bleibt
            # unangetastet und wird anschliessend als EXTERNAL_HOLDING angezeigt.
            legacy_unbeweisbar = (
                str(trade.get("link_status") or "") == "LEGACY_UNLINKED"
                and not trade.get("decision_id")
                and not str(trade.get("entry_order_id") or "").strip()
                and not str(trade.get("entry_fill_id") or "").strip()
                and not str(trade.get("broker_position_id") or "").strip()
                and not str(trade.get("broker_account_fingerprint") or "").strip()
            )
            if legacy_unbeweisbar:
                anzahl = self._fehlender_ledger_bestand.get(trade_id, 0) + 1
                self._fehlender_ledger_bestand[trade_id] = anzahl
                if anzahl < 2:
                    trade_ledger.set_reconciliation_status(
                        trade_id, "LEGACY_ORPHAN_PENDING",
                        notiz=("Alteintrag ohne decision/order/fill/Positionsbuch; "
                               "zweiter vollstaendiger OKX-Snapshot erforderlich"))
                    residual.append({
                        "trade_id": trade_id, "symbol": symbol,
                        "ledger_menge": float(trade.get("menge") or 0.0),
                        "broker_menge": konto,
                        "status": "LEGACY_ORPHAN_PENDING",
                    })
                    continue
                if trade_ledger.mark_reconciled_closed(
                        trade_id,
                        grund="Unbeweisbarer Legacy-Ledgereintrag zweifach abgeglichen",
                        notiz=("Kein decision/order/fill/Positionsbuch-Bezug. Ein vorhandenes "
                               f"{symbol}-Guthaben bleibt externer Bestand; kein Auto-Verkauf, "
                               "Ausstiegspreis und P&L unbekannt")):
                    geschlossen.append(trade_id)
                    self._fehlender_ledger_bestand.pop(trade_id, None)
                continue

            if _ist_positiv(konto):
                self._fehlender_ledger_bestand.pop(trade_id, None)
                trade_ledger.set_reconciliation_status(
                    trade_id, "RESIDUAL_EXPOSURE",
                    notiz=("Coin-Guthaben vorhanden, aber kein Eintrag im OKX-Positionsbuch; "
                           "wird nicht automatisch verkauft"))
                residual.append({
                    "trade_id": trade_id, "symbol": symbol,
                    "ledger_menge": float(trade.get("menge") or 0.0),
                    "broker_menge": konto,
                    "status": "RESIDUAL_EXPOSURE",
                })
                continue

            anzahl = self._fehlender_ledger_bestand.get(trade_id, 0) + 1
            self._fehlender_ledger_bestand[trade_id] = anzahl
            if anzahl < 2:
                trade_ledger.set_reconciliation_status(
                    trade_id, "PENDING_CONFIRMATION",
                    notiz="Erster vollstaendiger OKX-Snapshot ohne Bestand")
                continue
            if trade_ledger.mark_reconciled_closed(
                    trade_id,
                    grund="Brokerbestand nicht mehr vorhanden (zweifach bestaetigt)",
                    notiz="Automatischer OKX-Abgleich; Ausstiegspreis und P&L unbekannt"):
                geschlossen.append(trade_id)
                self._fehlender_ledger_bestand.pop(trade_id, None)

        for trade_id in list(self._fehlender_ledger_bestand):
            if trade_id not in gesehen:
                self._fehlender_ledger_bestand.pop(trade_id, None)
        if geschlossen:
            self._melde(
                "Krypto: verwaiste offene Historieneintraege wurden nach zwei "
                "Brokerabgleichen geschlossen. Ergebnis bleibt als unbekannt markiert: "
                + ", ".join(str(x) for x in geschlossen),
                wichtig=True)
        return {"ok": True, "geschlossen": geschlossen, "residual": residual,
                "history_recovered": history_recovered,
                "repaired_ledgers": repaired_ledgers,
                "account_mismatch": account_mismatch,
                "erneut_zu_pruefen": sorted(self._fehlender_ledger_bestand)}

    def _verarbeite_manuelle_auftraege(self, broker) -> list[dict]:
        """Fuehrt WebUI-Absichten einmalig im Handelskern aus."""
        import manual_trade_control as controls
        import trade_ledger
        results = []
        for command in controls.pending():
            command_id = str(command.get("id") or "")
            symbol = str(command.get("symbol") or "").upper()
            position = self.buch.hole(symbol)
            try:
                if position is None or not position.ist_bewiesene_botposition:
                    raise ValueError("Keine eindeutig bewiesene Botposition im Positionsbuch.")
                trade = trade_ledger.offener_trade("okx", symbol)
                if not trade or int(trade.get("trade_id") or 0) != int(command.get("trade_id") or 0):
                    raise ValueError("Ledger-Trade und Positionsbuch stimmen nicht exakt ueberein.")
                expected_account = str(command.get("account_fingerprint") or "")
                current_account = str(getattr(broker, "account_fingerprint", lambda: "")() or "")
                if expected_account and expected_account != current_account:
                    raise ValueError("Der Auftrag gehoert zu einem anderen OKX-Konto.")
                if str(command.get("instrument") or "") and str(command.get("instrument")) != str(position.inst_id):
                    raise ValueError("Das OKX-Instrument des Auftrags stimmt nicht mit der Position ueberein.")
                # Vor jeder manuellen Handelswirkung erneut Brokerwahrheit
                # pruefen. Ein bereits extern verkaufter Bot-Trade darf nie
                # aus einem zufaellig vorhandenen Konto-Asset bedient werden.
                prior_exit = self._externer_verkaufsbeweis(position, position.menge)
                if prior_exit:
                    raise ValueError(
                        "OKX meldet bereits passende Verkaufsfills; zuerst den Positionsabgleich ausfuehren.")
                balances = {str(row.symbol).upper(): row for row in broker.positionen()}
                held = float(getattr(balances.get(symbol), "quantity", 0.0) or 0.0)
                if held + max(1e-12, position.menge * 0.001) < position.menge:
                    raise ValueError(
                        "OKX-Gesamtbestand ist kleiner als die bewiesene Botposition; keine manuelle Order gesendet.")
                controls.update(command_id, "PROCESSING", "Vom Handelskern uebernommen.")
                actor = str(command.get("actor") or "webui")
                action = str(command.get("action") or "")

                if action == "SET_PROTECTION":
                    stop = float(command.get("stop") or 0.0)
                    take = float(command.get("take_profit") or 0.0)
                    quote = broker.execution_quote(
                        self._instrument(symbol, position.inst_id), position.menge, side="sell")
                    current = float(quote.get("vwap") or 0.0)
                    max_risk = max(0.01, float(getattr(
                        self.cfg, "MANUAL_CRYPTO_MAX_STOP_DISTANCE_PCT", 0.25)))
                    if current <= 0 or not (stop < current < take):
                        raise ValueError("Es muss gelten: Stop-Loss < aktueller Verkaufskurs < Take-Profit.")
                    if (current - stop) / current > max_risk:
                        raise ValueError(
                            f"Stop-Loss liegt mehr als {max_risk * 100:.1f}% unter dem aktuellen Kurs.")
                    # Unmittelbar vor dem Broker-POST dauerhaft auf manuell
                    # schalten. Auch ein unklarer Amend darf danach keinen
                    # Freqtrade-Ausgang mehr ausloesen.
                    position.manuell(actor, "Manuelle Verwaltung ueber NEXUS aktiviert")
                    position.exit_state = "MANUAL"
                    self.buch.setze(position)
                    try:
                        state = broker.amend_position_protection(
                            self._instrument(symbol, position.inst_id), position.menge,
                            stop, take, algo_id=position.protection_algo_id,
                            trade_quote_ccy=position.trade_quote_ccy)
                    except OrderStatusUnklar as exc:
                        # v9.1: Der Amend-POST ist bereits angenommen, nur das
                        # Ruecklesen scheiterte. OKX kann den NEUEN Stop
                        # fuehren, waehrend der lokale Client-Stop noch mit dem
                        # ALTEN rechnet -- bis 9.0.15 lief das stumm
                        # auseinander, ohne Wiederaufsetzpunkt.
                        #
                        # Sicher ist der ENGERE der beiden Werte: er loest
                        # hoechstens zu frueh aus, nie zu spaet.
                        position.stop = max(float(position.stop or 0.0), float(stop))
                        position.broker_schutz = False
                        position.protection_status = "UNKNOWN_AFTER_AMEND"
                        position.exit_state = "MANUAL"
                        self.buch.setze(position)
                        controls.update(
                            command_id, "UNCLEAR",
                            "OKX hat die Aenderung angenommen, konnte sie aber nicht "
                            "bestaetigen. Der lokale Stop wurde auf den engeren Wert "
                            f"({position.stop:g}) gesetzt und der Broker-Schutz wird "
                            "beim naechsten Abgleich neu geprueft.")
                        self._melde(
                            f"Krypto {symbol}: TP/SL-Aenderung unbestaetigt. Lokaler "
                            f"Stop steht sicherheitshalber auf {position.stop:g}; "
                            "bitte die Schutzorder im OKX-Konto pruefen.",
                            wichtig=True, klasse="KRITISCH")
                        results.append({"id": command_id, "ok": False, "unclear": True})
                        continue
                    position.stop = float(state.get("stop") or stop)
                    position.take_profit = float(state.get("take_profit") or take)
                    position.broker_schutz = True
                    position.protection_status = "ACTIVE"
                    position.protection_algo_id = str(state.get("algo_id") or position.protection_algo_id)
                    position.protection_client_order_id = str(
                        state.get("algo_client_id") or position.protection_client_order_id)
                    self.buch.setze(position)
                    self._ledger_schutz_synchronisieren(position, str(state.get("detail") or ""))
                    detail = (f"Manuelle Verwaltung aktiv: SL {position.stop:g}, "
                              f"TP {position.take_profit:g}. Freqtrade-ROI und "
                              "Strategie-Exit sind fuer diese Position deaktiviert.")
                    controls.update(command_id, "SUCCEEDED", detail)
                    self._melde(f"Krypto {symbol}: {detail}", wichtig=True)
                    results.append({"id": command_id, "ok": True, "action": action})
                    continue

                # v9.1: Die vorherige Verwaltung wird gemerkt. Ein
                # FEHLGESCHLAGENER Verkauf darf die Position nicht dauerhaft
                # auf MANUELL stehen lassen -- bis 9.0.15 gab es im ganzen Code
                # keinen Weg zurueck auf AUTO, und Freqtrade-ROI sowie
                # Strategie-Exit waren fuer diese Position danach tot, obwohl
                # der Nutzer sie nur verkaufen wollte.
                verwaltung_vorher = str(position.verwaltung)
                notiz_vorher = str(position.verwaltungsnotiz or "")
                position.manuell(actor, "Manueller Verkauf ueber NEXUS angefordert")
                position.exit_state = "MANUAL_EXIT_PENDING"
                self.buch.setze(position)
                outcome = self._schliesse(
                    position, float(broker.execution_quote(
                        self._instrument(symbol, position.inst_id), position.menge,
                        side="sell").get("vwap") or 0.0),
                    "Manueller Verkauf über NEXUS", allow_manual=True,
                    explicit_manual=True)
                if outcome == "CLOSED":
                    lock = controls.add_lock(
                        broker="okx", account_fingerprint=current_account, symbol=symbol,
                        duration=str(command.get("lock") or "6H"),
                        reason="Position manuell ueber NEXUS verkauft", actor=actor)
                    controls.update(command_id, "SUCCEEDED",
                                    "Verkauf vollstaendig bestaetigt; Wiedereinstieg gesperrt.",
                                    lock_id=lock["id"])
                    results.append({"id": command_id, "ok": True, "action": action})
                elif outcome == "UNCLEAR":
                    # Hier bleibt MANUELL richtig: der Verkauf kann beim Broker
                    # liegen. Eine automatische Verwaltung waere gefaehrlich.
                    controls.update(command_id, "UNCLEAR",
                                    "Brokerzustand unklar; kein zweiter Auftrag wird gesendet.")
                    results.append({"id": command_id, "ok": False, "unclear": True})
                elif outcome == "PARTIAL":
                    # v9.1: Ein Teilverkauf ist ausgefuehrt worden. Vorher fiel
                    # er in den else-Zweig und wurde als "nicht ausgefuehrt"
                    # gemeldet -- und die angeforderte Wiedereinstiegssperre
                    # blieb aus.
                    lock = controls.add_lock(
                        broker="okx", account_fingerprint=current_account, symbol=symbol,
                        duration=str(command.get("lock") or "6H"),
                        reason="Position manuell ueber NEXUS teilweise verkauft",
                        actor=actor)
                    controls.update(
                        command_id, "PARTIAL",
                        "Teilweise verkauft; der gefuehrte Rest bleibt mit Schutz "
                        "bestehen. Wiedereinstieg gesperrt.", lock_id=lock["id"])
                    self._melde(
                        f"Krypto {symbol}: manueller Verkauf teilweise ausgefuehrt. "
                        "Der Rest bleibt im Positionsbuch und behaelt seinen Schutz.",
                        wichtig=True)
                    results.append({"id": command_id, "ok": True, "partial": True,
                                    "action": action})
                else:
                    # Bewiesen nicht ausgefuehrt: die Verwaltung wird auf den
                    # Stand vor dem Auftrag zurueckgesetzt.
                    position.verwaltung = verwaltung_vorher
                    position.verwaltungsnotiz = notiz_vorher
                    position.exit_state = "IDLE"
                    self.buch.setze(position)
                    controls.update(command_id, "FAILED",
                                    "Verkauf nicht ausgefuehrt; Position, Verwaltung und "
                                    "bestaetigter Schutz bleiben unveraendert.")
                    results.append({"id": command_id, "ok": False, "action": action})
            except OrderStatusUnklar as exc:
                controls.update(command_id, "UNCLEAR", str(exc))
                results.append({"id": command_id, "ok": False, "unclear": True})
            except (BrokerFehler, ValueError) as exc:
                controls.update(command_id, "FAILED", str(exc))
                results.append({"id": command_id, "ok": False, "detail": str(exc)})
        return results

    def _externer_verkaufsbeweis(self, position: KryptoPosition,
                                 expected_qty: float) -> dict:
        broker = self.broker
        if broker is None or not hasattr(broker, "external_exit_evidence"):
            return {}
        try:
            return dict(broker.external_exit_evidence(
                inst_id=position.inst_id, since=position.eroeffnet_am,
                expected_qty=expected_qty) or {})
        except BrokerFehler as exc:
            logger.warning("Externer Verkaufsfill fuer %s nicht abrufbar: %s",
                           position.symbol, exc)
            return {}

    def _position_extern_geschlossen(self, position: KryptoPosition,
                                     evidence: dict, bericht: dict, *,
                                     residual: float = 0.0,
                                     close_quantity: float = 0.0) -> None:
        """Schliesst nur mit echtem OKX-Fill; Rundungsstaub ist keine Position."""
        symbol = position.symbol.upper()
        intended = max(float(position.menge), float(close_quantity or 0.0))
        qty = min(intended, float(evidence.get("quantity") or 0.0))
        price = float(evidence.get("avg_price") or 0.0)
        if qty <= 0 or price <= 0 or not evidence.get("fill_ids"):
            return
        fee = max(0.0, float(evidence.get("fees_quote") or 0.0))
        entry_fee = max(0.0, float(position.entry_fee_quote or 0.0))
        gross = (price - position.einstieg) * qty
        net = gross - entry_fee - fee
        exit_id = (str((evidence.get("order_ids") or [""])[0]) or
                   str((evidence.get("fill_ids") or [""])[0]))
        try:
            import trade_ledger
            closed_id = trade_ledger.trade_close(
                broker="okx", symbol=symbol, ausstieg_preis=price,
                menge=intended,
                exit_grund="Manuell oder brokerseitig bei OKX verkauft",
                gebuehr=fee, netto_pnl=net, einstieg_preis=position.einstieg,
                eingestiegen_am=position.eroeffnet_am, asset_type="crypto",
                waehrung=self._quote_waehrung(position), paper=bool(position.paper),
                zeit=evidence.get("closed_at"), exit_order_id=exit_id,
                exit_fill_ids=list(evidence.get("fill_ids") or []),
                notiz=(f"OKX-Fill bestaetigt; Rest {residual:g} ist unter Mindestgroesse "
                       "und bleibt als Kontostaub unverwendet."))
            if not closed_id:
                raise RuntimeError("Ledger hat die bestaetigte Schliessung nicht angenommen")
        except Exception:
            logger.exception("Externe OKX-Schliessung nicht ins Ledger geschrieben")
            return
        self._buche_okx_ergebnis(position, net, gross, trade_id=exit_id)
        self.buch.entferne(symbol)
        self._gemeldeter_ueberhang.discard(symbol)
        bericht.setdefault("abgeglichen", []).append(symbol)
        bericht.setdefault("geschlossen", []).append(symbol)
        self.topf.setze_offene_positionen(len(self.buch.aktive()))
        self._melde(
            f"Krypto {symbol}: externer OKX-Verkauf anhand echter Fill-IDs bestaetigt. "
            f"{qty:g} zu {price:g} {self._quote_waehrung(position)}, "
            f"Netto {net:+.2f}; Rest {residual:g} ist nicht handelbarer Staub.",
            wichtig=True)

    def _melde_einmal(self, schluessel: str, text: str, *, wichtig: bool = False,
                      klasse: str = "") -> bool:
        """Eine unveraenderte Stoerung nur einmal melden -- nicht im Zyklustakt.

        v9.2: Bis 9.1 kam dieselbe kritische Meldung fuer jede betroffene
        Position bei JEDEM Zyklus erneut. Bei drei Positionen und
        Fuenf-Minuten-Takt sind das ueber 800 Nachrichten am Tag; danach liest
        sie niemand mehr -- und genau dann geht die eine wichtige unter.

        Der Schluessel wird aus Symbol, Fehlerklasse und Broker-ID gebildet.
        Aendert sich der Zustand, ist es wieder eine Nachricht. Nach Ablauf des
        Cooldowns ebenfalls, damit eine dauerhafte Stoerung nicht in
        Vergessenheit geraet.
        """
        cooldown = max(60.0, float(getattr(
            self.cfg, "STOERUNGS_MELDUNG_COOLDOWN_SEKUNDEN", 900.0)))
        merker = getattr(self, "_gemeldete_stoerungen", None)
        if merker is None:
            merker = self._gemeldete_stoerungen = {}
        zuletzt = float(merker.get(str(schluessel), 0.0))
        if time.time() - zuletzt < cooldown:
            return False
        merker[str(schluessel)] = time.time()
        self._melde(text, wichtig=wichtig, klasse=klasse)
        return True

    def _entwarnung(self, schluessel: str, text: str) -> None:
        """Genau einmal Entwarnung geben, wenn eine gemeldete Stoerung weg ist."""
        merker = getattr(self, "_gemeldete_stoerungen", None) or {}
        if str(schluessel) in merker:
            merker.pop(str(schluessel), None)
            self._melde(text, wichtig=True)

    def _scan_raster_sekunden(self) -> float:
        """Kerzenraster des aktiven Einstiegsmodus -- 0 heisst: kein Raster.

        Nur der Freqtrade-Modus rastet ein. Der NEXUS-Standard behaelt seinen
        freien Takt: sein Scanintervall haengt nicht an der Kerzengroesse, und
        Georgs Vorgabe ist, dass die anderen Modi unveraendert arbeiten.
        """
        try:
            from crypto_strategy_mode import FREQTRADE_SAMPLE, current_mode
            if current_mode() != FREQTRADE_SAMPLE:
                return 0.0
            from freqtrade_sample_strategy import TIMEFRAME
            return float(_kerzengroesse_sekunden(str(TIMEFRAME)))
        except Exception:
            logger.debug("Kerzenraster nicht bestimmbar", exc_info=True)
            return 0.0

    def _strategy_exit(self, position: KryptoPosition, current_price: float) -> tuple[bool, str]:
        """Evaluate the immutable entry strategy of one open position."""
        from crypto_strategy_mode import FREQTRADE_SAMPLE, NEXUS_STANDARD
        mode = str(position.entry_strategy_mode or "")
        if mode == NEXUS_STANDARD:
            # Preserve the existing NEXUS 8.3.1 position behaviour exactly:
            # broker/client stop and take-profit, no new exit rule added here.
            return False, ""
        if mode != FREQTRADE_SAMPLE:
            return False, ""
        from freqtrade_sample_strategy import (
            PARAMETER_HASH, STRATEGY_VERSION, exit_decision,
        )
        if (str(position.strategy_version) != STRATEGY_VERSION
                or str(position.strategy_parameter_hash) != PARAMETER_HASH):
            # v9.2: Erst eine ausdrueckliche Migration versuchen, statt sofort
            # zu pausieren. Ein Update, das nur die Ausstiegsreihenfolge oder
            # den Datenbedarf aendert, darf eine bewiesene Botposition nicht
            # aus der Verwaltung nehmen -- das war der Fehler vom 31.08.2026.
            # Der Eigentumsnachweis bleibt in JEDEM Fall unberuehrt.
            import strategy_migration
            fingerprint = ""
            try:
                fingerprint = str(getattr(self.broker, "account_fingerprint",
                                          lambda: "")() or "")
            except Exception:
                logger.debug("Kontofingerprint nicht lesbar", exc_info=True)
            ergebnis = strategy_migration.migriere(
                position, actor="auto-upgrade", account_fingerprint=fingerprint)
            self.buch.setze(position)
            if ergebnis.get("migriert"):
                self._melde(
                    f"Krypto {position.symbol}: Strategie migriert "
                    f"{ergebnis['von_version']} -> {ergebnis['nach_version']} "
                    f"({ergebnis['grund']}). Eigentumsnachweis und Broker-Schutz "
                    "unveraendert; automatische Verwaltung laeuft weiter.",
                    wichtig=True)
            else:
                # Nicht migrierbar: die Position wird pausiert, bleibt aber
                # eine bewiesene Botposition. Ueberwachung, Broker-Schutz und
                # die Wiedereinstiegssperre laufen weiter.
                position.pausiere(
                    "Strategie-Snapshot nicht reproduzierbar: "
                    + str(ergebnis.get("grund") or "unbekannte Identitaet"),
                    status=ergebnis.get("status") or
                    strategy_migration.STATUS_MIGRATION_NOETIG)
                self.buch.setze(position)
                self._melde_einmal(
                    f"strategie-migration:{position.symbol}:{ergebnis.get('status')}",
                    f"Krypto {position.symbol}: bestaetigte Botposition, aber die "
                    "Einstiegsstrategie ist nicht reproduzierbar. Automatische "
                    "Strategie-Ausgaenge pausiert; Broker-Schutz, Ueberwachung "
                    "und die Wiedereinstiegssperre bleiben aktiv.",
                    wichtig=True, klasse="KRITISCH")
                return False, ""
        broker = self.broker
        if broker is None:
            return False, ""
        try:
            candles = broker.historie(
                self._instrument(position.symbol, position.inst_id),
                str(getattr(self.cfg, "FREQTRADE_HISTORY_DURATION", "3 D")),
                "5 mins", False)
            opened = datetime.fromisoformat(str(position.eroeffnet_am).replace("Z", "+00:00"))
            if opened.tzinfo is None:
                opened = opened.replace(tzinfo=timezone.utc)
            elapsed = (datetime.now(timezone.utc) - opened.astimezone(timezone.utc)).total_seconds() / 60.0
            close, reason, audit = exit_decision(
                candles, entry_price=position.einstieg,
                current_price=current_price, elapsed_minutes=elapsed,
                entry_fee_pct=self._entry_fee_pct(position),
                exit_fee_pct=self._taker_satz())
            if close:
                logger.info("Freqtrade-Ausgang %s: %s | %s", position.symbol, reason, audit)
            return bool(close), str(reason or "")
        except (BrokerFehler, ValueError) as exc:
            logger.warning("Freqtrade-Ausstieg fuer %s nicht pruefbar: %s", position.symbol, exc)
            return False, ""

    def _position_verschwunden(self, position: KryptoPosition, bericht: dict) -> None:
        """Kein Guthaben mehr: die Position wurde ausserhalb des Bots geschlossen.

        Bis 8.1.3 wurde sie hier nur still aus dem Buch genommen. Damit fehlte
        der Trade im Ledger und im Risikotopf, und der wahrscheinlichste Grund
        -- die brokerseitige Schutzorder hat ausgeloest -- stand nirgends.
        """
        symbol = position.symbol.upper()
        evidence = self._externer_verkaufsbeweis(position, position.menge)
        if evidence and position.ist_bewiesene_botposition:
            self._position_extern_geschlossen(position, evidence, bericht, residual=0.0)
            return
        grund = ("Broker-Schutzorder ausgeloest" if position.broker_schutz
                 else "extern geschlossen (keine Bot-Schutzorder aktiv)")
        preis = self._letzter_kurs(position)
        quote = self._quote_waehrung(position)

        # Ohne echten Fill wird kein aktueller Ticker als angeblicher
        # Verkaufspreis verbucht. Der Trade wird geschlossen, P&L bleibt NULL.
        try:
            import trade_ledger
            trade = trade_ledger.offener_trade("okx", symbol)
            if trade:
                trade_ledger.mark_reconciled_closed(
                    int(trade["trade_id"]), grund=grund,
                    notiz="Kein exakter OKX-Verkaufsfill gefunden; Preis und P&L bleiben unbekannt.")
        except Exception:
            logger.debug("Unbelegte Fremdschliessung nicht ins Ledger geschrieben", exc_info=True)
        self._melde(f"Krypto {symbol}: kein Guthaben mehr vorhanden -- {grund}. "
                    "Kein exakter OKX-Fill gefunden; Ergebnis bleibt unbekannt.",
                    wichtig=True)

        if not position.ist_bewiesene_botposition:
            # Eine pausierte oder fremde Position wird nicht abgerechnet und
            # nicht entfernt -- sie gehoert dem Bot nicht.
            self._melde(f"Krypto {symbol}: kein Guthaben mehr, Position steht "
                        f"aber auf {position.verwaltung} und bleibt im Buch.",
                        wichtig=True)
            return
        self.buch.entferne(symbol)
        self._gemeldeter_ueberhang.discard(symbol)
        bericht.setdefault("abgeglichen", []).append(symbol)
        self.topf.setze_offene_positionen(len(self.buch.aktive()))

    def _menge_an_orderbuch_anpassen(self, symbol: str, mitglied, menge: float,
                                     quote_ccy: str) -> tuple[float, str]:
        """Verkleinert eine Order, die das Orderbuch sprengen wuerde.

        Geprueft wird, wieviel sich kaufen laesst, ohne den besten Briefkurs
        um mehr als ``CRYPTO_MAX_BOOK_IMPACT_PCT`` zu verlassen. Ist das
        Orderbuch nicht abrufbar, bleibt die Menge unveraendert -- eine
        fehlende Messung darf keinen Kauf erfinden und keinen verhindern.
        """
        broker = self.broker
        if broker is None or menge <= 0:
            return menge, ""
        grenze = float(getattr(self.cfg, "CRYPTO_MAX_BOOK_IMPACT_PCT", 0.005))
        anteil = float(getattr(self.cfg, "CRYPTO_MAX_BOOK_SHARE", 0.25))
        if grenze <= 0:
            return menge, ""

        inst_id = str(getattr(mitglied, "inst_id", "") or "").upper() or f"{symbol}-{quote_ccy}"
        try:
            buch = broker.client.orderbook(inst_id, depth=20)
        except Exception:
            logger.debug("Orderbuch %s nicht abrufbar", inst_id, exc_info=True)
            return menge, ""

        asks = [(float(p), float(q)) for p, q in (buch.get("asks") or []) if p > 0 and q > 0]
        if not asks:
            return menge, ""

        bester = asks[0][0]
        tragfaehig = 0.0
        for preis, groesse in asks:
            if (preis - bester) / bester > grenze:
                break
            tragfaehig += groesse
        # Nur einen Teil der sichtbaren Tiefe beanspruchen.
        tragfaehig *= max(0.0, min(1.0, anteil))
        if tragfaehig <= 0:
            return 0.0, (f"Orderbuch bietet innerhalb von {grenze * 100:.2f} % "
                         f"keine nutzbare Tiefe")
        if menge <= tragfaehig:
            return menge, ""

        neue_menge = self._auf_lot_runden(symbol, tragfaehig)
        if neue_menge <= 0:
            return 0.0, (f"Orderbuch traegt nur {tragfaehig:g} {symbol} -- "
                         f"unter der Mindestgroesse")
        mindestwert = float(getattr(self.cfg, "OKX_MIN_POSITION_VALUE", 15.0))
        if neue_menge * bester < mindestwert:
            return 0.0, (f"Orderbuch traegt nur {neue_menge * bester:.2f} {quote_ccy} "
                         f"innerhalb von {grenze * 100:.2f} %; Mindestordergroesse "
                         f"{mindestwert:.2f} {quote_ccy}")
        return neue_menge, (
            f"Order von {menge:g} auf {neue_menge:g} {symbol} wegen Orderbuchtiefe "
            f"reduziert (innerhalb von {grenze * 100:.2f} % ab {bester:g} "
            f"liegen {tragfaehig:g})")

    def _stop_mindestabstand(self, preis: float, stop: float, spanne: float,
                             quote_ccy: str) -> tuple[float, str]:
        """Hebt einen zu engen Stop auf den Kostenabstand an.

        Rueckgabe: (Stop, Hinweis). Der Hinweis ist leer, wenn der ATR-Stop
        ohnehin weit genug sitzt.
        """
        if preis <= 0 or stop <= 0 or stop >= preis:
            return stop, ""
        faktor = float(getattr(self.cfg, "CRYPTO_STOP_KOSTEN_FAKTOR", 1.5))
        if faktor <= 0:
            return stop, ""
        gebuehr = self._taker_satz()
        # Roundtrip: Gebuehr auf beiden Seiten plus einmal die Spanne.
        kosten_pct = 2.0 * gebuehr + max(0.0, float(spanne or 0.0))
        mindest_pct = kosten_pct * faktor
        ist_pct = (preis - stop) / preis
        if ist_pct >= mindest_pct:
            return stop, ""
        neuer_stop = preis * (1.0 - mindest_pct)
        return neuer_stop, (
            f"Stop von {ist_pct * 100:.3f} % auf {mindest_pct * 100:.3f} % "
            f"erweitert -- enger als die Handelskosten "
            f"({kosten_pct * 100:.3f} % Roundtrip) waere ein Stop-Out ein "
            f"rechnerisch sicherer Verlust")

    def _taker_satz(self) -> float:
        """Der geltende Taker-Satz -- gemessen, wenn der Broker ihn kennt."""
        broker = self.broker
        if broker is not None and hasattr(broker, "gebuehrensatz"):
            try:
                satz = float(broker.gebuehrensatz())
                if satz > 0:
                    return satz
            except Exception:
                logger.debug("Gebuehrensatz nicht abrufbar", exc_info=True)
        return float(getattr(self.cfg, "OKX_TAKER_FEE_PCT", 0.0035))

    def _second_opinion(self, symbol, protokoll, *, preis, menge, stop, ziel,
                        waehrung, signal, kosten, erwartete_bewegung,
                        mitglied) -> bool:
        """Zweite Meinung; bei kritisch kann ausschliesslich Georg freigeben."""
        import second_opinion as so

        live = bool(self.broker is not None and not self.broker.ist_paper())
        if not so.aktiv(live=live):
            return True

        fakten = {
            "symbol": symbol, "broker": "okx",
            "modus": "LIVE" if live else "DEMO",
            "preis": round(float(preis), 8),
            "menge": round(float(menge), 8),
            "wert": round(float(menge) * float(preis), 2),
            "waehrung": waehrung,
            "stop": round(float(stop), 8), "ziel": round(float(ziel), 8),
            "chance_risiko": round((ziel - preis) / (preis - stop), 2)
                             if preis > stop else None,
            "technik": [b.detail for b in protokoll.beitraege
                        if getattr(b, "quelle", "") == TECHNIK][:4],
            "kosten": {
                "huerde_pct": round(float(kosten.required_edge_pct) * 100, 3),
                "erwartete_bewegung_pct": round(float(erwartete_bewegung) * 100, 3),
                "gebuehr_pct": round(self._taker_satz() * 100, 4),
            },
            "universum": {"rang": getattr(mitglied, "letzter_rang", None),
                          "score": round(float(getattr(mitglied, "letzter_score", 0.0)), 3)},
            "portfolio": {"offene_positionen": len(self.buch.aktive())},
            "decision_id": protokoll.decision_id,
        }

        # Eine vorhandene Freigabe wird ohne weitere KI-Kosten geprueft. Sie
        # gilt nur fuer dieselbe, praktisch unveraenderte Ordergrundlage.
        pending = next((e for e in so.offene("okx")
                        if str(e.get("symbol", "")).upper() == str(symbol).upper()), None)
        if pending:
            if not pending.get("freigegeben"):
                protokoll.blockiert(NUTZER, "kritische KI-Warnung wartet auf persoenliche Freigabe")
                return False
            cash = self.broker.verfuegbares_cash(waehrung)
            gueltig, warum = so.grundlage_noch_gueltig(
                pending, preis=preis, cash=float(cash or 0.0),
                bestand_vorhanden=self.buch.hole(symbol) is not None,
                risiko_offen=self.risiko.darf_kaufen("crypto")[0],
                menge=menge, stop=stop)
            so.verwerfe("okx", symbol)
            if gueltig:
                protokoll.ergaenze(NUTZER, DAFUER, gewicht=0.0,
                                   detail="persoenlich per Telegram freigegeben; feste Regeln erneut bestanden")
                return True
            self._melde(f"🛡️ {symbol}: frühere Freigabe verworfen – {warum}. "
                        "Eine neue Entscheidung braucht eine neue Freigabe.", wichtig=True)

        urteil = so.hole(self.ai, fakten)
        if not urteil.gefragt:
            return True

        # Der KI-Beitrag steht IMMER mit Gewicht 0,0 und NEUTRAL im Protokoll.
        protokoll.ki("terra", NEUTRAL, urteil.kurztext or "keine Einschaetzung",
                     modell=urteil.modell, gewicht=0.0,
                     kosten_usd=urteil.kosten_usd)

        if urteil.einschaetzung == so.NICHT_ERREICHBAR:
            self._melde(f"KI nicht erreichbar vor dem Kauf von {symbol} "
                        f"({urteil.begruendung}). Der Kauf laeuft nach den festen "
                        f"Regeln weiter.", wichtig=False)
            return True

        if urteil.kritisch:
            if so.human_gate_aktiv():
                eintrag = so.stelle_zurueck(broker="okx", symbol=symbol,
                                            urteil=urteil, fakten=fakten)
                self._melde(so.rueckfragetext(eintrag), wichtig=True, klasse="KRITISCH")
                protokoll.blockiert(NUTZER, "kritische KI-Warnung: persoenliche Freigabe erforderlich")
                return False
            self._melde(so.warntext(urteil, fakten), wichtig=True, klasse="KRITISCH")
            protokoll.ergaenze(RISK_GATE, NEUTRAL, gewicht=0.0,
                               detail="KI-Warnung kritisch; Human-Gate deaktiviert",
                               datenquelle="Second Opinion")
        return True

    def _melde_bereitschaft(self) -> None:
        """Die uebrigen Bedingungen der Anlaufsperre pruefen.

        Bewusst ohne zusaetzliche Netzabfragen: geprueft wird, was der Zyklus
        ohnehin schon weiss.
        """
        broker = self.broker
        try:
            self.bereitschaft.melde("systemzeit", True)
            self.bereitschaft.melde("protokoll", True)
            if broker is None:
                return
            # Instrumentkatalog und Handelsregeln
            try:
                instrumente = broker.client.instruments()
                self.bereitschaft.melde("instrumente", bool(instrumente),
                                        f"{len(instrumente)} Instrumente")
                beispiel = next(iter(instrumente.values()), None) if instrumente else None
                self.bereitschaft.melde(
                    "handelsregeln",
                    bool(beispiel and beispiel.lot_size and beispiel.min_size))
            except Exception as exc:
                self.bereitschaft.melde("instrumente", False, str(exc)[:120])
                self.bereitschaft.melde("handelsregeln", False, str(exc)[:120])
            # Gebuehrensatz
            satz = self._taker_satz()
            self.bereitschaft.melde("gebuehren", satz > 0, f"{satz * 100:.4f} %")
            # Kursdaten: ein frischer Ticker, nicht bloss "ein Zyklus lief".
            frisch = False
            alter = None
            try:
                tickers = broker.client.tickers()
                stempel = max((t.timestamp_ms for t in tickers.values()
                               if getattr(t, "timestamp_ms", 0)), default=0)
                if stempel:
                    alter = max(0.0, time.time() - stempel / 1000.0)
                    frisch = alter <= _tickeralter_grenze(self.cfg)
            except Exception:
                logger.debug("Tickeralter nicht bestimmbar", exc_info=True)
            self.bereitschaft.melde("kursdaten", frisch,
                                    f"letzter Ticker vor {alter:.0f} s" if alter is not None
                                    else "Alter unbekannt")

            # Signalkerze: echte Messung gegen die Kerzengroesse, nicht der
            # Anlauftimer in anderen Worten.
            kerze = _kerzengroesse_sekunden(
                str(getattr(self.cfg, "CRYPTO_BAR_SIZE", "15 mins")))
            self.bereitschaft.melde(
                "signalkerze", self.bereitschaft.kerzen_vollstaendig(kerze),
                f"Kerzengroesse {kerze / 60:.0f} min")
            # Offene, unklare Orders
            self.bereitschaft.melde("keine_unklare_order",
                                    not self._offene_order_symbole())
        except Exception:
            logger.debug("Bereitschaftspruefung unvollstaendig", exc_info=True)

    def _guthaben_uebersicht(self) -> dict:
        """Guthaben je Waehrung -- ohne zusaetzliche Netzabfrage zu erzwingen."""
        broker = self.broker
        if broker is None:
            return {}
        try:
            roh = broker.client.balances()
        except Exception:
            logger.debug("Guthaben nicht abrufbar", exc_info=True)
            return {}
        out = {}
        for waehrung, eintrag in (roh or {}).items():
            gesamt = float(eintrag.get("gesamt", 0.0) or 0.0)
            if gesamt > 0:
                out[str(waehrung).upper()] = {
                    "gesamt": round(gesamt, 8),
                    "frei": round(float(eintrag.get("cash", 0.0) or 0.0), 8),
                }
        return out

    def _eigene_positionen(self, broker_name: str):
        """(Menge, Preis) der Positionen, die dem Bot in dieser Domaene gehoeren.

        Grundlage fuer das handelbare Kapital. Fremdbestaende und pausierte
        Positionen zaehlen ausdruecklich NICHT mit.
        """
        if str(broker_name).lower() != "okx":
            return ()
        paare = []
        for position in self.buch.alle():
            if not position.darf_schutz_ausfuehren:
                continue
            preis = position.hoechstkurs or position.einstieg
            if position.menge > 0 and preis > 0:
                paare.append((position.symbol.upper(), position.menge, preis))
        return tuple(paare)

    def _rest_lohnt_sich(self, position: KryptoPosition, rest: float, kurs: float) -> bool:
        """Ist eine Restmenge gross genug, um weiter gefuehrt zu werden?

        Zu kleine Reste kann OKX gar nicht mehr verkaufen (minSz) -- die
        weiter zu fuehren wuerde bei jedem Zyklus eine fehlschlagende Order
        erzeugen.
        """
        if rest <= 0 or kurs <= 0:
            return False
        gerundet = self._auf_lot_runden(position.symbol, rest)
        if gerundet <= 0:
            return False
        # v9.1: Massstab ist, ob OKX den Rest UEBERHAUPT VERKAUFEN KANN --
        # nicht, ob er fuer eine NEUE Position gross genug waere.
        # OKX_MIN_POSITION_VALUE (15,00) ist die Eroeffnungsschwelle. Damit
        # galt ein Rest von 11,55 USDC als "nicht handelbarer Staub", obwohl er
        # das Hundertfache der OKX-Mindestgroesse war -- und verlor Client-Stop,
        # Broker-Schutz und Ledgerzeile.
        try:
            meta = self.broker.client.instrument(position.inst_id)
            min_size = float(getattr(meta, "min_size", 0.0) or 0.0)
        except Exception:
            logger.debug("Mindestgroesse fuer %s nicht lesbar", position.symbol,
                         exc_info=True)
            min_size = 0.0
        if min_size > 0 and gerundet < min_size:
            return False
        # Zusaetzlich eine echte Staubgrenze: unter diesem Gegenwert deckt der
        # Verkauf nicht einmal die Gebuehren.
        staubwert = float(getattr(self.cfg, "OKX_DUST_VALUE_LIMIT", 1.0))
        return gerundet * kurs >= staubwert

    def _schutz_als_verloren_merken(self, position: KryptoPosition) -> None:
        """Nach einem fehlgeschlagenen Verkauf gilt der Broker-Schutz als weg.

        ``schliesse_position`` storniert bei OKX ZUERST die Schutzorder und
        sendet danach den Verkauf. Schlaegt der Verkauf fehl, ist die
        Schutzorder trotzdem storniert -- die Position liegt ungeschuetzt im
        Konto. Bis v8.1.3 blieb ``broker_schutz`` dabei auf True, und die
        einzige Wiederherstellung (``if not position.broker_schutz``) griff
        deshalb nie.
        """
        if not position.broker_schutz:
            return
        position.broker_schutz = False
        self.buch.setze(position)
        logger.warning("Broker-Schutz fuer %s gilt nach fehlgeschlagenem Verkauf "
                       "als storniert -- wird im naechsten Takt neu gesetzt.",
                       position.symbol)

    def _schutz_nachziehen(self, position: KryptoPosition) -> None:
        """Broker-Schutz fuer die verbliebene Menge neu setzen.

        Nach einem Teilverkauf gilt die alte Schutzorder fuer eine Menge, die
        es nicht mehr gibt. Ohne dieses Nachziehen laege der Rest ungeschuetzt.
        """
        broker = self.broker
        if broker is None or position.menge <= 0:
            return
        try:
            try:
                zustand = broker.reconcile_position_protection(
                    self._instrument(position.symbol, position.inst_id),
                    position.menge, position.stop, position.take_profit,
                    protection_client_id=position.protection_client_order_id,
                    trade_quote_ccy=position.trade_quote_ccy)
            except TypeError:
                zustand = broker.reconcile_position_protection(
                    self._instrument(position.symbol, position.inst_id),
                    position.menge, position.stop, position.take_profit)
            position.broker_schutz = bool(zustand.get("protection_confirmed"))
            position.protection_algo_id = str(zustand.get("algo_id") or "")
            position.protection_client_order_id = str(
                zustand.get("algo_client_id") or position.protection_client_order_id)
            position.protection_status = (
                "ACTIVE" if position.broker_schutz else
                "MISSING" if bool(zustand.get("checked")) else "PENDING")
            self.buch.setze(position)
            self._ledger_schutz_synchronisieren(
                position, str(zustand.get("detail") or ""))
            if not position.broker_schutz and bool(zustand.get("checked")):
                self._melde(f"Krypto {position.symbol}: Schutzorder fuer die Restmenge "
                            f"{position.menge:g} konnte NICHT bestaetigt werden -- "
                            f"nur der Client-Stop schuetzt.", wichtig=True)
        except BrokerFehler as exc:
            self._melde(f"Krypto {position.symbol}: Schutzorder fuer die Restmenge "
                        f"nicht setzbar ({exc}) -- nur der Client-Stop schuetzt.",
                        wichtig=True)

    @staticmethod
    def _verkaufsmeldung(position, menge, geplant, rest, rest_gefuehrt,
                         kurs, gebuehr, netto, quote, grund) -> str:
        """Verkaufsmeldung, die eine Teilausfuehrung ausdruecklich benennt."""
        import meldungen
        from datetime import datetime, timezone
        haltedauer = ""
        try:
            ein = datetime.fromisoformat(str(position.eroeffnet_am))
            if ein.tzinfo is None:
                ein = ein.replace(tzinfo=timezone.utc)
            minuten = (datetime.now(timezone.utc) - ein).total_seconds() / 60.0
            haltedauer = (f"{minuten:.0f} min" if minuten < 90
                          else f"{minuten / 60:.1f} h")
        except (TypeError, ValueError):
            haltedauer = ""
        return meldungen.verkauf(
            broker="okx", symbol=position.symbol, menge=menge, geplant=geplant,
            preis=kurs, waehrung=quote, gebuehr=gebuehr, ergebnis=netto,
            grund=grund, haltedauer=haltedauer, rest_gefuehrt=rest_gefuehrt)

    def _letzter_kurs(self, position: KryptoPosition) -> float:
        """Letzter bekannter Kurs -- ohne Ausnahme, ohne Blockieren."""
        broker = self.broker
        if broker is None:
            return 0.0
        try:
            quote = broker.latest_bid_ask(
                self._instrument(position.symbol, position.inst_id)) or {}
            return float(quote.get("last") or quote.get("bid") or 0.0)
        except Exception:
            logger.debug("Letzter Kurs fuer %s nicht abrufbar", position.symbol, exc_info=True)
            return 0.0

    @staticmethod
    def _quote_waehrung(position: KryptoPosition) -> str:
        """Quotewaehrung aus der Instrumentkennung -- nie blind EUR."""
        inst_id = str(getattr(position, "inst_id", "") or "")
        if "-" in inst_id:
            return inst_id.rsplit("-", 1)[-1].upper()
        return ""

    @staticmethod
    def _entry_fee_pct(position: KryptoPosition) -> float:
        """Tatsaechliche Einstiegsgebuehr relativ zum beweisbaren Fillwert."""
        fillwert = float(position.einstieg or 0.0) * float(position.menge or 0.0)
        return (max(0.0, float(position.entry_fee_quote or 0.0)) / fillwert
                if fillwert > 0 else 0.0)

    def _buche_okx_ergebnis(self, position: KryptoPosition, netto: float,
                            brutto: float, *, trade_id: str) -> bool:
        """Bucht exakt dasselbe Netto in Ledger- und OKX-Risikowaehrung."""
        broker = self.broker
        if broker is None:
            return False
        quote = self._quote_waehrung(position) or str(
            getattr(broker, "quote_ccy", "") or "EUR").upper()
        risk_ccy = str(getattr(broker, "kontowaehrung", lambda: quote)() or quote).upper()
        rate = (broker.quote_conversion_rate(quote, risk_ccy)
                if hasattr(broker, "quote_conversion_rate") else
                1.0 if quote == risk_ccy else None)
        if not rate or rate <= 0:
            self.topf.state.trading_halted = True
            self.topf.speichern()
            self._melde(
                f"Krypto {position.symbol}: Ergebnis {netto:.4f} {quote} kann nicht "
                f"belastbar nach {risk_ccy} umgerechnet werden. Neue Kaeufe sind "
                "vorsorglich gestoppt.", wichtig=True, klasse="KRITISCH")
            return False
        self.topf.buche_ergebnis(
            float(netto) * float(rate), brutto=float(brutto) * float(rate),
            trade_id=str(trade_id or ""))
        return True

    @staticmethod
    def _ledger_schutz_synchronisieren(position: KryptoPosition,
                                        detail: str = "") -> None:
        """Spiegelt den periodischen Schutzabgleich in den offenen Trade."""
        try:
            import trade_ledger
            trade = trade_ledger.offener_trade("okx", position.symbol)
            if not trade:
                return
            trade_ledger.set_protection(
                int(trade["trade_id"]), algo_id=position.protection_algo_id,
                client_order_id=position.protection_client_order_id,
                status=position.protection_status, detail=detail)
        except Exception:
            logger.debug("Schutzstatus %s nicht ins Ledger gespiegelt",
                         position.symbol, exc_info=True)

    def _schliesse(self, position: KryptoPosition, preis: float, grund: str, *,
                   allow_manual: bool = False,
                   explicit_manual: bool = False) -> str:
        broker = self.broker
        if broker is None:
            return "FAILED"
        protokoll = Entscheidungsprotokoll(position.symbol, asset_type="crypto",
                                           broker="okx", aktion="VERKAUF")
        protokoll.technik(DAFUER, 1.0, grund)
        protokoll.messwerte(
            entry_decision_id=position.decision_id,
            entry_strategy_mode=position.entry_strategy_mode,
            strategy_name=position.strategy_name,
            strategy_version=position.strategy_version,
            strategy_parameter_hash=position.strategy_parameter_hash,
            exit_reason=grund,
        )

        # Harte Obergrenze: der Bot verkauft NIE mehr, als in seinem Buch
        # steht. Selbst wenn im Konto mehr liegt -- das gehoert ihm nicht.
        verkaufsmenge = float(position.menge)
        erlaubt = (position.darf_automatisch_verkaufen or
                   (allow_manual and position.darf_schutz_ausfuehren))
        if not erlaubt:
            logger.info("Verkauf %s uebersprungen: Position steht auf %s",
                        position.symbol, position.verwaltung)
            return "BLOCKED"
        if verkaufsmenge <= 0:
            return "FAILED"
        if not explicit_manual and position.exit_retry_after:
            try:
                retry = datetime.fromisoformat(position.exit_retry_after.replace("Z", "+00:00"))
                if retry.tzinfo is None:
                    retry = retry.replace(tzinfo=timezone.utc)
                if retry > datetime.now(timezone.utc):
                    logger.info("Verkauf %s wartet bis %s (vorheriger Versuch: %s)",
                                position.symbol, retry.isoformat(), position.exit_last_detail)
                    return "COOLDOWN"
            except ValueError:
                pass
        # v9.1: Der Broker storniert als ERSTEN Schritt die OKX-Schutzorder.
        # Ab diesem Moment ist die Position ungeschuetzt -- auch wenn der
        # Prozess gleich darauf stirbt (SIGKILL, Stromausfall, OOM). Bis 9.0.15
        # blieb broker_schutz dabei auf True, und der einzige periodische
        # Schutzabgleich steht hinter "if not position.broker_schutz" -- er lief
        # deshalb nie wieder. Die Position stand dauerhaft nackt, waehrend die
        # Oberflaeche "Schutz aktiv" meldete.
        #
        # Der Vermerk wird deshalb VOR dem Brokeraufruf persistiert. Er ist
        # bewusst pessimistisch: scheitert der Verkauf schon vor dem Storno,
        # findet der naechste Abgleich die noch vorhandene Schutzorder ueber
        # ihre algoClOrdId wieder und bestaetigt sie. Das kostet einen Aufruf
        # und ist die sichere Richtung.
        schutz_vorher = bool(position.broker_schutz)
        position.exit_state = "SUBMITTING"
        position.exit_last_detail = str(grund)[:300]
        if schutz_vorher:
            position.broker_schutz = False
            position.protection_status = "LOST"
        self.buch.setze(position)
        try:
            ergebnis = broker.schliesse_position(self._instrument(position.symbol, position.inst_id),
                                                 verkaufsmenge, preis)
        except OrderStatusUnklar as exc:
            protokoll.ergaenze(BROKER, NEUTRAL, detail=f"Transportzustand unklar: {exc}")
            protokoll.abschliessen("UNKLAR", "Verkauf konnte nicht bestaetigt werden")
            speichere_quellen(protokoll)
            if dict(getattr(broker, "letzte_stornierung", {}) or {}).get("inst_id"):
                self._schutz_als_verloren_merken(position)
                self._schutz_nachziehen(position)
            position.exit_state = "UNCLEAR"
            position.exit_retry_after = (datetime.now(timezone.utc) + timedelta(hours=24)).isoformat()
            position.exit_last_detail = str(exc)[:300]
            self.buch.setze(position)
            self._melde(f"Krypto {position.symbol}: Verkaufszustand UNKLAR -- kein zweiter "
                        f"Versuch. Bitte im OKX-Konto pruefen.",
                        wichtig=True, klasse="KRITISCH")
            return "UNCLEAR"
        except BrokerFehler as exc:
            protokoll.ergaenze(BROKER, DAGEGEN, detail=str(exc))
            protokoll.abschliessen("FEHLGESCHLAGEN", str(exc))
            speichere_quellen(protokoll)
            logger.warning("Verkauf %s fehlgeschlagen: %s", position.symbol, exc)
            if dict(getattr(broker, "letzte_stornierung", {}) or {}).get("inst_id"):
                self._schutz_als_verloren_merken(position)
                self._schutz_nachziehen(position)
            self._exit_fehlversuch(position, str(exc))
            return "FAILED"

        # Konnte die alte Schutzorder nicht storniert werden, ist das
        # Guthaben eingefroren -- der Verkauf wird dann stillschweigend zur
        # Teilausfuehrung. Das muss sichtbar sein.
        storno = dict(getattr(broker, "letzte_stornierung", {}) or {})
        if storno.get("fehler"):
            self._melde(meldungen_sicherheit(
                f"Schutzorder nicht stornierbar · {position.symbol}",
                "Die alte Schutzorder liess sich nicht entfernen: "
                + "; ".join(str(f)[:120] for f in storno["fehler"]),
                handlung="Das Guthaben kann eingefroren sein. Offene Orders im "
                         "OKX-Konto pruefen."), wichtig=True, klasse="KRITISCH")

        menge = float(ergebnis.filled_quantity or 0.0)
        kurs = float(ergebnis.avg_fill_price or preis)
        if menge <= 0:
            protokoll.abschliessen("NICHT_AUSGEFUEHRT", ergebnis.hinweis or "keine Ausfuehrung")
            speichere_quellen(protokoll)
            self._schutz_als_verloren_merken(position)
            self._schutz_nachziehen(position)
            # v9.1: "0 gefuellt" ist nicht dasselbe wie "nachweislich nicht
            # ausgefuehrt". Der Broker berechnet dafuer ``terminal``: erst wenn
            # OKX einen Endzustand bestaetigt hat, ist der Fehlschlag bewiesen.
            # Bis 9.0.15 wurde das Feld NIE gelesen -- eine Order, deren
            # Statusabfrage dreimal leer blieb, landete im 5-Minuten-Retry und
            # wurde erneut gesendet, obwohl sie ausgefuehrt sein konnte.
            if not bool(getattr(ergebnis, "terminal", True)):
                position.exit_state = "UNCLEAR"
                position.exit_retry_after = (
                    datetime.now(timezone.utc) + timedelta(hours=24)).isoformat()
                position.exit_last_detail = (
                    f"{grund}: OKX bestaetigt keinen Endzustand "
                    f"({ergebnis.hinweis or 'ohne Detail'})")[:300]
                self.buch.setze(position)
                self._melde(
                    f"Krypto {position.symbol}: Verkaufszustand UNKLAR -- OKX hat "
                    "keinen Endzustand bestaetigt. Kein zweiter Versuch. Bitte im "
                    "OKX-Konto pruefen.", wichtig=True, klasse="KRITISCH")
                return "UNCLEAR"
            self._exit_fehlversuch(
                position, f"{grund}: 0 von {verkaufsmenge:g} ausgefuehrt"
                + (f" ({ergebnis.hinweis})" if ergebnis.hinweis else ""))
            return "FAILED"

        # Nie mehr verbuchen, als verkauft werden durfte. Meldet der Broker
        # eine groessere Menge, ist das ein Datenfehler und keine Erlaubnis.
        if menge > verkaufsmenge * (1.0 + 1e-9):
            logger.warning("Verkauf %s meldete %g statt hoechstens %g -- gedeckelt.",
                           position.symbol, menge, verkaufsmenge)
            menge = verkaufsmenge

        ergebnis_pnl = (kurs - position.einstieg) * menge
        quote = self._quote_waehrung(position) or str(
            getattr(broker, "quote_ccy", "") or "EUR").upper()
        ausstiegsgebuehr = (max(0.0, float(getattr(ergebnis, "fees_quote", 0.0) or 0.0))
                            if getattr(ergebnis, "fill_evidence_complete", False)
                            else self._gebuehr(menge, kurs, quote))
        einstiegsgebuehr_gesamt = max(0.0, float(position.entry_fee_quote or 0.0))
        einstiegsgebuehr = (einstiegsgebuehr_gesamt * menge / verkaufsmenge
                            if verkaufsmenge > 0 else einstiegsgebuehr_gesamt)
        netto = ergebnis_pnl - einstiegsgebuehr - ausstiegsgebuehr
        eindeutige_exit_id = (str(ergebnis.reference_id or "") or
                              (str(ergebnis.order_ids[0]) if ergebnis.order_ids else "") or
                              f"{position.order_id}:{grund}")
        self._buche_okx_ergebnis(
            position, netto, ergebnis_pnl, trade_id=eindeutige_exit_id)

        # --- Teilausfuehrung -------------------------------------------------
        # Bis 8.1.3 wurde die Position IMMER vollstaendig aus dem Buch
        # genommen -- auch wenn nur 10 % ausgefuehrt wurden. Am 25.08.2026
        # blieben dadurch 14,19 SOL ohne Stop, ohne Ziel und ohne Buchfuehrung
        # im Konto liegen. Ab 8.1.4 bleibt der Rest gefuehrt und geschuetzt.
        rest = round(verkaufsmenge - menge, 12)
        rest_gefuehrt = False
        if rest > 0 and self._rest_lohnt_sich(position, rest, kurs):
            position.menge = rest
            position.entry_fee_quote = max(
                0.0, einstiegsgebuehr_gesamt - einstiegsgebuehr)
            position.broker_schutz = False       # Schutz galt fuer die alte Menge
            self.buch.setze(position)
            rest_gefuehrt = True
            self._schutz_nachziehen(position)
        else:
            if rest > 0:
                self._melde(f"Krypto {position.symbol}: Restmenge {rest:g} {quote} "
                            f"liegt unter der Mindestgroesse und wird nicht mehr "
                            f"gefuehrt.", wichtig=True)
            self.buch.entferne(position.symbol)
            self._gemeldeter_ueberhang.discard(position.symbol.upper())
        try:
            import trade_ledger
            trade_ledger.trade_close(
                broker="okx", symbol=position.symbol.upper(), ausstieg_preis=kurs,
                menge=menge, exit_grund=grund, gebuehr=ausstiegsgebuehr,
                netto_pnl=netto, referenzpreis=preis,
                einstieg_preis=position.einstieg, eingestiegen_am=position.eroeffnet_am,
                asset_type="crypto", waehrung=quote, paper=bool(position.paper),
                exit_order_id=(str(ergebnis.order_ids[0]) if ergebnis.order_ids else ""),
                exit_fill_ids=list(getattr(ergebnis, "fill_ids", []) or []),
                mfe_pct=(100.0 * (position.hoechstkurs - position.einstieg) / position.einstieg
                         if position.hoechstkurs and position.einstieg else None))
        except Exception:
            logger.debug("Trade-Ledger Ausstieg OKX nicht geschrieben", exc_info=True)

        teil = (f"; Teilausfuehrung {menge:g} von {verkaufsmenge:g}"
                + (f", Rest {rest:g} bleibt gefuehrt und geschuetzt" if rest_gefuehrt
                   else ", Rest verfaellt") if rest > 0 else "")
        protokoll.ergaenze(BROKER, NEUTRAL,
                           detail=(f"{menge:g} zu {kurs:g}, Gebuehren gesamt "
                                   f"{einstiegsgebuehr + ausstiegsgebuehr:.4f}{teil}"))
        protokoll.abschliessen("AUSGEFUEHRT", grund)
        speichere_quellen(protokoll)
        self._melde(self._verkaufsmeldung(position, menge, verkaufsmenge, rest,
                                          rest_gefuehrt, kurs,
                                          einstiegsgebuehr + ausstiegsgebuehr, netto,
                                          quote, grund), wichtig=True)
        self.topf.setze_offene_positionen(len(self.buch.aktive()))
        return "PARTIAL" if rest_gefuehrt else "CLOSED"

    def _exit_fehlversuch(self, position: KryptoPosition, detail: str) -> None:
        """Persistenter Retry-Cooldown und Telegram-Deduplizierung."""
        now = datetime.now(timezone.utc)
        position.exit_state = "RETRY_WAIT"
        position.exit_retry_after = (now + timedelta(minutes=max(
            1.0, float(getattr(self.cfg, "OKX_EXIT_RETRY_MINUTES", 5.0))))).isoformat()
        position.exit_last_detail = str(detail)[:300]
        notify = True
        if position.exit_last_notice_at:
            try:
                previous = datetime.fromisoformat(position.exit_last_notice_at.replace("Z", "+00:00"))
                if previous.tzinfo is None:
                    previous = previous.replace(tzinfo=timezone.utc)
                notify = (now - previous).total_seconds() >= max(
                    60.0, float(getattr(self.cfg, "OKX_EXIT_ALERT_COOLDOWN_SECONDS", 900.0)))
            except ValueError:
                pass
        if notify:
            position.exit_last_notice_at = now.isoformat()
        self.buch.setze(position)
        if notify:
            self._melde(meldungen_sicherheit(
                f"Verkauf nicht ausgefuehrt · {position.symbol}", detail,
                handlung=("Broker-Schutz wurde sofort neu abgeglichen. Ein neuer "
                          f"Verkaufsversuch ist fruehestens ab {position.exit_retry_after} erlaubt.")),
                wichtig=True, klasse="KRITISCH")

    def _gebuehr(self, menge: float, preis: float, quote_ccy: str = "EUR") -> float:
        """Gebuehr mit dem GEMESSENEN Satz, nicht mit der Annahme."""
        from cost_engine import commission_for
        return commission_for(menge, preis, asset_type="crypto",
                              currency=str(quote_ccy or "EUR"), broker="okx",
                              fee_pct=self._taker_satz())

    def _offene_order_symbole(self) -> list[str]:
        """Symbole mit noch nicht abgeschlossener Bot-Order."""
        try:
            registry = self._order_registry()
            return [str(meta.get("symbol") or key.split(":")[-1]).upper()
                    for key, meta in registry.nicht_terminale().items()]
        except Exception:
            logger.debug("Offene Bot-Orders nicht ermittelbar", exc_info=True)
            return []

    @staticmethod
    def _nichtausfuehrungs_text(ergebnis, beleg: dict) -> str:
        """Klartext, warum ein freigegebener Kauf nicht stattgefunden hat."""
        art = str(beleg.get("ord_type") or "").upper()
        limit = beleg.get("limit_price")
        angefordert = float(beleg.get("requested_qty") or 0.0)
        status = getattr(ergebnis, "execution_status", "UNKNOWN")
        kopf = {
            "CANCELED_NO_FILL": (
                f"Kauf erlaubt -- bei OKX nicht ausgefuehrt: "
                f"0/{angefordert:g} zum {art or 'FOK'}-Limit"
                + (f" {float(limit):g}" if limit else "")),
            "REJECTED": "Kauf erlaubt -- von OKX abgelehnt",
            "EXPIRED": "Kauf erlaubt -- bei OKX verfallen",
            "PARTIAL": "Kauf erlaubt -- bei OKX nur teilweise ausgefuehrt",
        }.get(status, "Kauf erlaubt -- Ausgang bei OKX unklar")
        teile = [kopf]
        if beleg.get("cancel_source"):
            teile.append(f"cancelSource={beleg['cancel_source']}")
        if beleg.get("s_code"):
            teile.append(f"sCode={beleg['s_code']}")
        if beleg.get("s_msg"):
            teile.append(str(beleg["s_msg"])[:120])
        elif getattr(ergebnis, "hinweis", ""):
            teile.append(str(ergebnis.hinweis)[:120])
        return " · ".join(x for x in teile if x)

    def _order_registry(self):
        from order_ownership import OrderOwnershipRegistry
        return OrderOwnershipRegistry(
            _state_root() / str(getattr(
                self.cfg, "BOT_ORDER_REGISTRY_FILE", "bot_order_registry.json")))

    def _persistiere_okx_entry(self, *, symbol: str, decision_id: int,
                               ergebnis, intent: dict,
                               nachtraeglich: bool = False):
        """Echte OKX-Fills atomar als Bot-Teilmenge beweisen.

        Der Kontosaldo ist absichtlich kein Eingabewert. Eigentum entsteht
        allein aus der persistierten clOrdId, der ordId und echten tradeIds.
        """
        fill_ids = [str(x) for x in (getattr(ergebnis, "fill_ids", []) or [])
                    if str(x).strip()]
        order_ids = [str(x) for x in (getattr(ergebnis, "order_ids", []) or [])
                     if str(x).strip()]
        if (not bool(getattr(ergebnis, "fill_evidence_complete", False))
                or not fill_ids or not order_ids
                or float(getattr(ergebnis, "filled_quantity", 0.0) or 0.0) <= 0):
            return None, None
        strategy = dict(intent.get("strategy_identity") or {})
        strategy_mode = str(intent.get("strategy_mode") or
                            strategy.get("entry_strategy_mode") or "")
        menge = float(ergebnis.filled_quantity)
        kurs = float(ergebnis.avg_fill_price or intent.get("signal_price") or 0.0)
        signal_price = float(intent.get("signal_price") or 0.0)
        planned_stop = float(intent.get("stop") or 0.0)
        planned_take = float(intent.get("take") or 0.0)
        # Schutz und ROI werden IMMER am echten Durchschnittsfill verankert.
        # Im Freqtrade-Modus sind -10 % und anfangs +4 % netto Teil der
        # offiziellen SampleStrategy. Die spaeteren ROI-Stufen werden im
        # 60-Sekunden-Monitor clientseitig ausgewertet.
        stop, take = fill_anchored_stop_take(
            strategy_mode=strategy_mode, fill_price=kurs, filled_quantity=menge,
            entry_fee_quote=float(getattr(ergebnis, "fees_quote", 0.0) or 0.0),
            exit_fee_pct=self._taker_satz(), signal_price=signal_price,
            planned_stop=planned_stop, planned_take=planned_take)
        cl_ord_id = str(getattr(ergebnis, "client_order_id", "") or
                        getattr(ergebnis, "reference_id", "") or
                        intent.get("cl_ord_id") or "")
        order_tag = str(getattr(ergebnis, "order_tag", "") or
                        intent.get("order_tag") or "")
        protection_client_id = ("P" + "".join(
            ch for ch in cl_ord_id if ch.isalnum()))[:32]
        # v9.1: Die ROI-Uhr laeuft ab dem FILL, nicht ab der Verbuchung.
        # Vorher griff der Dataclass-Default datetime.now(). Im Normalfall sind
        # das nur Sekunden -- wird ein Fill aber erst nach einem Absturz
        # aufgeklaert (nachtraeglich=True), startete die Uhr komplett neu, und
        # die Position blieb auf der 4-%-Stufe stehen statt auf 2 % oder 1 %
        # zu fallen. Freqtrade misst die Haltedauer ab dem Einstiegsfill.
        eroeffnet = _fillzeitpunkt(ergebnis) or datetime.now(timezone.utc).isoformat()
        position = KryptoPosition(
            eroeffnet_am=eroeffnet,
            symbol=str(symbol).upper(), inst_id=str(intent.get("inst_id") or "").upper(),
            menge=menge, einstieg=kurs, stop=stop,
            take_profit=take,
            order_id=order_ids[0], referenz=cl_ord_id,
            broker_schutz=bool(ergebnis.stop_order_platziert), hoechstkurs=kurs,
            paper=bool(ergebnis.paper), decision_id=int(decision_id),
            entry_strategy_mode=strategy_mode,
            strategy_name=str(strategy.get("strategy_name") or ""),
            strategy_version=str(strategy.get("strategy_version") or ""),
            strategy_parameter_hash=str(strategy.get("parameter_hash") or ""),
            strategy_parameters=strategy,
            trade_quote_ccy=str(getattr(ergebnis, "trade_quote_ccy", "") or
                                intent.get("trade_quote_ccy") or ""),
            client_order_id=cl_ord_id, order_tag=order_tag,
            fill_ids=fill_ids, ownership_verified=True,
            # v9.2: Konto festhalten, damit ein Bestand aus dem Demokonto
            # nach einem Umschalten auf Live nicht uebernommen wird.
            account_fingerprint=(
                self.broker.account_fingerprint()
                if hasattr(self.broker, "account_fingerprint") else ""),
            entry_fee_by_currency=dict(getattr(ergebnis, "fees", {}) or {}),
            entry_fee_quote=float(getattr(ergebnis, "fees_quote", 0.0) or 0.0),
            protection_client_order_id=protection_client_id,
            protection_status="PENDING",
        )
        self.buch.setze(position)
        self.topf.setze_offene_positionen(len(self.buch.aktive()))

        trade_id = None
        try:
            import trade_ledger
            trade_id = trade_ledger.trade_open(
                broker="okx", symbol=position.symbol, menge=menge,
                einstieg_preis=kurs, referenzpreis=intent.get("signal_price"),
                asset_type="crypto", waehrung=self._quote_waehrung(position),
                paper=bool(ergebnis.paper),
                gebuehr=float(getattr(ergebnis, "fees_quote", 0.0) or 0.0),
                marktphase=str(intent.get("marktphase") or ""),
                decision_id=decision_id,
                strategie_version=str(strategy.get("strategy_version") or ""),
                entry_strategy_mode=strategy_mode,
                strategy_parameter_hash=str(strategy.get("parameter_hash") or ""),
                strategy_parameters=strategy,
                enter_tag=str(intent.get("enter_tag") or "")[:160],
                broker_position_id=position.inst_id,
                entry_order_id=order_ids[0], entry_fill_id=fill_ids[0],
                entry_fill_ids=fill_ids,
                entry_fills=list(getattr(ergebnis, "fills", []) or []),
                client_order_id=cl_ord_id, order_tag=order_tag,
                ownership_status="VERIFIED_BROKER_FILL_CHAIN",
                entry_fee_by_currency=dict(getattr(ergebnis, "fees", {}) or {}),
                broker_account_fingerprint=(
                    self.broker.account_fingerprint()
                    if hasattr(self.broker, "account_fingerprint") else ""),
                reconciliation_status="CONFIRMED_OPEN",
                notiz=("nachtraeglich aus persistierter OKX-Order bestaetigt"
                       if nachtraeglich else "echte OKX-tradeId-Fills bestaetigt"))
        except Exception:
            logger.warning("OKX-Fill konnte nicht vollstaendig ins Trade-Ledger geschrieben werden",
                           exc_info=True)

        registry = self._order_registry()
        proof = dict(intent)
        proof.update({"decision_id": int(decision_id), "zustand": "FILLED",
                      "ord_id": order_ids[0], "cl_ord_id": cl_ord_id,
                      "fill_ids": fill_ids, "trade_id": trade_id})
        registry.register_orders(order_ids, symbol, proof, asset_type="crypto")
        registry.register_orders(fill_ids, symbol,
                                 {**proof, "identifier_type": "FILL"},
                                 asset_type="crypto")
        if trade_id:
            registry.clear_pending(symbol, "crypto")
        else:
            registry.setze_zustand(
                symbol, "AWAITING_POSITION_CONFIRMATION", "crypto",
                ord_id=order_ids[0], cl_ord_id=cl_ord_id, fill_ids=fill_ids)

        # Erst nachdem Position, Ledger und Eigentumsregister haltbar sind,
        # darf die Schutzorder entstehen. Ein Absturz davor wird beim
        # Reconciliation-Lauf eindeutig nachgeholt; es gibt keine verwaiste
        # Schutzorder ohne lokale Position mehr.
        if trade_id:
            try:
                try:
                    protection = self.broker.reconcile_position_protection(
                        self._instrument(position.symbol, position.inst_id),
                        position.menge, position.stop, position.take_profit,
                        protection_client_id=protection_client_id,
                        trade_quote_ccy=position.trade_quote_ccy)
                except TypeError:
                    protection = self.broker.reconcile_position_protection(
                        self._instrument(position.symbol, position.inst_id),
                        position.menge, position.stop, position.take_profit)
                position.broker_schutz = bool(protection.get("protection_confirmed"))
                position.protection_algo_id = str(protection.get("algo_id") or "")
                position.protection_client_order_id = str(
                    protection.get("algo_client_id") or protection_client_id)
                position.protection_status = (
                    "ACTIVE" if position.broker_schutz else
                    "MISSING" if bool(protection.get("checked", True)) else "PENDING")
                self.buch.setze(position)
                trade_ledger.set_protection(
                    trade_id,
                    algo_id=position.protection_algo_id,
                    client_order_id=position.protection_client_order_id,
                    status=position.protection_status,
                    detail=str(protection.get("detail") or ""))
                ergebnis.stop_order_platziert = position.broker_schutz
                ergebnis.take_order_platziert = position.broker_schutz
                ergebnis.protection_algo_id = position.protection_algo_id
                ergebnis.protection_client_order_id = position.protection_client_order_id
            except BrokerFehler as exc:
                position.protection_status = "MISSING"
                self.buch.setze(position)
                trade_ledger.set_protection(
                    trade_id, client_order_id=protection_client_id,
                    status="MISSING", detail=str(exc))
                self._melde(meldungen_sicherheit(
                    f"Broker-Schutz fehlt · {position.symbol}",
                    f"Der Kauf ist eindeutig verbucht, aber die OKX-Schutzorder "
                    f"konnte nicht bestaetigt werden: {exc}",
                    handlung="Neue Einstiege in dieses Symbol bleiben gesperrt; "
                             "NEXUS versucht den Schutz im naechsten Takt erneut."),
                    wichtig=True, klasse="KRITISCH")
        return position, trade_id

    def _reconcile_pending_okx_orders(self, broker) -> list[dict]:
        registry = self._order_registry()
        abgeschlossen: list[dict] = []
        for key, intent in registry.nicht_terminale().items():
            if str(intent.get("asset_type") or "").lower() != "crypto":
                continue
            if str(intent.get("broker") or "okx").lower() != "okx":
                continue
            symbol = str(intent.get("symbol") or key.split(":")[-1]).upper()
            result = broker.reconcile_order_evidence(intent)
            if result is None:
                continue
            decision_id = int(intent.get("decision_id") or 0)
            record_order_result(
                decision_id, result, broker="okx", symbol=symbol,
                requested_qty=intent.get("qty"),
                requested_price=intent.get("signal_price"),
                currency=str(intent.get("trade_quote_ccy") or ""))
            order_ids = list(getattr(result, "order_ids", []) or [])
            if result.fill_evidence_complete and result.filled_quantity > 0:
                position, trade_id = self._persistiere_okx_entry(
                    symbol=symbol, decision_id=decision_id, ergebnis=result,
                    intent=intent, nachtraeglich=True)
                if position:
                    mark_execution(
                        decision_id, "FILLED", order_ids,
                        reference_id=position.client_order_id,
                        fill_price=position.einstieg, fill_qty=position.menge,
                        broker_paper=bool(position.paper))
                    abgeschlossen.append({"symbol": symbol, "trade_id": trade_id,
                                           "status": "FILLED"})
                continue
            if result.terminal and float(result.gross_filled_quantity or 0.0) <= 0:
                registry.register_orders(
                    order_ids, symbol, {**intent, "zustand": str(result.status).upper()},
                    asset_type="crypto")
                registry.clear_pending(symbol, "crypto")
                mark_execution(decision_id, str(result.status or "NOT_FILLED").upper(),
                               order_ids, reference_id=result.reference_id,
                               broker_paper=bool(result.paper))
                abgeschlossen.append({"symbol": symbol,
                                       "status": str(result.status).upper()})
                continue
            registry.setze_zustand(
                symbol, "AWAITING_FILL_EVIDENCE", "crypto",
                ord_id=(order_ids[0] if order_ids else ""),
                cl_ord_id=result.client_order_id or result.reference_id)
        return abgeschlossen

    def _standard_timeframe_confirmation(self, instrument: Instrument,
                                         protokoll: Entscheidungsprotokoll) -> tuple[bool, str]:
        """Existing NEXUS 5m/1h confirmation, isolated from SampleStrategy."""
        broker = self.broker
        try:
            trend = broker.historie(
                instrument, "14 D",
                str(getattr(self.cfg, "CRYPTO_TREND_BAR_SIZE", "1 hour")), False)
            confirm = broker.historie(
                instrument, "1 D",
                str(getattr(self.cfg, "CRYPTO_CONFIRM_BAR_SIZE", "5 mins")), False)
        except BrokerFehler as exc:
            protokoll.blockiert(BROKER, f"Mehrzeitebenen-Daten fehlen: {exc}")
            return False, "5m/1h-Daten nicht verfuegbar"
        if trend is None or len(trend) < 55:
            protokoll.blockiert(TECHNIK, "zu wenige abgeschlossene 1h-Kerzen")
            return False, "1h-Trend nicht pruefbar"
        trend_close = trend["close"].astype(float)
        trend_sma20 = float(trend_close.rolling(20).mean().iloc[-1])
        trend_sma50 = float(trend_close.rolling(50).mean().iloc[-1])
        trend_ok = (float(trend_close.iloc[-1]) > trend_sma50
                    and trend_sma20 > trend_sma50)
        candle_times = dict(protokoll.daten.get("candle_timestamps") or {})
        candle_times["1h"] = str(trend.index[-1]) if len(trend) else None
        protokoll.messwerte(sma20_1h=trend_sma20, sma50_1h=trend_sma50,
                           candle_timestamps=candle_times)
        protokoll.ergaenze(
            TECHNIK, DAFUER if trend_ok else DAGEGEN, gewicht=0.45,
            detail="1h-Aufwaertstrend bestaetigt" if trend_ok else "1h-Trend nicht positiv",
            datenquelle="OKX abgeschlossene 1h-Kerzen")
        if not trend_ok:
            return False, "1h-Trendfilter"
        if confirm is None or len(confirm) < 24:
            protokoll.blockiert(TECHNIK, "zu wenige abgeschlossene 5m-Kerzen")
            return False, "5m-Bestaetigung nicht pruefbar"
        confirm_close = confirm["close"].astype(float)
        confirm_ok = (float(confirm_close.iloc[-1]) >
                      float(confirm_close.rolling(20).mean().iloc[-1])
                      and float(confirm_close.iloc[-1]) >= float(confirm_close.iloc[-4]))
        protokoll.ergaenze(
            TECHNIK, DAFUER if confirm_ok else DAGEGEN, gewicht=0.35,
            detail="5m-Impuls bestaetigt" if confirm_ok else "5m-Impuls fehlt",
            datenquelle="OKX abgeschlossene 5m-Kerzen")
        if not confirm_ok:
            return False, "5m-Bestaetigungsfilter"
        candle_times = dict(protokoll.daten.get("candle_timestamps") or {})
        candle_times["5m"] = str(confirm.index[-1]) if len(confirm) else None
        protokoll.messwerte(candle_timestamps=candle_times)
        return True, ""

    # -- Chancensuche -------------------------------------------------------
    def _scan_blockiert(self, grund: str, *, gate: str,
                        strategy_mode: str) -> dict:
        """Eine globale Kaufsperre als sichtbare Scanentscheidung ablegen.

        Diese Sperren greifen vor der Einzelpruefung eines Coins. Ohne einen
        eigenen Eintrag sah /decisions deshalb stundenlang unveraendert aus,
        obwohl der Fuenf-Minuten-Takt korrekt weiterlief.
        """
        text = str(grund or "globale Krypto-Kaufsperre")[:500]
        # v9.1: Eine unveraenderte Sperre wird nur EINMAL protokolliert, nicht
        # bei jeder Scanrunde. Bei 300 s Takt waren das 288 Zeilen pro Tag mit
        # symbol="OKX_SCAN"; sie verdraengten die echten Ablehnungsgruende aus
        # der Top-5-Liste des Dashboards -- waehrend die Seite daneben
        # behauptet, ein Scan ohne Signal erzeuge keinen Datensatz.
        schluessel = (str(gate or "scan_gate"), str(text or ""))
        neu = getattr(self, "_letzte_scan_sperre", None) != schluessel
        self._letzte_scan_sperre = schluessel
        try:
            if not neu:
                raise StopIteration
            from decision_journal import record_decision
            record_decision(
                symbol="OKX_SCAN", asset_type="crypto", broker="okx",
                paper=bool(getattr(self.cfg, "OKX_DEMO", True)),
                status="BLOCKED", blocked_by=str(gate or "scan_gate"),
                reason=text, execution_status="",
                strategy_mode=str(strategy_mode or ""),
                entry_strategy_mode=str(strategy_mode or ""),
                evaluated_filters=[{
                    "name": str(gate or "scan_gate"), "status": "BLOCKED",
                    "reason": text,
                }],
                not_evaluated_filters=[
                    "universe", "technical_signal", "costs", "order_execution"
                ],
            )
        except StopIteration:
            pass                      # unveraenderte Sperre, schon protokolliert
        except Exception:
            logger.debug("Globale OKX-Scanblockade nicht protokollierbar",
                         exc_info=True)
        return {"ok": True, "gescannt": 0, "strategy_mode": strategy_mode,
                "hinweis": text, "scan_blocked": True, "blocked_by": gate,
                "erneut_protokolliert": neu}

    def scan(self) -> dict:
        broker = self.broker
        if broker is None:
            return {"ok": False, "grund": "OKX nicht verbunden"}


        from crypto_strategy_mode import CRYPTO_PAUSED, current_mode
        strategy_mode = current_mode()
        if strategy_mode == CRYPTO_PAUSED:
            return self._scan_blockiert(
                "Krypto-Neueinstiege sind pausiert. eToro sowie OKX-Schutz, "
                "Reconciliation und positionsgebundene Ausstiege laufen weiter.",
                gate="crypto_strategy_mode", strategy_mode=strategy_mode)

        # Ungeklaerte Exposure sperrt neue Einstiege fail-closed, bis die
        # Herkunft geklaert ist. Verkaeufe und Schutzorders bleiben erlaubt.
        if getattr(self, "_exposure_sperre", None):
            return self._scan_blockiert(
                "Neue Einstiege gesperrt: " + "; ".join(self._exposure_sperre),
                gate="exposure_reconciliation", strategy_mode=strategy_mode)

        darf, grund = self.risiko.darf_kaufen("crypto")
        if not darf:
            return self._scan_blockiert(
                grund, gate="risk_gate", strategy_mode=strategy_mode)

        # Die SampleStrategy darf nicht indirekt durch eine GPT-bewertete
        # Attention-Reihenfolge beeinflusst werden. Wie eine Freqtrade-
        # Pairlist verarbeitet sie deshalb deterministisch alle aktuell durch
        # die harten OKX-/Liquiditaetsfilter freigegebenen Paare. Im normalen
        # NEXUS-Modus bleibt das bewaehrte, begrenzte Focus-Set unveraendert.
        from crypto_strategy_mode import FREQTRADE_SAMPLE
        if strategy_mode == FREQTRADE_SAMPLE:
            symbole = sorted(self.universum.handelbare_symbole("okx"))
        else:
            symbole = self.universum.focus_set("okx")
        offene = {p.symbol.upper() for p in self.buch.aktive()}
        kandidaten = [s for s in symbole if s.upper() not in offene]

        # Der Scan hat alle globalen Sperren passiert. Damit ist eine spaeter
        # erneut auftretende Sperre wieder eine echte Nachricht und wird auch
        # wieder protokolliert.
        self._letzte_scan_sperre = None

        bericht = {"ok": True, "gescannt": 0, "gekauft": [], "abgelehnt": {},
                   "strategy_mode": strategy_mode}
        for symbol in kandidaten:
            darf, grund = self.risiko.darf_kaufen("crypto")
            if not darf:
                bericht["hinweis"] = grund
                break
            bericht["gescannt"] += 1
            try:
                ergebnis = self.pruefe_kandidat(symbol)
            except Exception as exc:
                logger.exception("Kandidatenpruefung %s fehlgeschlagen", symbol)
                record_system_error(
                    symbol=symbol, asset_type="crypto", broker="okx",
                    gate="candidate_processing", exc=exc,
                    paper=bool(getattr(self.cfg, "OKX_DEMO", True)),
                )
                bericht["abgelehnt"][symbol] = f"Fehler: {type(exc).__name__}"
                continue
            if ergebnis.get("gekauft"):
                bericht["gekauft"].append(symbol)
            else:
                bericht["abgelehnt"][symbol] = ergebnis.get("grund", "")
        return bericht

    def pruefe_kandidat(self, symbol: str) -> dict:
        """Der vollstaendige Kaufweg fuer genau ein Instrument."""
        broker = self.broker
        protokoll = Entscheidungsprotokoll(symbol, asset_type="crypto", broker="okx")
        from crypto_strategy_mode import (
            CRYPTO_PAUSED, FREQTRADE_SAMPLE, NEXUS_STANDARD,
            current_mode, entry_snapshot,
        )
        strategy_mode = current_mode()
        if strategy_mode == CRYPTO_PAUSED:
            protokoll.blockiert(RISK_GATE, "Krypto-Neueinstiege per Laufzeitschalter pausiert")
            return self._abschluss(protokoll, "ABGELEHNT", "Krypto-Neueinstiege pausiert")
        strategy_identity = entry_snapshot(strategy_mode)
        protokoll.messwerte(
            entry_strategy_mode=strategy_mode,
            strategy_name=strategy_identity.get("strategy_name"),
            strategy_version=strategy_identity.get("strategy_version"),
            strategy_parameter_hash=strategy_identity.get("parameter_hash"),
            strategy_parameters=strategy_identity,
        )

        # Ein manueller Verkauf sperrt den Basiswert unabhaengig vom
        # Quote-Markt. So kauft der naechste Scan ONDO nicht sofort erneut
        # ueber USD/USDC/EUR.
        try:
            import manual_trade_control
            account = str(getattr(broker, "account_fingerprint", lambda: "")() or "")
            lock_reason = manual_trade_control.lock_reason("okx", account, symbol)
        except Exception as exc:
            # v9.1: fail-CLOSED. Ein Lesefehler der Sperrdatei (Rechte, NFS,
            # defektes JSON) bedeutete bis 9.0.15 "keine Sperre" -- der Bot
            # kaufte den gerade manuell verkauften Coin sofort nach. An einem
            # Sicherheitsgate muss der Zweifel sperren, nicht freigeben.
            logger.warning("Wiedereinstiegssperre nicht lesbar: %s", exc, exc_info=True)
            lock_reason = ("Wiedereinstiegssperre nicht lesbar -- Einstieg "
                           "vorsorglich blockiert, bis die Datei wieder lesbar ist")
        if lock_reason:
            protokoll.blockiert(RISK_GATE, lock_reason)
            return self._abschluss(protokoll, "ABGELEHNT", lock_reason)

        # --- Anlaufsperre (v8.1.4) ------------------------------------------
        # Neue Einstiege warten, bis die Domaene handelsbereit ist UND die
        # Mindestwartezeit abgelaufen ist. Verkaeufe, Stops und Schutzorders
        # betrifft das nicht -- die laufen in pruefe_positionen() sofort.
        darf_kaufen, bereit_grund = self.bereitschaft.darf_kaufen()
        if not darf_kaufen:
            protokoll.blockiert(RISK_GATE, bereit_grund)
            return self._abschluss(protokoll, "ABGELEHNT", bereit_grund)

        mitglied = self.universum.zustand.hole("okx", symbol)
        if mitglied is None or not mitglied.handelbar:
            protokoll.blockiert(UNIVERSE, "nicht im handelbaren Universum")
            return self._abschluss(protokoll, "ABGELEHNT", "nicht im handelbaren Universum")
        # Ab 9.0.1 ist die Monatsliste nur Mitgliedschaft, keine Handelsfreigabe.
        # Eine fehlgeschlagene Monatsrotation behaelt deshalb die vorige Liste.
        # Sicherheit entsteht im Geldpfad aus der Anlaufsperre oben sowie den
        # nachfolgenden Kerzen-, Instrument-, Spread-, Kosten- und Risikogates.
        instrument = self._instrument(symbol, mitglied.inst_id)
        quote_ccy = instrument.currency
        try:
            trade_quote_ccy = (broker.trade_quote_for_instrument(
                instrument, require_cash=True)
                if hasattr(broker, "trade_quote_for_instrument") else quote_ccy)
        except BrokerFehler as exc:
            protokoll.blockiert(BROKER, str(exc))
            return self._abschluss(protokoll, "ABGELEHNT", str(exc))
        protokoll.ergaenze(UNIVERSE, DAFUER, gewicht=0.2,
                           detail=f"Rang {mitglied.letzter_rang}, Score {mitglied.letzter_score:.3f}",
                           datenquelle="UniverseManager")
        protokoll.messwerte(
            universe_rank=getattr(mitglied, "letzter_rang", None),
            universe_score=getattr(mitglied, "letzter_score", None),
            currency=quote_ccy, trade_quote_ccy=trade_quote_ccy,
        )
        if strategy_mode == NEXUS_STANDARD and mitglied.ai_bewertung:
            protokoll.ki("luna", DAFUER if mitglied.ai_bewertung == "HIGH" else NEUTRAL,
                         f"Einstufung {mitglied.ai_bewertung}", modell=mitglied.ai_modell,
                         cache=True, gewicht=0.1)

        # --- Signal --------------------------------------------------------
        is_freqtrade = strategy_mode == FREQTRADE_SAMPLE
        try:
            df = broker.historie(
                instrument,
                str(getattr(self.cfg, "FREQTRADE_HISTORY_DURATION", "3 D")
                    if is_freqtrade else getattr(self.cfg, "CRYPTO_HISTORY_DURATION", "3 D")),
                "5 mins" if is_freqtrade else
                str(getattr(self.cfg, "CRYPTO_BAR_SIZE", "15 mins")),
                False,
            )
        except BrokerFehler as exc:
            protokoll.blockiert(BROKER, f"Kursdaten nicht verfuegbar: {exc}")
            return self._abschluss(protokoll, "ABGELEHNT", "keine Kursdaten")
        # v9.1: Die Zahl kommt aus der Strategie selbst, nicht aus einer
        # zweiten, fest eingetippten Kopie. Die frueheren 200 haben
        # Instrumente mit duenner Historie (Neulistings, Handelspausen)
        # verworfen, die Freqtrade mit 30 Kerzen handeln wuerde.
        if is_freqtrade:
            from freqtrade_sample_strategy import STARTUP_CANDLES
            minimum_candles = int(STARTUP_CANDLES)
        else:
            minimum_candles = 60
        if df is None or len(df) < minimum_candles:
            protokoll.blockiert(TECHNIK, f"zu wenige Kerzen ({0 if df is None else len(df)})")
            return self._abschluss(protokoll, "ABGELEHNT", "zu wenige Kerzen")

        if is_freqtrade:
            from freqtrade_sample_strategy import evaluate
            from strategy import Signal
            try:
                sample = evaluate(df)
            except ValueError as exc:
                protokoll.blockiert(TECHNIK, str(exc))
                return self._abschluss(protokoll, "ABGELEHNT", str(exc))
            signal = Signal(
                "BUY" if sample.entry else "HOLD", sample.entry_reason,
                0.5, sample.close, sample.atr)
            protokoll.messwerte(
                rsi_5m=sample.rsi, tema_5m=sample.tema,
                bb_middle_5m=sample.bb_middle, volume_5m=sample.volume,
                atr=sample.atr,
                completed_candles_only=True,
                candle_timestamps={"5m": sample.candle_time},
                signal_reason=sample.entry_reason,
                signal_checks=dict(getattr(sample, "entry_checks", {}) or {}),
                enter_tag="freqtrade_sample_entry",
            )
        else:
            from strategy import generate_signal
            signal = generate_signal(df, None)
            try:
                from strategy import prepare
                ind15 = prepare(df)
                last15 = ind15.iloc[-1] if ind15 is not None and len(ind15) else {}
                protokoll.messwerte(
                    rsi_15m=last15.get("rsi") if hasattr(last15, "get") else None,
                    atr=getattr(signal, "atr", None),
                    completed_candles_only=True,
                    candle_timestamps={"15m": str(df.index[-1]) if len(df) else None},
                    signal_reason=getattr(signal, "reason", ""),
                    enter_tag=getattr(signal, "reason", ""),
                )
            except Exception:
                logger.debug("15m-Auditindikatoren nicht extrahierbar", exc_info=True)
        if signal.action != "BUY":
            protokoll.technik(DAGEGEN, 0.6, f"{signal.action}: {signal.reason}")
            return self._abschluss(
                protokoll, "KEIN_SIGNAL", f"Kein Kaufsignal: {signal.reason}")
        protokoll.technik(DAFUER, 0.6, signal.reason)

        if not is_freqtrade:
            confirmed, confirmation_reason = self._standard_timeframe_confirmation(
                instrument, protokoll)
            if not confirmed:
                return self._abschluss(protokoll, "ABGELEHNT", confirmation_reason)

        preis = float(signal.price or 0.0)
        if preis <= 0:
            protokoll.blockiert(TECHNIK, "kein gueltiger Signalpreis")
            return self._abschluss(protokoll, "ABGELEHNT", "kein gueltiger Preis")

        # --- Live-Quote und Spanne ----------------------------------------
        quote = broker.latest_bid_ask(instrument) or {}
        bid, ask = float(quote.get("bid") or 0.0), float(quote.get("ask") or 0.0)
        from cost_engine import fallback_spread_pct, spread_pct_from_bid_ask
        spanne = spread_pct_from_bid_ask(bid, ask, fallback_spread_pct("crypto"))
        max_spanne = float(getattr(self.cfg, "MAX_SPREAD_CRYPTO_PCT", 0.006))
        marktqualitaet_ok = spanne <= max_spanne
        if ask > 0:
            preis = ask          # gekauft wird zum Briefkurs, nicht zum Schlusskurs
        protokoll.messwerte(price=preis, bid=bid, ask=ask, spread_pct=spanne,
                           spread_limit_pct=max_spanne, quote_source="OKX Ticker")
        protokoll.ergaenze(MARKT, DAFUER if marktqualitaet_ok else DAGEGEN, gewicht=0.3,
                           detail=f"Spanne {spanne * 100:.3f} % (Grenze {max_spanne * 100:.2f} %)",
                           datenquelle="OKX Ticker")

        # --- Schutzwerte und Menge ----------------------------------------
        if is_freqtrade:
            from freqtrade_sample_strategy import MINIMAL_ROI, STOPLOSS, roi_exit_price
            stop = preis * (1.0 + float(STOPLOSS))
            # Broker-side disaster protection uses the initial ROI target.
            # The 2%/1% time steps remain client-managed and are checked on
            # every position cycle from the immutable entry snapshot.
            ziel = roi_exit_price(
                preis, float(MINIMAL_ROI["0"]),
                entry_fee_pct=self._taker_satz(),
                exit_fee_pct=self._taker_satz())
        else:
            from risk_manager import calculate_stop_take
            stop, ziel = calculate_stop_take(preis, "BUY", signal.atr, "crypto")
        # Der Stop darf nie enger sitzen als die Handelskosten. Sonst ist ein
        # Stop-Out rechnerisch ein garantierter Verlust -- genau das ist am
        # 25.08.2026 zweimal innerhalb von 63 Sekunden passiert.
        stop, stop_hinweis = self._stop_mindestabstand(preis, stop, spanne, quote_ccy)
        if stop_hinweis:
            protokoll.ergaenze(RISK_GATE, NEUTRAL, gewicht=0.0, detail=stop_hinweis,
                               datenquelle="Kostenmodell OKX")
        quote_rate = (broker.quote_conversion_rate(quote_ccy, trade_quote_ccy)
                      if hasattr(broker, "quote_conversion_rate") else
                      1.0 if quote_ccy == trade_quote_ccy else None)
        if not quote_rate or quote_rate <= 0:
            grund = (f"keine beobachtete Umrechnung {quote_ccy}->{trade_quote_ccy}; "
                     "USD wird nicht mit USDC gleichgesetzt")
            protokoll.blockiert(RISK_GATE, grund)
            return self._abschluss(protokoll, "ABGELEHNT", grund)
        # Jeder Handelskanal traegt sein eigenes Risiko. Ein USD-Kauf darf
        # daher weder aus dem EUR- noch aus dem USDC-Guthaben dimensioniert
        # werden. Der globale OKX-Topf begrenzt weiterhin Tagesverlust und
        # Anzahl der Positionen; die konkrete Ordergroesse basiert jedoch
        # ausschliesslich auf dem freien Cash ihres tradeQuoteCcy-Kanals.
        lane_cash = broker.verfuegbares_cash(trade_quote_ccy)
        if lane_cash is None or lane_cash <= 0:
            grund = f"freies {trade_quote_ccy}-Guthaben nicht abrufbar oder null"
            protokoll.blockiert(RISK_GATE, grund)
            return self._abschluss(protokoll, "ABGELEHNT", grund)
        # v9.3: Schwebende eigene Kaeufe derselben Quote-Lane abziehen. Sonst
        # sieht Kandidat B dasselbe Geld, das Kandidat A bereits gebunden hat
        # -- solange die Belastung bei OKX noch nicht verbucht ist. Die Lanes
        # bleiben getrennt: eine EUR-Reservierung blockiert kein USDC.
        gebunden = self._order_registry().lane_reservierung(
            trade_quote_ccy, asset_type="crypto", ausser_symbol=symbol)
        if gebunden > 0:
            puffer = 1.0 + max(0.0, float(getattr(
                self.cfg, "RESERVIERUNG_PUFFER_PCT", 0.01)))
            lane_cash = max(0.0, lane_cash - gebunden * puffer)
            protokoll.messwerte(
                lane_reserviert=round(gebunden * puffer, 8),
                lane_capital_nach_reservierung=round(lane_cash, 8))
            if lane_cash <= 0:
                grund = (f"freies {trade_quote_ccy}-Guthaben vollstaendig durch "
                         "ungeklaerte eigene Kaeufe gebunden")
                protokoll.blockiert(RISK_GATE, grund)
                return self._abschluss(protokoll, "ABGELEHNT", grund)
        menge, groessen_grund = self.topf.positionsgroesse(
            preis * quote_rate, stop * quote_rate, asset_type="crypto",
            kontowert_override=lane_cash)
        menge = self._auf_lot_runden(symbol, menge)
        topf_status = self.topf.uebersicht()
        protokoll.messwerte(
            stop=stop, take=ziel, planned_qty=menge,
            equity_before=topf_status.get("kontowert"),
            lane_capital_before=lane_cash,
            lane_currency=trade_quote_ccy,
            daily_pnl=topf_status.get("tages_pnl"),
            open_positions=topf_status.get("offene_positionen"),
            trades_today=topf_status.get("trades_heute"),
            cooldown_active=topf_status.get("abkuehlung_aktiv"),
            risk_amount=(abs(preis - stop) * quote_rate * menge
                         if menge > 0 else None),
        )
        protokoll.ergaenze(RISK_GATE, DAFUER if menge > 0 else DAGEGEN, gewicht=0.4,
                           detail=groessen_grund, datenquelle="Risikotopf OKX")

        # --- Cash-Reserve: verkleinern statt blockieren --------------------
        # Bis 8.1.2 pruefte der Bot nur "passt die geplante Order ins freie
        # Cash?" und liess bei Nein die GESAMTE Order fallen. Eine kleinere,
        # regelkonforme Order war damit unmoeglich. Jetzt wird zuerst
        # verkleinert und erst danach abgelehnt, wenn selbst die kleinste
        # zulaessige Order nicht mehr passt.
        geplante_menge = float(menge)
        menge, cash_hinweis, cash_grund = self._menge_an_cash_anpassen(
            symbol, menge, preis * quote_rate, trade_quote_ccy)
        try:
            protokoll.messwerte(
                cash_before=broker.verfuegbares_cash(trade_quote_ccy),
                market_quote_ccy=quote_ccy,
                trade_quote_ccy=trade_quote_ccy,
                quote_conversion_rate=quote_rate)
        except Exception:
            logger.debug("Cash-Auditwert nicht abrufbar", exc_info=True)
        cash_ok = menge > 0
        if cash_hinweis:
            protokoll.ergaenze(RISK_GATE, NEUTRAL, gewicht=0.0, detail=cash_hinweis,
                               datenquelle="Cash-Reserve OKX")
            # Bewusst KEINE Telegram-Meldung an dieser Stelle. Der Kandidat
            # muss erst die restliche Kaufkaskade bestehen. Sonst kaeme bei
            # knappem Guthaben je Scan eine Nachricht pro geprueftem Coin --
            # fuer Kaeufe, die danach ohnehin nicht stattfinden. Gemeldet
            # wird die Verkleinerung erst beim tatsaechlichen Kauf.
        if not cash_ok:
            protokoll.ergaenze(RISK_GATE, DAGEGEN, gewicht=0.4, detail=cash_grund,
                               datenquelle="Cash-Reserve OKX")

        # --- Orderbuchtiefe -------------------------------------------------
        # Am 25.08.2026 bestellte der Bot 46,9 SOL und bekam 0,50 -- OKX
        # stornierte den Rest, weil der geschaetzte Ausfuehrungspreis den
        # besten Kurs um mehr als 5 % verfehlte. Was ausgefuehrt wurde, wurde
        # zu einem Preis ausgefuehrt, den der Markt sofort wieder verliess.
        if cash_ok:
            menge, buch_hinweis = self._menge_an_orderbuch_anpassen(
                symbol, mitglied, menge, quote_ccy)
            cash_ok = menge > 0
            if buch_hinweis:
                protokoll.ergaenze(MARKT, NEUTRAL, gewicht=0.0, detail=buch_hinweis,
                                   datenquelle="OKX Orderbuch")
            if not cash_ok:
                cash_grund = buch_hinweis or "Orderbuch zu duenn"
                protokoll.ergaenze(MARKT, DAGEGEN, gewicht=0.4, detail=cash_grund,
                                   datenquelle="OKX Orderbuch")

        # --- Kosten --------------------------------------------------------
        # Bewusst NACH der Cash-Anpassung: die Kostenrechnung haengt an der
        # Menge. Eine verkleinerte Order darf nicht mit der Kostenschaetzung
        # der urspruenglich geplanten Groesse freigegeben werden.
        from cost_engine import estimate_roundtrip
        # Mit Menge 0 liefert das Kostenmodell eine Fantasiehuerde (Division
        # durch ein Nullvolumen) und schriebe sie ins Entscheidungsjournal.
        # Ist die Menge ohnehin abgelehnt, wird die Referenzmenge gerechnet
        # und der Beitrag klar als nicht anwendbar gekennzeichnet.
        kosten = estimate_roundtrip(menge if cash_ok else geplante_menge, preis,
                                    asset_type="crypto", currency=quote_ccy,
                                    fee_pct=self._taker_satz(),
                                    bid=bid, ask=ask, broker="okx")
        erwartete_bewegung = abs(ziel - preis) / preis if preis > 0 else 0.0
        # required_edge_pct enthaelt bereits Kostenmultiplikator und
        # Sicherheitsmarge -- genau dieselbe Huerde wie auf der Aktienseite.
        netto_edge_ok = erwartete_bewegung > float(kosten.required_edge_pct)
        protokoll.messwerte(
            final_qty=menge, position_value=(menge * preis if menge > 0 else None),
            fees_estimated=(kosten.buy_commission + kosten.sell_commission),
            cost_pct=getattr(kosten, "total_cost_pct", None),
            required_edge_pct=kosten.required_edge_pct,
            expected_move_pct=erwartete_bewegung,
            net_edge_pct=(erwartete_bewegung - kosten.required_edge_pct),
        )
        protokoll.ergaenze(BROKER, DAFUER if netto_edge_ok else DAGEGEN, gewicht=0.5,
                           detail=(f"erwartete Bewegung {erwartete_bewegung * 100:.2f} % gegen "
                                   f"Kostenhuerde {kosten.required_edge_pct * 100:.2f} % "
                                   f"(davon Gebuehren "
                                   f"{(kosten.buy_commission + kosten.sell_commission):.4f} {quote_ccy})"),
                           datenquelle="Cost Engine (OKX-Gebuehren)")

        # --- Deterministische Endpruefung ----------------------------------
        from candidate_gate import bewerte_kandidat
        entscheidung = bewerte_kandidat(
            state_allows_buy=self._zustand_erlaubt_kauf(),
            broker_online=broker.is_connected(),
            instrument_identity_ok=self._identitaet_ok(symbol),
            market_open=True,                       # Krypto handelt immer
            # v9.2: Eine pausierte oder manuell verwaltete Botposition sperrt
            # den Wiedereinstieg genauso wie eine automatisch verwaltete.
            # Vorher meldete eine BEOBACHTEN-Position hier "keine Position
            # offen" -- der Bot haette denselben Coin ein zweites Mal gekauft.
            # Der Buchschluessel ist der Basiswert, damit sperrt LINK auch
            # LINK-EUR, LINK-USD und LINK-USDT.
            position_already_open=bool(
                self.buch.hole(symbol) and self.buch.hole(symbol).blocks_reentry),
            duplicate_open_order=(symbol.upper() in self._offene_order_symbole()
                                  or broker.hat_offene_order(instrument, "BUY")),
            risk_allows_buy=self.risiko.darf_kaufen("crypto")[0],
            portfolio_allows_buy=self._portfolio_erlaubt(),
            cash_allows_buy=cash_ok,
            market_quality_ok=marktqualitaet_ok,
            cost_quote_ok=True,
            net_edge_ok=netto_edge_ok,
            quantity=menge, price=preis, stop=stop, take_profit=ziel)

        if not entscheidung.approved:
            protokoll.blockiert(CANDIDATE_GATE, f"{entscheidung.blocked_by}: {entscheidung.reason}")
            return self._abschluss(protokoll, "ABGELEHNT", entscheidung.reason)

        # --- GPT Second Opinion (v8.2) --------------------------------------
        # GANZ AM ENDE, wenn alles Deterministische bestanden ist. Die KI
        # bleibt eine neutrale Warn- und Dokumentationsquelle. Ist das Human
        # Gate aktiv, wartet allein Georgs zeitlich begrenzte Freigabe; danach
        # prueft der naechste Scan die gesamte feste Kaskade erneut.
        human_gate_ok = True
        if not is_freqtrade:
            human_gate_ok = self._second_opinion(
                symbol, protokoll, preis=preis, menge=menge, stop=stop, ziel=ziel,
                waehrung=quote_ccy, signal=signal, kosten=kosten,
                erwartete_bewegung=erwartete_bewegung, mitglied=mitglied)
        if not human_gate_ok:
            return self._abschluss(
                protokoll, "PENDING_HUMAN_APPROVAL",
                "kritische KI-Warnung wartet auf persoenliche Freigabe")

        # --- Order ---------------------------------------------------------
        # Die Entscheidung MUSS vor dem Netzwerk-Submit dauerhaft existieren.
        # So kann auch UNKNOWN_AFTER_SUBMIT niemals eine verwaiste Order ohne
        # Herkunft erzeugen.
        from decision_journal import record_decision
        ready_payload = self._decision_payload(
            protokoll, status="APPROVED", reason="alle deterministischen Gates bestanden",
            paper=bool(getattr(self.cfg, "OKX_DEMO", True)))
        ready_payload["execution_status"] = "READY_TO_SUBMIT"
        decision_id = record_decision(**ready_payload)
        if decision_id is None:
            protokoll.blockiert(CANDIDATE_GATE, "Entscheidung konnte nicht persistent verknuepft werden")
            return self._abschluss(protokoll, "SYSTEM_ERROR", "Audit-Persistenz fehlgeschlagen")
        inst_id = str(
            getattr(getattr(instrument, "contract", None), "localSymbol", "")
            or mitglied.inst_id or normalize_inst_id(symbol, quote_ccy)).upper()
        cl_ord_id = client_order_id_for_decision(decision_id)
        order_tag = str(getattr(self.cfg, "OKX_ORDER_TAG", "NEXUS"))[:16]
        intent = {
            "broker": "okx", "asset_type": "crypto", "symbol": symbol.upper(),
            "decision_id": int(decision_id), "zustand": "SUBMITTING",
            "inst_id": inst_id, "qty": float(menge),
            "signal_price": float(preis), "stop": float(stop), "take": float(ziel),
            "cl_ord_id": cl_ord_id, "client_order_id": cl_ord_id,
            "order_tag": order_tag, "trade_quote_ccy": trade_quote_ccy,
            "strategy_mode": strategy_mode, "strategy_identity": strategy_identity,
            "enter_tag": ("freqtrade_sample_entry" if is_freqtrade else
                          str(getattr(signal, "reason", "") or "")[:160]),
            "marktphase": self._marktphase(),
        }
        registry = self._order_registry()
        # Vor dem ersten Netzwerkbyte dauerhaft schreiben. Derselbe
        # Entscheidungsschluessel erzeugt immer dieselbe clOrdId.
        registry.register_pending(symbol, intent, asset_type="crypto")
        mark_execution(decision_id, "SUBMITTING", [], reference_id=cl_ord_id)
        broker._nexus_submit_context = {
            "decision_id": int(decision_id), "client_order_id": cl_ord_id,
            "order_tag": order_tag,
        }
        try:
            ergebnis = broker.kaufe_mit_absicherung(instrument, menge, preis, stop, ziel)
        except OrderStatusUnklar as exc:
            exc_intent = dict(getattr(exc, "intent", {}) or {})
            ord_ids = list(getattr(exc, "order_ids", []) or [])
            registry.setze_zustand(
                symbol, "UNKNOWN_AFTER_SUBMIT", "crypto",
                ord_id=(ord_ids[0] if ord_ids else exc_intent.get("ord_id", "")),
                cl_ord_id=getattr(exc, "reference_id", "") or cl_ord_id)
            mark_execution(decision_id, "UNKNOWN_AFTER_SUBMIT",
                           ord_ids, reference_id=getattr(exc, "reference_id", "") or cl_ord_id)
            protokoll.ergaenze(BROKER, NEUTRAL, detail=f"Transportzustand unklar: {exc}")
            self._melde(f"Krypto {symbol}: Kaufzustand UNKLAR (clOrdId "
                        f"{getattr(exc, 'reference_id', '') or cl_ord_id}). Kein zweiter "
                        "Kauf; NEXUS klaert dieselbe Order im Hintergrund ueber OKX.",
                        wichtig=True, klasse="KRITISCH")
            return self._abschluss(protokoll, "UNKLAR", "Transportzustand nach Kauf unklar")
        except BrokerFehler as exc:
            registry.setze_zustand(symbol, "REJECTED", "crypto")
            registry.clear_pending(symbol, "crypto")
            mark_execution(decision_id, "FAILED", [])
            protokoll.blockiert(BROKER, str(exc))
            return self._abschluss(protokoll, "FEHLGESCHLAGEN", str(exc))
        finally:
            broker._nexus_submit_context = {}

        gefuellt = float(ergebnis.filled_quantity or 0.0)
        # v9.3: Entscheidung und Ausfuehrung sind zwei getrennte Zustaende.
        # "SUBMITTED_NOT_FILLED" sagte nicht, WARUM nichts passiert ist --
        # beim WLD-Beispiel (FOK, 0/270,94 storniert) stand in der
        # Entscheidungsansicht weiter APPROVED, was wie ein erfolgreicher
        # Kauf aussieht.
        execution_status = getattr(ergebnis, "execution_status", None) or (
            "FILLED" if gefuellt > 0 else "SUBMITTED_NOT_FILLED")
        mark_execution(
            decision_id, execution_status, getattr(ergebnis, "order_ids", []) or [],
            reference_id=str(getattr(ergebnis, "reference_id", "") or ""),
            fill_price=getattr(ergebnis, "avg_fill_price", None),
            fill_qty=getattr(ergebnis, "filled_quantity", None),
            broker_paper=bool(getattr(ergebnis, "paper", True)),
        )
        record_order_result(
            decision_id, ergebnis, broker="okx", symbol=symbol,
            requested_qty=menge, requested_price=preis, currency=quote_ccy,
        )
        if gefuellt <= 0:
            if bool(getattr(ergebnis, "terminal", False)):
                registry.register_orders(
                    getattr(ergebnis, "order_ids", []) or [], symbol,
                    {**intent, "zustand": str(ergebnis.status).upper()},
                    asset_type="crypto")
                registry.clear_pending(symbol, "crypto")
            else:
                registry.setze_zustand(
                    symbol, "AWAITING_FILL_EVIDENCE", "crypto",
                    ord_id=str(next(iter(ergebnis.order_ids or []), "")))
            beleg = dict(getattr(ergebnis, "execution_evidence", {}) or {})
            grund = self._nichtausfuehrungs_text(ergebnis, beleg)
            protokoll.messwerte(
                execution_status=execution_status,
                final_status=getattr(ergebnis, "final_status", "UNKLAR"),
                broker_cancel_source=str(beleg.get("cancel_source") or ""),
                broker_s_code=str(beleg.get("s_code") or ""),
                broker_limit_price=beleg.get("limit_price"),
                broker_filled_qty=beleg.get("filled_qty"),
                broker_requested_qty=beleg.get("requested_qty"))
            protokoll.ergaenze(BROKER, DAGEGEN, detail=grund)
            return self._abschluss(protokoll, "NICHT_AUSGEFUEHRT", grund)

        position, trade_id = self._persistiere_okx_entry(
            symbol=symbol, decision_id=decision_id, ergebnis=ergebnis, intent=intent)
        if position is None:
            registry.setze_zustand(
                symbol, "AWAITING_FILL_EVIDENCE", "crypto",
                ord_id=str(next(iter(ergebnis.order_ids or []), "")),
                cl_ord_id=cl_ord_id)
            return self._abschluss(
                protokoll, "UNKLAR",
                "Order ausgefuehrt, echte OKX-tradeId-Beweiskette noch unvollstaendig")
        kurs = position.einstieg

        protokoll.ergaenze(BROKER, DAFUER, gewicht=1.0,
                           detail=(f"{gefuellt:g} zu {kurs:g}; Broker-Schutz "
                                   f"{'ja' if ergebnis.stop_order_platziert else 'nein'}"))
        # Einheitliche Kaufmeldung. Die Verkleinerungen (Cash-Reserve,
        # Orderbuchtiefe) stehen als Hinweis darin -- gemeldet wird beim
        # tatsaechlichen Kauf, einmal, mit den echten Zahlen.
        import meldungen
        hinweise = [h for h in (cash_hinweis, locals().get("buch_hinweis", ""),
                                locals().get("stop_hinweis", "")) if h]
        markt_quote = self._quote_waehrung(position) or quote_ccy
        abrechnung = str(position.trade_quote_ccy or "").upper()
        if abrechnung and abrechnung != str(markt_quote).upper():
            hinweise.append(f"Abgerechnet in {abrechnung}; Kurse stehen in {markt_quote}.")
        self._melde(meldungen.kauf(
            broker="okx", symbol=symbol, menge=gefuellt, preis=kurs,
            # v9.1: Preis, Stop und Ziel stehen in der MARKTQUOTE des instId
            # (BTC-USD -> USD). Etikettiert wurde bis 9.0.15 die
            # Abrechnungswaehrung -- die Meldung sagte dann "50 000.00 EUR",
            # waehrend das Ledger dieselben Zahlen als USD verbucht. Die
            # Abrechnungswaehrung steht jetzt als eigener Hinweis dabei.
            waehrung=self._quote_waehrung(position) or quote_ccy,
            gebuehr=float(getattr(ergebnis, "fees_quote", 0.0) or 0.0),
            gebuehr_pct=self._taker_satz(), stop=stop, ziel=ziel,
            grund=getattr(signal, "reason", "") or "technisches Einstiegssignal",
            geplant=geplante_menge, schutz=bool(ergebnis.stop_order_platziert),
            hinweise=hinweise), wichtig=True)
        return self._abschluss(protokoll, "AUSGEFUEHRT", "gekauft", gekauft=True,
                               execution=ergebnis)

    def _marktphase(self) -> str:
        """Marktphase fuer die spaetere Auswertung -- oder leer.

        Bewusst nicht geraten: eine falsche Phase verfaelscht die Auswertung
        nach Marktphase still. Leer heisst "nicht bekannt".
        """
        try:
            from market_regime import letzter_bekannter
            # NUR lesen: der Kryptopfad darf keinen Marktdaten-Download
            # ausloesen und im Kaufpfad nicht auf das Netz warten.
            return letzter_bekannter()
        except Exception:
            logger.debug("Marktphase nicht ermittelbar", exc_info=True)
            return ""

    # -- Hilfsmittel --------------------------------------------------------
    def _abschluss(self, protokoll: Entscheidungsprotokoll, ergebnis: str, grund: str,
                   *, gekauft: bool = False, execution=None) -> dict:
        protokoll.abschliessen(ergebnis, grund)
        source_payload = protokoll.als_dict()
        try:
            from decision_journal import record_decision
            status = ("APPROVED" if gekauft else
                      "BLOCKED" if str(ergebnis).upper() == "ABGELEHNT" else
                      "NO_SIGNAL" if str(ergebnis).upper() == "KEIN_SIGNAL" else
                      "UNKNOWN_AFTER_SUBMIT" if str(ergebnis).upper() == "UNKLAR" else
                      str(ergebnis).upper())
            payload = self._decision_payload(
                protokoll, status=status, reason=grund,
                paper=bool(getattr(execution, "paper", True)))
            payload["execution_status"] = status
            if execution is not None:
                payload.update({
                    "execution_status": str(getattr(execution, "status", "")),
                    "order_ids": list(getattr(execution, "order_ids", []) or []),
                    "reference_id": str(getattr(execution, "reference_id", "") or ""),
                    "filled_quantity": float(getattr(execution, "filled_quantity", 0.0) or 0.0),
                    "avg_fill_price": float(getattr(execution, "avg_fill_price", 0.0) or 0.0),
                })
            decision_id = record_decision(**payload)
            speichere_quellen(source_payload, decision_id=decision_id or protokoll.decision_id)
        except Exception:
            logger.debug("Entscheidungsjournal nicht schreibbar", exc_info=True)
        return {"gekauft": gekauft, "grund": grund, "protokoll": protokoll.als_dict()}

    @staticmethod
    def _decision_payload(protokoll: Entscheidungsprotokoll, *, status: str,
                          reason: str, paper: bool) -> dict:
        source_payload = protokoll.als_dict()
        payload = {
            "decision_id": protokoll.decision_id,
            "symbol": protokoll.symbol, "asset_type": "crypto", "broker": "okx",
            "approved": str(status).upper() == "APPROVED", "status": str(status).upper(),
            "paper": bool(paper),
            "blocked_by": (protokoll.blockierer[0].quelle if protokoll.blockierer else ""),
            "reason": reason, "hauptquelle": protokoll.hauptquelle(),
            "sources": source_payload.get("quellen", []),
        }
        payload.update(dict(protokoll.daten))
        return payload

    def _auf_lot_runden(self, symbol: str, menge: float) -> float:
        broker = self.broker
        if broker is None or menge <= 0:
            return 0.0
        try:
            member = self.universum.zustand.hole("okx", symbol)
            inst_id = str(getattr(member, "inst_id", "") or normalize_inst_id(symbol, broker.quote_ccy))
            meta = broker.client.instrument(inst_id)
        except BrokerFehler:
            # Fail closed. Vorher kam die Menge UNGERUNDET zurueck -- also
            # weder auf dem Lotraster noch gegen minSz geprueft. OKX lehnt
            # so eine Order ab; schlimmer, sie wandert ungeprueft durch die
            # Cash-Rechnung. Ohne Instrumentdaten wird nicht gekauft.
            logger.warning("Lotgroesse fuer %s nicht abrufbar -- kein Kauf.", symbol)
            return 0.0
        if meta is None:
            return 0.0
        from broker.okx import quantize_down
        gerundet = quantize_down(menge, meta.lot_size)
        return gerundet if gerundet >= float(meta.min_size or 0) else 0.0

    def _zustand_erlaubt_kauf(self) -> bool:
        try:
            from bot_zustand import BotZustand
            return bool(BotZustand().darf_kaufen())
        except Exception:
            # Kein lesbarer Zustand heisst: nicht kaufen. Im Zweifel gilt
            # immer die sichere Seite.
            logger.warning("Botzustand nicht lesbar -- Kauf wird blockiert.", exc_info=True)
            return False

    def _identitaet_ok(self, symbol: str) -> bool:
        """Ein OKX-Instrument ist eindeutig, wenn es im Katalog LIVE steht."""
        broker = self.broker
        if broker is None:
            return False
        try:
            member = self.universum.zustand.hole("okx", symbol)
            inst_id = str(getattr(member, "inst_id", "") or normalize_inst_id(symbol, broker.quote_ccy))
            meta = broker.client.instrument(inst_id)
        except BrokerFehler:
            return False
        return bool(meta and meta.ist_live and meta.base_ccy.upper() == str(symbol).upper())

    def _portfolio_erlaubt(self) -> bool:
        grenze = int(getattr(self.cfg, "OKX_MAX_OPEN_POSITIONS", 6))
        return len(self.buch.aktive()) < grenze

    def _menge_an_cash_anpassen(self, symbol: str, menge: float, preis: float,
                                quote_ccy: str = "") -> tuple[float, str, str]:
        """Verkleinert die Order auf das verfuegbare Cash statt sie zu blockieren.

        Rueckgabe: (menge, hinweis, ablehnungsgrund)
            menge  = 0 bedeutet: auch die kleinste zulaessige Order passt nicht
            hinweis        gefuellt, wenn tatsaechlich verkleinert wurde
            ablehnungsgrund gefuellt, wenn menge == 0

        Rechenweg:
            reserve      = freies Cash * OKX_CASH_RESERVE_PCT
            max_notional = (frei - reserve) / (1 + Taker-Gebuehr)

        Die Gebuehr wird ausdruecklich herausgerechnet. Vorher steckte sie
        stillschweigend in der Reserve -- wer bis an die Reservegrenze
        verkleinert, wuerde sie sonst genau mit der Gebuehr wieder aufbrauchen.

        Verkleinern ist sicherheitstechnisch unbedenklich: der Stopabstand
        bleibt unveraendert, die Position wird kleiner, das Risiko je Trade
        sinkt also. Die Kosten- und Netto-Edge-Pruefung laeuft anschliessend
        trotzdem mit der neuen Menge erneut.
        """
        broker = self.broker
        if broker is None:
            return 0.0, "", "OKX nicht verbunden"
        if menge <= 0 or preis <= 0:
            return 0.0, "", "Keine gueltige Menge oder kein Preis"

        waehrung = str(quote_ccy or getattr(broker, "quote_ccy", "EUR")).upper()
        frei = broker.verfuegbares_cash(waehrung)
        if frei is None:
            return 0.0, "", f"Freies {waehrung}-Guthaben nicht abrufbar"

        reserve_pct = max(0.0, float(getattr(self.cfg, "OKX_CASH_RESERVE_PCT", 0.05)))
        # Der GEMESSENE Satz, nicht die Annahme -- sonst plant die
        # Cash-Rechnung mit einer Gebuehr, die es nicht gibt.
        gebuehr_pct = max(0.0, self._taker_satz())
        mindestwert = float(getattr(self.cfg, "OKX_MIN_POSITION_VALUE", 15.0))

        reserve_betrag = frei * reserve_pct
        verfuegbar = max(0.0, frei - reserve_betrag)
        max_notional = verfuegbar / (1.0 + gebuehr_pct)

        geplanter_wert = menge * preis
        if geplanter_wert <= max_notional:
            return menge, "", ""

        # Verkleinern und auf das OKX-Mengenraster abrunden.
        neue_menge = self._auf_lot_runden(symbol, max_notional / preis)
        neuer_wert = neue_menge * preis

        if neue_menge <= 0:
            return 0.0, "", (
                f"Cash reicht nicht: frei {frei:.2f} {waehrung}, davon "
                f"{reserve_betrag:.2f} Reserve; nutzbar {max_notional:.2f} "
                f"{waehrung} liegt unter der OKX-Mindestmenge")
        if neuer_wert < mindestwert:
            return 0.0, "", (
                f"Cash reicht nicht: moeglich waeren nur {neuer_wert:.2f} "
                f"{waehrung}, Mindestordergroesse ist {mindestwert:.2f} "
                f"{waehrung} (frei {frei:.2f}, Reserve {reserve_betrag:.2f})")

        hinweis = (f"Order von {geplanter_wert:.2f} {waehrung} auf "
                   f"{neuer_wert:.2f} {waehrung} wegen Cash-Reserve reduziert "
                   f"(frei {frei:.2f}, Reserve {reserve_betrag:.2f}, "
                   f"Gebuehr {gebuehr_pct * 100:.2f} %)")
        return neue_menge, hinweis, ""

    # -- Statusanzeige ------------------------------------------------------
    def status(self) -> dict:
        try:
            from crypto_strategy_mode import status as strategy_mode_status
            strategy_status = strategy_mode_status()
        except Exception as exc:
            strategy_status = {"active_mode": "CRYPTO_PAUSED", "error": str(exc)}
        return {
            "zeit": datetime.now(timezone.utc).isoformat(),
            "zyklen": self.zyklen,
            "verbunden": self.broker is not None,
            "modus": ("DEMO" if (self.broker and self.broker.ist_paper()) else "LIVE")
                     if self.broker else "-",
            # Ab v8.1.4 gehoert alles in den Status, was der Nutzer im
            # Telegram-Status und auf dem Dashboard sehen muss. Bis 8.1.3
            # stand dort ueber OKX schlicht nichts.
            "handelsbereitschaft": self.bereitschaft.status(),
            "guthaben": self._guthaben_uebersicht(),
            "exposure": dict(self._letzte_exposure),
            "handelbares_kapital": round(float(self.topf.kontowert or 0.0), 2),
            "gebuehrensatz_pct": round(self._taker_satz() * 100, 4),
            "crypto_strategy": strategy_status,
            "positionen": [p.als_dict() for p in self.buch.aktive()],
            "konto_asset_hinweise": [p.als_dict() for p in self.buch.alle()
                                      if not p.darf_schutz_ausfuehren],
            "universum": self.universum.uebersicht("okx"),
            "risiko": self.topf.uebersicht() if self.topf else {},
            "takt": self.takt.plan().get("crypto", {}),
            "letzter_universumslauf": self.letzter_universumslauf,
            "letzter_fehler": self.letzter_fehler,
        }


__all__ = ["CryptoEngine", "KryptoPosition", "KryptoPositionsbuch",
           "fill_anchored_stop_take", "VERWALTUNG_AUTO",
           "VERWALTUNG_MANUELL"]
