# TradingBot NEXUS 9.4.1

NEXUS 9.4.1 korrigiert die responsive WebUI: Das NEXUS-Logo bleibt am Desktop
auf 46 x 46 Pixel begrenzt, die Analysewerkzeuge der Desktop-GUI stehen als
eigene WebUI-Seite bereit und das kumulierte Nettoergebnis wird als lokale
SVG-Grafik mit getrennten Kurven je Waehrung dargestellt. Die eToro-/OKX-
Ownership-, Kaufkoordinations-, Schutz- und Migrationsregeln aus 9.4 bleiben
unveraendert.

NEXUS handelt zwei strikt getrennte Bereiche:

- eToro für Aktien im Aktien-Marktfenster;
- OKX Deutschland/EEA für Krypto-Spot rund um die Uhr im Demo- oder bewusst
  freigegebenen Live-Modus.

NEXUS 9.0 behebt zuerst die Reconciliation-, Entscheidungsdaten-, Telegram-,
Sortierungs- und `CORE_VOLUME_20`-Fehler aus 8.3.1. Zusätzlich gibt es für
neue OKX-Einstiege einen zur Laufzeit umschaltbaren, isolierten Modus nach den
Regeln der offiziellen Freqtrade `SampleStrategy`.

Der globale Krypto-Modus gilt nur für neue Käufe. Jede offene OKX-Position
behält dauerhaft die Strategie, Version und Parameter, mit der sie eröffnet
wurde. Ein Wechsel verändert niemals rückwirkend die Verwaltung einer offenen
Position.

NEXUS 9.0.1 erweitert gezielt die Kryptoseite: 20 recherchierte Kernwerte
bleiben dauerhaft im OKX-Beobachtungsuniversum, 30 weitere Werte werden
monatlich aus echten OKX-Spotvolumina neu bewertet. Die Aufnahmefilter für
die Beobachtung sind kryptogerechter; vor einer Order gelten weiterhin die
strengeren Geldpfad-Sicherheiten. Die neue Seite **Trades** zeigt auf Deutsch
offene und geschlossene Trades, kumulierte Ergebnisse und für OKX eine
responsive Kerzengrafik mit markiertem Kauf und Verkauf.

NEXUS 9.0.2 ist ein gezieltes Stabilitätsupdate. OKX unterstützt nun die
tatsächlich verfügbaren Spot-Quotes EUR, USD und USDC, verwaiste offene
Ledger-Trades werden sicher mit dem Brokerbestand abgeglichen, identische
Telegram-Nachrichten können nicht mehr parallel doppelt gesendet werden und
brokerseitige eToro-Stop-/Zielausführungen erhalten einen eindeutigen
Ausstiegsgrund. Universum, WebUI und Handelsstrategien bleiben fachlich
unverändert.

NEXUS 9.0.3 zieht die Broker-Wahrheit konsequent vor den lokalen Ledgerstatus:
eToro-Positionen gelten erst mit aktueller, exakt passender `positionId` als
offen; bereits geschlossene Käufe werden nach einem Neustart nicht erneut
eingespielt. OKX lädt die Fill-Historie paginiert nach und rekonstruiert
fehlende Verkäufe und Teilverkäufe. Unklare Ledgerzeilen stehen getrennt unter
**Klärung nötig**. Aktienkäufe besitzen jetzt dieselbe 15-minütige
Handelsbereitschaft wie Krypto. Die WebUI erhält auf Handy und Tablet ein
zugängliches Dropdown-Menü; die Desktopnavigation bleibt unverändert.

NEXUS 9.0.4 schließt die dabei sichtbar gewordenen Restlücken. Eine gemeldete
eToro-Orderausführung erzeugt erst dann einen Trade, wenn dieselbe
`positionId` aktuell beim Broker vorhanden ist; dadurch entsteht kein
Phantom-Trade wie bei MSFT. OKX-Instrumente verwenden die vom Broker
gelieferte `tradeQuoteCcyList`, sodass Unified-USD-Handelspaare korrekt über
den jeweils zulässigen Handelskanal ausgewählt werden. In 9.0.11 sind das
ausschließlich EUR, USD oder USDC. SOL und andere Coins bleiben stets
Bestand, niemals Handels-Cash. Ein alter, nicht belegbarer SOL-Ledger-Eintrag
wird erst nach zwei vollständigen Brokerabgleichen geschlossen, ohne das echte
SOL-Guthaben zu verkaufen. Telegram-Nachrichten werden 30 Sekunden gesammelt
und dedupliziert; Telegram lässt sich in der WebUI ohne Neustart aktivieren
oder deaktivieren.

NEXUS 9.0.5 stabilisiert die OKX-Verbindung anhand der offiziellen OKX-V5-
Vorgaben. Eine abweichende Systemzeit wird nicht mehr als dauerhaft falscher
API-Key behandelt. Der Krypto-Worker bleibt bei einem Startfehler aktiv und
verbindet sich mit Backoff erneut. Signierte REST- und WebSocket-Anfragen
verwenden die gemessene OKX-Serverzeit; der Privatstream überwacht Text-
Ping/Pong, Wartungshinweise und Verbindungslimits. Die WebUI trennt jetzt
Worker-Heartbeat, Broker-Authentifizierung und einmaligen API-Test. Alte
Kontodaten können dadurch niemals „ONLINE“ oder „KÄUFE FREI“ vortäuschen.

NEXUS 9.0.6 schließt die danach belegten Konsistenzlücken im Geldpfad. Ein
eToro-Fill wird bei kurz verzögerter Brokerdarstellung nicht mehr nach wenigen
Sekunden zum Fremdtrade erklärt: Die exakte `positionId` bleibt während einer
Karenz gesperrt und wird mehrfach gegen Depot und Historie geprüft. Bei OKX
werden Account-Salden und Botpositionen fachlich getrennt. BTC, ETH, SOL und
XRP im Spot-Konto sind verfügbare Konto-Assets, keine offenen Trades. Nur ein
exakt belegter, aktiv verwalteter Bot-Einstieg erscheint als Botposition.
WebSocket-Pongs gelten nicht mehr als Beweis für frische Kontodaten;
regelmäßige REST-Vollsichten bereinigen partielle oder alte Stream-Snapshots.

NEXUS 9.0.7 beseitigt die verbleibende Grundursache der CRM-, NVDA- und
QCOM-Fälle. Ein unklarer asynchroner eToro-Auftrag ist kein globaler
Verbindungsverlust mehr. Neue Orders verwenden den v3-202-Pfad, bleiben per
`X-Request-Id` gesperrt und werden durch einen dauerhaften Hintergrundabgleich
über `orderId/referenceId` bis zur exakten `positionId` verfolgt. Eine bereits
als OBSERVE sichtbare Position wird bei spätem Beweis ohne Mengendopplung zu
BOT/AUTO hochgestuft. OKX verwendet kontospezifische Instrumentregeln aus
`/account/instruments`: EUR ist primäre Bot-Cashwährung, USDC zusätzlich
erlaubt. USD, USDT und TRY sind keine Standard-Bot-Cashwährungen. Ein
Unified-USD-Markt ist nur mit passender `tradeQuoteCcyList` und beobachteter
Umrechnung handelbar. Vorhandene Spot-Assets bleiben vom Botbesitz getrennt.

NEXUS 9.0.8 korrigiert den beim ersten Pi-Lauf sichtbar gewordenen
`NameError` im neuen eToro-Ausnahmezweig. Gleichzeitig fragt der Scanner das
Depot nicht mehr für jedes HOLD-Instrument erneut ab und verteilt eToro-Aufrufe
gleichmäßig über die dokumentierten Ratenfenster. Frische Positions- und
Doppelorderprüfungen vor einem tatsächlichen Kauf bleiben vollständig aktiv.

NEXUS 9.0.9 macht die Broker-Beweiskette zur verbindlichen Grundlage. OKX-
Kontosalden sind nur Konto-Assets; eine Botposition benötigt `clOrdId/tag`,
`ordId` und echte `tradeId`-Fills. Teilfills, Nettomenge und tatsächliche
Gebühren werden vollständig gespeichert, unklare Orders nie erneut gesendet.
Der stabile 20er-Kern enthält nur für das konkrete Konto ausführbare und
qualitativ geeignete EUR-/USDC-Spotwerte. Das Entscheidungslog funktioniert
wieder, unterscheidet `NO_SIGNAL` von echten Blockaden und zeigt konkrete
Krypto-Regelwerte. eToro-Privatstream-Ereignisse beschleunigen die vorhandene
REST-/`positionId`-Reconciliation, ersetzen sie aber nicht.

NEXUS 9.0.10 korrigiert die OKX-Equity-Bremse: Die Umwandlung von Cash in
eine bewiesene Botposition gilt nicht mehr als Kontoverlust. Globale
Scanblockaden erscheinen außerdem als konkrete Einträge im Entscheidungslog.

NEXUS 9.0.11 übernimmt die robuste Pairlist-Idee von Freqtrade für den
OKX-Spotbetrieb, ohne Futures oder simuliertes USDT einzuführen. Ein breiter
öffentlicher SPOT-Katalog dient nur der Entdeckung; handelbar bleibt
ausschließlich die Schnittmenge mit `/account/instruments`. EUR, USD und USDC
sind getrennte, tatsächlich finanzierte Handelskanäle. Jede Order verwendet
eine von OKX gemeldete `tradeQuoteCcy`; Guthaben und Risiko werden nie
zwischen den Währungen vermischt. Der stabile Kern und die dynamische Liste
werden nach normalisiertem echten OKX-Volumen aufgebaut.

## Dokumentation

- [Ausführliche Projektbeschreibung für GitHub](README_GITHUB_NEXUS_9.0.4_DE.md)

- [Installation und Update](INSTALLATIONSANLEITUNG_NEXUS_9.0_DE.md)
- [Update auf 9.0.2](INSTALLATIONSANLEITUNG_NEXUS_9.0.2_DE.md)
- [Update auf 9.0.3](INSTALLATIONSANLEITUNG_NEXUS_9.0.3_DE.md)
- [Korrekturen 9.0.3](KORREKTUREN_NEXUS_9.0.3_DE.md)
- [Update auf 9.0.4](INSTALLATIONSANLEITUNG_NEXUS_9.0.4_DE.md)
- [Korrekturen 9.0.4](KORREKTUREN_NEXUS_9.0.4_DE.md)
- [Update auf 9.0.5](INSTALLATIONSANLEITUNG_NEXUS_9.0.5_DE.md)
- [Korrekturen und OKX-PDF-Abgleich 9.0.5](KORREKTUREN_NEXUS_9.0.5_DE.md)
- [Update auf 9.0.6](INSTALLATIONSANLEITUNG_NEXUS_9.0.6_DE.md)
- [Broker-Konsistenz und API-Abgleich 9.0.6](KORREKTUREN_NEXUS_9.0.6_DE.md)
- [Update auf 9.0.7](INSTALLATIONSANLEITUNG_NEXUS_9.0.7_DE.md)
- [API-, Reconciliation- und Währungskorrekturen 9.0.7](KORREKTUREN_NEXUS_9.0.7_DE.md)
- [Update auf 9.0.8](INSTALLATIONSANLEITUNG_NEXUS_9.0.8_DE.md)
- [eToro-Scanner-Korrekturen 9.0.8](KORREKTUREN_NEXUS_9.0.8_DE.md)
- [Update auf 9.0.9](INSTALLATIONSANLEITUNG_NEXUS_9.0.9_DE.md)
- [Update auf 9.0.10](INSTALLATIONSANLEITUNG_NEXUS_9.0.10_DE.md)
- [Update auf 9.0.11](INSTALLATIONSANLEITUNG_NEXUS_9.0.11_DE.md)
- [Brokerwahrheit, Währung und Diagnose 9.0.9](KORREKTUREN_NEXUS_9.0.9_DE.md)
- [Korrekturen 9.0.2](KORREKTUREN_NEXUS_9.0.2_DE.md)
- [Update auf 9.0.1](INSTALLATIONSANLEITUNG_NEXUS_9.0.1_DE.md)
- [Krypto-Universum und Trade-Analyse](KRYPTO_UNIVERSUM_UND_TRADEANALYSE_NEXUS_9.0.1_DE.md)
- [Freqtrade-SampleStrategy-Modus](FREQTRADE_MODUS_NEXUS_9.0_DE.md)
- [Risikoprüfung](RISIKOPRUEFUNG_NEXUS_9.0_DE.md)
- [Änderungen](CHANGELOG_v9.0_NEXUS.txt)
- [Testprotokoll](TEST_REPORT_v9.0_NEXUS.txt)
- [Testprotokoll 9.0.1](TEST_REPORT_v9.0.1_NEXUS.txt)
- [Testprotokoll 9.0.2](TEST_REPORT_v9.0.2_NEXUS.txt)
- [Testprotokoll 9.0.3](TEST_REPORT_v9.0.3_NEXUS.txt)
- [Testprotokoll 9.0.4](TEST_REPORT_v9.0.4_NEXUS.txt)
- [Testprotokoll 9.0.5](TEST_REPORT_v9.0.5_NEXUS.txt)
- [Testprotokoll 9.0.6](TEST_REPORT_v9.0.6_NEXUS.txt)
- [Testprotokoll 9.0.7](TEST_REPORT_v9.0.7_NEXUS.txt)
- [Testprotokoll 9.0.8](TEST_REPORT_v9.0.8_NEXUS.txt)
- [Testprotokoll 9.0.9](TEST_REPORT_v9.0.9_NEXUS.txt)
- [Testprotokoll 9.0.10](TEST_REPORT_v9.0.10_NEXUS.txt)
- [Testprotokoll 9.0.11](TEST_REPORT_v9.0.11_NEXUS.txt)
- [WireGuard/VPN](WIREGUARD_VPN_EINRICHTUNG_DE.md)

## Raspberry-Pi-Schnellstart

```bash
chmod +x Pi_*.sh Nexus_*.sh WebUI_Starten.sh WireGuard_Status_Pruefen.sh
./Pi_Installieren.sh
./.venv/bin/python settings_migration.py --auto
./.venv/bin/python webui_setup.py
./Pi_WebUI_Aktivieren.sh
./Nexus_Einrichten.sh --test
./Pi_Service_Aktivieren.sh
```

Installation und Migration setzen eToro auf Paper und OKX auf Demo. LIVE wird
niemals automatisch übernommen oder aktiviert.
