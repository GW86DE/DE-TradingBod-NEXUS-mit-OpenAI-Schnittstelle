// Positionen verwalten (neu in v8.1.5).
//
// Georg am 25.08.2026: eine selbst gekaufte Aktie liess sich dem Bot nicht
// uebergeben -- die alte Pruefung verlangte "Stop < Einstand < Ziel" und war
// bei einer Position im Minus unerfuellbar. Jetzt wird gegen den AKTUELLEN
// KURS geprueft, und diese Seite ist die Stelle dafuer.
//
// Die Seite fasst weder Broker noch Positionsbuch an. Sie zeigt die
// Momentaufnahme des Handelskerns und legt Auftraege ab, die der Kern in
// seiner eigenen Schleife am echten Kurs ausfuehrt.

let stand = null;

function zahl(v, stellen = 2, vorzeichen = false) {
  if (v === null || v === undefined || v === '') return '–';
  const n = Number(v);
  if (!isFinite(n)) return '–';
  return n.toLocaleString('de-DE', {
    minimumFractionDigits: stellen, maximumFractionDigits: stellen,
    ...(vorzeichen ? { signDisplay: 'always' } : {})
  });
}

function verwaltungsmarke(modus) {
  const m = String(modus || '').toUpperCase();
  if (m === 'AUTO') return badge('BOT VERWALTET', 'ok');
  if (m === 'PENDING_TAKEOVER') return badge('ÜBERNAHME LÄUFT', 'warn');
  // v9.3: Ein eigener Kauf im eToro-Propagationsfenster ist KEIN
  // Fremdbestand. Bis 9.2 stand hier "NUR BEOBACHTET" mit der Herkunft
  // BROKER_EXISTING -- fachlich falsch und für den Nutzer irreführend.
  if (m === 'PENDING_CONFIRMATION') return badge('EIGENER KAUF · WIRD BESTÄTIGT', 'warn');
  return badge('NUR BEOBACHTET', '');
}

// v9.3: Eigentum, Abgleich und Verwaltung getrennt zeigen — dieselbe
// Trennung wie auf der Kryptoseite seit 9.2.
function zuordnung(x) {
  const texte = {
    VERIFIED: '<span class="ok">Eigentum über positionId bewiesen</span>',
    PENDING: '<span class="warn">Eigener Kauf · positionId noch nicht im Depot</span>',
    EXTERNAL: '<span class="small">Fremdbestand beim Broker</span>',
    UNPROVABLE: '<span class="bad">ID-Kette unvollständig</span>',
  };
  const e = texte[String(x.eigentum || '')] || '<span class="small">Eigentum unbekannt</span>';
  const ids = (x.position_ids || []).length
    ? `<br><span class="small">positionId ${esc((x.position_ids || []).join(', '))}</span>` : '';
  return `${e}${ids}`;
}

function kursHinweis(x) {
  const q = String(x.kursquelle || '');
  if (!q || q === 'UNBEKANNT') return '';
  const namen = {
    ETORO_PNL_CLOSE_RATE: 'Depotkurs',
    ETORO_RATES_BID: 'Bid',
    ETORO_RATES_ASK: 'Ask',
    ETORO_RATES_LAST: 'letzte Ausführung',
  };
  const alter = (x.kursalter != null && Number(x.kursalter) >= 60)
    ? ` · ${Math.round(Number(x.kursalter) / 60)} min alt` : '';
  return `<div class="small">${esc(namen[q] || q)}${esc(alter)}</div>`;
}

function ortszeit(utc) {
  if (!utc) return '';
  const d = new Date(String(utc).endsWith('Z') || String(utc).includes('+') ? utc : utc + 'Z');
  if (isNaN(d)) return String(utc).replace('T', ' ').slice(0, 19);
  return d.toLocaleString('de-DE', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });
}

function karten(e) {
  const p = e?.positionen || [];
  const mitWert = p.filter(x => x.unrealisiert != null);
  const buch = mitWert.reduce((a, x) => a + Number(x.unrealisiert || 0), 0);
  const vomBot = p.filter(x => String(x.verwaltung || '') === 'AUTO').length;
  const wartend = p.filter(x => String(x.verwaltung || '') === 'PENDING_TAKEOVER').length;
  return `
    <article class="card"><h3>Offene Positionen</h3><div class="metric">${p.length}</div>
      <p>${vomBot} vom Bot verwaltet · ${p.length - vomBot - wartend} nur beobachtet${wartend ? ` · ${wartend} in Übernahme` : ''}</p></article>
    <article class="card"><h3>Buchwert</h3>
      <div class="metric">${mitWert.length ? zahl(buch, 2, true) : 'n/v'}</div>
      <p>${mitWert.length ? 'unrealisiert, über alle Positionen mit Kurs' : 'Keine aktuellen Kurse — der Handelskern muss laufen.'}</p>
      ${mitWert.length < p.length ? `<div class="small">${p.length - mitWert.length} Position(en) ohne Kurs sind nicht enthalten.</div>` : ''}</article>`;
}

function zeile(x, std) {
  const s = esc(x.symbol);
  const recordId = String(x.record_id || '');
  const kennung = recordId.replace(/[^A-Za-z0-9_-]/g, '_');
  const modus = String(x.verwaltung || '').toUpperCase();
  const kursBekannt = x.kurs != null && Number(x.kurs) > 0;
  // Ohne Kurs wird nichts angeboten: der Kern koennte den Auftrag ohnehin
  // nicht pruefen, und ein Knopf, der nichts tut, ist schlimmer als keiner.
  const knoepfe = modus === 'AUTO'
    ? `<button class="secondary" onclick="beobachten('${recordId}')">Nur beobachten</button>`
    : modus === 'PENDING_TAKEOVER'
      ? '<span class="small">Der Kern prüft gerade den Broker-Schutz.</span>'
      : modus === 'PENDING_CONFIRMATION'
      ? '<span class="small">Eigener Kauf — die Bestätigung läuft automatisch.</span>'
      : kursBekannt
        ? `<button onclick="uebernahmeFormular('${kennung}')">Bot übernehmen</button>`
        : '<span class="small">Kein aktueller Kurs — Übernahme erst möglich, wenn Kursdaten anliegen.</span>';
  return `<tr>
    <td><strong>${s}</strong><div class="small">${esc(x.herkunft || '')} · seit ${esc(ortszeit(x.seit))}</div></td>
    <td>${zahl(x.menge, 4)}</td>
    <td>${zahl(x.einstand, 2)}</td>
    <td>${kursBekannt ? zahl(x.kurs, 2) + kursHinweis(x) : '<span class="small">unbekannt</span>'}</td>
    <td>${x.unrealisiert == null ? '–' : zahl(x.unrealisiert, 2, true)}</td>
    <td>${x.stop ? zahl(x.stop, 2) : '–'} / ${x.ziel ? zahl(x.ziel, 2) : '–'}</td>
    <td>${zuordnung(x)}</td>
    <td>${verwaltungsmarke(x.verwaltung)}<div class="small">${esc(x.notiz || '')}</div></td>
    <td>${knoepfe}</td></tr>
    <tr id="form-${esc(kennung)}" class="hidden"><td colspan="9">
      <div class="toolbar">
        <div class="field"><label>Stop, % unter dem Kurs</label>
          <input type="number" id="stop-${esc(kennung)}" min="0.1" max="50" step="0.1" value="${std.stop}"></div>
        <div class="field"><label>Ziel, % über dem Kurs</label>
          <input type="number" id="ziel-${esc(kennung)}" min="0.1" max="200" step="0.1" value="${std.ziel}"></div>
        <button onclick="uebernehmen('${recordId}','${kennung}')">Übergeben</button>
        <button class="secondary" onclick="uebernahmeFormular('${kennung}')">Abbrechen</button>
      </div>
      <p class="small">Prozent statt fester Beträge, weil der Kurs oben ein paar Sekunden alt ist.
      Der Handelskern rechnet beide Werte gegen den Kurs, den er beim Ausführen sieht.
      Steht die Position im Minus, wird beim Auslösen des Stops ein Verlust realisiert —
      der Kern nennt den Betrag in seiner Antwort.</p>
    </td></tr>`;
}

function tabelle(e, std) {
  const p = e?.positionen || [];
  if (!p.length) return '<p>Keine offenen Aktienpositionen. Sobald der Handelskern welche meldet, stehen sie hier.</p>';
  return `<table><thead><tr>
    <th>Wert</th><th>Menge</th><th>Einstand</th><th>Kurs</th><th>Buchwert</th>
    <th>Stop / Ziel</th><th>Zuordnung</th><th>Verwaltung</th><th>Aktion</th></tr></thead>
    <tbody>${p.map(x => zeile(x, std)).join('')}</tbody></table>`;
}

function okxTabelle(o) {
  const p = o?.positionen || [];
  if (!p.length) return '<p>Keine offenen, vom Bot verwalteten Kryptopositionen.</p>';
  return `<table><thead><tr><th>Wert</th><th>Menge</th><th>Einstieg</th><th>Stop / Ziel</th><th>Einstiegsstrategie</th><th>Verwaltung</th></tr></thead>
    <tbody>${p.map(x => `<tr><td>${esc(x.symbol)}</td><td>${zahl(x.menge, 8)}</td>
      <td>${zahl(x.einstieg, 6)}</td><td>${x.stop ? zahl(x.stop, 6) : '–'} / ${x.take_profit ? zahl(x.take_profit, 6) : '–'}</td>
      <td><strong>${esc(x.entry_strategy_mode || 'UNBEKANNT')}</strong>
        <div class="small">${esc(x.strategy_version || 'keine Version')}${x.strategy_parameter_hash ? ` · ${esc(String(x.strategy_parameter_hash).slice(0, 12))}` : ''}</div></td>
      <td>${verwaltungsmarke(x.verwaltung)}<div class="small">Decision ${x.decision_id ?? '–'}${x.verwaltungsnotiz ? ` · ${esc(x.verwaltungsnotiz)}` : ''}</div></td></tr>`).join('')}</tbody></table>`;
}

function exposureBadge(klasse) {
  const k = String(klasse || '').toUpperCase();
  const map = {
    CASH: ['CASH', ''],
    BOT_MANAGED: ['BOT VERWALTET', 'ok'],
    ACCOUNT_ASSET: ['KONTO-ASSET', ''],
    EXTERNAL_HOLDING: ['EXTERNER BESTAND', 'warn'],
    RESIDUAL_EXPOSURE: ['UNKLARE RESTPOSITION', 'bad'],
    UNKNOWN_EXPOSURE: ['UNKLARER BESTAND', 'bad'],
  };
  const row = map[k] || [k || 'NOCH NICHT KLASSIFIZIERT', ''];
  return badge(row[0], row[1]);
}

function okxKonto(konto) {
  if (!konto?.vorhanden) {
    return '<p>Der Kryptohandelskern hat noch keinen Kontostand geschrieben.</p>';
  }
  const guthaben = konto.guthaben || {};
  const exposure = konto.exposure || {};
  const nachWaehrung = {};
  for (const row of (exposure.bestaende || [])) {
    const ccy = String(row.waehrung || '').toUpperCase();
    if (!ccy) continue;
    if (!nachWaehrung[ccy]) nachWaehrung[ccy] = [];
    nachWaehrung[ccy].push(row);
  }
  const waehrungen = Object.keys(guthaben).sort();
  const modus = String(konto.modus || '').toUpperCase();
  const erklaerung = modus === 'DEMO'
    ? 'OKX stellt im DEMO-Konto Demo-Startguthaben bereit. Es ist kein Kaufauftrag und wird vom Bot nicht als eigene Position verkauft.'
    : 'Spot-Salden sind verfügbare Konto-Assets. Nur ein exakt belegter Bot-Einstieg erscheint zusätzlich als verwaltete Position.';
  if (!waehrungen.length) return `<p>${esc(erklaerung)} Noch keine Guthaben-Momentaufnahme vorhanden.</p>`;
  return `<p class="small">${esc(erklaerung)}</p><table><thead><tr>
    <th>Währung</th><th>Gesamt</th><th>Frei</th><th>Einordnung</th></tr></thead><tbody>
    ${waehrungen.map(ccy => {
      const x = guthaben[ccy] || {};
      const rows = nachWaehrung[ccy] || [];
      const einordnung = rows.length
        ? rows.map(r => `${exposureBadge(r.klasse)}<div class="small">${esc(r.begruendung || '')}</div>`).join('')
        : '<span class="small">Reconciliation läuft noch</span>';
      return `<tr><td><strong>${esc(ccy)}</strong></td><td>${zahl(x.gesamt, 8)}</td>
        <td>${zahl(x.frei, 8)}</td><td>${einordnung}</td></tr>`;
    }).join('')}</tbody></table>`;
}

function auftragsTabelle(a) {
  const offen = a?.offen || [], fertig = a?.erledigt || [];
  if (!offen.length && !fertig.length) return '<p>Noch nichts beauftragt.</p>';
  const zeilen = [
    ...offen.map(x => `<tr><td>${esc(ortszeit(x.erstellt_am))}</td><td>${esc(x.symbol)}</td>
      <td>${esc(x.aktion)}</td><td>${badge('WARTET AUF DEN KERN', 'warn')}</td>
      <td>Wird beim nächsten Durchlauf ausgeführt.</td></tr>`),
    ...fertig.map(x => `<tr><td>${esc(ortszeit(x.erledigt_am))}</td><td>${esc(x.symbol)}</td>
      <td>${esc(x.aktion)}</td><td>${x.ok ? badge('AUSGEFÜHRT', 'ok') : badge('ABGELEHNT', 'bad')}</td>
      <td>${esc(x.detail || '')}</td></tr>`),
  ];
  return `<table><thead><tr><th>Zeit</th><th>Wert</th><th>Aktion</th><th>Status</th><th>Ergebnis</th></tr></thead>
    <tbody>${zeilen.join('')}</tbody></table>`;
}

function uebernahmeFormular(symbol) {
  document.querySelector(`#form-${CSS.escape(symbol)}`)?.classList.toggle('hidden');
}

function positionFuerRecord(recordId) {
  return (stand?.etoro?.positionen || []).find(x => String(x.record_id || '') === String(recordId));
}

function identityPayload(x) {
  return {
    symbol: x.symbol, record_id: x.record_id,
    position_ids: x.position_ids || [], instrument_id: x.instrument_id || '',
    account_fingerprint: x.account_fingerprint || '', snapshot_id: x.snapshot_id || '',
  };
}

async function uebernehmen(recordId, domKey) {
  const xrow = positionFuerRecord(recordId);
  if (!xrow) return melde('Position ist nicht mehr im aktuellen Snapshot. Bitte neu laden.', false);
  const stop = Number(document.querySelector(`#stop-${CSS.escape(domKey)}`).value);
  const ziel = Number(document.querySelector(`#ziel-${CSS.escape(domKey)}`).value);
  try {
    const x = await api('/api/positions/uebernehmen', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...identityPayload(xrow), stop_pct: stop, ziel_pct: ziel }),
    });
    melde(x.detail, true);
    load();
  } catch (e) { melde(e.message, false); }
}

async function beobachten(recordId) {
  const xrow = positionFuerRecord(recordId);
  if (!xrow) return melde('Position ist nicht mehr im aktuellen Snapshot. Bitte neu laden.', false);
  if (!confirm(`${xrow.symbol} · positionId ${(xrow.position_ids || []).join(', ')} nur noch beobachten? Der Bot verkauft genau diese Position dann nicht mehr selbst.`)) return;
  try {
    const x = await api('/api/positions/beobachten', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(identityPayload(xrow)),
    });
    melde(x.detail, true);
    load();
  } catch (e) { melde(e.message, false); }
}

function melde(text, ok) {
  document.querySelector('#hinweis').innerHTML =
    `<p class="alert ${ok ? 'success' : 'danger'}">${esc(text)}</p>`;
}

async function load() {
  try {
    stand = await api('/api/positions');
    const std = { stop: stand.standard_stop_pct, ziel: stand.standard_ziel_pct };
    document.querySelector('#etoro-karten').innerHTML = karten(stand.etoro);
    document.querySelector('#etoro-tabelle').innerHTML = tabelle(stand.etoro, std);
    document.querySelector('#okx-konto').innerHTML = okxKonto(stand.okx_konto);
    document.querySelector('#okx-tabelle').innerHTML = okxTabelle(stand.okx);
    document.querySelector('#auftraege').innerHTML = auftragsTabelle(stand.auftraege);
    const e = stand.etoro || {};
    document.querySelector('#etoro-stand').textContent = e.updated_at
      ? `Stand ${ortszeit(e.updated_at)}${e.kurse_verfuegbar ? '' : ' · ohne aktuelle Kurse'}`
      : 'Der Handelskern hat noch keine Momentaufnahme geschrieben.';
  } catch (e) {
    document.querySelector('#etoro-tabelle').innerHTML = `<div class="alert danger">${esc(e.message)}</div>`;
  }
}

load();
setInterval(load, 20000);
