let current = 1, pages = 1;
const brokerFilter = document.getElementById('broker');
const assetFilter = document.getElementById('asset');
const statusFilter = document.getElementById('status');
const sourceFilter = document.getElementById('source');
const symbolFilter = document.getElementById('symbol');
const dayFilter = document.getElementById('day');
const countNode = document.getElementById('count');
const decisionRowsNode = document.getElementById('decisionRows');
const pageNode = document.getElementById('page');
const prevButton = document.getElementById('prev');
const nextButton = document.getElementById('next');
const sysSearchNode = document.getElementById('sysSearch');
const sysLevelNode = document.getElementById('sysLevel');
const systemRowsNode = document.getElementById('systemRows');

function qs() {
  return new URLSearchParams({
    page: current, per_page: 15, broker: brokerFilter.value,
    asset_type: assetFilter.value, status: statusFilter.value,
    source: sourceFilter.value, symbol: symbolFilter.value, day: dayFilter.value,
  });
}

function reason(x) {
  const checks = Object.entries(x.signal_checks || {})
    .filter(([, value]) => value && value.passed === false)
    .map(([name]) => name.replaceAll('_', ' '));
  const metrics = Object.entries(x.metrics || {})
    .map(([key, value]) => `${key}=${typeof value === 'number' ? Number(value).toPrecision(5) : value}`)
    .join(' · ');
  return `${esc(x.reason || x.signal_reason || x.blocked_by || '')}`
    + `${checks.length ? `<br><span class="small">Nicht erfüllt: ${esc(checks.join(', '))}</span>` : ''}`
    + `${metrics ? `<br><span class="small">${esc(metrics)}</span>` : ''}`;
}

function sources(x) {
  const rows = Array.isArray(x) ? x : [];
  return rows.slice(0, 5)
    .map(v => typeof v === 'string' ? v : (v.quelle || v.source || v.datenquelle || ''))
    .filter(Boolean).join(', ');
}

function strategy(x) {
  const mode = x.strategy_mode || '–', version = x.strategy_version || '';
  return `<strong>${esc(mode)}</strong>${version ? `<br><span class="small">${esc(version)}${x.strategy_parameter_hash ? ` · ${esc(String(x.strategy_parameter_hash).slice(0, 12))}` : ''}</span>` : ''}`;
}

// v9.3: Entscheidung und Ausführung sind zwei Zustände. Eine freigegebene,
// aber nicht ausgeführte Order stand bis 9.2 grün als "APPROVED" da — das
// sieht aus wie ein erfolgreicher Kauf. Beim WLD-Beispiel wurde die
// FOK-Order mit 0/270,94 storniert.
const AUSFUEHRUNGSTEXT = {
  FILLED: 'Gekauft',
  PARTIAL: 'Teilweise ausgeführt',
  CANCELED_NO_FILL: 'Kauf erlaubt – bei OKX nicht ausgeführt',
  SUBMITTED_NOT_FILLED: 'Kauf erlaubt – nicht ausgeführt',
  REJECTED: 'Vom Broker abgelehnt',
  EXPIRED: 'Beim Broker verfallen',
  UNKNOWN: '⚠️ Ausgang unklar',
};

// Grün ausschließlich für einen tatsächlich ausgeführten Kauf.
function entscheidungsmarke(x) {
  const s = String(x.status || '');
  const e = String(x.execution_status || '').toUpperCase();
  if (s === 'APPROVED') {
    if (e === 'FILLED') return badge('APPROVED', 'ok');
    if (!e || e === 'READY_TO_SUBMIT' || e === 'SUBMITTING') return badge('APPROVED', 'warn');
    return badge('APPROVED · nicht ausgeführt', 'warn');
  }
  if (s === 'NO_SIGNAL') return badge(s, '');
  if (s.includes('BLOCK') || s === 'SYSTEM_ERROR') return badge(s, 'bad');
  return badge(s, 'warn');
}

function ausfuehrungsmarke(status) {
  const s = String(status || '').toUpperCase();
  if (!s) return '';
  const klasse = s === 'FILLED' ? 'ok'
    : s === 'PARTIAL' ? 'warn'
    : s === 'UNKNOWN' ? 'bad' : '';
  return badge(AUSFUEHRUNGSTEXT[s] || s, klasse);
}

function execution(x) {
  const events = (x.execution_events || []).slice(0, 3).map(e => e.event_type).join(' → ');
  const orders = (x.orders || []).map(o => `${o.role}:${o.status} ${o.filled_qty ?? '–'}/${o.requested_qty ?? '–'}`).join(' · ');
  return `${ausfuehrungsmarke(x.execution_status)}${events ? `<br><span class="small">${esc(events)}</span>` : ''}${orders ? `<br><span class="small">${esc(orders)}</span>` : ''}<br><span class="small">${x.paper ? 'DEMO/PAPER' : 'LIVE'} · Update ${esc(x.updated_at_local || '–')}</span>`;
}

async function loadDecisions(page = 1) {
  current = page;
  try {
    const d = await api('/api/logs/decisions?' + qs());
    pages = d.pages || 1;
    countNode.textContent = `${d.total} Eintraege`;
    decisionRowsNode.innerHTML = d.rows.map(x => `<tr>
      <td>${esc(x.created_at_local || '')}</td>
      <td>${esc(x.broker)}</td>
      <td><strong>${esc(x.symbol)}</strong><br><span class="small">${esc(x.asset_type)}</span></td>
      <td>${strategy(x)}</td>
      <td>${entscheidungsmarke(x)}</td>
      <td>${reason(x)}</td>
      <td>${esc(x.hauptquelle || '')}</td>
      <td class="source-list">${esc(sources(x.sources))}</td>
      <td>${execution(x)}</td></tr>`).join('') || '<tr><td colspan="9">Keine Treffer</td></tr>';
    pageNode.textContent = `Seite ${current} von ${pages}`;
    prevButton.disabled = current <= 1;
    nextButton.disabled = current >= pages;
  } catch (e) {
    decisionRowsNode.innerHTML = `<tr><td colspan="9">${esc(e.message)}</td></tr>`;
  }
}

async function loadSystem() {
  try {
    const p = new URLSearchParams({search: sysSearchNode.value, level: sysLevelNode.value, limit: 300});
    const d = await api('/api/logs/system?' + p);
    systemRowsNode.textContent = d.rows.join('\n');
  } catch (e) {
    systemRowsNode.textContent = e.message;
  }
}

prevButton.onclick = () => loadDecisions(Math.max(1, current - 1));
nextButton.onclick = () => loadDecisions(Math.min(pages, current + 1));
loadDecisions();
loadSystem();
