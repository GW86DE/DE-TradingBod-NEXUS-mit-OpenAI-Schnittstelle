let tradeDaten = {};
let chartDaten = null;
let ausgewaehlt = null;
let manualDaten = {commands:[],locks:[]};

const zahl = (v, stellen = 2) => v === null || v === undefined || v === ''
  ? 'unbekannt'
  : Number(v).toLocaleString('de-DE', {minimumFractionDigits: stellen, maximumFractionDigits: stellen});
const zeit = v => {
  if (!v) return '–';
  const d = new Date(v);
  return Number.isNaN(d.getTime()) ? String(v) : d.toLocaleString('de-DE', {dateStyle: 'short', timeStyle: 'short', timeZone: 'Europe/Berlin'});
};
const modus = r => r.entry_strategy_mode || r.strategie_version || 'UNBEKANNT';

function metricKarte(titel, wert, zusatz = '', klasse = '') {
  return `<article class="card"><h3>${esc(titel)}</h3><div class="metric ${klasse}">${esc(wert)}</div><div class="small">${esc(zusatz)}</div></article>`;
}

function zeichneKennzahlen() {
  const k = tradeDaten.kennzahlen || {};
  const waehrungsText = obj => Object.entries(obj || {}).map(([w,v])=>`${zahl(v)} ${w}`).join(' · ');
  const getrennt = waehrungsText(k.summe_nach_waehrung);
  const ergebnis = k.summe_netto === null || k.summe_netto === undefined
    ? (getrennt || 'unbekannt') : `${zahl(k.summe_netto)} ${waehrungHinweis()}`;
  const ergebnisKlasse = Number(k.summe_netto || 0) > 0 ? 'pos' : Number(k.summe_netto || 0) < 0 ? 'neg' : '';
  const gebuehren = k.gebuehren == null
    ? (waehrungsText(k.gebuehren_nach_waehrung) || 'unbekannt')
    : `${zahl(k.gebuehren)} ${waehrungHinweis()}`;
  document.querySelector('#trade-kennzahlen').innerHTML = [
    metricKarte('Offene Trades', k.offen ?? 0, 'werden nicht als 0,00 bewertet'),
    metricKarte('Klärung nötig', k.klaerung ?? 0, 'nicht als offen bestätigt', (k.klaerung ?? 0) ? 'neg' : ''),
    metricKarte('Geschlossene Trades', k.geschlossen ?? 0, `${k.bewertbar ?? 0} mit bekanntem Ergebnis`),
    metricKarte('Trefferquote', k.trefferquote_pct == null ? 'unbekannt' : `${zahl(k.trefferquote_pct, 1)} %`, `${k.gewinne ?? 0} Gewinne · ${k.verluste ?? 0} Verluste`),
    metricKarte('Nettoergebnis', ergebnis, 'realisierte Ledger-Ergebnisse', ergebnisKlasse),
    metricKarte('Gebühren', gebuehren, 'je Quote-Währung · soweit bekannt'),
  ].join('');
}

function waehrungHinweis() {
  const b = document.querySelector('#trade-broker')?.value || '';
  return b === 'etoro' ? 'Kontowährung' : b === 'okx' ? 'Quote' : 'je Trade';
}

function pnlText(v, w = '') {
  if (v === null || v === undefined) return '<span class="small">unbekannt</span>';
  const klasse = Number(v) > 0 ? 'trade-pos' : Number(v) < 0 ? 'trade-neg' : '';
  return `<span class="${klasse}">${esc(zahl(v))} ${esc(w || '')}</span>`;
}

function pnlMitProzent(v, pct, w = '') {
  const basis = pnlText(v, w);
  const klasse = Number(pct) > 0 ? 'trade-pos' : Number(pct) < 0 ? 'trade-neg' : '';
  return `${basis}${pct === null || pct === undefined ? '' : `<br><span class="small ${klasse}">${esc(zahl(pct, 2))} %</span>`}`;
}

function statusDeutsch(v) {
  return ({PENDING_CONFIRMATION:'Abgleich läuft',RESIDUAL_EXPOSURE:'Restbestand ohne Positionsbuch',
    UNPROVABLE:'Brokerbeweis fehlt',ACCOUNT_MISMATCH:'Anderes OKX-Konto',
    EXTERNAL_OBSERVE:'Externer Bestand · nur beobachten',CONFIRMED_OPEN:'Bestätigte Botposition',STRATEGY_MIGRATION_REQUIRED:'Bestätigte Botposition · Strategie-Migration erforderlich',ACCOUNT_MISMATCH:'Anderes OKX-Konto · keine automatische Übernahme'})[String(v||'').toUpperCase()] || (v || 'unbekannt');
}

function hatVerifiziertenBotnachweis(v) {
  return ['VERIFIED','VERIFIED_BROKER_FILL_CHAIN'].includes(String(v||'').toUpperCase());
}

// v9.1: management_note, exit_state, exit_retry_after und protection_detail
// wurden berechnet, ins JSON geschrieben -- und nie angezeigt. Der in 9.0.15
// eingefuehrte Retry-Cooldown und die 24-Stunden-Sperre nach einem unklaren
// Ausstieg waren damit in der Oberflaeche unsichtbar, obwohl der Changelog das
// Gegenteil behauptet. Eine pausierte Position stand dort als "Offen · Schutz
// aktiv".
function exitZustandText(r) {
  const s = String(r.exit_state || 'IDLE').toUpperCase();
  if (s === 'IDLE' || s === '') return '';
  const bis = r.exit_retry_after ? ` · nächster Versuch ${zeit(r.exit_retry_after)}` : '';
  const texte = {
    SUBMITTING: 'Verkauf läuft',
    RETRY_WAIT: 'Verkauf fehlgeschlagen, Wartezeit',
    UNCLEAR: '⚠️ Verkaufszustand UNKLAR — kein zweiter Versuch',
    MANUAL: 'manuell verwaltet',
    MANUAL_EXIT_PENDING: 'manueller Verkauf angefordert',
  };
  return `<br><span class="small">${esc(texte[s] || s)}${esc(bis)}</span>`;
}

// v9.2: Eigentum, Abgleich und Verwaltung sind DREI Zustaende und werden
// jetzt getrennt gezeigt. Vorher gab es nur einen gemischten Status: eine
// lueckenlos bewiesene, aber pausierte Botposition stand dort als
// "Externer Bestand · ohne identische ID-Kette" -- fachlich falsch.
function zuordnung(r) {
  const eigentumTexte = {
    BEWIESEN: '<span class="ok">Eigentum bewiesen</span>',
    UNVOLLSTAENDIG: '<span class="warn">Eigentum unvollständig</span>',
    KEIN_BEWEIS: '<span class="bad">kein Brokerbeweis</span>',
  };
  const e = eigentumTexte[String(r.eigentum_status || '')] || '<span class="small">Eigentum unbekannt</span>';
  const a = statusDeutsch(r.abgleich_status || r.reconciliation_status);
  const modus = String(r.management_mode || '').toUpperCase();
  const modusTexte = {AUTO: 'automatisch', MANUELL: 'manuell', BEOBACHTEN: 'nur beobachtet'};
  const v = r.verwaltung_status
    ? `Verwaltung: ${esc(r.verwaltung_status)}`
    : (modusTexte[modus] ? `Verwaltung: ${modusTexte[modus]}` : '');
  const migriert = r.strategie_migriert_am
    ? `<br><span class="small">Strategie migriert${r.strategie_migriert_von ? ' von '+esc(r.strategie_migriert_von) : ''} · ${esc(zeit(r.strategie_migriert_am))}</span>`
    : '';
  return `${e}<br><span class="small">Abgleich: ${esc(a)}</span>${v ? `<br><span class="small">${v}</span>` : ''}${migriert}`;
}

function tradeGrund(r, offen, klaerung) {
  // In der Klaerungstabelle steht der Abgleichstatus schon in der Spalte
  // "Zuordnung". Hier steht deshalb, was die Zeile konkret braucht.
  if (klaerung) {
    const s = String(r.abgleich_status || r.reconciliation_status || '').toUpperCase();
    if (s === 'STRATEGY_MIGRATION_REQUIRED')
      return 'Strategieversion hat gewechselt. Eigentum und Broker-Schutz bleiben; '
           + 'nur die automatischen Ausstiege pausieren bis zur Migration.';
    if (s === 'ACCOUNT_MISMATCH')
      return 'Der Bestand gehört zu einem anderen OKX-Konto. Keine automatische Übernahme.';
    if (String(r.eigentum_status || '') === 'BEWIESEN')
      return 'Brokerbeweis vollständig — "Erneut mit OKX prüfen" gleicht sofort ab.';
    return 'Ohne vollständige Broker-ID-Kette. Nur beobachten, kein Auto-Verkauf.';
  }
  if (!offen) return r.exit_grund || 'unbekannt';
  const p = String(r.protection_status || '').toUpperCase();
  const modus = String(r.management_mode || '').toUpperCase();
  const manual = modus === 'MANUELL' ? ' · manuell verwaltet'
               : modus === 'BEOBACHTEN' ? ' · nur beobachtet (kein Auto-Ausstieg)' : '';
  const notiz = r.management_note ? `<br><span class="small">${esc(r.management_note)}</span>` : '';
  const zustand = exitZustandText(r);
  if (p === 'ACTIVE') return `Offen · OKX-Schutz aktiv${r.protection_algo_id ? ' · Algo '+r.protection_algo_id : ''}${manual}${notiz}${zustand}`;
  if (p === 'MISSING') return `Offen · ACHTUNG: Broker-Schutz fehlt${manual}${notiz}${zustand}`;
  if (p === 'LOST') return `Offen · ⚠️ Schutz während eines Verkaufs storniert — wird neu gesetzt${notiz}${zustand}`;
  if (p === 'UNKNOWN_AFTER_AMEND') return `Offen · ⚠️ TP/SL-Änderung unbestätigt — bitte im OKX-Konto prüfen${notiz}${zustand}`;
  return `Offen · Schutzabgleich läuft${manual}${notiz}${zustand}`;
}

function liveKurs(r) {
  if (r.current_price === null || r.current_price === undefined)
    return '<span class="small">nicht belastbar abrufbar</span>';
  return `${esc(zahl(r.current_price, 8))} ${esc(r.market_quote_ccy || r.waehrung || '')}<br><span class="small">${esc(r.current_source || 'OKX')}${r.current_at ? ' · '+esc(zeit(r.current_at)) : ''}</span>`;
}

function schutzZiele(r) {
  const stop = r.stop_price == null ? 'unbekannt' : `${zahl(r.stop_price, 8)}${r.stop_distance_pct == null ? '' : ` (${zahl(r.stop_distance_pct, 2)} %)`}`;
  const roi = r.active_roi_price == null ? '' : `<br><span class="small">Aktives ROI ${zahl(r.active_roi_pct, 1)} %: ${zahl(r.active_roi_price, 8)}</span>`;
  const brokerTp = r.broker_take_profit == null ? '' : `<br><span class="small">Broker-TP: ${zahl(r.broker_take_profit, 8)}</span>`;
  return `<span>SL: ${esc(stop)}</span>${roi}${brokerTp}`;
}

function tradeTabelle(rows, offen, klaerung = false) {
  if (!rows.length) return `<p class="small">Keine ${offen ? 'offenen' : 'geschlossenen'} Trades im gewählten Zeitraum.</p>`;
  const body = rows.map(r => {
    const id = Number(r.trade_id);
    const selected = id === ausgewaehlt ? ' selected' : '';
    return `<tr class="trade-row${selected}" tabindex="0" data-trade-id="${id}">
      <td><strong>${esc(r.symbol || '?')}</strong><br><span class="small">${esc(r.instrument || r.broker_position_id || String(r.broker || '').toUpperCase())}${r.settlement_currency ? ` · Abrechnung ${esc(r.settlement_currency)}` : ''}</span></td>
      <td>${esc(zahl(r.menge, 8))}</td><td>${esc(zahl(r.einstieg_preis, 8))}<br><span class="small">${esc(zeit(r.eingestiegen_am))}</span></td>
      ${offen ? `<td>${liveKurs(r)}</td>` : `<td>${esc(zahl(r.ausstieg_preis, 8))}<br><span class="small">${esc(zeit(r.ausgestiegen_am))}</span></td>`}
      <td>${offen ? pnlMitProzent(r.open_net_pnl, r.open_net_pct, r.market_quote_ccy || r.waehrung) : pnlMitProzent(r.netto_pnl, r.netto_pnl_pct, r.waehrung)}</td>
      ${offen ? `<td>${schutzZiele(r)}</td>` : ''}${offen ? `<td>${zuordnung(r)}</td>` : ''}<td>${esc(tradeGrund(r, offen, klaerung))}${klaerung && r.notiz ? `<br><span class="small">${esc(r.notiz)}</span>` : ''}</td>
      <td>${badge(modus(r), String(modus(r)).includes('FREQTRADE') ? 'warn' : '')}<br><span class="small">${esc(r.enter_tag || 'kein Einstiegstag')}</span></td>
      <td>${r.paper ? badge('DEMO', 'ok') : badge('LIVE', 'bad')}</td>
      ${offen && !klaerung ? (String(r.broker).toLowerCase()==='okx' && hatVerifiziertenBotnachweis(r.ownership_status) ? `<td><select class="manual-action" data-trade-id="${id}" data-symbol="${esc(r.symbol || '')}">
        <option value="SET_PROTECTION">TP/SL ändern · manuelle Verwaltung</option>
        <option value="SELL">Jetzt preisbegrenzt verkaufen</option>
      </select><button class="secondary manual-submit" data-trade-id="${id}" data-symbol="${esc(r.symbol || '')}">Ausführen</button></td>` : '<td>–</td>') : ''}
      ${klaerung ? `<td><select class="reconcile-action" data-trade-id="${id}" data-symbol="${esc(r.symbol || '')}">
        <option value="RECHECK">Erneut mit OKX prüfen</option>
        <option value="CONFIRM_ACCOUNT_ASSET">Als Konto-Asset bestätigen</option>
        <option value="DELETE_LOCAL">Eintrag löschen</option>
      </select><button class="secondary reconcile-submit" data-trade-id="${id}" data-symbol="${esc(r.symbol || '')}">Ausführen</button></td>` : ''}
    </tr>`;
  }).join('');
  const manualHead = offen && !klaerung ? '<th>Manuelle Aktion</th>' : '';
  return `<table class="trade-table"><thead><tr><th>Wert / Markt</th><th>Menge</th><th>Kauf</th><th>${offen ? 'Aktuell' : 'Verkauf'}</th><th>Netto</th>${offen ? '<th>SL / Ziele</th><th>Zuordnung</th>' : ''}<th>Grund</th><th>Modus / Signal</th><th>Konto</th>${manualHead}${klaerung ? '<th>Klärungsaktion</th>' : ''}</tr></thead><tbody>${body}</tbody></table>`;
}

function verbindeZeilen() {
  document.querySelectorAll('.trade-row').forEach(row => {
    const waehlen = () => ladeChart(Number(row.dataset.tradeId));
    row.addEventListener('click', waehlen);
    row.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); waehlen(); } });
  });
  document.querySelectorAll('.reconcile-action, .reconcile-submit').forEach(node => {
    node.addEventListener('click', e => e.stopPropagation());
  });
  document.querySelectorAll('.manual-action, .manual-submit').forEach(node => {
    node.addEventListener('click', e => e.stopPropagation());
  });
  document.querySelectorAll('.manual-submit').forEach(button => {
    button.addEventListener('click', async e => {
      e.stopPropagation();
      const id=Number(button.dataset.tradeId), symbol=button.dataset.symbol;
      const row=(tradeDaten.offene_trades||[]).find(x=>Number(x.trade_id)===id)||{};
      const action=document.querySelector(`.manual-action[data-trade-id="${id}"]`)?.value||'SET_PROTECTION';
      const payload={action};
      if(action==='SET_PROTECTION'){
        const stop=prompt(`${symbol}: neuer Stop-Loss als absoluter Kurs`, row.stop_price ?? '');
        if(stop===null) return;
        const take=prompt(`${symbol}: neuer Take-Profit als absoluter Kurs`, row.broker_take_profit ?? '');
        if(take===null) return;
        payload.stop=Number(String(stop).replace(',','.')); payload.take_profit=Number(String(take).replace(',','.'));
        if(!Number.isFinite(payload.stop)||!Number.isFinite(payload.take_profit)){alert('Ungültige Kursangabe.');return;}
        if(!confirm(`${symbol}: TP/SL wirklich ändern?\n\nDanach wird die Position vollständig MANUELL verwaltet. Freqtrade-ROI und Strategie-Exit werden für diese Position deaktiviert.`)) return;
        payload.confirmation=prompt(`Zur Bestätigung exakt eingeben:\nSET_PROTECTION ${symbol}`)||'';
      }else{
        const lock=(prompt('Wiedereinstieg sperren: 1H, 6H, DAY oder MANUAL','6H')||'').toUpperCase();
        if(!['1H','6H','DAY','MANUAL'].includes(lock)){alert('Ungültige Sperrdauer.');return;}
        if(!confirm(`${symbol}: gesamte bewiesene Botposition jetzt verkaufen?\n\nDer Kern storniert den Schutz, wartet auf die Guthabenfreigabe und sendet nur einen preisbegrenzten FOK-Verkauf. Bei Misserfolg wird der Schutz sofort erneuert.`)) return;
        payload.lock=lock; payload.confirmation=prompt(`Zur Bestätigung exakt eingeben:\nSELL ${symbol}`)||'';
      }
      button.disabled=true;
      try{
        const result=await api(`/api/manual-trades/${id}`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
        alert(result.detail); await ladeTrades();
      }catch(err){alert(err.message);}finally{button.disabled=false;}
    });
  });
  document.querySelectorAll('.reconcile-submit').forEach(button => {
    button.addEventListener('click', async e => {
      e.stopPropagation();
      const id = Number(button.dataset.tradeId), symbol = button.dataset.symbol;
      const select = document.querySelector(`.reconcile-action[data-trade-id="${id}"]`);
      const action = select?.value || 'RECHECK';
      const labels = {RECHECK:'erneut mit OKX prüfen', CONFIRM_ACCOUNT_ASSET:'als Konto-Asset bestätigen', DELETE_LOCAL:'lokal löschen'};
      if (!confirm(`${symbol}: Eintrag wirklich ${labels[action]}?\n\nEs wird niemals Guthaben bei OKX verkauft oder gelöscht.`)) return;
      button.disabled = true;
      try {
        const result = await api(`/api/trades/${id}/reconciliation`, {
          method:'POST', headers:{'Content-Type':'application/json'},
          body:JSON.stringify({action, symbol})
        });
        alert(result.detail);
        await ladeTrades();
      } catch (err) {
        alert(err.message);
      } finally { button.disabled = false; }
    });
  });
}

function zeichneTabellen() {
  document.querySelector('#open-trades').innerHTML = tradeTabelle(tradeDaten.offene_trades || [], true);
  document.querySelector('#reconcile-trades').innerHTML = tradeTabelle(tradeDaten.klaerungs_trades || [], true, true);
  document.querySelector('#closed-trades').innerHTML = tradeTabelle(tradeDaten.geschlossene_trades || [], false);
  verbindeZeilen();
}

function zeichneManualStatus(){
  const commands=(manualDaten.commands||[]).slice(0,8), locks=manualDaten.locks||[];
  if(!commands.length&&!locks.length){document.querySelector('#manual-trade-status').innerHTML='<p class="small">Keine manuellen Aufträge oder aktiven Sperren.</p>';return;}
  const c=commands.length?`<h3>Letzte Aufträge</h3><table class="trade-table"><thead><tr><th>Zeit</th><th>Wert</th><th>Aktion</th><th>Status</th><th>Details</th></tr></thead><tbody>${commands.map(x=>`<tr><td>${esc(zeit(x.created_at))}</td><td><strong>${esc(x.symbol||'?')}</strong></td><td>${esc(x.action||'')}</td><td>${badge(x.status||'UNBEKANNT',['SUCCEEDED','PARTIAL'].includes(x.status)?'ok':x.status==='FAILED'||x.status==='UNCLEAR'?'bad':'warn')}</td><td>${esc(x.detail||'wartet auf den Handelskern')}</td></tr>`).join('')}</tbody></table>`:'';
  const l=locks.length?`<h3>Aktive Wiedereinstiegssperren</h3><table class="trade-table"><thead><tr><th>Wert</th><th>Bis</th><th>Grund</th><th>Aktion</th></tr></thead><tbody>${locks.map(x=>`<tr><td><strong>${esc(x.symbol||'?')}</strong></td><td>${x.until?esc(zeit(x.until)):'bis zur manuellen Freigabe'}</td><td>${esc(x.reason||'')}</td><td><button class="secondary release-lock" data-lock-id="${esc(x.id||'')}">Sperre aufheben</button></td></tr>`).join('')}</tbody></table>`:'';
  document.querySelector('#manual-trade-status').innerHTML=c+l;
  document.querySelectorAll('.release-lock').forEach(button=>button.addEventListener('click',async()=>{
    if(!confirm('Wiedereinstiegssperre wirklich aufheben? Der nächste Scan darf den Coin wieder kaufen.')) return;
    button.disabled=true;
    try{const result=await api(`/api/manual-trades/locks/${button.dataset.lockId}/release`,{method:'POST'});alert(result.detail);await ladeManualStatus();}
    catch(err){alert(err.message);}finally{button.disabled=false;}
  }));
}

async function ladeManualStatus(){
  try{manualDaten=await api('/api/manual-trades');zeichneManualStatus();}
  catch(e){document.querySelector('#manual-trade-status').innerHTML=`<p class="small trade-neg">${esc(e.message)}</p>`;}
}

function svgText(x, y, text, anchor = 'start', klasse = '') {
  return `<text x="${x}" y="${y}" text-anchor="${anchor}" class="${klasse}">${esc(text)}</text>`;
}

function zeichneProfit() {
  const ziel = document.querySelector('#profit-chart');
  const legend = document.querySelector('#profit-legend');
  const roh = tradeDaten.kumulierte_ergebnisse_nach_waehrung || {};
  let serien = Object.entries(roh).map(([waehrung, rows]) => ({
    waehrung,
    rows: (Array.isArray(rows) ? rows : []).filter(row =>
      Number.isFinite(Number(row?.wert)) && row?.zeit)
  })).filter(serie => serie.rows.length);
  // Abwaertskompatibilitaet zu aelteren Endpunkten mit genau einer Kurve.
  if (!serien.length && Array.isArray(tradeDaten.kumulierte_ergebnisse)) {
    const rows = tradeDaten.kumulierte_ergebnisse.filter(row =>
      Number.isFinite(Number(row?.wert)) && row?.zeit);
    if (rows.length) serien = [{waehrung: rows[0].waehrung || waehrungHinweis(), rows}];
  }
  if (!serien.length) {
    ziel.innerHTML = '<div class="trade-empty">Noch keine bewertbaren geschlossenen Trades.</div>';
    if (legend) legend.innerHTML = '';
    return;
  }
  const palette = ['#39d98a','#4ca3ff','#ffbd59','#c084fc','#fb7185','#22d3ee'];
  const width = Math.max(420, ziel.clientWidth || 700), height = Math.max(220, Math.min(330, width * .42));
  const pad = {l: 58, r: 18, t: 18, b: 38};
  const alleRows = serien.flatMap(serie => serie.rows);
  const values = [0, ...alleRows.map(x => Number(x.wert))];
  let min = Math.min(...values), max = Math.max(...values);
  if (min === max) { min -= 1; max += 1; }
  const zeitwerte = alleRows.map(row => new Date(row.zeit).getTime()).filter(Number.isFinite);
  let von = Math.min(...zeitwerte), bis = Math.max(...zeitwerte);
  if (von === bis) { von -= 30 * 60 * 1000; bis += 30 * 60 * 1000; }
  const x = value => pad.l + (new Date(value).getTime() - von) * (width - pad.l - pad.r) / (bis - von);
  const y = v => pad.t + (max - v) * (height - pad.t - pad.b) / (max - min);
  let grid = '';
  for (let i = 0; i <= 4; i++) {
    const v = min + (max - min) * i / 4, yy = y(v);
    grid += `<line x1="${pad.l}" y1="${yy}" x2="${width-pad.r}" y2="${yy}" class="chart-grid"/>${svgText(pad.l-8, yy+4, zahl(v), 'end', 'chart-label')}`;
  }
  const kurven = serien.map((serie, index) => {
    const farbe = palette[index % palette.length];
    const punkte = serie.rows.map(row => `${x(row.zeit)},${y(Number(row.wert))}`).join(' ');
    const linie = serie.rows.length > 1
      ? `<polyline points="${punkte}" fill="none" stroke="${farbe}" stroke-width="3" stroke-linejoin="round" stroke-linecap="round"/>`
      : '';
    const punkteSvg = serie.rows.map(row => `<circle cx="${x(row.zeit)}" cy="${y(Number(row.wert))}" r="4" fill="${farbe}" stroke="#08111f" stroke-width="2"><title>${esc(serie.waehrung)} · ${esc(row.symbol)} · ${esc(zahl(row.pnl))} · ${esc(zeit(row.zeit))}</title></circle>`).join('');
    return linie + punkteSvg;
  }).join('');
  ziel.innerHTML = `<svg viewBox="0 0 ${width} ${height}" class="chart-svg" aria-label="Kumuliertes Nettoergebnis je Währung">${grid}<line x1="${pad.l}" y1="${y(0)}" x2="${width-pad.r}" y2="${y(0)}" class="zero-line"/>${kurven}${svgText(pad.l, height-11, zeit(new Date(von).toISOString()), 'start', 'chart-label')}${svgText(width-pad.r, height-11, zeit(new Date(bis).toISOString()), 'end', 'chart-label')}</svg>`;
  if (legend) legend.innerHTML = serien.map((serie,index) => `<span><i style="background:${palette[index%palette.length]}"></i>${esc(serie.waehrung)}</span>`).join('');
}

function candleZeitX(iso, candles, x) {
  const t = new Date(iso).getTime();
  let best = 0, dist = Infinity;
  candles.forEach((c, i) => { const d = Math.abs(new Date(c.zeit).getTime() - t); if (d < dist) { dist = d; best = i; } });
  return x(best);
}

function zeichneKerzen() {
  const ziel = document.querySelector('#trade-chart');
  if (!chartDaten?.ok || !(chartDaten.candles || []).length) {
    ziel.innerHTML = `<div class="trade-empty">${esc(chartDaten?.fehler || 'Keine Kerzendaten verfügbar.')}</div>`;
    document.querySelector('#trade-chart-legend').innerHTML = '';
    return;
  }
  const candles = chartDaten.candles;
  const width = Math.max(520, ziel.clientWidth || 850), height = Math.max(310, Math.min(510, width * .54));
  const pad = {l: 76, r: 22, t: 28, b: 52};
  const extra = [chartDaten.kauf?.preis, chartDaten.verkauf?.preis, chartDaten.stop, chartDaten.take_profit, chartDaten.active_roi_price, chartDaten.current_price].filter(v => v != null).map(Number);
  let min = Math.min(...candles.map(c => Number(c.low)), ...extra), max = Math.max(...candles.map(c => Number(c.high)), ...extra);
  const margin = Math.max((max-min) * .08, max * .001); min -= margin; max += margin;
  const plotW = width-pad.l-pad.r, plotH = height-pad.t-pad.b;
  const step = plotW / candles.length, bodyW = Math.max(2, Math.min(10, step*.62));
  const x = i => pad.l + step * (i + .5), y = v => pad.t + (max-Number(v))*plotH/(max-min);
  let grid = '';
  for (let i=0;i<=5;i++) { const v=min+(max-min)*i/5, yy=y(v); grid += `<line x1="${pad.l}" y1="${yy}" x2="${width-pad.r}" y2="${yy}" class="chart-grid"/>${svgText(pad.l-9,yy+4,zahl(v, Math.abs(v)<1?6:2),'end','chart-label')}`; }
  const bodies = candles.map((c,i) => {
    const up=Number(c.close)>=Number(c.open), top=y(Math.max(Number(c.open),Number(c.close))), bottom=y(Math.min(Number(c.open),Number(c.close)));
    return `<g class="candle ${up?'up':'down'}"><line x1="${x(i)}" y1="${y(c.high)}" x2="${x(i)}" y2="${y(c.low)}"/><rect x="${x(i)-bodyW/2}" y="${top}" width="${bodyW}" height="${Math.max(1,bottom-top)}"><title>${esc(zeit(c.zeit))}\nO ${esc(zahl(c.open,8))} · H ${esc(zahl(c.high,8))} · T ${esc(zahl(c.low,8))} · S ${esc(zahl(c.close,8))}</title></rect></g>`;
  }).join('');
  const lines = [[chartDaten.stop,'Stop-Loss','stop-line'],[chartDaten.take_profit,'Broker-TP 4%','target-line'],[chartDaten.active_roi_price,`Aktives ROI ${zahl(chartDaten.active_roi_pct,1)}%`,'roi-line'],[chartDaten.current_price,'Aktuell','current-line']].filter(x=>x[0]!=null).map(([v,label,k])=>`<line x1="${pad.l}" y1="${y(v)}" x2="${width-pad.r}" y2="${y(v)}" class="${k}"/>${svgText(width-pad.r-5,y(v)-6,`${label} ${zahl(v,8)}`,'end','line-label')}`).join('');
  const marker = (obj, label, klasse, richtung) => {
    if (!obj || obj.preis == null) return '';
    const xx=candleZeitX(obj.zeit,candles,x), yy=y(obj.preis), p=richtung==='up'?`${xx},${yy-4} ${xx-8},${yy+12} ${xx+8},${yy+12}`:`${xx},${yy+4} ${xx-8},${yy-12} ${xx+8},${yy-12}`;
    const ly=richtung==='up'?yy+29:yy-19;
    return `<polygon points="${p}" class="${klasse}"><title>${esc(label)} · ${esc(zeit(obj.zeit))} · ${esc(zahl(obj.preis,8))}</title></polygon>${svgText(xx,ly,`${label} ${zahl(obj.preis,8)}`,'middle',`${klasse}-text`)}`;
  };
  const kauf=marker(chartDaten.kauf,'KAUF','buy-marker','up'), verkauf=marker(chartDaten.verkauf,'VERKAUF','sell-marker','down');
  const ticks=[0,Math.floor((candles.length-1)/2),candles.length-1].map(i=>svgText(x(i),height-16,zeit(candles[i].zeit),'middle','chart-label')).join('');
  ziel.innerHTML=`<svg viewBox="0 0 ${width} ${height}" class="chart-svg" aria-label="Kerzen für ${esc(chartDaten.instrument)}">${grid}${bodies}${lines}${kauf}${verkauf}${ticks}</svg>`;
  document.querySelector('#trade-chart-title').textContent=`${chartDaten.instrument} · Kauf/Verkauf`;
  document.querySelector('#trade-chart-info').textContent=`${chartDaten.bar}-Kerzen · nur abgeschlossen · letzter Schluss ${zahl(chartDaten.letzter_schluss,8)} ${chartDaten.waehrung || ''}${chartDaten.current_price ? ` · aktuell ${zahl(chartDaten.current_price,8)} (${chartDaten.current_source})` : ''}`;
  document.querySelector('#trade-chart-mode').textContent=chartDaten.entry_strategy_mode || 'UNBEKANNT';
  document.querySelector('#trade-chart-mode').className='status '+(String(chartDaten.entry_strategy_mode||'').includes('FREQTRADE')?'warn':'ok');
  document.querySelector('#trade-chart-legend').innerHTML='<span><i class="legend-buy"></i>Kauf</span><span><i class="legend-sell"></i>Verkauf</span><span><i class="legend-up"></i>Steigende Kerze</span><span><i class="legend-down"></i>Fallende Kerze</span>'+(chartDaten.stop!=null?'<span><i class="legend-stop"></i>Stop-Loss</span>':'')+(chartDaten.take_profit!=null?'<span><i class="legend-target"></i>Broker-TP</span>':'')+(chartDaten.active_roi_price!=null?'<span><i class="legend-roi"></i>Aktives ROI-Ziel</span>':'')+(chartDaten.current_price!=null?'<span><i class="legend-current"></i>Aktueller Verkauf-VWAP</span>':'');
}

async function ladeChart(id) {
  ausgewaehlt=id; zeichneTabellen();
  const ziel=document.querySelector('#trade-chart'); ziel.innerHTML='<div class="trade-empty">Kerzen werden geladen …</div>';
  try { chartDaten=await api(`/api/trades/${id}/candles`); zeichneKerzen(); }
  catch(e) { chartDaten={ok:false,fehler:e.message}; zeichneKerzen(); }
}

async function ladeTrades() {
  const broker=document.querySelector('#trade-broker').value, tage=document.querySelector('#trade-tage').value;
  try {
    tradeDaten=await api(`/api/trades?broker=${encodeURIComponent(broker)}&tage=${encodeURIComponent(tage)}`);
    zeichneKennzahlen(); zeichneTabellen(); zeichneProfit();
    await ladeManualStatus();
    document.querySelector('#trade-note').textContent=tradeDaten.hinweis || '';
  } catch(e) { document.querySelector('#trade-note').className='alert danger section'; document.querySelector('#trade-note').textContent=e.message; }
}

document.querySelector('#trade-refresh').addEventListener('click',ladeTrades);
document.querySelector('#trade-broker').addEventListener('change',ladeTrades);
document.querySelector('#trade-tage').addEventListener('change',ladeTrades);
let resizeTimer;
window.addEventListener('resize',()=>{clearTimeout(resizeTimer);resizeTimer=setTimeout(()=>{zeichneProfit();zeichneKerzen();},150)});
ladeTrades();
