function fmtDuration(v){let s=Math.max(0,Math.round(Number(v||0)));const d=Math.floor(s/86400);s%=86400;const h=Math.floor(s/3600);s%=3600;const m=Math.floor(s/60);return d?`${d} T ${h} h ${m} min`:h?`${h} h ${m} min`:`${m} min`}
function pct(used,total){return total?`${(Number(used)/Number(total)*100).toFixed(1)} %`:'n/v'}
function onlineCard(name,x,subtitle){const on=x?.online;const age=x?.heartbeat_age_seconds;const contact=x?.last_broker_contact||'-';const interval=x?.health_interval_seconds||30;const key=name.startsWith('eToro')?'etoro':'okx';return `<article class="card"><h3>${esc(name)}</h3><div class="metric">${on?badge('ONLINE','ok'):badge('OFFLINE','bad')}</div><p>${esc(subtitle||x?.modus||'-')}</p><div class="small">Worker: ${x?.worker_alive?'aktiv':'offline'} · Broker: ${x?.broker_online?'authentifiziert':'nicht verbunden'}<br>Heartbeat: ${age==null?'nicht vorhanden':Math.round(age)+' s'}<br>Aktiver Auth-Test: alle ${interval} s<br>Letzter Brokerkontakt: ${esc(contact)}<br>${esc(x?.last_connection_error||x?.letzter_fehler||'')}</div><div class="toolbar mini"><button class="secondary" onclick="testBroker('${key}','demo')">Demo API einmalig testen</button><button class="secondary" onclick="testBroker('${key}','live')">LIVE API einmalig testen</button></div></article>`}
// Die Entscheidungen stehen als UTC in der Datenbank. Bis v8.1.3 wurden sie
// unveraendert angezeigt -- eine Zeile von 13:25 Ortszeit stand dort als
// "11:25" und sah aus wie eine Stunde alte Anzeige.
function ortszeit(utc){
  if(!utc) return '';
  const d = new Date(String(utc).endsWith('Z')||String(utc).includes('+') ? utc : utc+'Z');
  if(isNaN(d)) return String(utc).replace('T',' ').slice(0,19);
  return d.toLocaleString('de-DE',{day:'2-digit',month:'2-digit',
    hour:'2-digit',minute:'2-digit',second:'2-digit'});
}
// v8.1.4: Guthaben, Positionen und Handelsbereitschaft der Kryptoseite.
// Bis 8.1.3 stand ueber OKX auf dem Dashboard nur "online/offline".
function okxKarten(o){
  if(!o||!o.vorhanden) return `<article class="card"><h3>OKX Krypto</h3>
    <div class="metric">${badge('KEIN HEARTBEAT','warn')}</div>
    <p>Läuft die Kryptoseite?</p></article>`;
  const g = Object.entries(o.guthaben||{})
    .sort((a,b)=>(b[1].gesamt||0)-(a[1].gesamt||0)).slice(0,4)
    .map(([w,v])=>`${Number(v.gesamt).toLocaleString('de-DE',{maximumFractionDigits:6})} ${esc(w)}`)
    .join(' · ') || 'kein Guthaben';
  const pos = (o.positionen||[]).map(p=>
    `${esc(p.symbol)} ${Number(p.menge).toLocaleString('de-DE',{maximumFractionDigits:8})} @ ${Number(p.einstieg).toLocaleString('de-DE')}`
  ).join('<br>') || 'keine';
  const u = o.universum||{};
  const bereit = o.kaeufe_erlaubt
    ? badge('KÄUFE FREI','ok')
    : badge('KÄUFE GESPERRT','warn');
  const offen = (o.offene_bedingungen||[]).slice(0,3).join(' · ');
  const stand = o.werte_veraltet ? '<br><strong>Stand veraltet – keine Handelsfreigabe</strong>' : '';
  return `<article class="card"><h3>OKX Guthaben</h3>
      <div class="metric">${o.handelbares_kapital==null?'n/v':Number(o.handelbares_kapital).toLocaleString('de-DE',{maximumFractionDigits:2})}</div>
      <p>handelbares Kapital · Taker ${o.gebuehrensatz_pct??'?'} %</p>
      <div class="small">${g}${stand}</div></article>
    <article class="card"><h3>OKX Positionen</h3>
      <div class="metric">${(o.positionen||[]).length}</div>
      <p>${o.modus||'?'} · Universum ${u.aktiv??u.handelbar??0} aktiv</p>
      <div class="small">${pos}${stand}</div></article>
    <article class="card"><h3>Handelsbereitschaft</h3>
      <div class="metric">${bereit}</div>
      <p>${esc(o.bereitschaft_grund||'')}</p>
      <div class="small">${offen?('Offen: '+esc(offen)):'Alle Bedingungen erfüllt'}</div></article>`;
}


// v8.1.5: Die Aktienseite hatte auf dem Dashboard keine Positionskarte --
// stattdessen stand die Zahl der OKX-Positionen ZWEIMAL da. Diese Karte liest
// stock_positions.json, die der Aktienkern bei jedem Abgleich schreibt.
function etoroPositionen(s){
  const p = s?.positionen || [];
  if(!p.length) return `<article class="card"><h3>eToro Positionen</h3>
    <div class="metric">0</div><p>keine offene Position</p>
    <div class="small">${s?.updated_at?('Stand '+esc(ortszeit(s.updated_at))):'Der Aktienkern hat noch nichts gemeldet.'}</div></article>`;
  // Buchwert nur summieren, wenn er auch bekannt ist. Fehlende Kurse als 0 zu
  // behandeln waere eine Falschaussage -- 0 sieht aus wie ausgeglichen.
  const mitWert = p.filter(x=>x.unrealisiert!=null);
  const buch = mitWert.reduce((a,x)=>a+Number(x.unrealisiert||0),0);
  const beobachtet = p.filter(x=>String(x.verwaltung||'')!=='AUTO').length;
  const zeilen = p.slice(0,6).map(x=>{
    const u = x.unrealisiert==null ? '–'
      : Number(x.unrealisiert).toLocaleString('de-DE',{minimumFractionDigits:2,maximumFractionDigits:2,signDisplay:'always'});
    const marke = String(x.verwaltung||'')==='AUTO' ? '🤖'
      : String(x.verwaltung||'')==='PENDING_TAKEOVER' ? '⏳' : '👁';
    return `${marke} ${esc(x.symbol)} ${Number(x.menge).toLocaleString('de-DE',{maximumFractionDigits:4})} @ ${Number(x.einstand).toLocaleString('de-DE',{maximumFractionDigits:2})} · ${u}`;
  }).join('<br>');
  const rest = p.length>6 ? `<br>… und ${p.length-6} weitere` : '';
  const buchtext = mitWert.length
    ? `Buchwert ${buch.toLocaleString('de-DE',{minimumFractionDigits:2,maximumFractionDigits:2,signDisplay:'always'})}`
      + (mitWert.length<p.length ? ` (${p.length-mitWert.length} ohne Kurs)` : '')
    : 'Buchwert unbekannt – keine aktuellen Kurse';
  return `<article class="card"><h3>eToro Positionen</h3>
    <div class="metric">${p.length}</div>
    <p>${esc(buchtext)}${beobachtet?` · ${beobachtet} nur beobachtet`:''}</p>
    <div class="small">${zeilen}${rest}<br><a href="/positions">Positionen verwalten →</a></div></article>`;
}

function etoroBereitschaft(runtime){
  const s=runtime?.stock_trading_ready||{};
  if(!Object.keys(s).length) return `<article class="card"><h3>Aktien-Handelsbereitschaft</h3><div class="metric">${badge('ANLAUF','warn')}</div><p>Noch kein vollständiger Bereitschaftsstatus.</p></article>`;
  const frei=Boolean(s.kaeufe_erlaubt);
  const offen=(s.offen||[]).slice(0,4).join(' · ');
  return `<article class="card"><h3>Aktien-Handelsbereitschaft</h3>
    <div class="metric">${frei?badge('KÄUFE FREI','ok'):badge('KÄUFE GESPERRT','warn')}</div>
    <p>${esc(s.grund||'')}</p><div class="small">${offen?('Offen: '+esc(offen)):'Alle Bedingungen erfüllt'}${s.freigabe_um?`<br>Früheste Freigabe: ${esc(s.freigabe_um)}`:''}</div></article>`;
}

function etoroReconciliation(s){
  const active=s?.active||[];
  if(!active.length) return `<article class="card"><h3>eToro Ausführungsabgleich</h3><div class="metric">${badge('KLAR','ok')}</div><p>Keine ungeklärte Einstiegsausführung.</p></article>`;
  const rows=active.slice(0,4).map(x=>`${esc(x.symbol||'?')} · ${esc(x.state||'?')} · Order ${esc((x.order_ids||[]).join(', ')||'–')} · Ref ${esc(x.reference_id||'–')}`).join('<br>');
  return `<article class="card"><h3>eToro Ausführungsabgleich</h3><div class="metric">${badge('KRITISCH','warn')}</div><p>${active.length} ungeklärt; neue Käufe dieser Demo/Live-/Profil-Domäne gesperrt.</p><div class="small">${rows}</div></article>`;
}

function gruppe(titel){return `<h2 class="dashboard-gruppe">${esc(titel)}</h2>`}

function decisionRows(rows){if(!rows?.length)return '<p>Noch keine ernsthaften Kaufkandidaten protokolliert.</p>';return `<table><thead><tr><th>Zeit</th><th>Wert</th><th>Broker</th><th>Status</th><th>Begründung</th></tr></thead><tbody>${rows.map(r=>`<tr><td>${esc(ortszeit(r.created_at_utc))}</td><td>${esc(r.symbol||'?')}</td><td>${esc(r.broker||'?')}</td><td>${badge(r.status||'?',(r.status==='APPROVED'&&String(r.execution_status||'').toUpperCase()==='FILLED')?'ok':'warn')}</td><td>${esc(r.reason||r.blocked_by||'-')}</td></tr>`).join('')}</tbody></table>`}
async function load(){try{const d=await api('/api/dashboard');const s=await api('/api/settings');const b=d.bot||{},dec=d.decisions||{},market=d.stock_market||{},pi=d.pi||{},tg=d.telegram||{},profile=s.risk_profile||{};const ramUsed=pi.memory_used_mb||0,ramTotal=pi.memory_total_mb||0,diskUsed=pi.disk_used_mb||0,diskTotal=pi.disk_total_mb||0;document.querySelector('#cards').innerHTML=[
  // v8.1.5: Kacheln nach Zustaendigkeit gruppiert. Die Gruppenzeile spannt
  // ueber die ganze Grid-Breite (.dashboard-gruppe), damit das auto-fit-Raster
  // unveraendert weiterlaeuft -- die Anordnung bleibt so, wie sie Georg gefaellt.
  gruppe('Zustand'),
  `<article class="card"><h3>Botzustand</h3><div class="metric">${badge((b.zustand||'?').toUpperCase(),b.zustand==='aktiv'?'ok':'warn')}</div><p>${esc(b.grund||'')}</p></article>`,
  `<article class="card"><h3>Risikoprofil</h3><div class="metric">${badge((profile.active||'?').toUpperCase(),profile.active==='offensiv'?'warn':'ok')}</div><p>Änderbar unter Einstellungen; OFFENSIV braucht eine zweite Bestätigung.</p></article>`,
  `<article class="card"><h3>Telegram</h3><div class="metric">${tg.configured?badge('EINGERICHTET','ok'):badge('OFFEN','warn')}</div><p>Senden: ${esc(tg.delivery_stalled?'GESTAUT':'bereit')} · Steuerung: ${esc(tg.control?.status||'nicht gestartet')}</p><div class="small">Queue: ${tg.queued||0} · Fehlerfolge: ${tg.consecutive_failures||0}<br>Tagesbericht: 18:00 Europe/Berlin, inkl. Entscheidungen/Ablehnungen als Datei.</div></article>`,

  gruppe('Aktien · eToro'),
  onlineCard('eToro Aktien',d.etoro,`${d.etoro?.modus||s.etoro?.mode||'PAPER'} · Markt ${market.open?'OFFEN':market.phase||'ZU'}`),
  etoroBereitschaft(d.etoro),
  `<article class="card"><h3>Aktienmarkt</h3><div class="metric">${market.open?badge('OFFEN','ok'):badge(market.phase||'ZU','warn')}</div><p>${esc(market.reason||'Reguläre US-Sitzung')}</p><div class="small">Heute: ${esc(market.open_time||'-')} bis ${esc(market.close_time||'-')}<br>Regel: ${esc(market.regular_hours_ny)}<br>Nächste Öffnung: ${esc(market.next_open||'-')}</div></article>`,
  etoroPositionen(d.stock_positions),
  etoroReconciliation(d.etoro_reconciliation),
  `<article class="card"><h3>Entscheidungen heute</h3><div class="metric">${dec.candidates||0}</div><p>${dec.approved||0} freigegeben · ${dec.blocked||0} abgelehnt</p></article>`,

  gruppe('Krypto · OKX'),
  onlineCard('OKX Krypto 24/7',d.okx,d.okx?.modus||s.okx?.mode||'DEMO'),
  okxKarten(d.okx_detail),

  gruppe('System'),
  `<article class="card"><h3>Pi-Zustand</h3><div class="metric">${pi.cpu_temperature_c==null?'n/v':Number(pi.cpu_temperature_c).toFixed(1)+' °C'}</div><p>Online seit ${fmtDuration(pi.system_uptime_seconds)}</p><div class="small">CPU ${pi.cpu_usage_pct==null?'erste Messung läuft':pi.cpu_usage_pct+' %'} · RAM ${pct(ramUsed,ramTotal)}<br>Speicher ${pct(diskUsed,diskTotal)} · frei ${(Number(pi.disk_free_mb||0)/1024).toFixed(1)} GB<br>${esc((pi.warnings||[]).join(' · ')||'Keine Systemwarnung')}</div></article>`,
].join('');;const store=d.decision_storage||{};document.querySelector('#decision-storage').textContent=`${store.rows||0} Datensätze in ${store.file||'decision_history.sqlite'}; Spiegel: ${store.mirror||'decision_journal.jsonl'}. ${store.scope||''}`;document.querySelector('#recent-decisions').innerHTML=decisionRows(d.recent_decisions);const sel=document.querySelector('#migration-source');const sources=d.migration?.gefundene_vorgaengerversionen||[];sel.innerHTML=sources.length?sources.map(x=>`<option value="${esc(x)}">${esc(x)}</option>`).join(''):'<option value="">Keine Vorgängerversion erkannt</option>';document.querySelector('#providers').innerHTML=Object.entries(d.news||{}).map(([n,x])=>`<article class="card"><h3>${esc(n)}</h3><div class="metric">${badge(x.state||'unknown',x.state==='ok'?'ok':x.state==='disabled'?'':'warn')}</div><p>${esc(x.detail||'Noch nicht aktiv gemessen')}</p><button class="secondary" onclick='testProvider(${JSON.stringify(n)})'>Jetzt testen</button></article>`).join('')}catch(e){document.querySelector('#cards').innerHTML=`<div class="alert danger">${esc(e.message)}</div>`}}
async function testBroker(broker,mode){try{const x=await api('/api/brokers/test',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({broker,mode})});alert(`${broker.toUpperCase()} ${mode.toUpperCase()}: ${x.ok?'OK':'FEHLER'}\n${x.detail||''}\nLatenz: ${x.latency_ms||0} ms`);load()}catch(e){alert(e.message)}}
async function testProvider(name){try{const x=await api('/api/providers/test',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({source:name})});alert(`${name}: ${x.ok?'OK':'FEHLER'}\n${x.detail||''}`);load()}catch(e){alert(e.message)}}
async function migrateOld(){const source=document.querySelector('#migration-source').value;if(!source)return;const phrase=prompt("Trading-Core stoppen. Zur Bestätigung UEBERNEHMEN eingeben:");if(phrase!=='UEBERNEHMEN')return;try{const x=await api('/api/migration',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({source,confirm:phrase})});document.querySelector('#migration-result').innerHTML=`<p class="alert success">${esc(x.detail)} Kopiert: ${esc((x.copied||[]).join(', ')||'nichts Neues')}.</p>`;load()}catch(e){document.querySelector('#migration-result').innerHTML=`<p class="alert danger">${esc(e.message)}</p>`}}
async function control(action){const phrase=action==='pause'?'PAUSIEREN':'AKTIVIEREN';if(prompt(`Zur Bestätigung ${phrase} eingeben:`)!==phrase)return;try{await api(`/api/control/${action}`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({confirm:phrase,reason:'WebUI'})});load()}catch(e){alert(e.message)}}
load();setInterval(load,15000);
