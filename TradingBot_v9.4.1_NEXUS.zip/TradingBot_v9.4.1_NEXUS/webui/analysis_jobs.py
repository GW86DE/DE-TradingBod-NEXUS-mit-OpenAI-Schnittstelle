"""Lokale, authentifizierte Analyse-Auftraege fuer die WebUI.

Die WebUI startet ausschliesslich fest hinterlegte Analyseprogramme.  Sie
veraendert weder Handelsparameter noch Brokerzustand und uebergibt keine frei
formulierbaren Shell-Befehle.  Ergebnisse werden lokal protokolliert, damit
Browser-Neuladen und ein Neustart der WebUI sie nicht verlieren.
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
JOB_DIR = ROOT / "runtime" / "webui_analysis"
MAX_OUTPUT_BYTES = 250_000

TASKS = {
    "backtest": {"label": "Backtest", "group": "Strategie", "script": "run_backtest.py",
                 "description": "Historischer Out-of-Sample-Test nach Kosten."},
    "walkforward": {"label": "Walk-Forward", "group": "Strategie", "script": "run_walkforward.py",
                    "description": "Zeitliche Stabilitaet in mehreren Testfenstern."},
    "profiles": {"label": "Profile vergleichen", "group": "Strategie", "script": "profile_vergleich.py",
                 "description": "Rendite und Drawdown der drei Risikoprofile."},
    "sweep": {"label": "Parameter / Symbol Sweep", "group": "Strategie", "script": "sweep.py",
              "description": "Robustheit ueber Symbole und Parameterkombinationen."},
    "ml": {"label": "ML-Modell trainieren", "group": "ML", "script": "train_model.py",
           "description": "Gemeinsames Modell mit chronologischem Split trainieren."},
    "news_check": {"label": "News-/Krisencheck", "group": "News & Research",
                   "script": "webui_news_check.py",
                   "description": "Aktuelle Marktlage mit dem bestehenden Nachrichtenfilter pruefen."},
    "underdogs": {"label": "Underdog Screening", "group": "News & Research",
                  "script": "underdog_screening.py",
                  "description": "Kandidaten mit den bestehenden NEXUS-Kriterien pruefen."},
    "news_sources": {"label": "Newsquellen pruefen", "group": "News & Research",
                     "script": "news_sources_status.py",
                     "description": "Verfuegbarkeit der konfigurierten Research-Quellen."},
}


def _utc() -> str:
    return datetime.now(timezone.utc).isoformat()


def _state_path(job_id: str) -> Path:
    return JOB_DIR / f"{job_id}.json"


def _log_path(job_id: str) -> Path:
    return JOB_DIR / f"{job_id}.log"


def _write(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(tmp, path)


def _read(path: Path) -> dict:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _running(state: dict) -> bool:
    if state.get("status") != "RUNNING":
        return False
    try:
        os.kill(int(state.get("pid") or 0), 0)
        return True
    except (OSError, TypeError, ValueError):
        return False


def _normalise(state: dict) -> dict:
    if state.get("status") == "RUNNING" and not _running(state):
        state = {**state, "status": "INTERRUPTED", "finished_at": _utc(),
                 "detail": "Analyseprozess wurde beendet, bevor ein Ergebnis gespeichert wurde."}
        if state.get("job_id"):
            _write(_state_path(str(state["job_id"])), state)
    return state


def _recent(limit: int = 20) -> list[dict]:
    JOB_DIR.mkdir(parents=True, exist_ok=True)
    states = [_normalise(_read(path)) for path in JOB_DIR.glob("*.json")]
    states = [s for s in states if s.get("job_id") and s.get("task") in TASKS]
    return sorted(states, key=lambda s: str(s.get("started_at") or ""), reverse=True)[:limit]


def overview() -> dict:
    recent = _recent()
    latest = {}
    for state in recent:
        latest.setdefault(state["task"], state)
    tasks = []
    for task_id, spec in TASKS.items():
        state = latest.get(task_id, {})
        tasks.append({"id": task_id, **spec,
                      "status": state.get("status", "NEVER"),
                      "started_at": state.get("started_at"),
                      "finished_at": state.get("finished_at"),
                      "job_id": state.get("job_id")})
    return {"tasks": tasks, "recent": recent,
            "running": any(item.get("status") == "RUNNING" for item in recent)}


def start(task: str, actor: str = "webui") -> dict:
    task = str(task or "").strip().lower()
    if task not in TASKS:
        raise ValueError("Unbekannte Analyse")
    if any(item.get("status") == "RUNNING" for item in _recent()):
        raise ValueError("Es laeuft bereits eine Analyse. Bitte warte bis sie beendet ist.")
    job_id = f"{int(time.time())}-{uuid.uuid4().hex[:8]}"
    state = {"job_id": job_id, "task": task, "label": TASKS[task]["label"],
             "status": "STARTING", "started_at": _utc(), "finished_at": None,
             "actor": str(actor)[:80], "pid": None, "returncode": None}
    _write(_state_path(job_id), state)
    command = [sys.executable, "-m", "webui.analysis_jobs", "--worker", task, job_id]
    process = subprocess.Popen(command, cwd=str(ROOT), stdin=subprocess.DEVNULL,
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                               start_new_session=True, close_fds=True)
    current = _read(_state_path(job_id))
    if current.get("status") == "STARTING":
        state.update(status="RUNNING", pid=process.pid)
        _write(_state_path(job_id), state)
        return state
    return current


def output(job_id: str) -> dict:
    job_id = str(job_id or "")
    if not job_id or any(c not in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_" for c in job_id):
        raise ValueError("Ungueltige Auftrags-ID")
    state = _normalise(_read(_state_path(job_id)))
    if not state:
        raise FileNotFoundError(job_id)
    try:
        raw = _log_path(job_id).read_bytes()
        if len(raw) > MAX_OUTPUT_BYTES:
            raw = b"[... aeltere Ausgabe gekuerzt ...]\n" + raw[-MAX_OUTPUT_BYTES:]
        text = raw.decode("utf-8", errors="replace")
    except FileNotFoundError:
        text = "Analyse wird gestartet ..."
    return {"state": state, "output": text}


def _worker(task: str, job_id: str) -> int:
    state = _read(_state_path(job_id))
    state.update(status="RUNNING", pid=os.getpid())
    _write(_state_path(job_id), state)
    script = ROOT / TASKS[task]["script"]
    log = _log_path(job_id)
    rc = 1
    try:
        with log.open("w", encoding="utf-8", errors="replace") as stream:
            stream.write(f"NEXUS Analyse: {TASKS[task]['label']}\nStart: {_utc()}\n\n")
            stream.flush()
            completed = subprocess.run([sys.executable, "-u", str(script)], cwd=str(ROOT),
                                       stdin=subprocess.DEVNULL, stdout=stream,
                                       stderr=subprocess.STDOUT, check=False)
            rc = int(completed.returncode)
    except Exception as exc:
        log.parent.mkdir(parents=True, exist_ok=True)
        with log.open("a", encoding="utf-8", errors="replace") as stream:
            stream.write(f"\nAnalyse konnte nicht ausgefuehrt werden: {type(exc).__name__}: {exc}\n")
    state.update(status="SUCCEEDED" if rc == 0 else "FAILED", returncode=rc,
                 finished_at=_utc())
    _write(_state_path(job_id), state)
    return rc


if __name__ == "__main__":
    if len(sys.argv) == 4 and sys.argv[1] == "--worker" and sys.argv[2] in TASKS:
        raise SystemExit(_worker(sys.argv[2], sys.argv[3]))
    raise SystemExit("Nur als NEXUS-Analyseworker aufrufen.")
