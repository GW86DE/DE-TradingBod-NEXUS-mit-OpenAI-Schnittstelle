"""FastAPI-WebUI. Keine Route kann Orders erzeugen oder LIVE armieren."""
from __future__ import annotations

import hmac
import threading
import time
from pathlib import Path

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from starlette.concurrency import run_in_threadpool

from . import auth
from .settings_store import (
    save as save_settings, set_broker_mode, set_crypto_strategy_mode, set_risk_profile,
    set_telegram_runtime,
    snapshot as settings_snapshot,
)
from .state import (
    core_online, dashboard, decision_log, system_log, trade_analysis, universe,
)

ROOT = Path(__file__).resolve().parents[1]
HERE = Path(__file__).resolve().parent

import sys
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
import config       # noqa: E402  -- fuer die Versionsnummer

app = FastAPI(title=f"TradingBot {getattr(config, 'VERSION_NEXUS', '')}",
              docs_url=None, redoc_url=None, openapi_url=None)
app.mount("/static", StaticFiles(directory=str(HERE / "static")), name="static")

_LOGIN_LOCK = threading.Lock()
_LOGIN_FAILURES: dict[str, list[float]] = {}
_LOGIN_WINDOW_SECONDS = 10 * 60
_LOGIN_MAX_FAILURES = 5


@app.middleware("http")
async def security_headers(request: Request, call_next):
    response = await call_next(request)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "no-referrer"
    response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
    response.headers["Content-Security-Policy"] = (
        "default-src 'self'; img-src 'self' data:; connect-src 'self'; "
        "script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; "
        "frame-ancestors 'none'; base-uri 'none'; form-action 'self'"
    )
    return response


def _login_key(request: Request) -> str:
    return str(request.client.host if request.client else "unknown")[:96]


def _login_blocked(key: str) -> bool:
    now = time.monotonic()
    with _LOGIN_LOCK:
        recent = [x for x in _LOGIN_FAILURES.get(key, []) if now - x < _LOGIN_WINDOW_SECONDS]
        _LOGIN_FAILURES[key] = recent
        return len(recent) >= _LOGIN_MAX_FAILURES


def _login_failed(key: str) -> None:
    with _LOGIN_LOCK:
        _LOGIN_FAILURES.setdefault(key, []).append(time.monotonic())


def _login_succeeded(key: str) -> None:
    with _LOGIN_LOCK:
        _LOGIN_FAILURES.pop(key, None)


def _session(request: Request, *, required: bool = True) -> dict | None:
    session = auth.decode_session(request.cookies.get(auth.COOKIE, ""))
    if required and not session:
        raise HTTPException(status_code=401, detail="Anmeldung erforderlich")
    return session


def _csrf(request: Request, session: dict) -> None:
    supplied = request.headers.get("x-csrf-token", "")
    expected = str(session.get("csrf") or "")
    if not supplied or not hmac.compare_digest(supplied, expected):
        raise HTTPException(status_code=403, detail="CSRF-Pruefung fehlgeschlagen")


def _version() -> str:
    """Die Version kommt ausschliesslich aus der config.

    Bis v8.1.3 stand "8.1.2 NEXUS" an neun Stellen fest im Code -- nach jedem
    Update zeigte die Oberflaeche deshalb die alte Nummer.
    """
    roh = str(getattr(config, "VERSION_NEXUS", "") or "").strip()
    return roh.replace("-NEXUS", "").replace("NEXUS", "").strip() or "?"


def _page(name: str, session: dict) -> HTMLResponse:
    text = (HERE / "templates" / name).read_text(encoding="utf-8")
    text = text.replace("{{CSRF}}", str(session.get("csrf") or ""))
    text = text.replace("{{USER}}", str(session.get("u") or ""))
    text = text.replace("{{VERSION}}", _version())
    return HTMLResponse(text, headers={"Cache-Control": "no-store"})


@app.get("/login", response_class=HTMLResponse)
async def login_page(request: Request):
    if _session(request, required=False):
        return RedirectResponse("/", status_code=303)
    text = (HERE / "templates" / "login.html").read_text(encoding="utf-8")
    setup = "" if auth.configured() else (
        '<p class="alert danger">Noch kein WebUI-Benutzer eingerichtet. Lokal ausfuehren: '
        '<code>python3 webui_setup.py</code></p>'
    )
    text = text.replace("{{SETUP}}", setup).replace("{{VERSION}}", _version())
    return HTMLResponse(text, headers={"Cache-Control": "no-store"})


@app.post("/login")
async def login(request: Request):
    if not auth.configured():
        return HTMLResponse("WebUI nicht eingerichtet", status_code=503)
    form = await request.form()
    username, password = str(form.get("username") or ""), str(form.get("password") or "")
    key = _login_key(request)
    if _login_blocked(key):
        return HTMLResponse("Zu viele Fehlversuche. Bitte spaeter erneut versuchen.", status_code=429)
    if not auth.authenticate(username, password):
        _login_failed(key)
        return HTMLResponse("Anmeldung fehlgeschlagen", status_code=401)
    _login_succeeded(key)
    token, _ = auth.issue_session(username)
    response = RedirectResponse("/", status_code=303)
    response.set_cookie(auth.COOKIE, token, httponly=True, samesite="strict",
                        secure=auth.secure_cookie(), max_age=8 * 3600, path="/")
    return response


@app.get("/", response_class=HTMLResponse)
async def dashboard_page(request: Request):
    session = _session(request, required=False)
    return _page("dashboard.html", session) if session else RedirectResponse("/login", status_code=303)


@app.get("/settings", response_class=HTMLResponse)
async def settings_page(request: Request):
    session = _session(request, required=False)
    return _page("settings.html", session) if session else RedirectResponse("/login", status_code=303)


@app.get("/universe", response_class=HTMLResponse)
async def universe_page(request: Request):
    session = _session(request, required=False)
    return _page("universe.html", session) if session else RedirectResponse("/login", status_code=303)


@app.get("/api/universe")
async def api_universe(request: Request):
    _session(request)
    return await run_in_threadpool(universe)


# ---------------------------------------------------------------------------
# Trade-Analyse (rein lesend, neu in v9.0.1)
# ---------------------------------------------------------------------------
@app.get("/trades", response_class=HTMLResponse)
async def trades_page(request: Request):
    session = _session(request, required=False)
    return _page("trades.html", session) if session else RedirectResponse("/login", status_code=303)


@app.get("/api/trades")
async def api_trades(request: Request, broker: str = "", tage: int = 90):
    _session(request)
    return await run_in_threadpool(trade_analysis, broker=broker, tage=tage)


# ---------------------------------------------------------------------------
# Analyse & Training (dieselben Programme wie in der Desktop-GUI)
# ---------------------------------------------------------------------------
@app.get("/analysis", response_class=HTMLResponse)
async def analysis_page(request: Request):
    session = _session(request, required=False)
    return _page("analysis.html", session) if session else RedirectResponse("/login", status_code=303)


@app.get("/api/analysis")
async def api_analysis(request: Request):
    _session(request)
    from webui import analysis_jobs
    return await run_in_threadpool(analysis_jobs.overview)


@app.post("/api/analysis/{task}")
async def api_analysis_start(task: str, request: Request):
    session = _session(request); _csrf(request, session)
    from webui import analysis_jobs
    try:
        job = await run_in_threadpool(
            analysis_jobs.start, task, f"webui:{session.get('u')}")
    except ValueError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from None
    return {"ok": True, "job": job,
            "detail": "Analyse lokal gestartet. Handelslogik und Broker bleiben unangetastet."}


@app.get("/api/analysis/jobs/{job_id}")
async def api_analysis_output(job_id: str, request: Request):
    _session(request)
    from webui import analysis_jobs
    try:
        return await run_in_threadpool(analysis_jobs.output, job_id)
    except (ValueError, FileNotFoundError) as exc:
        raise HTTPException(status_code=404, detail="Analyseauftrag nicht gefunden") from exc


@app.post("/api/trades/{trade_id}/reconciliation")
async def api_trade_reconciliation(trade_id: int, request: Request):
    session = _session(request); _csrf(request, session)
    payload = await request.json()
    import okx_reconciliation_actions as actions
    try:
        action = await run_in_threadpool(
            actions.anfordern, trade_id, str(payload.get("action") or ""),
            symbol=str(payload.get("symbol") or ""),
            actor=f"webui:{session.get('u')}")
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from None
    return {"ok": True, "action": action,
            "detail": ("Klärungsaktion sicher vorgemerkt. Der OKX-Kern prüft sie "
                       "im nächsten Zyklus; Brokerbestand und Orders bleiben unangetastet.")}


@app.get("/api/manual-trades")
async def api_manual_trades(request: Request):
    _session(request)
    import manual_trade_control
    return await run_in_threadpool(manual_trade_control.overview)


@app.post("/api/manual-trades/{trade_id}")
async def api_manual_trade_request(trade_id: int, request: Request):
    session = _session(request); _csrf(request, session)
    payload = await request.json()
    import manual_trade_control
    try:
        command = await run_in_threadpool(
            manual_trade_control.request, trade_id,
            str(payload.get("action") or ""),
            stop=payload.get("stop") or 0.0,
            take_profit=payload.get("take_profit") or 0.0,
            lock=str(payload.get("lock") or "6H"),
            actor=f"webui:{session.get('u')}",
            confirmation=str(payload.get("confirmation") or ""))
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from None
    return {"ok": True, "command": command,
            "detail": ("Manueller Einmalauftrag vorgemerkt. Der OKX-Kern prueft "
                       "ihn im naechsten Positionszyklus und zeigt danach den "
                       "bestaetigten Brokerzustand.")}


@app.post("/api/manual-trades/locks/{lock_id}/release")
async def api_manual_trade_lock_release(lock_id: str, request: Request):
    session = _session(request); _csrf(request, session)
    import manual_trade_control
    changed = await run_in_threadpool(
        manual_trade_control.release_lock, lock_id, f"webui:{session.get('u')}")
    if not changed:
        raise HTTPException(status_code=404, detail="Aktive Sperre nicht gefunden.")
    return {"ok": True, "detail": "Wiedereinstiegssperre aufgehoben."}


@app.get("/api/trades/{trade_id}/candles")
async def api_trade_candles(trade_id: int, request: Request):
    _session(request)
    from trade_chart_data import chart_for_trade
    return await run_in_threadpool(chart_for_trade, trade_id)


# ---------------------------------------------------------------------------
# Positionen (neu in v8.1.5)
# ---------------------------------------------------------------------------
# Georg wollte eine selbst gekaufte Aktie an den Bot uebergeben und hatte
# dafuer in der WebUI keine Stelle. Diese Seite ist die Stelle.
#
# Die Oberflaeche fasst dabei NIE selbst den Broker oder das Positionsbuch an.
# Sie zeigt die Momentaufnahme des Kerns (stock_positions.json) und legt
# Auftraege ab, die der Kern in seiner eigenen Schleife ausfuehrt.
@app.get("/positions", response_class=HTMLResponse)
async def positions_page(request: Request):
    session = _session(request, required=False)
    return _page("positions.html", session) if session else RedirectResponse("/login", status_code=303)


@app.get("/api/positions")
async def api_positions(request: Request):
    _session(request)
    import positions_auftraege
    from webui import state as _state
    daten = _state._json("stock_positions.json",
                         {"positionen": [], "kurse_verfuegbar": False})
    krypto = _state._json("crypto_positions.json", {"positionen": []})
    # Nur vollstaendig bewiesene, automatisch verwaltete Positionen. Alte
    # BEOBACHTEN-/synthetische Fill-Zeilen gehoeren in "Klaerung noetig".
    krypto = {**krypto, "positionen": [row for row in (krypto.get("positionen") or [])
              if bool(row.get("ownership_verified"))
              and str(row.get("verwaltung") or "").upper() in {"AUTO", "MANUELL"}
              and bool(row.get("fill_ids"))]}
    # Das Positionsbuch enthaelt bewusst nur Bot-Positionen. Das getrennte
    # Kontoobjekt zeigt deshalb Guthaben wie XRP/ETH/SOL im OKX-Demokonto,
    # ohne sie fälschlich als offene Orders auszugeben.
    return {"etoro": daten, "okx": krypto, "okx_konto": _state._okx_detail(),
            "auftraege": await run_in_threadpool(positions_auftraege.uebersicht),
            "standard_stop_pct": round(float(getattr(config, "STOP_LOSS_PCT", 0.025)) * 100, 2),
            "standard_ziel_pct": round(float(getattr(config, "TAKE_PROFIT_PCT", 0.05)) * 100, 2),
            "gueltig_minuten": positions_auftraege.AUFTRAG_GUELTIG_MINUTEN}


@app.post("/api/positions/{aktion}")
async def api_positions_auftrag(aktion: str, request: Request):
    session = _session(request); _csrf(request, session)
    import positions_auftraege
    if aktion not in positions_auftraege.AKTIONEN:
        raise HTTPException(status_code=404, detail="unbekannte Aktion")
    payload = await request.json()
    try:
        auftrag = await run_in_threadpool(
            positions_auftraege.anfordern,
            str(payload.get("symbol") or ""), aktion,
            stop_pct=payload.get("stop_pct", 0.0),
            ziel_pct=payload.get("ziel_pct", 0.0),
            record_id=str(payload.get("record_id") or ""),
            position_ids=payload.get("position_ids") or [],
            instrument_id=str(payload.get("instrument_id") or ""),
            account_fingerprint=str(payload.get("account_fingerprint") or ""),
            snapshot_id=str(payload.get("snapshot_id") or ""),
            von=f"webui:{session.get('u')}")
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return {"ok": True, "auftrag": auftrag,
            "detail": ("Auftrag hinterlegt. Der Handelskern führt ihn beim "
                       "nächsten Durchlauf am aktuellen Kurs aus — Stop und "
                       "Ziel werden dann gegen den echten Kurs geprüft.")}


@app.get("/logbook", response_class=HTMLResponse)
async def logbook_page(request: Request):
    session = _session(request, required=False)
    return _page("logbook.html", session) if session else RedirectResponse("/login", status_code=303)


@app.post("/api/logout")
async def logout(request: Request):
    session = _session(request); _csrf(request, session)
    response = JSONResponse({"ok": True})
    response.delete_cookie(auth.COOKIE, path="/")
    return response


@app.get("/api/dashboard")
async def api_dashboard(request: Request):
    _session(request)
    return await run_in_threadpool(dashboard)


@app.get("/api/settings")
async def api_settings(request: Request):
    _session(request)
    return await run_in_threadpool(settings_snapshot)


@app.post("/api/settings")
async def api_settings_save(request: Request):
    session = _session(request); _csrf(request, session)
    try:
        payload = await request.json()
        result = await run_in_threadpool(save_settings, payload)
        return {"ok": True, "settings": result,
                "detail": ("Gespeichert. News-Quellen, API-Schluessel und Budgets wirken SOFORT -- ohne Neustart. Broker-Zugaenge, Handelsmodus und Risikogrenzen werden wie bisher beim naechsten Start des Trading-Core uebernommen.")}
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from None


@app.post("/api/telegram/runtime")
async def api_telegram_runtime(request: Request):
    session = _session(request); _csrf(request, session)
    payload = await request.json()
    try:
        result = await run_in_threadpool(
            set_telegram_runtime, bool(payload.get("enabled")))
        aktiv = bool(result.get("telegram", {}).get("enabled"))
        return {"ok": True, "settings": result,
                "detail": ("Telegram ist sofort aktiviert; Versand und Fernsteuerung laufen."
                           if aktiv else
                           "Telegram ist sofort deaktiviert; es werden keine Nachrichten gesendet und keine Befehle angenommen.")}
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from None


@app.get("/api/logs/decisions")
async def api_decisions(request: Request, page: int = 1, per_page: int = 15,
                        broker: str = "", asset_type: str = "", status: str = "",
                        source: str = "", symbol: str = "", day: str = ""):
    _session(request)
    return await run_in_threadpool(
        decision_log, page=page, per_page=per_page, broker=broker,
        asset_type=asset_type, status=status, source=source, symbol=symbol, day=day,
    )


@app.get("/api/logs/system")
async def api_system_log(request: Request, search: str = "", level: str = "", limit: int = 300):
    _session(request)
    return {"rows": await run_in_threadpool(system_log, search=search, level=level, limit=limit)}


@app.post("/api/providers/test")
async def api_provider_test(request: Request):
    session = _session(request); _csrf(request, session)
    payload = await request.json()
    source = str(payload.get("source") or "")
    from news_sources import MultiSourceNews
    return await run_in_threadpool(MultiSourceNews().active_health_test, source, "AAPL")


@app.post("/api/ai/test")
async def api_ai_test(request: Request):
    """Prueft den KI-Zugang mit einer kleinen, billigen Anfrage.

    Bis v8.1.3 gab es fuer eToro, OKX und die Nachrichtenquellen je einen
    Testknopf -- fuer die KI keinen. Ob der OpenAI-Schluessel stimmt, liess
    sich nur daran erkennen, dass irgendwann keine Antwort kam.
    """
    session = _session(request); _csrf(request, session)
    return await run_in_threadpool(_ai_test)


def _ai_test() -> dict:
    import time as _time
    from ai_status import kurzstatus  # noqa: F401  (nur zur Verfuegbarkeitspruefung)
    try:
        from ai_router import AIRouter
    except Exception as exc:
        return {"ok": False, "detail": f"KI-Router nicht ladbar: {exc}"}

    try:
        router = AIRouter(config)
    except Exception as exc:
        return {"ok": False, "detail": f"KI-Router nicht startbar: {exc}"}

    if not getattr(router, "aktiv", False):
        return {"ok": False, "detail": "KI ist ausgeschaltet oder kein Schluessel hinterlegt.",
                "status": router.status() if hasattr(router, "status") else {}}

    schema = {"type": "object", "additionalProperties": False,
              "required": ["antwort"],
              "properties": {"antwort": {"type": "string", "maxLength": 40}}}
    start = _time.monotonic()
    try:
        antwort = router.frage(
            "second_opinion", {"pruefung": "verbindungstest"}, schema,
            anweisung="Antworte ausschliesslich mit {\"antwort\": \"bereit\"}.",
            cache_erlaubt=False)
    except Exception as exc:
        return {"ok": False, "detail": f"{type(exc).__name__}: {exc}"}

    dauer = round(_time.monotonic() - start, 2)
    if not getattr(antwort, "ok", False):
        return {"ok": False, "detail": str(getattr(antwort, "grund", "keine Antwort")),
                "dauer_s": dauer}
    return {
        "ok": True,
        "detail": f"Antwort in {dauer} s",
        "modell": str(getattr(antwort, "modell", "")),
        "kosten_usd": round(float(getattr(antwort, "kosten_usd", 0.0) or 0.0), 6),
        "dauer_s": dauer,
        "status": router.status() if hasattr(router, "status") else {},
    }


@app.post("/api/brokers/test")
async def api_broker_test(request: Request):
    session = _session(request); _csrf(request, session)
    payload = await request.json()
    from broker_diagnostics import test_connection
    try:
        return await run_in_threadpool(
            test_connection, str(payload.get("broker") or ""), str(payload.get("mode") or ""),
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from None


@app.post("/api/brokers/mode")
async def api_broker_mode(request: Request):
    session = _session(request); _csrf(request, session)
    payload = await request.json()
    try:
        result = await run_in_threadpool(
            set_broker_mode, str(payload.get("broker") or ""),
            str(payload.get("mode") or ""), str(payload.get("confirm") or ""),
        )
        return {"ok": True, "settings": result,
                "detail": "Modus gespeichert und LIVE-Arming entfernt. Trading-Core neu starten."}
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from None


@app.post("/api/risk-profile")
async def api_risk_profile(request: Request):
    session = _session(request); _csrf(request, session)
    payload = await request.json()
    try:
        result = await run_in_threadpool(
            set_risk_profile, str(payload.get("profile") or ""),
            str(payload.get("confirm") or ""),
        )
        return {"ok": True, "settings": result,
                "detail": "Risikoprofil gespeichert. Es gilt nach Neustart sicher fuer beide Domaenen."}
    except (ValueError, KeyError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from None


@app.post("/api/crypto-strategy")
async def api_crypto_strategy(request: Request):
    session = _session(request); _csrf(request, session)
    payload = await request.json()
    try:
        result = await run_in_threadpool(
            set_crypto_strategy_mode, str(payload.get("mode") or ""),
            source=f"webui:{session.get('u')}",
            confirm=str(payload.get("confirm") or ""),
            reason=str(payload.get("reason") or "WebUI-Laufzeitwechsel"),
        )
        return {"ok": True, "settings": result,
                "detail": ("OKX-Strategiemodus sofort gespeichert. Der Wechsel gilt nur "
                           "fuer neue Einstiege; offene Positionen behalten ihre "
                           "gespeicherte Einstiegsstrategie. Kein Neustart erforderlich.")}
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from None


@app.post("/api/migration")
async def api_migration(request: Request):
    session = _session(request); _csrf(request, session)
    payload = await request.json()
    if str(payload.get("confirm") or "") != "UEBERNEHMEN":
        raise HTTPException(status_code=400, detail="Bestaetigung 'UEBERNEHMEN' erforderlich")
    if await run_in_threadpool(core_online):
        raise HTTPException(status_code=409, detail="Trading-Core zuerst stoppen; WebUI darf weiterlaufen.")
    from settings_migration import bericht, migrate_from
    source = Path(str(payload.get("source") or "")).resolve()
    allowed = {Path(x).resolve() for x in bericht(ROOT).get("gefundene_vorgaengerversionen", [])}
    if source not in allowed:
        raise HTTPException(status_code=400, detail="Quelle ist keine erkannte Vorgaengerversion.")
    copied, skipped = await run_in_threadpool(migrate_from, source, ROOT, False)
    return {"ok": True, "copied": copied, "skipped": skipped,
            "detail": ("Uebernahme abgeschlossen. Beide Broker wurden sicher auf Demo/Paper "
                       "gesetzt und alle LIVE-Freigaben entfernt.")}


@app.post("/api/control/{action}")
async def api_control(action: str, request: Request):
    session = _session(request); _csrf(request, session)
    payload = await request.json()
    mapping = {
        "pause": ("pausiert", "PAUSIEREN"),
        "resume": ("aktiv", "AKTIVIEREN"),
        "stop": ("gestoppt", "VOLLSTAENDIG STOPPEN"),
    }
    if action not in mapping:
        raise HTTPException(status_code=404, detail="unbekannte Aktion")
    state, phrase = mapping[action]
    if str(payload.get("confirm") or "") != phrase:
        raise HTTPException(status_code=400, detail=f"Bestaetigung '{phrase}' erforderlich")
    from bot_zustand import BotZustand
    bot = BotZustand(str(ROOT / "bot_zustand.json"))
    previous = bot.setze(state, str(payload.get("reason") or "WebUI"), f"webui:{session.get('u')}")
    return {"ok": True, "previous": previous, "state": state}
