"""v9.1 -- drei Varianten derselben Frage: was gilt, wenn es mittendrin aufhoert?

B1  Der Broker storniert beim Verkauf ZUERST die Schutzorder. Stirbt der
    Prozess danach, war die Position bis 9.0.15 dauerhaft ungeschuetzt: das
    Buch stand weiter auf broker_schutz=True, und der einzige periodische
    Abgleich lief hinter "if not position.broker_schutz". Er griff nie wieder.

B2  Der Fill-Nachweis wurde nur geholt, wenn WENIGER im Konto lag als im Buch.
    Lag Fremdbestand desselben Coins im Konto, galt weiter die veraltete
    Buchmenge -- und der naechste Stop verkaufte sie ein zweites Mal, aus dem
    Bestand des Nutzers.

B3  "0 gefuellt" galt als bewiesener Fehlschlag. Das vom Broker berechnete
    Feld ``terminal`` wurde nie gelesen, also landete auch eine Order mit
    offenem Ausgang im 5-Minuten-Retry statt in der 24-Stunden-Sperre.
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
os.environ.setdefault("TRADINGBOT_TEST_STATE_DIR", "/tmp/tradingbot_tests")
Path(os.environ["TRADINGBOT_TEST_STATE_DIR"]).mkdir(parents=True, exist_ok=True)

WURZEL = Path(__file__).resolve().parent.parent


# ===========================================================================
# B1 -- das Schutzfenster
# ===========================================================================
def test_schutzverlust_wird_vor_dem_brokeraufruf_persistiert():
    """Der Vermerk muss auf der Platte stehen, BEVOR storniert wird.

    Sonst hilft er bei genau dem Fall nicht, fuer den er da ist: dem
    Prozessabbruch zwischen Storno und Verkauf.
    """
    quelle = (WURZEL / "crypto_engine.py").read_text(encoding="utf-8")
    start = quelle.index("def _schliesse")
    block = quelle[start:quelle.index("broker.schliesse_position", start)]
    assert 'position.broker_schutz = False' in block, \
        "Der Schutz gilt ab dem Brokeraufruf als verloren"
    assert 'position.protection_status = "LOST"' in block
    # Und der Vermerk muss auch gespeichert werden, nicht nur im RAM stehen.
    assert "self.buch.setze(position)" in block


def test_unterbrochener_verkauf_loest_einen_schutzabgleich_aus():
    """exit_state hatte bis 9.0.15 keinen einzigen auswertenden Leser."""
    quelle = (WURZEL / "crypto_engine.py").read_text(encoding="utf-8")
    start = quelle.index("def pruefe_positionen")
    block = quelle[start:start + 16000]
    assert "exit_unterbrochen" in block, \
        "Ein abgebrochener Ausstieg muss den Schutzabgleich erzwingen"
    assert '"SUBMITTING"' in block and '"MANUAL_EXIT_PENDING"' in block
    assert "if not position.broker_schutz or exit_unterbrochen:" in block


def test_geheilte_position_meldet_sich_und_laeuft_weiter():
    quelle = (WURZEL / "crypto_engine.py").read_text(encoding="utf-8")
    start = quelle.index("def pruefe_positionen")
    block = quelle[start:start + 16000]
    assert 'position.exit_state = "IDLE"' in block, \
        "Nach erfolgreichem Abgleich darf der Zustand nicht haengen bleiben"
    assert "unterbrochener Verkauf erkannt" in block, \
        "Georg muss von einem geheilten Abbruch erfahren"


def test_exit_state_hat_jetzt_einen_auswertenden_leser():
    """Der Kern des Befunds: das Feld wurde geschrieben und nie gelesen."""
    quelle = (WURZEL / "crypto_engine.py").read_text(encoding="utf-8")
    # Ein reiner Schreibzugriff ("exit_state =") zaehlt nicht.
    lesend = [z for z in quelle.splitlines()
              if "exit_state" in z and "exit_state =" not in z
              and "exit_state:" not in z]
    assert lesend, "exit_state muss den Handel beeinflussen, nicht nur die Anzeige"


# ===========================================================================
# B2 -- Fremdbestand
# ===========================================================================
def test_ueberhang_holt_den_fill_nachweis():
    """Der Zweig "mehr im Konto als im Buch" war der blinde Fleck."""
    quelle = (WURZEL / "crypto_engine.py").read_text(encoding="utf-8")
    start = quelle.index("MEHR im Konto als im Buch")
    block = quelle[start:start + 1600]
    assert "_externer_verkaufsbeweis(position, position.menge)" in block, \
        "Ohne Nachweis wird eine bereits verkaufte Menge ein zweites Mal verkauft"
    assert "_position_extern_geschlossen(" in block
    assert "continue" in block


def test_beide_abweichungsrichtungen_pruefen_den_broker():
    """Weniger UND mehr im Konto muessen beide gegen echte Fills laufen."""
    quelle = (WURZEL / "crypto_engine.py").read_text(encoding="utf-8")
    start = quelle.index("abweichung > MENGEN_TOLERANZ")
    block = quelle[start:start + 2600]
    assert block.count("_externer_verkaufsbeweis(") >= 2, \
        f"Nur {block.count('_externer_verkaufsbeweis(')} Nachweis(e) -- beide Richtungen noetig"


# ===========================================================================
# B3 -- unklar ist nicht dasselbe wie fehlgeschlagen
# ===========================================================================
def test_offener_ausgang_kommt_in_die_lange_sperre():
    quelle = (WURZEL / "crypto_engine.py").read_text(encoding="utf-8")
    stelle = quelle.index('protokoll.abschliessen("NICHT_AUSGEFUEHRT"')
    block = quelle[stelle:stelle + 1800]
    assert 'getattr(ergebnis, "terminal", True)' in block
    assert 'exit_state = "UNCLEAR"' in block
    assert "hours=24" in block
    assert 'return "UNCLEAR"' in block


def test_bewiesener_fehlschlag_behaelt_den_kurzen_retry():
    """Die Gegenprobe -- sonst waere jede abgelehnte Order 24 Stunden gesperrt."""
    quelle = (WURZEL / "crypto_engine.py").read_text(encoding="utf-8")
    stelle = quelle.index('protokoll.abschliessen("NICHT_AUSGEFUEHRT"')
    block = quelle[stelle:stelle + 1800]
    assert "self._exit_fehlversuch(" in block
    assert 'return "FAILED"' in block


def test_broker_liefert_das_terminal_feld():
    """Ohne dieses Feld waere die Unterscheidung nicht zu treffen."""
    from broker.base import OrderErgebnis
    assert "terminal" in OrderErgebnis.__dataclass_fields__, \
        "Der Ausstiegspfad braucht die Beweislage des Brokers"
