"""v9.1 -- die Freqtrade-Treue.

Die Rechenseite war schon in 9.0.15 bit-genau (RSI14, TEMA9, BB-Mitte gegen
unabhaengige Referenzen auf 0.000e+00). Die Abweichungen lagen im
ZEITVERHALTEN und in einer unnoetigen Kopplung:

F1  ``exit_decision`` rief als erste Zeile ``evaluate(raw)``. Bei duenner
    Kerzenhistorie warf das, der Aufrufer fing ab -- und eine Position mit
    +4,79 % Gewinn blieb liegen, obwohl ihre ROI-Stufe erreicht war. Echtes
    Freqtrade rechnet ROI und Stoploss ohne Dataframe.
F2  Der Takt lief frei mit 300 s statt am 5-Minuten-Kerzenraster.
F3  Der Backtest prueft jetzt Stop vor Signal -- wie Freqtrade.
F4  startup_candle_count 30 statt 200, wie im Original.
F5  Reihenfolge stoploss -> ROI -> Signal, damit der Ausstiegsgrund stimmt.
F6  Die ROI-Uhr haengt am Einstiegsfill, nicht an der Verbuchung.
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
os.environ.setdefault("TRADINGBOT_TEST_STATE_DIR", "/tmp/tradingbot_tests")
Path(os.environ["TRADINGBOT_TEST_STATE_DIR"]).mkdir(parents=True, exist_ok=True)

WURZEL = Path(__file__).resolve().parent.parent


def kerzen(n):
    idx = pd.date_range("2026-08-01", periods=n, freq="5min", tz="UTC")
    p = np.linspace(100, 110, n)
    return pd.DataFrame({"open": p, "high": p * 1.001, "low": p * 0.999,
                         "close": p, "volume": np.full(n, 1000.0)}, index=idx)


# ===========================================================================
# F1 -- ROI und Stoploss brauchen keine Kerzen
# ===========================================================================
def test_roi_greift_auch_ohne_ausreichende_kerzen():
    """Der konkrete Fall: 65 Minuten alt, +4,79 % netto, ROI-Stufe 1 %."""
    import freqtrade_sample_strategy as sample

    schliessen, grund, audit = sample.exit_decision(
        kerzen(5), entry_price=100.0, current_price=105.0,
        elapsed_minutes=65, entry_fee_pct=0.001, exit_fee_pct=0.001)

    assert schliessen is True, "ROI muss ohne Dataframe entscheiden koennen"
    assert grund == "freqtrade_roi_1pct"
    assert audit["exit_stage"] == "roi"


def test_stoploss_greift_auch_ohne_kerzen():
    import freqtrade_sample_strategy as sample

    schliessen, grund, audit = sample.exit_decision(
        pd.DataFrame(), entry_price=100.0, current_price=89.0, elapsed_minutes=5)
    assert schliessen and grund == "freqtrade_stop_loss"
    assert audit["exit_stage"] == "stoploss"
    assert audit["stoploss_price"] == pytest.approx(90.0)


def test_fehlende_kerzen_kosten_nur_das_exit_signal():
    """Ohne Kerzen kein Signal -- aber auch kein Absturz und kein Fehlurteil."""
    import freqtrade_sample_strategy as sample

    schliessen, grund, audit = sample.exit_decision(
        kerzen(5), entry_price=100.0, current_price=100.5, elapsed_minutes=5)
    assert schliessen is False and grund == ""
    assert audit["exit_stage"] == "signal_unavailable"
    assert "signal_error" in audit


# ===========================================================================
# F5 -- die Reihenfolge bestimmt den protokollierten Grund
# ===========================================================================
def test_roi_gewinnt_gegen_das_exit_signal(monkeypatch):
    """Freqtrade prueft ROI VOR dem Signal. Der Grund landet im Ledger."""
    import freqtrade_sample_strategy as sample

    class Auswertung:
        exit = True
        def audit_values(self):
            return {"exit": True}

    monkeypatch.setattr(sample, "evaluate", lambda _raw: Auswertung())
    schliessen, grund, _ = sample.exit_decision(
        kerzen(60), entry_price=100.0, current_price=103.0, elapsed_minutes=35)
    assert schliessen and grund == "freqtrade_roi_2pct", \
        "Ein ROI-Ausstieg darf nicht als Signal-Ausstieg gezaehlt werden"


def test_signal_entscheidet_wenn_roi_nicht_erreicht_ist(monkeypatch):
    """Die Gegenprobe -- use_exit_signal bleibt wirksam, auch im Minus."""
    import freqtrade_sample_strategy as sample

    class Auswertung:
        exit = True
        def audit_values(self):
            return {"exit": True}

    monkeypatch.setattr(sample, "evaluate", lambda _raw: Auswertung())
    schliessen, grund, _ = sample.exit_decision(
        kerzen(60), entry_price=100.0, current_price=99.5, elapsed_minutes=35)
    assert schliessen and grund == "freqtrade_exit_signal"


def test_stoploss_gewinnt_gegen_beide(monkeypatch):
    import freqtrade_sample_strategy as sample

    class Auswertung:
        exit = True
        def audit_values(self):
            return {"exit": True}

    monkeypatch.setattr(sample, "evaluate", lambda _raw: Auswertung())
    _, grund, _ = sample.exit_decision(
        kerzen(60), entry_price=100.0, current_price=85.0, elapsed_minutes=90)
    assert grund == "freqtrade_stop_loss"


# ===========================================================================
# F4 -- startup_candle_count wie im Original
# ===========================================================================
def test_startup_entspricht_der_offiziellen_samplestrategy():
    import freqtrade_sample_strategy as sample
    assert sample.STARTUP_CANDLES == 30


def test_engine_nimmt_die_zahl_aus_der_strategie():
    """Keine zweite, fest eingetippte Kopie derselben Zahl."""
    quelle = (WURZEL / "crypto_engine.py").read_text(encoding="utf-8")
    assert "minimum_candles = 200" not in quelle
    assert "from freqtrade_sample_strategy import STARTUP_CANDLES" in quelle


# ===========================================================================
# F3 -- der Backtest misst die Freqtrade-Reihenfolge
# ===========================================================================
def test_backtest_prueft_stop_vor_dem_signal():
    """Sonst rettet ein Signal Trades, die ausgestoppt worden waeren."""
    quelle = (WURZEL / "freqtrade_sample_backtest.py").read_text(encoding="utf-8")
    stop_intrabar = quelle.index('reason = "stop_loss"')
    roi = quelle.index('reason = f"roi_')
    signal = quelle.index('reason = "exit_signal"')
    assert stop_intrabar < roi < signal, (
        "Reihenfolge muss stoploss -> ROI -> Exit-Signal sein")


# ===========================================================================
# F2 -- der Takt rastet am Kerzenraster ein
# ===========================================================================
def test_taktgeber_kann_einrasten():
    import time
    from scheduler_v7 import SCAN, Taktgeber

    takt = Taktgeber()
    takt.markiere("crypto", SCAN, jetzt=1000.0, raster_sekunden=300.0)
    with takt._lock:
        vermerkt = takt._letzter_lauf[("crypto", SCAN)]
    versatz = time.time() % 300.0
    assert vermerkt == pytest.approx(1000.0 - versatz, abs=1.0), \
        "Der Vermerk muss auf den zuletzt passierten Rasterpunkt zeigen"


def test_ohne_raster_bleibt_der_takt_unveraendert():
    """Die anderen Modi duerfen sich nicht aendern."""
    from scheduler_v7 import SCAN, Taktgeber

    takt = Taktgeber()
    takt.markiere("crypto", SCAN, jetzt=1000.0)
    with takt._lock:
        assert takt._letzter_lauf[("crypto", SCAN)] == 1000.0


def test_nur_der_freqtrade_modus_rastet_ein(monkeypatch, tmp_path):
    monkeypatch.setenv("TRADINGBOT_TEST_STATE_DIR", str(tmp_path))
    import crypto_strategy_mode as modus
    from crypto_engine import CryptoEngine

    engine = CryptoEngine.__new__(CryptoEngine)
    modus.set_mode(modus.NEXUS_STANDARD, source="test", notify=False)
    assert engine._scan_raster_sekunden() == 0.0, \
        "Der Standardmodus behaelt seinen freien Takt"
    modus.set_mode(modus.FREQTRADE_SAMPLE, source="test", notify=False)
    assert engine._scan_raster_sekunden() == 300.0, \
        "Freqtrade entscheidet auf der 5-Minuten-Kerze"


# ===========================================================================
# F6 -- die ROI-Uhr haengt am Fill
# ===========================================================================
def test_fillzeitpunkt_wird_aus_den_fills_gelesen():
    from crypto_engine import _fillzeitpunkt

    class Ergebnis:
        fills = [{"ts": "1756000000000"}, {"ts": "1755999000000"}]

    zeit = _fillzeitpunkt(Ergebnis())
    assert zeit.startswith("2025-") or zeit.startswith("2026-")
    # Der FRUEHESTE Fill zaehlt -- die Haltedauer beginnt beim ersten Stueck.
    assert "1755999000000" not in zeit
    from datetime import datetime, timezone
    erwartet = datetime.fromtimestamp(1755999000.0, timezone.utc).isoformat()
    assert zeit == erwartet


def test_fehlende_fillzeit_faellt_sauber_zurueck():
    from crypto_engine import _fillzeitpunkt

    class Leer:
        fills = []

    assert _fillzeitpunkt(Leer()) == ""
    class Kaputt:
        fills = [{"ts": "keine zahl"}, {"ts": None}]
    assert _fillzeitpunkt(Kaputt()) == ""


def test_position_uebernimmt_den_fillzeitpunkt():
    quelle = (WURZEL / "crypto_engine.py").read_text(encoding="utf-8")
    stelle = quelle.index("position = KryptoPosition(")
    block = quelle[max(0, stelle - 900):stelle + 200]
    assert "_fillzeitpunkt(ergebnis)" in block
    assert "eroeffnet_am=eroeffnet" in block
