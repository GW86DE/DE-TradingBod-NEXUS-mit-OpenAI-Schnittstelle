"""Rein lesende OKX-Kerzendaten fuer die WebUI-Tradeanalyse."""
from __future__ import annotations

import json
import logging
import re
import threading
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path

import config
from broker.okx import OKXClient
from trade_ledger import trade_detail

ROOT = Path(__file__).resolve().parent
PAIR = re.compile(r"^[A-Z0-9]{2,20}-[A-Z0-9]{2,10}$")
_CACHE: dict[int, tuple[float, dict]] = {}
_LIVE_CACHE: dict[tuple[str, float], tuple[float, dict]] = {}
_LOCK = threading.RLock()
logger = logging.getLogger(__name__)
_CLIENT_FACTORY = lambda: OKXClient(
    demo=True, base_url=str(getattr(config, "OKX_BASE_URL", "https://eea.okx.com")),
    timeout=min(3.0, float(getattr(config, "OKX_TIMEOUT_SECONDS", 15.0))),
)


def _utc(value) -> datetime:
    dt = datetime.fromisoformat(str(value or "").replace("Z", "+00:00"))
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


def _timeframe(seconds: float) -> tuple[str, int]:
    """Kleinste Kerze, mit der der Trade in hoechstens 100 Punkten sichtbar ist."""
    for bar, size in (("5m", 300), ("15m", 900), ("1H", 3600),
                      ("4H", 14_400), ("1Dutc", 86_400)):
        if seconds <= size * 92:
            return bar, size
    return "1Dutc", 86_400


def _position_lines(symbol: str, instrument: str = "") -> dict:
    try:
        path = ROOT / "crypto_positions.json"
        data = json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}
        rows = list(data.get("positionen") or [])
        for row in rows:
            if (instrument and
                    str(row.get("inst_id") or "").upper() == instrument.upper()):
                return dict(row)
        for row in rows:
            if str(row.get("symbol") or "").upper() == symbol:
                return dict(row)
    except Exception:
        logger.debug("Schutzlinien fuer die Trade-Grafik nicht lesbar", exc_info=True)
    return {"stop": None, "take_profit": None}


def _instrument(trade: dict) -> str:
    broker_pair = str(trade.get("broker_position_id") or "").strip().upper()
    if PAIR.fullmatch(broker_pair):
        return broker_pair
    symbol = str(trade.get("symbol") or "").upper()
    quote = str(trade.get("waehrung") or getattr(config, "OKX_QUOTE_CCY", "EUR")).upper()
    pair = f"{symbol}-{quote}"
    if not PAIR.fullmatch(pair):
        raise ValueError("Ungültige oder nicht unterstützte OKX-Instrumentkennung")
    return pair


def _sell_vwap(book: dict, quantity: float) -> float:
    remaining = float(quantity or 0.0)
    if remaining <= 0:
        return 0.0
    value = 0.0
    for price, available in book.get("bids") or []:
        take = min(remaining, max(0.0, float(available or 0.0)))
        value += take * float(price or 0.0)
        remaining -= take
        if remaining <= max(1e-12, quantity * 1e-9):
            return value / float(quantity)
    return 0.0


def _gemessener_taker_satz(_client=None) -> float:
    """Der bei OKX gemessene Taker-Satz, mit der config als Rueckfall.

    Die Oberflaeche hat bewusst keine Brokerverbindung. Der Handelskern misst
    den Satz und schreibt ihn in ``runtime_status_okx.json`` -- dieselbe
    Quelle, aus der das Dashboard ihn schon anzeigt. Vorher rechnete diese
    Seite mit der Annahme aus der config, waehrend der Bot mit dem gemessenen
    Satz verkaufte: die ROI-Linie lag ueber dem echten Verkaufskurs, und
    dieselbe Gebuehr stand in derselben Oberflaeche mit zwei Zahlen.
    """
    try:
        import okx_status
        satz = okx_status.gemessener_taker_satz()
        if satz and satz > 0:
            return float(satz)
    except Exception:
        logger.debug("Gemessener Gebuehrensatz nicht verfuegbar", exc_info=True)
    return float(getattr(config, "OKX_TAKER_FEE_PCT", 0.0035))


def _live_quote(client: OKXClient, instrument: str, quantity: float,
                tickers: dict) -> dict:
    key = (instrument, round(float(quantity or 0.0), 12))
    now = time.monotonic()
    with _LOCK:
        cached = _LIVE_CACHE.get(key)
        if cached and now - cached[0] <= 15.0:
            return dict(cached[1])
    result = {"current_price": None, "current_source": "",
              "current_executable": False, "current_at": ""}
    try:
        book = client.orderbook(instrument, depth=max(
            20, min(400, int(getattr(config, "OKX_EXECUTION_BOOK_DEPTH", 100)))))
        price = _sell_vwap(book, quantity)
        ts_ms = int(book.get("timestamp_ms") or 0)
        age = (time.time() * 1000.0 - ts_ms) / 1000.0 if ts_ms else float("inf")
        if price > 0 and -5.0 <= age <= max(
                0.5, float(getattr(config, "OKX_ORDERBOOK_MAX_AGE_SECONDS", 3.0))):
            result = {
                "current_price": price,
                "current_source": "OKX Orderbuch · Verkauf-VWAP volle Menge",
                "current_executable": True,
                "current_at": (datetime.fromtimestamp(
                    ts_ms / 1000.0, timezone.utc).isoformat() if ts_ms else ""),
            }
    except Exception:
        logger.debug("Orderbuchkurs fuer %s nicht verfuegbar", instrument, exc_info=True)
    if result["current_price"] is None:
        ticker = tickers.get(instrument)
        bid = float(getattr(ticker, "bid", 0.0) or 0.0) if ticker else 0.0
        ticker_ts = int(getattr(ticker, "timestamp_ms", 0) or 0) if ticker else 0
        ticker_age = ((time.time() * 1000.0 - ticker_ts) / 1000.0
                      if ticker_ts else float("inf"))
        if bid > 0 and -5.0 <= ticker_age <= 30.0:
            result = {
                "current_price": bid, "current_source": "OKX bester Geldkurs",
                "current_executable": False,
                "current_at": (datetime.fromtimestamp(
                    ticker_ts / 1000.0,
                    timezone.utc).isoformat()
                               if ticker_ts else ""),
            }
    with _LOCK:
        _LIVE_CACHE[key] = (now, result)
        if len(_LIVE_CACHE) > 128:
            oldest = min(_LIVE_CACHE, key=lambda item: _LIVE_CACHE[item][0])
            _LIVE_CACHE.pop(oldest, None)
    return dict(result)


def live_metrics_for_trades(rows: list[dict]) -> list[dict]:
    """Ergaenzt offene OKX-Trades rein lesend um Live-, SL- und ROI-Werte."""
    output = [dict(row) for row in (rows or [])]
    okx_rows = [row for row in output
                if str(row.get("broker") or "").lower() == "okx"
                and not row.get("ausgestiegen_am")
                # Ohne die beim Fill gespeicherte instId wird kein Livepaar
                # geraten. Genau dieses Raten verwechselte USD/USDC/EUR.
                and PAIR.fullmatch(str(row.get("broker_position_id") or "").upper())]
    if not okx_rows:
        return output
    try:
        client = _CLIENT_FACTORY()
        tickers = client.tickers()
    except Exception:
        logger.debug("OKX-Livekurse fuer Trades nicht abrufbar", exc_info=True)
        return output
    for row in okx_rows:
        try:
            instrument = _instrument(row)
            quantity = float(row.get("menge") or 0.0)
            position = _position_lines(
                str(row.get("symbol") or "").upper(), instrument)
            row["instrument"] = instrument
            row["market_quote_ccy"] = instrument.rsplit("-", 1)[-1]
            row["settlement_currency"] = str(
                position.get("trade_quote_ccy") or row.get("waehrung") or "").upper()
            row["stop_price"] = position.get("stop")
            row["broker_take_profit"] = position.get("take_profit")
            row.update(_live_quote(client, instrument, quantity, tickers))
            current = float(row.get("current_price") or 0.0)
            entry = float(row.get("einstieg_preis") or 0.0)
            entry_fee = float(row.get("einstieg_gebuehr") or 0.0)
            # v9.1: der GEMESSENE Satz, wie im Handelskern -- nicht die
            # Annahme aus der config. Vorher rechnete diese Seite mit 0,35 %,
            # waehrend der Bot mit dem bei OKX abgefragten Satz (typisch
            # 0,10 %) verkaufte. Die eingezeichnete ROI-Linie lag dadurch ueber
            # dem Kurs, bei dem tatsaechlich verkauft wird, und das Dashboard
            # zeigte daneben den gemessenen Satz -- zwei Zahlen fuer dieselbe
            # Sache in derselben Oberflaeche.
            fee_pct = _gemessener_taker_satz(client)
            if entry > 0 and quantity > 0:
                open_cost = entry * quantity + entry_fee
                if current > 0:
                    exit_fee = current * quantity * fee_pct
                    net = (current - entry) * quantity - entry_fee - exit_fee
                    row["open_net_pnl"] = round(net, 10)
                    row["open_net_pct"] = round(
                        100.0 * net / open_cost, 6) if open_cost > 0 else None
                    stop = float(row.get("stop_price") or 0.0)
                    target = float(row.get("broker_take_profit") or 0.0)
                    row["stop_distance_pct"] = (
                        round(100.0 * (stop / current - 1.0), 4) if stop > 0 else None)
                    row["broker_take_distance_pct"] = (
                        round(100.0 * (target / current - 1.0), 4)
                        if target > 0 else None)
                # v9.1: Auch eine PAUSIERTE Position bekommt kein ROI-Ziel
                # mehr angezeigt. Der Kern ruft _strategy_exit nur fuer AUTO
                # auf -- bei BEOBACHTEN wartete der Nutzer auf einen Ausstieg,
                # der nie kommt. Genau diesen Zustand setzt der Kern selbst,
                # wenn ein Strategie-Snapshot nicht reproduzierbar ist.
                if (str(row.get("entry_strategy_mode") or "") == "FREQTRADE_SAMPLE"
                        and str(position.get("verwaltung") or "AUTO").upper() == "AUTO"):
                    from freqtrade_sample_strategy import roi_exit_price, roi_threshold
                    opened = _utc(row.get("eingestiegen_am"))
                    elapsed = max(0.0, (datetime.now(timezone.utc) - opened).total_seconds() / 60.0)
                    threshold = roi_threshold(elapsed)
                    entry_fee_pct = entry_fee / (entry * quantity) if entry * quantity > 0 else 0.0
                    row["elapsed_minutes"] = round(elapsed, 2)
                    row["active_roi_pct"] = threshold * 100.0
                    row["active_roi_price"] = roi_exit_price(
                        entry, threshold, entry_fee_pct=entry_fee_pct,
                        exit_fee_pct=fee_pct)
        except Exception:
            logger.debug("Livewerte fuer Trade %s nicht berechenbar",
                         row.get("trade_id"), exc_info=True)
    return output


def chart_for_trade(trade_id: int, *, force: bool = False) -> dict:
    """Kerzen, Kauf-/Verkaufsmarker und bekannte Schutzlinien."""
    key = int(trade_id)
    now_mono = time.monotonic()
    with _LOCK:
        cached = _CACHE.get(key)
        if cached and not force and now_mono - cached[0] < 60:
            return dict(cached[1])

    trade = trade_detail(key)
    if not trade:
        return {"ok": False, "fehler": "Trade nicht gefunden"}
    if str(trade.get("broker") or "").lower() != "okx":
        return {"ok": False, "fehler": (
            "Kerzen sind auf dieser Seite derzeit für OKX-Kryptotrades verfügbar. "
            "Der eToro-Trade bleibt vollständig in der Tabelle sichtbar.")}
    try:
        entry_time = _utc(trade.get("eingestiegen_am"))
        exit_time = (_utc(trade.get("ausgestiegen_am"))
                     if trade.get("ausgestiegen_am") else datetime.now(timezone.utc))
        if exit_time < entry_time:
            raise ValueError("Ausstiegszeit liegt vor der Einstiegszeit")
        bar, bar_seconds = _timeframe((exit_time - entry_time).total_seconds())
        window_start = entry_time - timedelta(seconds=bar_seconds * 3)
        window_end = exit_time + timedelta(seconds=bar_seconds * 3)
        client = _CLIENT_FACTORY()
        frame = client.historical_candles(
            _instrument(trade), bar=bar, limit=100,
            end_ms=int(window_end.timestamp() * 1000), nur_abgeschlossen=True)
        if frame.empty:
            return {"ok": False, "fehler": "OKX liefert für diesen Zeitraum keine abgeschlossenen Kerzen"}
        frame = frame[(frame.index >= window_start) & (frame.index <= window_end)]
        if frame.empty:
            return {"ok": False, "fehler": "Der historische OKX-Ausschnitt enthält den Tradezeitraum nicht"}
        candles = [{
            "zeit": index.to_pydatetime().astimezone(timezone.utc).isoformat(),
            "open": float(row["open"]), "high": float(row["high"]),
            "low": float(row["low"]), "close": float(row["close"]),
            "volume": float(row["volume"]),
        } for index, row in frame.iterrows()]
        letzter = float(candles[-1]["close"])
        einstieg = float(trade.get("einstieg_preis") or 0)
        menge = float(trade.get("menge") or 0)
        offen = not bool(trade.get("ausgestiegen_am"))
        instrument = _instrument(trade)
        lines = _position_lines(
            str(trade.get("symbol") or "").upper(), instrument) if offen else {
            "stop": None, "take_profit": None}
        live = live_metrics_for_trades([trade])[0] if offen else {}
        result = {
            "ok": True, "trade_id": key, "symbol": trade.get("symbol"),
            "instrument": instrument, "bar": bar,
            "nur_abgeschlossene_kerzen": True, "candles": candles,
            "kauf": {"zeit": entry_time.isoformat(), "preis": trade.get("einstieg_preis")},
            "verkauf": ({"zeit": _utc(trade["ausgestiegen_am"]).isoformat(),
                          "preis": trade.get("ausstieg_preis")}
                         if trade.get("ausgestiegen_am") else None),
            "stop": lines.get("stop"), "take_profit": lines.get("take_profit"),
            "active_roi_price": live.get("active_roi_price"),
            "active_roi_pct": live.get("active_roi_pct"),
            "current_price": live.get("current_price"),
            "current_source": live.get("current_source"),
            "letzter_schluss": letzter,
            "offenes_ergebnis": (round((letzter - einstieg) * menge
                                        - float(trade.get("einstieg_gebuehr") or 0), 8)
                                  if offen and einstieg > 0 and menge > 0 else None),
            "waehrung": instrument.rsplit("-", 1)[-1],
            "settlement_currency": live.get("settlement_currency") or "",
            "entry_strategy_mode": trade.get("entry_strategy_mode") or "UNBEKANNT",
            "strategie_version": trade.get("strategie_version") or "UNBEKANNT",
            "hinweis": "Kauf und Verkauf markieren die tatsächlichen Ledger-Zeitpunkte/Fills.",
        }
    except Exception as exc:
        result = {"ok": False, "fehler": f"Kerzendaten nicht verfügbar: {type(exc).__name__}: {str(exc)[:180]}"}
    with _LOCK:
        if len(_CACHE) >= 64:
            oldest = min(_CACHE, key=lambda item: _CACHE[item][0])
            _CACHE.pop(oldest, None)
        _CACHE[key] = (now_mono, result)
    return dict(result)


__all__ = ["chart_for_trade", "live_metrics_for_trades"]
